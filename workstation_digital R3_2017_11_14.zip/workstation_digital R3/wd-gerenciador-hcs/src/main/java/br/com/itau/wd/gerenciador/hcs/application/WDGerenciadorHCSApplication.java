package br.com.itau.wd.gerenciador.hcs.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@SpringBootApplication
@ComponentScan(basePackages = {"br.com.itau.wd.gerenciador.hcs.*"})
@PropertySources({
	@PropertySource(value="file:${app.properties}", ignoreResourceNotFound=false)
})
public class WDGerenciadorHCSApplication {

	public static void main(String[] args) {
		SpringApplication.run(WDGerenciadorHCSApplication.class, args);
	}
}