package br.com.itau;

import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_CLIENT_ID;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_DATASOURCE;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_DRIVER_CLASS;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_PASSWORD;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_TOKEN;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_URL;
import static br.com.itau.util.Constants.PROPERTY_NAME_HIBERNATE_CONNECTION_USERNAME;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import org.hibernate.HibernateException;
import org.hibernate.service.jdbc.connections.spi.ConnectionProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.itau.sc.conexao.ConexaoBD;

public class SCConexaoDSHibernateProvider implements ConnectionProvider {
	 
	private static final long serialVersionUID = 1L;

	private static final Logger logger = LoggerFactory.getLogger(SCConexaoDSHibernateProvider.class);

	private String dataSourceName;
	private String user;
	private String password;
	private String token1;
	private String clientId;
	private String driver;
	private String url;
	private boolean usePool;
	private transient ConexaoBD conexaoBD = null;	

	public void configure(Properties props) {
		
		logger.info("configure");
		
		dataSourceName = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_DATASOURCE);

		logger.info("dataSourceName = " + dataSourceName);
		
		if (dataSourceName == null) {
			String msg = "datasource JNDI name was not specified by property hibernate.connection.datasource";
			throw new HibernateException(msg);
	    }

		user = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_USERNAME);
	    password = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_PASSWORD);
	    token1 = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_TOKEN);
	    clientId = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_CLIENT_ID);
	    driver = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_DRIVER_CLASS);
	    url = props.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_URL);
	    usePool = (url == null) || "".equals(url);
	}

	@SuppressWarnings("rawtypes")
	public boolean isUnwrappableAs(Class unwrapType) {
		return false;
	}

	public <T> T unwrap(Class<T> unwrapType) {
		return null;
	}

	public Connection getConnection() throws SQLException {

		try {

			if (conexaoBD == null) {
			
				PropertiesRetriever p = new PropertiesRetriever();
				
				dataSourceName = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_DATASOURCE);
				user = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_USERNAME);
			    password = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_PASSWORD);
			    token1 = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_TOKEN);
			    clientId = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_CLIENT_ID);
			    driver = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_DRIVER_CLASS);
			    url = p.getProperty(PROPERTY_NAME_HIBERNATE_CONNECTION_URL);
			    usePool = (url == null) || "".equals(url);

				logger.info("user = " + user);
			    logger.info("password = " + password);
			    logger.info("token = " + token1);
			    logger.info("clientId = " + clientId);
			    logger.info("driver = " + driver);
			    logger.info("url = " + url);
			    logger.info("usePool = " + usePool);

				conexaoBD = new ConexaoBD(dataSourceName, driver, url, user, password, token1, usePool);
			    conexaoBD.setClientIdentifier(clientId);
			    
				 if(!conexaoBD.getConnection().isClosed()){
					 logger.info("Conex�o aberta...");
				 }else{
					 logger.info("Conex�o fechada...");
				 }
			}
			
			return conexaoBD.getConnection();
				
		} catch (SQLException e) {
			logger.error(e.getMessage(), e);
			throw e;
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			throw new SQLException(e.getMessage());
		}	
	}

	public void closeConnection(Connection conn) throws SQLException {
		conn.close();
	}

	public boolean supportsAggressiveRelease() {
		return false;
	}
}