package br.com.itau.wd.gerenciador.negocio.exception;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;

@ControllerAdvice
public class NegocioErrorController {

	private static final Logger logger = LoggerFactory.getLogger(NegocioErrorController.class);	
	
    @ExceptionHandler(NegocioException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleConsultaPendenciaException(HttpServletRequest req, NegocioException ex) {

    	String errorMessage = ex.getMensagem();
    	String errorURL = STRING_EMPTY.equals(ex.getUrl()) ? req.getRequestURL().toString() : ex.getUrl();
        logger.error(ex.getMensagem(), ex);

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }	
	
    @ExceptionHandler(IOException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleIOException(HttpServletRequest req, IOException ex) {

    	String errorMessage = ex.getMessage();
    	String errorURL = req.getRequestURL().toString();
        logger.error(ex.getMessage(), ex);

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }
}