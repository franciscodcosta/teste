package br.com.itau.wd.gerenciador.negocio.utils;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.SSLContext;

import org.apache.commons.lang.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonObject;
import com.ibm.www.maximo.MXBinaryType;
import com.ibm.www.maximo.MXDateTimeType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXDoubleType;
import com.ibm.www.maximo.MXLangStringType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringType;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

public class NegocioUtils {

	private NegocioUtils() {}
	
	/**
	 * Configura o TLS
	 * 
	 * @param tls
	 * @throws NegocioException 
	 */
	
	public static void configurarTls(String tls) throws NegocioException {
		
		try {
			SSLContext ctx = SSLContext.getInstance(tls);
			ctx.init(null, null, null);
			SSLContext.setDefault(ctx);
		}
		catch (NoSuchAlgorithmException | KeyManagementException ex) {
			throw new NegocioException(ex);
		}
	}
	
	/**
	 * Monta o JSON
	 * @param json
	 * @param mapDePara
	 * @return
	 * @throws IOException 
	 */
	public static String obterJsonDePara(String json, Map<String, String> mapDePara) throws IOException {
		
		Map<String, Object> mapDest = new HashMap<>();
		Map<String, Object> mapOrig = GerenciadorUtils.convertJsonToMap(json);			

		for (Entry<String, String> entry : mapDePara.entrySet()) {
			
			if (mapOrig.containsKey(entry.getKey())) {
				mapDest.put(entry.getValue(), mapOrig.get(entry.getKey()));
			}
			else {
				mapDest.put(entry.getValue(), STRING_EMPTY);
			}
		}

		return new ObjectMapper().writeValueAsString(mapDest);
	}
	
	/**
	 * Obtem o dado do JSON
	 * 
	 * @param objJson
	 * @param key
	 * @return
	 */
	public static String obterDadoJson(JsonObject objJson, String key) {
		
		return objJson.get(key) == null ? STRING_EMPTY : objJson.get(key).getAsString().trim();
	}
	
	/**
	 * Converte o objeto para String
	 * 
	 * @param dado
	 * @return
	 */
	public static String converterObjetoParaString(Object dado) {
		
		String retorno = STRING_EMPTY;

		if (dado == null) {
			retorno = STRING_EMPTY;
		}
		else if (dado instanceof MXDateTimeType) {
			retorno = formatarData(((MXDateTimeType)dado).get_value());
		}
		else if (dado instanceof MXStringType) {
			retorno = ((MXStringType)dado).get_value();
		}
		else if (dado instanceof MXDomainType) {
			retorno = ((MXDomainType)dado).get_value();
		}
		else if (dado instanceof MXLongType) {
			retorno = Long.toString(((MXLongType)dado).get_value());
		}
		else if (dado instanceof MXDoubleType) {
			retorno = Double.toString(((MXDoubleType)dado).get_value());
		}
		else if (dado instanceof MXBinaryType) {
			retorno = Arrays.toString(((MXBinaryType)dado).get_value());
		}
		else if (dado instanceof MXLangStringType) {
			retorno = ((MXLangStringType)dado).get_value();
		}

		return retorno;
	}
	
	/**
	 * Converte o valor para double
	 * 
	 * @param valor
	 * @return
	 */
	public static double converterDouble(String valor) {
		
		if (valor != null && !STRING_EMPTY.equals(valor.trim())) {
			return Double.parseDouble(valor);
		}
		else {
			return 0.0;
		}
	}
	
	/**
	 * Converte o valor para boolean
	 * 
	 * @param valor
	 * @return
	 */
	public static Boolean converterBoolean(String valor) {
		
		Boolean ret = false; 
		
		if (valor != null && ("1".equals(valor) || "true".equalsIgnoreCase(valor))) {
			return true;
		}

		return ret;
	}
	
	/**
	 * Preenche zeros a esquerda
	 * 
	 * @param dado
	 * @param tamanho
	 * @return
	 */
	public static String preencherZerosEsquerda(String dado, int tamanho) {
		
		return StringUtils.leftPad(dado, tamanho, "0");
	}
	
	/**
	 * Obtem a data formatada
	 * 
	 * @param data
	 * @return
	 */
	private static String formatarData(Calendar data) {
		
		DateFormat df = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

		return df.format(data.getTime());		
	}
}