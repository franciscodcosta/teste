package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTDATE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TARGETFINISH;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRRESUMOQueryType;
import com.ibm.www.maximo.ITAUWDSRRESUMOQueryTypeSR;
import com.ibm.www.maximo.ITAUWDSRRESUMO_SRType;
import com.ibm.www.maximo.MXDateTimeType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDSRRESUMOResponseType;
import com.ibm.www.maximo.QueryITAUWDSRRESUMOType;
import com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Resumo Solicitação Serviço
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaResumoSolicitacaoServicoService {
	
	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaResumoSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar resumo da solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarResumoSolicitacaoServico(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA RESUMO SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDSRRESUMOType objeto = obterObjeto(json);
			
			//Enviar os dados
			QueryITAUWDSRRESUMOResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA RESUMO SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDSRRESUMOType obterObjeto(String json) {
		
		// Leitura do JSON
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String TICKETID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		ITAUWDSRRESUMOQueryTypeSR QueryTypeSR = new ITAUWDSRRESUMOQueryTypeSR();
		QueryTypeSR.setTICKETID(new MXStringQueryType[]{new MXStringQueryType(TICKETID)});

		ITAUWDSRRESUMOQueryType QueryType = new ITAUWDSRRESUMOQueryType();
		QueryType.setSR(QueryTypeSR);

		QueryITAUWDSRRESUMOType objeto = new QueryITAUWDSRRESUMOType();
		objeto.setITAUWDSRRESUMOQuery(QueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDSRRESUMOResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);
		
		JsonObject objJsonDados = new JsonObject();

		if (resposta.getITAUWDSRRESUMOSet() != null && resposta.getITAUWDSRRESUMOSet().length > 0) {

			ITAUWDSRRESUMO_SRType SRType[] = resposta.getITAUWDSRRESUMOSet();

			MXStringType TICKETID = SRType[0].getTICKETID();
			MXDateTimeType REPORTDATE = SRType[0].getREPORTDATE();
			MXStringType REPORTEDBY = SRType[0].getREPORTEDBY();
			MXDateTimeType TARGETFINISH = SRType[0].getTARGETFINISH();
			MXDomainType STATUS = SRType[0].getSTATUS();

			objJsonDados.addProperty(JSON_KEY_MAXIMO_TICKETID, NegocioUtils.converterObjetoParaString(TICKETID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTDATE, NegocioUtils.converterObjetoParaString(REPORTDATE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDBY, NegocioUtils.converterObjetoParaString(REPORTEDBY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_TARGETFINISH, NegocioUtils.converterObjetoParaString(TARGETFINISH));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_STATUS, NegocioUtils.converterObjetoParaString(STATUS));
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Enviar os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDSRRESUMOResponseType enviarDados(QueryITAUWDSRRESUMOType objeto, String endpoint) throws RemoteException { 
	
		//Configura o Proxy
		ITAUWDSRRESUMOPortTypeProxy proxy = new ITAUWDSRRESUMOPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDSRRESUMOSOAP11BindingStub)proxy.getITAUWDSRRESUMOPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRRESUMOSOAP11BindingStub)proxy.getITAUWDSRRESUMOPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDSRRESUMO(objeto);
	}	
}