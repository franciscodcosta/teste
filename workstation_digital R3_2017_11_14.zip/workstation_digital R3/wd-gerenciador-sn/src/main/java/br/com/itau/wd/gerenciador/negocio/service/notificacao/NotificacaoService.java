package br.com.itau.wd.gerenciador.negocio.service.notificacao;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_SIGLA_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_BPM;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_RAINBOW;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SAP;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SP2;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * Enviar dados de notificação de uma dada pendência para atuação de um usuário no salesforce
 * 
 * @author Itaú
 *
 */
@Service
public class NotificacaoService {

	@Resource
	private Environment env;
	
	/**
	 * Monta o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException 
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			String siglaSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_SIGLA_SISTEMA_PRODUTO);

			Map<String, String> mapDePara = new HashMap<>();

			switch (siglaSistemaProduto.toUpperCase()) {

				case SIGLA_SISTEMA_SAP:
				case SIGLA_SISTEMA_BPM:

					criarMapaRequisicaoSap(mapDePara);
					break;

				case SIGLA_SISTEMA_SP2:

					criarMapaRequisicaoPeople(mapDePara);
					break;
					
				case SIGLA_SISTEMA_RAINBOW:
					
					criarMapaRequisicaoRainbow(mapDePara);
					break;
					
				default:
			}
			
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara);
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			String siglaSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_SIGLA_SISTEMA_PRODUTO);			

			Map<String, String> mapDePara = new HashMap<>();

			switch (siglaSistemaProduto.toUpperCase()) {
			
				case SIGLA_SISTEMA_SAP:
				case SIGLA_SISTEMA_BPM:	
				case SIGLA_SISTEMA_RAINBOW:	

					criarMapRespostaSap(mapDePara);
					break;

				case SIGLA_SISTEMA_SP2:
					
					criarMapaRespostaPeople(mapDePara);
					break;

				default:	
			}
			
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Cria o mapa de requisição do SAP
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRequisicaoSap(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_UID, JSON_KEY_UID);
		mapDePara.put(JSON_KEY_SIGLA_SISTEMA_PRODUTO, JSON_KEY_SIGLA_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
	}

	/**
	 * Cria o mapa de requisição do Rainbow
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRequisicaoRainbow(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
		mapDePara.put(JSON_KEY_SIGLA_SISTEMA_PRODUTO, JSON_KEY_SIGLA_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
	}
	
	/**
	 * Cria o mapa de resposta do SAP
	 * 
	 * @param mapDePara
	 */
	private void criarMapRespostaSap(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_UID, JSON_KEY_UID);
		mapDePara.put(JSON_KEY_STATUS, JSON_KEY_STATUS);
	}
	
	/**
	 * Cria o mapa de requisição do People
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRequisicaoPeople(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
		mapDePara.put(JSON_KEY_SIGLA_SISTEMA_PRODUTO, JSON_KEY_SIGLA_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
	}
	
	/**
	 * Cria o mapa de resposta do People
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRespostaPeople(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
		mapDePara.put(JSON_KEY_STATUS, JSON_KEY_STATUS);
	}
}