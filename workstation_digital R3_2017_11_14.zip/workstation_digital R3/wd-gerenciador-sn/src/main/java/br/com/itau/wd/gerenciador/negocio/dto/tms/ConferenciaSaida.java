package br.com.itau.wd.gerenciador.negocio.dto.tms;

import java.util.ArrayList;
import java.util.List;

public class ConferenciaSaida {

	private String link;
	private int pin;
	private String senha;
	private String status;
	private String mensagem;
	private List<Sala> salas;
	
	public ConferenciaSaida() {
		salas = new ArrayList<>();
	}
	
	public String getLink() {
		return link;
	}
	
	public void setLink(String link) {
		this.link = link;
	}
	
	public int getPin() {
		return pin;
	}
	
	public void setPin(int pin) {
		this.pin = pin;
	}
	
	public String getSenha() {
		return senha;
	}
	
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getMensagem() {
		return mensagem;
	}
	
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public List<Sala> getSalas() {
		return salas;
	}

	public void setSalas(List<Sala> salas) {
		this.salas = salas;
	}
}