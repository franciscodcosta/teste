package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ACESSO_EXTERNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ANDAR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_CAPACIDADE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DATA_REUNIAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_FIM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_INICIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_LISTA_ESPERA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_LISTA_POLOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_NUMERO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_POLO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_RECORRENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_REUNIAO_RECORRENTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_TORRE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.dto.tms.Polo;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaEntrada;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaSaida;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapStub;
import net.tandberg._2004._02.tms.external.booking.ConferenceStatus;

@Service
public class TMSCancelaTeleconferenciaService {

	private static final Logger logger = LoggerFactory.getLogger(TMSCancelaTeleconferenciaService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Cancela Teleconferência
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String cancelarTeleconferencia(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - CANCELA TELECONFERENCIA *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Obtem o objeto
			TeleconferenciaEntrada teleconferenciaEntrada = obterObjeto(json);
			
			//Envia os dados
			TeleconferenciaSaida teleconferenciaSaida = enviarDados(teleconferenciaEntrada, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(teleconferenciaSaida, json);
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obter o objeto 
	 * 
	 * @param json
	 */
	private TeleconferenciaEntrada obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String dataReuniao = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_DATA_REUNIAO);
		String reuniaoRecorrente = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_REUNIAO_RECORRENTE);
		String recorrencia = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_RECORRENCIA);
		String horaInicio = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_INICIO);
		String horaFim = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_FIM);
		String acessoExterno = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_ACESSO_EXTERNO);

		TeleconferenciaEntrada teleconferencia = new TeleconferenciaEntrada();

		teleconferencia.setDataReuniao(dataReuniao);
		teleconferencia.setReuniaoRecorrente(reuniaoRecorrente);
		teleconferencia.setRecorrencia(recorrencia);
		teleconferencia.setHoraInicio(horaInicio);
		teleconferencia.setHoraFim(horaFim);
		teleconferencia.setAcessoExterno(acessoExterno);
		
		JsonArray objJsonArrayPolos = (JsonArray) objJson.get(JSON_KEY_TMS_LISTA_POLOS);

		for (int i = 0; i < objJsonArrayPolos.size(); i++) {

			JsonObject objJsonPolo = (JsonObject)objJsonArrayPolos.get(i);
			
			String polo = objJsonPolo.get(JSON_KEY_TMS_POLO).getAsString();
			String listaEspera = objJsonPolo.get(JSON_KEY_TMS_LISTA_ESPERA).getAsString();
			
			Polo poloDto = new Polo();
			
			poloDto.setPolo(polo);
			poloDto.setListaEspera(listaEspera);

			teleconferencia.getPolos().add(poloDto);
		}
		
		return teleconferencia;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(TeleconferenciaSaida resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, STRING_EMPTY);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		JsonArray objJsonArrayPolos = new JsonArray();

		for (Polo polo : resposta.getLista()) {

			JsonObject objJsonPolo = new JsonObject();

			objJsonPolo.addProperty(JSON_KEY_TMS_POLO, polo.getPolo());
			objJsonPolo.addProperty(JSON_KEY_TMS_TORRE, polo.getTorre());
			objJsonPolo.addProperty(JSON_KEY_TMS_ANDAR, polo.getAndar());
			objJsonPolo.addProperty(JSON_KEY_TMS_NUMERO, polo.getNumero());
			objJsonPolo.addProperty(JSON_KEY_TMS_CAPACIDADE, polo.getCapacidade());
			
			objJsonArrayPolos.add(objJsonPolo);
		}

		objJsonDados.add(JSON_KEY_TMS_LISTA_POLOS, objJsonArrayPolos);

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private TeleconferenciaSaida enviarDados(TeleconferenciaEntrada teleconferencia, String endpoint) throws RemoteException {
		
		TeleconferenciaSaida resposta = new TeleconferenciaSaida();
		
		//Configura o Proxy
		BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();

		String userName = "";
		Calendar startTime = null;
		Calendar endTime = null;
		ConferenceStatus conferenceStatus = ConferenceStatus.All;
		
		proxy.setEndpoint(endpoint);
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));

		//Envia os dados
		proxy.getConferencesForUser(userName, startTime, endTime, conferenceStatus); 
		
		return resposta;
	}	
}