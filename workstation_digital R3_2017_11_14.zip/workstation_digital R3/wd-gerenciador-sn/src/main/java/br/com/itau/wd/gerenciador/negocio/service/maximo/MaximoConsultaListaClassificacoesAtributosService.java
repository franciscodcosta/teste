package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_ASSETATTRID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSIFICATIONID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSSTRUCTUREID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_DOMAINID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_ORGID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_SECTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICACAO_SITEID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_CLASSFICACAO_ASSETATTRIBUTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSIFICACOES;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSSPEC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_WHERE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDCLASSQueryType;
import com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType;
import com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType;
import com.ibm.www.maximo.ITAUWDCLASS_CLASSSTRUCTUREType;
import com.ibm.www.maximo.MXLangStringType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDCLASSResponseType;
import com.ibm.www.maximo.QueryITAUWDCLASSType;
import com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Lista de Classificações e Atributos
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaListaClassificacoesAtributosService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaListaClassificacoesAtributosService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar lista de classificacoes e atributos 
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarListaClassificacoesAtributos(String json, String endpoint) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA CLASSIFICACOES E ATRIBUTOS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDCLASSType objeto = obterObjeto(json);

			//Envia os dados
			QueryITAUWDCLASSResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA CLASSIFICACOES E ATRIBUTOS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDCLASSType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		
		String WHERE = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_WHERE);

		ITAUWDCLASSQueryType QueryType = new ITAUWDCLASSQueryType();
		QueryType.setWHERE(WHERE);

		QueryITAUWDCLASSType objeto = new QueryITAUWDCLASSType();
		objeto.setITAUWDCLASSQuery(QueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDCLASSResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		JsonObject objJsonDados = new JsonObject();

		if (resposta.getITAUWDCLASSSet() != null && resposta.getITAUWDCLASSSet().length > 0) {

			JsonArray objJsonArrayClassificacoes = new JsonArray();

			for (ITAUWDCLASS_CLASSSTRUCTUREType CLASSSTRUCTUREType : resposta.getITAUWDCLASSSet()) {

				JsonObject objJsonClassificacao = new JsonObject();

				MXStringType CLASSIFICATIONID = CLASSSTRUCTUREType.getCLASSIFICATIONID();
				MXStringType CLASSSTRUCTUREID = CLASSSTRUCTUREType.getCLASSSTRUCTUREID();
				MXStringType DESCRIPTION = CLASSSTRUCTUREType.getDESCRIPTION();

				objJsonClassificacao.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSIFICATIONID, NegocioUtils.converterObjetoParaString(CLASSIFICATIONID));
				objJsonClassificacao.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSSTRUCTUREID, NegocioUtils.converterObjetoParaString(CLASSSTRUCTUREID));
				objJsonClassificacao.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_DESCRIPTION, NegocioUtils.converterObjetoParaString(DESCRIPTION));

				if (CLASSSTRUCTUREType.getCLASSSPEC() != null && CLASSSTRUCTUREType.getCLASSSPEC().length > 0) {

					JsonArray objJsonArrayCLASSSPEC = new JsonArray();

					for (ITAUWDCLASS_CLASSSPECType CLASSSPECType : CLASSSTRUCTUREType.getCLASSSPEC()) {
						
						MXStringType ASSETATTRID = CLASSSPECType.getASSETATTRID();
						MXStringType DOMAINID = CLASSSPECType.getDOMAINID();
						MXStringType ORGID = CLASSSPECType.getORGID();
						MXStringType SECTION = CLASSSPECType.getSECTION();
						MXStringType SITEID = CLASSSPECType.getSITEID();

						JsonObject objJsonCLASSSPECType = new JsonObject();

						objJsonCLASSSPECType.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_ASSETATTRID, NegocioUtils.converterObjetoParaString(ASSETATTRID));
						objJsonCLASSSPECType.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_DOMAINID, NegocioUtils.converterObjetoParaString(DOMAINID));
						objJsonCLASSSPECType.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_ORGID, NegocioUtils.converterObjetoParaString(ORGID));
						objJsonCLASSSPECType.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_SECTION, NegocioUtils.converterObjetoParaString(SECTION));
						objJsonCLASSSPECType.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_SITEID, NegocioUtils.converterObjetoParaString(SITEID));

						objJsonArrayCLASSSPEC.add(objJsonCLASSSPECType);
						
						if (CLASSSPECType.getASSETATTRIBUTE() != null && CLASSSPECType.getASSETATTRIBUTE().length > 0) {
							
							JsonArray objJsonArrayASSETATTRIBUTE = new JsonArray();
							
							for (ITAUWDCLASS_ASSETATTRIBUTEType ASSETATTRIBUTEType : CLASSSPECType.getASSETATTRIBUTE()) {
								
								MXLangStringType DESCRIPTION2 = ASSETATTRIBUTEType.getDESCRIPTION();
								
								JsonObject objJsonASSETATTRIBUTE = new JsonObject();

								objJsonASSETATTRIBUTE.addProperty(JSON_KEY_MAXIMO_CLASSIFICACAO_DESCRIPTION, NegocioUtils.converterObjetoParaString(DESCRIPTION2));

								objJsonArrayASSETATTRIBUTE.add(objJsonASSETATTRIBUTE);
							}

							objJsonCLASSSPECType.add(JSON_KEY_MAXIMO_LISTA_CLASSFICACAO_ASSETATTRIBUTE, objJsonArrayASSETATTRIBUTE);
						}
						
						objJsonClassificacao.add(JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSSPEC, objJsonArrayCLASSSPEC);
					}
				}

				objJsonArrayClassificacoes.add(objJsonClassificacao);
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSIFICACOES, objJsonArrayClassificacoes);
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);
		
		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDCLASSResponseType enviarDados(QueryITAUWDCLASSType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDCLASSPortTypeProxy proxy = new ITAUWDCLASSPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDCLASSSOAP11BindingStub)proxy.getITAUWDCLASSPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDCLASSSOAP11BindingStub)proxy.getITAUWDCLASSPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDCLASS(objeto);
	}
}