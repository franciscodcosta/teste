package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_MAXIMO_EXTERNALSYSTEM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_MAXIMO_SR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_AFFECTEDPERSON;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_AFFECTEDPHONE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ALNVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ASSETATTRID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSSTRUCTUREID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCUMENTDATA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ANEXOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ATRIBUTOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_TICKETS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LOCATION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_NUMVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TABLEVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETUID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_URLTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRCombinedKeySetTypeSR;
import com.ibm.www.maximo.ITAUWDSR_DOCLINKSType;
import com.ibm.www.maximo.ITAUWDSR_SRType;
import com.ibm.www.maximo.ITAUWDSR_TICKETSPECType;
import com.ibm.www.maximo.MXBinaryType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXDoubleType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.ProcessingActionType;
import com.ibm.www.maximo.SyncITAUWDSRResponseType;
import com.ibm.www.maximo.SyncITAUWDSRType;
import com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Registrar Solicitação Serviço
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoAberturaSolicitacaoServicoService {
	
	private static final Logger logger = LoggerFactory.getLogger(MaximoAberturaSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Registrar solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String registrarSolicitacaoServico(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - REGISTRAR SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			SyncITAUWDSRType objeto = obterObjeto(json);

			//Envia os dados 
			SyncITAUWDSRResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - REGISTRAR SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private SyncITAUWDSRType obterObjeto(String json) {

		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String REPORTEDBY = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_REPORTEDBY);
		String AFFECTEDPERSON = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_AFFECTEDPERSON);
		String CLASSSTRUCTUREID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_CLASSSTRUCTUREID);
		String DESCRIPTION = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_DESCRIPTION);
		String DESCRIPTION_LONGDESCRIPTION = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION);
		String LOCATION = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_LOCATION);
		String AFFECTEDPHONE = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_AFFECTEDPHONE);

		ITAUWDSR_SRType SRType = new ITAUWDSR_SRType();

		SRType.setAction(ProcessingActionType.Add);
		SRType.setREPORTEDBY(new MXStringType(REPORTEDBY));
		SRType.setAFFECTEDPERSON(new MXStringType(AFFECTEDPERSON));
		SRType.setCLASSSTRUCTUREID(new MXStringType(CLASSSTRUCTUREID));
		SRType.setCREATEDBY(new MXStringType(STRING_EMPTY));
		SRType.setDESCRIPTION(new MXStringType(DESCRIPTION));
		SRType.setDESCRIPTION_LONGDESCRIPTION(new MXStringType(DESCRIPTION_LONGDESCRIPTION));
		SRType.setEXTERNALSYSTEM(new MXDomainType(CONSTANTE_MAXIMO_EXTERNALSYSTEM));
		SRType.setLOCATION(new MXStringType(LOCATION));
		SRType.setAFFECTEDPHONE(new MXStringType(AFFECTEDPHONE));
		
		MXDomainType CLASS = new MXDomainType();
		CLASS.set_value(CONSTANTE_MAXIMO_SR);
		CLASS.setMaxvalue(CONSTANTE_MAXIMO_SR);

		SRType.setCLASS(CLASS);

		// Anexos
		JsonArray objJsonArrayAnexos = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_ANEXOS);

		ITAUWDSR_DOCLINKSType[] DOCLINKSType = new ITAUWDSR_DOCLINKSType[objJsonArrayAnexos.size()];

		for (int i = 0; i < objJsonArrayAnexos.size(); i++) {

			JsonObject objJsonAnexo = (JsonObject)objJsonArrayAnexos.get(i);
			
			String DOCTYPE = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_DOCTYPE);
			String URLTYPE = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_URLTYPE);
			String DOCUMENTDATA = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_DOCUMENTDATA);

			DOCLINKSType[i] = new ITAUWDSR_DOCLINKSType();
		
			DOCLINKSType[i].setAction(ProcessingActionType.Add);
			DOCLINKSType[i].setDOCTYPE(new MXStringType(DOCTYPE));
			DOCLINKSType[i].setURLTYPE(new MXStringType(URLTYPE));
			DOCLINKSType[i].setDOCUMENTDATA(new MXBinaryType(DOCUMENTDATA));
		}

		SRType.setDOCLINKS(DOCLINKSType);

		//Atributos
		JsonArray objJsonArrayAtributos = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_ATRIBUTOS);

		ITAUWDSR_TICKETSPECType[] TICKETSPECType = new ITAUWDSR_TICKETSPECType[objJsonArrayAtributos.size()];

		for (int i = 0; i < objJsonArrayAtributos.size(); i++) {

			JsonObject objJsonTicketSpec = (JsonObject)objJsonArrayAtributos.get(i);

			String ASSETATTRID = NegocioUtils.obterDadoJson(objJsonTicketSpec, JSON_KEY_MAXIMO_ASSETATTRID);
			String ALNVALUE = NegocioUtils.obterDadoJson(objJsonTicketSpec, JSON_KEY_MAXIMO_ALNVALUE);
			String NUMVALUE = NegocioUtils.obterDadoJson(objJsonTicketSpec, JSON_KEY_MAXIMO_NUMVALUE);
			String TABLEVALUE = NegocioUtils.obterDadoJson(objJsonTicketSpec, JSON_KEY_MAXIMO_TABLEVALUE);

			TICKETSPECType[i] = new ITAUWDSR_TICKETSPECType();

			TICKETSPECType[i].setAction(ProcessingActionType.Add);
			TICKETSPECType[i].setASSETATTRID(new MXStringType(ASSETATTRID));
			TICKETSPECType[i].setALNVALUE(new MXStringType(ALNVALUE));
			TICKETSPECType[i].setNUMVALUE(new MXDoubleType(NegocioUtils.converterDouble(NUMVALUE)));
			TICKETSPECType[i].setTABLEVALUE(new MXStringType(TABLEVALUE));
		}

		SRType.setTICKETSPEC(TICKETSPECType);

		SyncITAUWDSRType objeto = new SyncITAUWDSRType();
		objeto.setITAUWDSRSet(new ITAUWDSR_SRType[] {SRType});

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(SyncITAUWDSRResponseType resposta, String json) {

		ITAUWDSRCombinedKeySetTypeSR[] combinedKeySetTypeSr = resposta.getITAUWDSRSet();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_REPORTEDBY);

		//Popula o JSON
		JsonObject objJsonRet = new JsonObject();

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();
		
		JsonArray objJsonArrayTickets = new JsonArray(); 

		for (ITAUWDSRCombinedKeySetTypeSR CombinedKeySetTypeSR : combinedKeySetTypeSr) {
			
			JsonObject objJsonTicket = new JsonObject();
			
			objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETID, CombinedKeySetTypeSR.getTICKETID().get_value());
			objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETUID, CombinedKeySetTypeSR.getTICKETUID().get_value());
			
			objJsonArrayTickets.add(objJsonTicket);
		}

		objJsonDados.add(JSON_KEY_MAXIMO_LISTA_TICKETS, objJsonArrayTickets);

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString(); 
	}
	
	/**
	 * Enviar os dados 
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private SyncITAUWDSRResponseType enviarDados(SyncITAUWDSRType objeto, String endpoint) throws RemoteException {
		
		//Configura o Proxy
		ITAUWDSRPortTypeProxy proxy = new ITAUWDSRPortTypeProxy();

		proxy.setEndpoint(endpoint);
		((ITAUWDSRSOAP11BindingStub)proxy.getITAUWDSRPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRSOAP11BindingStub)proxy.getITAUWDSRPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));

		return proxy.syncITAUWDSR(objeto);
	}
}