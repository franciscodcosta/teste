package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCUMENTDATA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ANEXOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_WEBURL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDANEXOQueryType;
import com.ibm.www.maximo.ITAUWDANEXOQueryTypeDOCLINKS;
import com.ibm.www.maximo.ITAUWDANEXO_DOCLINKSType;
import com.ibm.www.maximo.MXBinaryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDANEXOResponseType;
import com.ibm.www.maximo.QueryITAUWDANEXOType;
import com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Anexo
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaAnexoService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaAnexoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Consultar anexo
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */	
	public String consultarAnexo(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA ANEXO - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDANEXOType objeto = obterObjeto(json);

			//Envia os dados
			QueryITAUWDANEXOResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA ANEXO - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDANEXOType obterObjeto(String json) {

		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String TICKETID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		ITAUWDANEXOQueryTypeDOCLINKS QueryTypeDOCLINKS = new ITAUWDANEXOQueryTypeDOCLINKS();
		//QueryTypeDOCLINKS.setDOCINFOID(new MXStringQueryType[]{new MXStringQueryType(TICKETID)});

		ITAUWDANEXOQueryType QueryType = new ITAUWDANEXOQueryType();
		QueryType.setDOCLINKS(QueryTypeDOCLINKS);

		QueryITAUWDANEXOType objeto = new QueryITAUWDANEXOType();
		objeto.setITAUWDANEXOQuery(QueryType);
		
		return objeto;
	}

	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDANEXOResponseType resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();
		
		if (resposta.getITAUWDANEXOSet() != null && resposta.getITAUWDANEXOSet().length > 0) {

			JsonArray objJsonArrayAnexos = new JsonArray();
			
			for (ITAUWDANEXO_DOCLINKSType DOCLINKSType : resposta.getITAUWDANEXOSet()) {

				MXStringType DOCTYPE = DOCLINKSType.getDOCTYPE();
				MXStringType WEBURL = DOCLINKSType.getWEBURL();
				MXBinaryType DOCUMENTDATA = DOCLINKSType.getDOCUMENTDATA();

				JsonObject objJsonAnexo = new JsonObject();

				objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCTYPE, NegocioUtils.converterObjetoParaString(DOCTYPE));
				objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCUMENTDATA, NegocioUtils.converterObjetoParaString(DOCUMENTDATA));
				objJsonAnexo.addProperty(JSON_KEY_MAXIMO_WEBURL, NegocioUtils.converterObjetoParaString(WEBURL));

				objJsonArrayAnexos.add(objJsonAnexo);
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_ANEXOS, objJsonArrayAnexos);
		}
		else {

			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}

	/**
	 * Enviar os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDANEXOResponseType enviarDados(QueryITAUWDANEXOType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDANEXOPortTypeProxy proxy = new ITAUWDANEXOPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDANEXOSOAP11BindingStub)proxy.getITAUWDANEXOPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDANEXOSOAP11BindingStub)proxy.getITAUWDANEXOPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDANEXO(objeto);
	}
}