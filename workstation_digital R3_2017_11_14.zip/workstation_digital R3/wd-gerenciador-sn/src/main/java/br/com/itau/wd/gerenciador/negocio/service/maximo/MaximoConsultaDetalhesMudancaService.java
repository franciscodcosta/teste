package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_DETALHES;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_FIM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_IMPACTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_INICIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_MOTIVO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_NUMERO_SOLICITACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_PROBABILIDADE_IMPACTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_RISCO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_TIPO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDWODETAILQueryType;
import com.ibm.www.maximo.ITAUWDWODETAILQueryTypeWOCHANGE;
import com.ibm.www.maximo.ITAUWDWODETAIL_WOCHANGEType;
import com.ibm.www.maximo.MXDateTimeType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDWODETAILResponseType;
import com.ibm.www.maximo.QueryITAUWDWODETAILType;
import com.ibm.www.maximo.wsdl.ITAUWDWODETAIL.ITAUWDWODETAILPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDWODETAIL.ITAUWDWODETAILSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consultar Detalhes Mudança
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaDetalhesMudancaService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaDetalhesMudancaService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar detalhes da mudança
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarDetalhesMudanca(String json, String endpoint) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA DETALHES MUDANÇAS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDWODETAILType objeto = obterObjeto(json);

			//Envia os dados
			QueryITAUWDWODETAILResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA DETALHES MUDANÇAS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDWODETAILType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String WOCHANGE = NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO);

		ITAUWDWODETAILQueryTypeWOCHANGE QueryTypeWOCHANGE = new ITAUWDWODETAILQueryTypeWOCHANGE();
		QueryTypeWOCHANGE.setWONUM(new MXStringQueryType[] {new MXStringQueryType(WOCHANGE)});

		ITAUWDWODETAILQueryType QueryType = new ITAUWDWODETAILQueryType();
		QueryType.setWOCHANGE(QueryTypeWOCHANGE);

		QueryITAUWDWODETAILType objeto = new QueryITAUWDWODETAILType();
		objeto.setITAUWDWODETAILQuery(QueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDWODETAILResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		
		JsonObject objJsonDados = new JsonObject();

		if (resposta.getITAUWDWODETAILSet() != null && resposta.getITAUWDWODETAILSet().length > 0) {
		
			ITAUWDWODETAIL_WOCHANGEType[] DETAILSet = resposta.getITAUWDWODETAILSet(); 

			MXStringType WONUM = DETAILSet[0].getWONUM();
			MXStringType REPORTEDBY = DETAILSet[0].getREPORTEDBY();
			MXDomainType STATUS = DETAILSet[0].getSTATUS();
			MXStringType WORKTYPE = DETAILSet[0].getWORKTYPE();
			MXStringType DESCRIPTION_LONGDESCRIPTION = DETAILSet[0].getDESCRIPTION_LONGDESCRIPTION();
			MXStringType ITAU_MOTMUD = DETAILSet[0].getITAU_MOTMUD();
			MXDateTimeType SCHEDSTART = DETAILSet[0].getSCHEDSTART();
			MXDateTimeType SCHEDFINISH = DETAILSet[0].getSCHEDFINISH();
			MXLongType ITAU_MRISCO = DETAILSet[0].getITAU_MRISCO();
			MXLongType ITAU_MIMPACTO = DETAILSet[0].getITAU_MIMPACTO();
			MXLongType ITAU_MPROBIMPACTO = DETAILSet[0].getITAU_MPROBIMPACTO();

			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_NUMERO_SOLICITACAO, NegocioUtils.converterObjetoParaString(WONUM));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE, NegocioUtils.converterObjetoParaString(REPORTEDBY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_STATUS, NegocioUtils.converterObjetoParaString(STATUS));			
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_TIPO, NegocioUtils.converterObjetoParaString(WORKTYPE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_DETALHES, NegocioUtils.converterObjetoParaString(DESCRIPTION_LONGDESCRIPTION));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_MOTIVO, NegocioUtils.converterObjetoParaString(ITAU_MOTMUD));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_INICIO, NegocioUtils.converterObjetoParaString(SCHEDSTART));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_FIM, NegocioUtils.converterObjetoParaString(SCHEDFINISH));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_RISCO, NegocioUtils.converterObjetoParaString(ITAU_MRISCO));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_IMPACTO, NegocioUtils.converterObjetoParaString(ITAU_MIMPACTO));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_PROBABILIDADE_IMPACTO, NegocioUtils.converterObjetoParaString(ITAU_MPROBIMPACTO));
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);
		
		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDWODETAILResponseType enviarDados(QueryITAUWDWODETAILType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDWODETAILPortTypeProxy proxy = new ITAUWDWODETAILPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDWODETAILSOAP11BindingStub)proxy.getITAUWDWODETAILPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDWODETAILSOAP11BindingStub)proxy.getITAUWDWODETAILPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDWODETAIL(objeto);
	}
}