/**
 * ITAUWDSRATUALIZAQueryTypeSRWORKLOG.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRATUALIZAQueryTypeSRWORKLOG  implements java.io.Serializable {
    private com.ibm.www.maximo.MXBooleanQueryType[] CLIENTVIEWABLE;

    private com.ibm.www.maximo.MXStringQueryType[] CREATEBY;

    private com.ibm.www.maximo.MXDateTimeQueryType[] CREATEDATE;

    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXDomainQueryType[] LOGTYPE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongQueryType[] WORKLOGID;

    private java.lang.Boolean filter;  // attribute

    public ITAUWDSRATUALIZAQueryTypeSRWORKLOG() {
    }

    public ITAUWDSRATUALIZAQueryTypeSRWORKLOG(
           com.ibm.www.maximo.MXBooleanQueryType[] CLIENTVIEWABLE,
           com.ibm.www.maximo.MXStringQueryType[] CREATEBY,
           com.ibm.www.maximo.MXDateTimeQueryType[] CREATEDATE,
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXDomainQueryType[] LOGTYPE,
           com.ibm.www.maximo.MXLongQueryType[] WORKLOGID,
           java.lang.Boolean filter) {
           this.CLIENTVIEWABLE = CLIENTVIEWABLE;
           this.CREATEBY = CREATEBY;
           this.CREATEDATE = CREATEDATE;
           this.DESCRIPTION = DESCRIPTION;
           this.LOGTYPE = LOGTYPE;
           this.WORKLOGID = WORKLOGID;
           this.filter = filter;
    }


    /**
     * Gets the CLIENTVIEWABLE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return CLIENTVIEWABLE
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getCLIENTVIEWABLE() {
        return CLIENTVIEWABLE;
    }


    /**
     * Sets the CLIENTVIEWABLE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param CLIENTVIEWABLE
     */
    public void setCLIENTVIEWABLE(com.ibm.www.maximo.MXBooleanQueryType[] CLIENTVIEWABLE) {
        this.CLIENTVIEWABLE = CLIENTVIEWABLE;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getCLIENTVIEWABLE(int i) {
        return this.CLIENTVIEWABLE[i];
    }

    public void setCLIENTVIEWABLE(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.CLIENTVIEWABLE[i] = _value;
    }


    /**
     * Gets the CREATEBY value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return CREATEBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCREATEBY() {
        return CREATEBY;
    }


    /**
     * Sets the CREATEBY value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param CREATEBY
     */
    public void setCREATEBY(com.ibm.www.maximo.MXStringQueryType[] CREATEBY) {
        this.CREATEBY = CREATEBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getCREATEBY(int i) {
        return this.CREATEBY[i];
    }

    public void setCREATEBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CREATEBY[i] = _value;
    }


    /**
     * Gets the CREATEDATE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return CREATEDATE
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getCREATEDATE() {
        return CREATEDATE;
    }


    /**
     * Sets the CREATEDATE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param CREATEDATE
     */
    public void setCREATEDATE(com.ibm.www.maximo.MXDateTimeQueryType[] CREATEDATE) {
        this.CREATEDATE = CREATEDATE;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getCREATEDATE(int i) {
        return this.CREATEDATE[i];
    }

    public void setCREATEDATE(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.CREATEDATE[i] = _value;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the LOGTYPE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return LOGTYPE
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getLOGTYPE() {
        return LOGTYPE;
    }


    /**
     * Sets the LOGTYPE value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param LOGTYPE
     */
    public void setLOGTYPE(com.ibm.www.maximo.MXDomainQueryType[] LOGTYPE) {
        this.LOGTYPE = LOGTYPE;
    }

    public com.ibm.www.maximo.MXDomainQueryType getLOGTYPE(int i) {
        return this.LOGTYPE[i];
    }

    public void setLOGTYPE(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.LOGTYPE[i] = _value;
    }


    /**
     * Gets the WORKLOGID value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return WORKLOGID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongQueryType[] getWORKLOGID() {
        return WORKLOGID;
    }


    /**
     * Sets the WORKLOGID value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param WORKLOGID   * Unique Key Component
     */
    public void setWORKLOGID(com.ibm.www.maximo.MXLongQueryType[] WORKLOGID) {
        this.WORKLOGID = WORKLOGID;
    }

    public com.ibm.www.maximo.MXLongQueryType getWORKLOGID(int i) {
        return this.WORKLOGID[i];
    }

    public void setWORKLOGID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.WORKLOGID[i] = _value;
    }


    /**
     * Gets the filter value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @return filter
     */
    public java.lang.Boolean getFilter() {
        return filter;
    }


    /**
     * Sets the filter value for this ITAUWDSRATUALIZAQueryTypeSRWORKLOG.
     * 
     * @param filter
     */
    public void setFilter(java.lang.Boolean filter) {
        this.filter = filter;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRATUALIZAQueryTypeSRWORKLOG)) return false;
        ITAUWDSRATUALIZAQueryTypeSRWORKLOG other = (ITAUWDSRATUALIZAQueryTypeSRWORKLOG) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLIENTVIEWABLE==null && other.getCLIENTVIEWABLE()==null) || 
             (this.CLIENTVIEWABLE!=null &&
              java.util.Arrays.equals(this.CLIENTVIEWABLE, other.getCLIENTVIEWABLE()))) &&
            ((this.CREATEBY==null && other.getCREATEBY()==null) || 
             (this.CREATEBY!=null &&
              java.util.Arrays.equals(this.CREATEBY, other.getCREATEBY()))) &&
            ((this.CREATEDATE==null && other.getCREATEDATE()==null) || 
             (this.CREATEDATE!=null &&
              java.util.Arrays.equals(this.CREATEDATE, other.getCREATEDATE()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.LOGTYPE==null && other.getLOGTYPE()==null) || 
             (this.LOGTYPE!=null &&
              java.util.Arrays.equals(this.LOGTYPE, other.getLOGTYPE()))) &&
            ((this.WORKLOGID==null && other.getWORKLOGID()==null) || 
             (this.WORKLOGID!=null &&
              java.util.Arrays.equals(this.WORKLOGID, other.getWORKLOGID()))) &&
            ((this.filter==null && other.getFilter()==null) || 
             (this.filter!=null &&
              this.filter.equals(other.getFilter())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLIENTVIEWABLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLIENTVIEWABLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLIENTVIEWABLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCREATEBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCREATEBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCREATEBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCREATEDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCREATEDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCREATEDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLOGTYPE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLOGTYPE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLOGTYPE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWORKLOGID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWORKLOGID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWORKLOGID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFilter() != null) {
            _hashCode += getFilter().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRATUALIZAQueryTypeSRWORKLOG.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRATUALIZAQueryType>SR>WORKLOG"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("filter");
        attrField.setXmlName(new javax.xml.namespace.QName("", "filter"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLIENTVIEWABLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLIENTVIEWABLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOGTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LOGTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKLOGID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKLOGID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
