package com.ibm.www.maximo.wsdl.ITAUWDLISTSW;

public class ITAUWDLISTSWPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWPortType iTAUWDLISTSWPortType = null;
  
  public ITAUWDLISTSWPortTypeProxy() {
    _initITAUWDLISTSWPortTypeProxy();
  }
  
  public ITAUWDLISTSWPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDLISTSWPortTypeProxy();
  }
  
  private void _initITAUWDLISTSWPortTypeProxy() {
    try {
      iTAUWDLISTSWPortType = (new com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWLocator()).getITAUWDLISTSWSOAP11Port();
      if (iTAUWDLISTSWPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDLISTSWPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDLISTSWPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDLISTSWPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDLISTSWPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWPortType getITAUWDLISTSWPortType() {
    if (iTAUWDLISTSWPortType == null)
      _initITAUWDLISTSWPortTypeProxy();
    return iTAUWDLISTSWPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDLISTSWResponseType queryITAUWDLISTSW(com.ibm.www.maximo.QueryITAUWDLISTSWType parameters) throws java.rmi.RemoteException{
    if (iTAUWDLISTSWPortType == null)
      _initITAUWDLISTSWPortTypeProxy();
    return iTAUWDLISTSWPortType.queryITAUWDLISTSW(parameters);
  }
  
  
}