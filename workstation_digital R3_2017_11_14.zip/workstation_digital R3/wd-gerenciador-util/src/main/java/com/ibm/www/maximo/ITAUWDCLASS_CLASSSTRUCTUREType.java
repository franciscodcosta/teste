/**
 * ITAUWDCLASS_CLASSSTRUCTUREType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDCLASS_CLASSSTRUCTUREType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    private com.ibm.www.maximo.MXStringType CLASSIFICATIONID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType[] CLASSSPEC;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDCLASS_CLASSSTRUCTUREType() {
    }

    public ITAUWDCLASS_CLASSSTRUCTUREType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXStringType CLASSIFICATIONID,
           com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType[] CLASSSPEC,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.CLASSIFICATIONID = CLASSIFICATIONID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DESCRIPTION = DESCRIPTION;
           this.CLASSSPEC = CLASSSPEC;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the CLASSIFICATIONID value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return CLASSIFICATIONID
     */
    public com.ibm.www.maximo.MXStringType getCLASSIFICATIONID() {
        return CLASSIFICATIONID;
    }


    /**
     * Sets the CLASSIFICATIONID value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param CLASSIFICATIONID
     */
    public void setCLASSIFICATIONID(com.ibm.www.maximo.MXStringType CLASSIFICATIONID) {
        this.CLASSIFICATIONID = CLASSIFICATIONID;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return CLASSSTRUCTUREID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param CLASSSTRUCTUREID   * Unique Key Component
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the CLASSSPEC value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return CLASSSPEC
     */
    public com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType[] getCLASSSPEC() {
        return CLASSSPEC;
    }


    /**
     * Sets the CLASSSPEC value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param CLASSSPEC
     */
    public void setCLASSSPEC(com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType[] CLASSSPEC) {
        this.CLASSSPEC = CLASSSPEC;
    }

    public com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType getCLASSSPEC(int i) {
        return this.CLASSSPEC[i];
    }

    public void setCLASSSPEC(int i, com.ibm.www.maximo.ITAUWDCLASS_CLASSSPECType _value) {
        this.CLASSSPEC[i] = _value;
    }


    /**
     * Gets the action value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDCLASS_CLASSSTRUCTUREType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDCLASS_CLASSSTRUCTUREType)) return false;
        ITAUWDCLASS_CLASSSTRUCTUREType other = (ITAUWDCLASS_CLASSSTRUCTUREType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.CLASSIFICATIONID==null && other.getCLASSIFICATIONID()==null) || 
             (this.CLASSIFICATIONID!=null &&
              this.CLASSIFICATIONID.equals(other.getCLASSIFICATIONID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              this.CLASSSTRUCTUREID.equals(other.getCLASSSTRUCTUREID()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.CLASSSPEC==null && other.getCLASSSPEC()==null) || 
             (this.CLASSSPEC!=null &&
              java.util.Arrays.equals(this.CLASSSPEC, other.getCLASSSPEC()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getCLASSIFICATIONID() != null) {
            _hashCode += getCLASSIFICATIONID().hashCode();
        }
        if (getCLASSSTRUCTUREID() != null) {
            _hashCode += getCLASSSTRUCTUREID().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getCLASSSPEC() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSPEC());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSPEC(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDCLASS_CLASSSTRUCTUREType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_CLASSSTRUCTUREType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSIFICATIONID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSIFICATIONID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_CLASSSPECType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
