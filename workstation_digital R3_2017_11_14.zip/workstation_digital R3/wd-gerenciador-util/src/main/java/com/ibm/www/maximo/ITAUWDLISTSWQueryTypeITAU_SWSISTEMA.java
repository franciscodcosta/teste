/**
 * ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDLISTSWQueryTypeITAU_SWSISTEMA  implements java.io.Serializable {
    private com.ibm.www.maximo.MXBooleanQueryType[] CORPORATIVO;

    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU_SWREDE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongQueryType[] ITAU_SWSISTEMAID;

    private com.ibm.www.maximo.MXBooleanQueryType[] LICENCIADO;

    private com.ibm.www.maximo.MXBooleanQueryType[] RESTRITO;

    private com.ibm.www.maximo.MXStringQueryType[] TIPO;

    public ITAUWDLISTSWQueryTypeITAU_SWSISTEMA() {
    }

    public ITAUWDLISTSWQueryTypeITAU_SWSISTEMA(
           com.ibm.www.maximo.MXBooleanQueryType[] CORPORATIVO,
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU_SWREDE,
           com.ibm.www.maximo.MXLongQueryType[] ITAU_SWSISTEMAID,
           com.ibm.www.maximo.MXBooleanQueryType[] LICENCIADO,
           com.ibm.www.maximo.MXBooleanQueryType[] RESTRITO,
           com.ibm.www.maximo.MXStringQueryType[] TIPO) {
           this.CORPORATIVO = CORPORATIVO;
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU = ITAU;
           this.ITAU_SWREDE = ITAU_SWREDE;
           this.ITAU_SWSISTEMAID = ITAU_SWSISTEMAID;
           this.LICENCIADO = LICENCIADO;
           this.RESTRITO = RESTRITO;
           this.TIPO = TIPO;
    }


    /**
     * Gets the CORPORATIVO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return CORPORATIVO
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getCORPORATIVO() {
        return CORPORATIVO;
    }


    /**
     * Sets the CORPORATIVO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param CORPORATIVO
     */
    public void setCORPORATIVO(com.ibm.www.maximo.MXBooleanQueryType[] CORPORATIVO) {
        this.CORPORATIVO = CORPORATIVO;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getCORPORATIVO(int i) {
        return this.CORPORATIVO[i];
    }

    public void setCORPORATIVO(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.CORPORATIVO[i] = _value;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the ITAU value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return ITAU
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU() {
        return ITAU;
    }


    /**
     * Sets the ITAU value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param ITAU
     */
    public void setITAU(com.ibm.www.maximo.MXBooleanQueryType[] ITAU) {
        this.ITAU = ITAU;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU(int i) {
        return this.ITAU[i];
    }

    public void setITAU(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU[i] = _value;
    }


    /**
     * Gets the ITAU_SWREDE value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return ITAU_SWREDE
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU_SWREDE() {
        return ITAU_SWREDE;
    }


    /**
     * Sets the ITAU_SWREDE value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param ITAU_SWREDE
     */
    public void setITAU_SWREDE(com.ibm.www.maximo.MXBooleanQueryType[] ITAU_SWREDE) {
        this.ITAU_SWREDE = ITAU_SWREDE;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU_SWREDE(int i) {
        return this.ITAU_SWREDE[i];
    }

    public void setITAU_SWREDE(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU_SWREDE[i] = _value;
    }


    /**
     * Gets the ITAU_SWSISTEMAID value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return ITAU_SWSISTEMAID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongQueryType[] getITAU_SWSISTEMAID() {
        return ITAU_SWSISTEMAID;
    }


    /**
     * Sets the ITAU_SWSISTEMAID value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param ITAU_SWSISTEMAID   * Unique Key Component
     */
    public void setITAU_SWSISTEMAID(com.ibm.www.maximo.MXLongQueryType[] ITAU_SWSISTEMAID) {
        this.ITAU_SWSISTEMAID = ITAU_SWSISTEMAID;
    }

    public com.ibm.www.maximo.MXLongQueryType getITAU_SWSISTEMAID(int i) {
        return this.ITAU_SWSISTEMAID[i];
    }

    public void setITAU_SWSISTEMAID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.ITAU_SWSISTEMAID[i] = _value;
    }


    /**
     * Gets the LICENCIADO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return LICENCIADO
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getLICENCIADO() {
        return LICENCIADO;
    }


    /**
     * Sets the LICENCIADO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param LICENCIADO
     */
    public void setLICENCIADO(com.ibm.www.maximo.MXBooleanQueryType[] LICENCIADO) {
        this.LICENCIADO = LICENCIADO;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getLICENCIADO(int i) {
        return this.LICENCIADO[i];
    }

    public void setLICENCIADO(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.LICENCIADO[i] = _value;
    }


    /**
     * Gets the RESTRITO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return RESTRITO
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getRESTRITO() {
        return RESTRITO;
    }


    /**
     * Sets the RESTRITO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param RESTRITO
     */
    public void setRESTRITO(com.ibm.www.maximo.MXBooleanQueryType[] RESTRITO) {
        this.RESTRITO = RESTRITO;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getRESTRITO(int i) {
        return this.RESTRITO[i];
    }

    public void setRESTRITO(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.RESTRITO[i] = _value;
    }


    /**
     * Gets the TIPO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @return TIPO
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTIPO() {
        return TIPO;
    }


    /**
     * Sets the TIPO value for this ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.
     * 
     * @param TIPO
     */
    public void setTIPO(com.ibm.www.maximo.MXStringQueryType[] TIPO) {
        this.TIPO = TIPO;
    }

    public com.ibm.www.maximo.MXStringQueryType getTIPO(int i) {
        return this.TIPO[i];
    }

    public void setTIPO(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TIPO[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDLISTSWQueryTypeITAU_SWSISTEMA)) return false;
        ITAUWDLISTSWQueryTypeITAU_SWSISTEMA other = (ITAUWDLISTSWQueryTypeITAU_SWSISTEMA) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CORPORATIVO==null && other.getCORPORATIVO()==null) || 
             (this.CORPORATIVO!=null &&
              java.util.Arrays.equals(this.CORPORATIVO, other.getCORPORATIVO()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.ITAU==null && other.getITAU()==null) || 
             (this.ITAU!=null &&
              java.util.Arrays.equals(this.ITAU, other.getITAU()))) &&
            ((this.ITAU_SWREDE==null && other.getITAU_SWREDE()==null) || 
             (this.ITAU_SWREDE!=null &&
              java.util.Arrays.equals(this.ITAU_SWREDE, other.getITAU_SWREDE()))) &&
            ((this.ITAU_SWSISTEMAID==null && other.getITAU_SWSISTEMAID()==null) || 
             (this.ITAU_SWSISTEMAID!=null &&
              java.util.Arrays.equals(this.ITAU_SWSISTEMAID, other.getITAU_SWSISTEMAID()))) &&
            ((this.LICENCIADO==null && other.getLICENCIADO()==null) || 
             (this.LICENCIADO!=null &&
              java.util.Arrays.equals(this.LICENCIADO, other.getLICENCIADO()))) &&
            ((this.RESTRITO==null && other.getRESTRITO()==null) || 
             (this.RESTRITO!=null &&
              java.util.Arrays.equals(this.RESTRITO, other.getRESTRITO()))) &&
            ((this.TIPO==null && other.getTIPO()==null) || 
             (this.TIPO!=null &&
              java.util.Arrays.equals(this.TIPO, other.getTIPO())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCORPORATIVO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCORPORATIVO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCORPORATIVO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_SWREDE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_SWREDE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_SWREDE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_SWSISTEMAID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_SWSISTEMAID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_SWSISTEMAID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLICENCIADO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLICENCIADO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLICENCIADO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRESTRITO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getRESTRITO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getRESTRITO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTIPO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTIPO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTIPO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDLISTSWQueryTypeITAU_SWSISTEMA.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDLISTSWQueryType>ITAU_SWSISTEMA"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CORPORATIVO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CORPORATIVO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_SWREDE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_SWREDE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_SWSISTEMAID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_SWSISTEMAID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LICENCIADO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LICENCIADO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RESTRITO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "RESTRITO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TIPO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TIPO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
