package com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA;

public class ITAUWDSRATUALIZAPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZAPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZAPortType iTAUWDSRATUALIZAPortType = null;
  
  public ITAUWDSRATUALIZAPortTypeProxy() {
    _initITAUWDSRATUALIZAPortTypeProxy();
  }
  
  public ITAUWDSRATUALIZAPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDSRATUALIZAPortTypeProxy();
  }
  
  private void _initITAUWDSRATUALIZAPortTypeProxy() {
    try {
      iTAUWDSRATUALIZAPortType = (new com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZALocator()).getITAUWDSRATUALIZASOAP11Port();
      if (iTAUWDSRATUALIZAPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDSRATUALIZAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDSRATUALIZAPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDSRATUALIZAPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDSRATUALIZAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZAPortType getITAUWDSRATUALIZAPortType() {
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDSRATUALIZAResponseType queryITAUWDSRATUALIZA(com.ibm.www.maximo.QueryITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType.queryITAUWDSRATUALIZA(parameters);
  }
  
  public com.ibm.www.maximo.SyncITAUWDSRATUALIZAResponseType syncITAUWDSRATUALIZA(com.ibm.www.maximo.SyncITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType.syncITAUWDSRATUALIZA(parameters);
  }
  
  public com.ibm.www.maximo.UpdateITAUWDSRATUALIZAResponseType updateITAUWDSRATUALIZA(com.ibm.www.maximo.UpdateITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType.updateITAUWDSRATUALIZA(parameters);
  }
  
  public com.ibm.www.maximo.CreateITAUWDSRATUALIZAResponseType createITAUWDSRATUALIZA(com.ibm.www.maximo.CreateITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType.createITAUWDSRATUALIZA(parameters);
  }
  
  public com.ibm.www.maximo.DeleteITAUWDSRATUALIZAResponseType deleteITAUWDSRATUALIZA(com.ibm.www.maximo.DeleteITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRATUALIZAPortType == null)
      _initITAUWDSRATUALIZAPortTypeProxy();
    return iTAUWDSRATUALIZAPortType.deleteITAUWDSRATUALIZA(parameters);
  }
  
  
}