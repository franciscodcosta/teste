/**
 * ITAUWDWODETAIL_WOCHANGEType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDWODETAIL_WOCHANGEType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION;

    private com.ibm.www.maximo.MXLongType ITAU_MIMPACTO;

    private com.ibm.www.maximo.MXStringType ITAU_MOTMUD;

    private com.ibm.www.maximo.MXLongType ITAU_MPROBIMPACTO;

    private com.ibm.www.maximo.MXLongType ITAU_MRISCO;

    private com.ibm.www.maximo.MXStringType REPORTEDBY;

    private com.ibm.www.maximo.MXStringType REPORTEDBYNAME;

    private com.ibm.www.maximo.MXDateTimeType SCHEDFINISH;

    private com.ibm.www.maximo.MXDateTimeType SCHEDSTART;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType SITEID;

    private com.ibm.www.maximo.MXDomainType STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType WONUM;

    private com.ibm.www.maximo.MXStringType WORKTYPE;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDWODETAIL_WOCHANGEType() {
    }

    public ITAUWDWODETAIL_WOCHANGEType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION,
           com.ibm.www.maximo.MXLongType ITAU_MIMPACTO,
           com.ibm.www.maximo.MXStringType ITAU_MOTMUD,
           com.ibm.www.maximo.MXLongType ITAU_MPROBIMPACTO,
           com.ibm.www.maximo.MXLongType ITAU_MRISCO,
           com.ibm.www.maximo.MXStringType REPORTEDBY,
           com.ibm.www.maximo.MXStringType REPORTEDBYNAME,
           com.ibm.www.maximo.MXDateTimeType SCHEDFINISH,
           com.ibm.www.maximo.MXDateTimeType SCHEDSTART,
           com.ibm.www.maximo.MXStringType SITEID,
           com.ibm.www.maximo.MXDomainType STATUS,
           com.ibm.www.maximo.MXStringType WONUM,
           com.ibm.www.maximo.MXStringType WORKTYPE,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.DESCRIPTION = DESCRIPTION;
           this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
           this.ITAU_MIMPACTO = ITAU_MIMPACTO;
           this.ITAU_MOTMUD = ITAU_MOTMUD;
           this.ITAU_MPROBIMPACTO = ITAU_MPROBIMPACTO;
           this.ITAU_MRISCO = ITAU_MRISCO;
           this.REPORTEDBY = REPORTEDBY;
           this.REPORTEDBYNAME = REPORTEDBYNAME;
           this.SCHEDFINISH = SCHEDFINISH;
           this.SCHEDSTART = SCHEDSTART;
           this.SITEID = SITEID;
           this.STATUS = STATUS;
           this.WONUM = WONUM;
           this.WORKTYPE = WORKTYPE;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return DESCRIPTION_LONGDESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION_LONGDESCRIPTION() {
        return DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param DESCRIPTION_LONGDESCRIPTION
     */
    public void setDESCRIPTION_LONGDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION) {
        this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Gets the ITAU_MIMPACTO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return ITAU_MIMPACTO
     */
    public com.ibm.www.maximo.MXLongType getITAU_MIMPACTO() {
        return ITAU_MIMPACTO;
    }


    /**
     * Sets the ITAU_MIMPACTO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param ITAU_MIMPACTO
     */
    public void setITAU_MIMPACTO(com.ibm.www.maximo.MXLongType ITAU_MIMPACTO) {
        this.ITAU_MIMPACTO = ITAU_MIMPACTO;
    }


    /**
     * Gets the ITAU_MOTMUD value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return ITAU_MOTMUD
     */
    public com.ibm.www.maximo.MXStringType getITAU_MOTMUD() {
        return ITAU_MOTMUD;
    }


    /**
     * Sets the ITAU_MOTMUD value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param ITAU_MOTMUD
     */
    public void setITAU_MOTMUD(com.ibm.www.maximo.MXStringType ITAU_MOTMUD) {
        this.ITAU_MOTMUD = ITAU_MOTMUD;
    }


    /**
     * Gets the ITAU_MPROBIMPACTO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return ITAU_MPROBIMPACTO
     */
    public com.ibm.www.maximo.MXLongType getITAU_MPROBIMPACTO() {
        return ITAU_MPROBIMPACTO;
    }


    /**
     * Sets the ITAU_MPROBIMPACTO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param ITAU_MPROBIMPACTO
     */
    public void setITAU_MPROBIMPACTO(com.ibm.www.maximo.MXLongType ITAU_MPROBIMPACTO) {
        this.ITAU_MPROBIMPACTO = ITAU_MPROBIMPACTO;
    }


    /**
     * Gets the ITAU_MRISCO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return ITAU_MRISCO
     */
    public com.ibm.www.maximo.MXLongType getITAU_MRISCO() {
        return ITAU_MRISCO;
    }


    /**
     * Sets the ITAU_MRISCO value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param ITAU_MRISCO
     */
    public void setITAU_MRISCO(com.ibm.www.maximo.MXLongType ITAU_MRISCO) {
        this.ITAU_MRISCO = ITAU_MRISCO;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringType REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }


    /**
     * Gets the REPORTEDBYNAME value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return REPORTEDBYNAME
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBYNAME() {
        return REPORTEDBYNAME;
    }


    /**
     * Sets the REPORTEDBYNAME value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param REPORTEDBYNAME
     */
    public void setREPORTEDBYNAME(com.ibm.www.maximo.MXStringType REPORTEDBYNAME) {
        this.REPORTEDBYNAME = REPORTEDBYNAME;
    }


    /**
     * Gets the SCHEDFINISH value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return SCHEDFINISH
     */
    public com.ibm.www.maximo.MXDateTimeType getSCHEDFINISH() {
        return SCHEDFINISH;
    }


    /**
     * Sets the SCHEDFINISH value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param SCHEDFINISH
     */
    public void setSCHEDFINISH(com.ibm.www.maximo.MXDateTimeType SCHEDFINISH) {
        this.SCHEDFINISH = SCHEDFINISH;
    }


    /**
     * Gets the SCHEDSTART value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return SCHEDSTART
     */
    public com.ibm.www.maximo.MXDateTimeType getSCHEDSTART() {
        return SCHEDSTART;
    }


    /**
     * Sets the SCHEDSTART value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param SCHEDSTART
     */
    public void setSCHEDSTART(com.ibm.www.maximo.MXDateTimeType SCHEDSTART) {
        this.SCHEDSTART = SCHEDSTART;
    }


    /**
     * Gets the SITEID value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringType SITEID) {
        this.SITEID = SITEID;
    }


    /**
     * Gets the STATUS value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainType getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainType STATUS) {
        this.STATUS = STATUS;
    }


    /**
     * Gets the WONUM value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return WONUM   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getWONUM() {
        return WONUM;
    }


    /**
     * Sets the WONUM value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param WONUM   * Unique Key Component
     */
    public void setWONUM(com.ibm.www.maximo.MXStringType WONUM) {
        this.WONUM = WONUM;
    }


    /**
     * Gets the WORKTYPE value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return WORKTYPE
     */
    public com.ibm.www.maximo.MXStringType getWORKTYPE() {
        return WORKTYPE;
    }


    /**
     * Sets the WORKTYPE value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param WORKTYPE
     */
    public void setWORKTYPE(com.ibm.www.maximo.MXStringType WORKTYPE) {
        this.WORKTYPE = WORKTYPE;
    }


    /**
     * Gets the action value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDWODETAIL_WOCHANGEType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDWODETAIL_WOCHANGEType)) return false;
        ITAUWDWODETAIL_WOCHANGEType other = (ITAUWDWODETAIL_WOCHANGEType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.DESCRIPTION_LONGDESCRIPTION==null && other.getDESCRIPTION_LONGDESCRIPTION()==null) || 
             (this.DESCRIPTION_LONGDESCRIPTION!=null &&
              this.DESCRIPTION_LONGDESCRIPTION.equals(other.getDESCRIPTION_LONGDESCRIPTION()))) &&
            ((this.ITAU_MIMPACTO==null && other.getITAU_MIMPACTO()==null) || 
             (this.ITAU_MIMPACTO!=null &&
              this.ITAU_MIMPACTO.equals(other.getITAU_MIMPACTO()))) &&
            ((this.ITAU_MOTMUD==null && other.getITAU_MOTMUD()==null) || 
             (this.ITAU_MOTMUD!=null &&
              this.ITAU_MOTMUD.equals(other.getITAU_MOTMUD()))) &&
            ((this.ITAU_MPROBIMPACTO==null && other.getITAU_MPROBIMPACTO()==null) || 
             (this.ITAU_MPROBIMPACTO!=null &&
              this.ITAU_MPROBIMPACTO.equals(other.getITAU_MPROBIMPACTO()))) &&
            ((this.ITAU_MRISCO==null && other.getITAU_MRISCO()==null) || 
             (this.ITAU_MRISCO!=null &&
              this.ITAU_MRISCO.equals(other.getITAU_MRISCO()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              this.REPORTEDBY.equals(other.getREPORTEDBY()))) &&
            ((this.REPORTEDBYNAME==null && other.getREPORTEDBYNAME()==null) || 
             (this.REPORTEDBYNAME!=null &&
              this.REPORTEDBYNAME.equals(other.getREPORTEDBYNAME()))) &&
            ((this.SCHEDFINISH==null && other.getSCHEDFINISH()==null) || 
             (this.SCHEDFINISH!=null &&
              this.SCHEDFINISH.equals(other.getSCHEDFINISH()))) &&
            ((this.SCHEDSTART==null && other.getSCHEDSTART()==null) || 
             (this.SCHEDSTART!=null &&
              this.SCHEDSTART.equals(other.getSCHEDSTART()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              this.SITEID.equals(other.getSITEID()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS()))) &&
            ((this.WONUM==null && other.getWONUM()==null) || 
             (this.WONUM!=null &&
              this.WONUM.equals(other.getWONUM()))) &&
            ((this.WORKTYPE==null && other.getWORKTYPE()==null) || 
             (this.WORKTYPE!=null &&
              this.WORKTYPE.equals(other.getWORKTYPE()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getDESCRIPTION_LONGDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION_LONGDESCRIPTION().hashCode();
        }
        if (getITAU_MIMPACTO() != null) {
            _hashCode += getITAU_MIMPACTO().hashCode();
        }
        if (getITAU_MOTMUD() != null) {
            _hashCode += getITAU_MOTMUD().hashCode();
        }
        if (getITAU_MPROBIMPACTO() != null) {
            _hashCode += getITAU_MPROBIMPACTO().hashCode();
        }
        if (getITAU_MRISCO() != null) {
            _hashCode += getITAU_MRISCO().hashCode();
        }
        if (getREPORTEDBY() != null) {
            _hashCode += getREPORTEDBY().hashCode();
        }
        if (getREPORTEDBYNAME() != null) {
            _hashCode += getREPORTEDBYNAME().hashCode();
        }
        if (getSCHEDFINISH() != null) {
            _hashCode += getSCHEDFINISH().hashCode();
        }
        if (getSCHEDSTART() != null) {
            _hashCode += getSCHEDSTART().hashCode();
        }
        if (getSITEID() != null) {
            _hashCode += getSITEID().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        if (getWONUM() != null) {
            _hashCode += getWONUM().hashCode();
        }
        if (getWORKTYPE() != null) {
            _hashCode += getWORKTYPE().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDWODETAIL_WOCHANGEType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDWODETAIL_WOCHANGEType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION_LONGDESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION_LONGDESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MIMPACTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MIMPACTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MOTMUD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MOTMUD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MPROBIMPACTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MPROBIMPACTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MRISCO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MRISCO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBYNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBYNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCHEDFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SCHEDFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCHEDSTART");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SCHEDSTART"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
