/**
 * ITAUWDSR_SRType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSR_SRType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    private com.ibm.www.maximo.MXStringType AFFECTEDPERSON;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainType CLASS;

    private com.ibm.www.maximo.MXStringType CLASSIFICATIONID;

    private com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID;

    private com.ibm.www.maximo.MXStringType CREATEDBY;

    private com.ibm.www.maximo.MXDateTimeType CREATIONDATE;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION;

    private com.ibm.www.maximo.MXDomainType EXTERNALSYSTEM;

    private com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK;

    private com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK;

    private com.ibm.www.maximo.MXBooleanType ITAU_GNSOK;

    private com.ibm.www.maximo.MXDateTimeType REPORTDATE;

    private com.ibm.www.maximo.MXStringType REPORTEDBY;

    private com.ibm.www.maximo.MXDomainType STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType TICKETID;

    private com.ibm.www.maximo.ITAUWDSR_TICKETSPECType[] TICKETSPEC;

    private com.ibm.www.maximo.ITAUWDSR_DOCLINKSType[] DOCLINKS;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDSR_SRType() {
    }

    public ITAUWDSR_SRType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXStringType AFFECTEDPERSON,
           com.ibm.www.maximo.MXDomainType CLASS,
           com.ibm.www.maximo.MXStringType CLASSIFICATIONID,
           com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringType CREATEDBY,
           com.ibm.www.maximo.MXDateTimeType CREATIONDATE,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION,
           com.ibm.www.maximo.MXDomainType EXTERNALSYSTEM,
           com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK,
           com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK,
           com.ibm.www.maximo.MXBooleanType ITAU_GNSOK,
           com.ibm.www.maximo.MXDateTimeType REPORTDATE,
           com.ibm.www.maximo.MXStringType REPORTEDBY,
           com.ibm.www.maximo.MXDomainType STATUS,
           com.ibm.www.maximo.MXStringType TICKETID,
           com.ibm.www.maximo.ITAUWDSR_TICKETSPECType[] TICKETSPEC,
           com.ibm.www.maximo.ITAUWDSR_DOCLINKSType[] DOCLINKS,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.AFFECTEDPERSON = AFFECTEDPERSON;
           this.CLASS = CLASS;
           this.CLASSIFICATIONID = CLASSIFICATIONID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.CREATEDBY = CREATEDBY;
           this.CREATIONDATE = CREATIONDATE;
           this.DESCRIPTION = DESCRIPTION;
           this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
           this.EXTERNALSYSTEM = EXTERNALSYSTEM;
           this.ITAU_GDISPOK = ITAU_GDISPOK;
           this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
           this.ITAU_GNSOK = ITAU_GNSOK;
           this.REPORTDATE = REPORTDATE;
           this.REPORTEDBY = REPORTEDBY;
           this.STATUS = STATUS;
           this.TICKETID = TICKETID;
           this.TICKETSPEC = TICKETSPEC;
           this.DOCLINKS = DOCLINKS;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }

    //RETIRAR
    private com.ibm.www.maximo.MXStringType LOCATION;
    private com.ibm.www.maximo.MXStringType AFFECTEDPHONE;
    
    public com.ibm.www.maximo.MXStringType getLOCATION() {
        return LOCATION;
    }
    
    public void setLOCATION(com.ibm.www.maximo.MXStringType LOCATION) {
        this.LOCATION = LOCATION;
    }
    
    public com.ibm.www.maximo.MXStringType getAFFECTEDPHONE() {
        return AFFECTEDPHONE;
    }
    
    public void setAFFECTEDPHONE(com.ibm.www.maximo.MXStringType AFFECTEDPHONE) {
        this.AFFECTEDPHONE = AFFECTEDPHONE;
    }
    

    //RETIRAR

    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDSR_SRType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDSR_SRType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the AFFECTEDPERSON value for this ITAUWDSR_SRType.
     * 
     * @return AFFECTEDPERSON
     */
    public com.ibm.www.maximo.MXStringType getAFFECTEDPERSON() {
        return AFFECTEDPERSON;
    }

    
    /**
     * Sets the AFFECTEDPERSON value for this ITAUWDSR_SRType.
     * 
     * @param AFFECTEDPERSON
     */
    public void setAFFECTEDPERSON(com.ibm.www.maximo.MXStringType AFFECTEDPERSON) {
        this.AFFECTEDPERSON = AFFECTEDPERSON;
    }


    /**
     * Gets the CLASS value for this ITAUWDSR_SRType.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainType getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSR_SRType.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainType CLASS) {
        this.CLASS = CLASS;
    }


    /**
     * Gets the CLASSIFICATIONID value for this ITAUWDSR_SRType.
     * 
     * @return CLASSIFICATIONID
     */
    public com.ibm.www.maximo.MXStringType getCLASSIFICATIONID() {
        return CLASSIFICATIONID;
    }


    /**
     * Sets the CLASSIFICATIONID value for this ITAUWDSR_SRType.
     * 
     * @param CLASSIFICATIONID
     */
    public void setCLASSIFICATIONID(com.ibm.www.maximo.MXStringType CLASSIFICATIONID) {
        this.CLASSIFICATIONID = CLASSIFICATIONID;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDSR_SRType.
     * 
     * @return CLASSSTRUCTUREID
     */
    public com.ibm.www.maximo.MXStringType getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDSR_SRType.
     * 
     * @param CLASSSTRUCTUREID
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }


    /**
     * Gets the CREATEDBY value for this ITAUWDSR_SRType.
     * 
     * @return CREATEDBY
     */
    public com.ibm.www.maximo.MXStringType getCREATEDBY() {
        return CREATEDBY;
    }


    /**
     * Sets the CREATEDBY value for this ITAUWDSR_SRType.
     * 
     * @param CREATEDBY
     */
    public void setCREATEDBY(com.ibm.www.maximo.MXStringType CREATEDBY) {
        this.CREATEDBY = CREATEDBY;
    }


    /**
     * Gets the CREATIONDATE value for this ITAUWDSR_SRType.
     * 
     * @return CREATIONDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getCREATIONDATE() {
        return CREATIONDATE;
    }


    /**
     * Sets the CREATIONDATE value for this ITAUWDSR_SRType.
     * 
     * @param CREATIONDATE
     */
    public void setCREATIONDATE(com.ibm.www.maximo.MXDateTimeType CREATIONDATE) {
        this.CREATIONDATE = CREATIONDATE;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSR_SRType.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSR_SRType.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSR_SRType.
     * 
     * @return DESCRIPTION_LONGDESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION_LONGDESCRIPTION() {
        return DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSR_SRType.
     * 
     * @param DESCRIPTION_LONGDESCRIPTION
     */
    public void setDESCRIPTION_LONGDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION) {
        this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Gets the EXTERNALSYSTEM value for this ITAUWDSR_SRType.
     * 
     * @return EXTERNALSYSTEM
     */
    public com.ibm.www.maximo.MXDomainType getEXTERNALSYSTEM() {
        return EXTERNALSYSTEM;
    }


    /**
     * Sets the EXTERNALSYSTEM value for this ITAUWDSR_SRType.
     * 
     * @param EXTERNALSYSTEM
     */
    public void setEXTERNALSYSTEM(com.ibm.www.maximo.MXDomainType EXTERNALSYSTEM) {
        this.EXTERNALSYSTEM = EXTERNALSYSTEM;
    }


    /**
     * Gets the ITAU_GDISPOK value for this ITAUWDSR_SRType.
     * 
     * @return ITAU_GDISPOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GDISPOK() {
        return ITAU_GDISPOK;
    }


    /**
     * Sets the ITAU_GDISPOK value for this ITAUWDSR_SRType.
     * 
     * @param ITAU_GDISPOK
     */
    public void setITAU_GDISPOK(com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK) {
        this.ITAU_GDISPOK = ITAU_GDISPOK;
    }


    /**
     * Gets the ITAU_GIQAGNSOK value for this ITAUWDSR_SRType.
     * 
     * @return ITAU_GIQAGNSOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GIQAGNSOK() {
        return ITAU_GIQAGNSOK;
    }


    /**
     * Sets the ITAU_GIQAGNSOK value for this ITAUWDSR_SRType.
     * 
     * @param ITAU_GIQAGNSOK
     */
    public void setITAU_GIQAGNSOK(com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK) {
        this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
    }


    /**
     * Gets the ITAU_GNSOK value for this ITAUWDSR_SRType.
     * 
     * @return ITAU_GNSOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GNSOK() {
        return ITAU_GNSOK;
    }


    /**
     * Sets the ITAU_GNSOK value for this ITAUWDSR_SRType.
     * 
     * @param ITAU_GNSOK
     */
    public void setITAU_GNSOK(com.ibm.www.maximo.MXBooleanType ITAU_GNSOK) {
        this.ITAU_GNSOK = ITAU_GNSOK;
    }


    /**
     * Gets the REPORTDATE value for this ITAUWDSR_SRType.
     * 
     * @return REPORTDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getREPORTDATE() {
        return REPORTDATE;
    }


    /**
     * Sets the REPORTDATE value for this ITAUWDSR_SRType.
     * 
     * @param REPORTDATE
     */
    public void setREPORTDATE(com.ibm.www.maximo.MXDateTimeType REPORTDATE) {
        this.REPORTDATE = REPORTDATE;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSR_SRType.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSR_SRType.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringType REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }


    /**
     * Gets the STATUS value for this ITAUWDSR_SRType.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainType getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSR_SRType.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainType STATUS) {
        this.STATUS = STATUS;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSR_SRType.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSR_SRType.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringType TICKETID) {
        this.TICKETID = TICKETID;
    }


    /**
     * Gets the TICKETSPEC value for this ITAUWDSR_SRType.
     * 
     * @return TICKETSPEC
     */
    public com.ibm.www.maximo.ITAUWDSR_TICKETSPECType[] getTICKETSPEC() {
        return TICKETSPEC;
    }


    /**
     * Sets the TICKETSPEC value for this ITAUWDSR_SRType.
     * 
     * @param TICKETSPEC
     */
    public void setTICKETSPEC(com.ibm.www.maximo.ITAUWDSR_TICKETSPECType[] TICKETSPEC) {
        this.TICKETSPEC = TICKETSPEC;
    }

    public com.ibm.www.maximo.ITAUWDSR_TICKETSPECType getTICKETSPEC(int i) {
        return this.TICKETSPEC[i];
    }

    public void setTICKETSPEC(int i, com.ibm.www.maximo.ITAUWDSR_TICKETSPECType _value) {
        this.TICKETSPEC[i] = _value;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDSR_SRType.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDSR_DOCLINKSType[] getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDSR_SRType.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDSR_DOCLINKSType[] DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }

    public com.ibm.www.maximo.ITAUWDSR_DOCLINKSType getDOCLINKS(int i) {
        return this.DOCLINKS[i];
    }

    public void setDOCLINKS(int i, com.ibm.www.maximo.ITAUWDSR_DOCLINKSType _value) {
        this.DOCLINKS[i] = _value;
    }


    /**
     * Gets the action value for this ITAUWDSR_SRType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSR_SRType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSR_SRType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSR_SRType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSR_SRType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSR_SRType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDSR_SRType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDSR_SRType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSR_SRType)) return false;
        ITAUWDSR_SRType other = (ITAUWDSR_SRType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.AFFECTEDPERSON==null && other.getAFFECTEDPERSON()==null) || 
             (this.AFFECTEDPERSON!=null &&
              this.AFFECTEDPERSON.equals(other.getAFFECTEDPERSON()))) &&
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              this.CLASS.equals(other.getCLASS()))) &&
            ((this.CLASSIFICATIONID==null && other.getCLASSIFICATIONID()==null) || 
             (this.CLASSIFICATIONID!=null &&
              this.CLASSIFICATIONID.equals(other.getCLASSIFICATIONID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              this.CLASSSTRUCTUREID.equals(other.getCLASSSTRUCTUREID()))) &&
            ((this.CREATEDBY==null && other.getCREATEDBY()==null) || 
             (this.CREATEDBY!=null &&
              this.CREATEDBY.equals(other.getCREATEDBY()))) &&
            ((this.CREATIONDATE==null && other.getCREATIONDATE()==null) || 
             (this.CREATIONDATE!=null &&
              this.CREATIONDATE.equals(other.getCREATIONDATE()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.DESCRIPTION_LONGDESCRIPTION==null && other.getDESCRIPTION_LONGDESCRIPTION()==null) || 
             (this.DESCRIPTION_LONGDESCRIPTION!=null &&
              this.DESCRIPTION_LONGDESCRIPTION.equals(other.getDESCRIPTION_LONGDESCRIPTION()))) &&
            ((this.EXTERNALSYSTEM==null && other.getEXTERNALSYSTEM()==null) || 
             (this.EXTERNALSYSTEM!=null &&
              this.EXTERNALSYSTEM.equals(other.getEXTERNALSYSTEM()))) &&
            ((this.ITAU_GDISPOK==null && other.getITAU_GDISPOK()==null) || 
             (this.ITAU_GDISPOK!=null &&
              this.ITAU_GDISPOK.equals(other.getITAU_GDISPOK()))) &&
            ((this.ITAU_GIQAGNSOK==null && other.getITAU_GIQAGNSOK()==null) || 
             (this.ITAU_GIQAGNSOK!=null &&
              this.ITAU_GIQAGNSOK.equals(other.getITAU_GIQAGNSOK()))) &&
            ((this.ITAU_GNSOK==null && other.getITAU_GNSOK()==null) || 
             (this.ITAU_GNSOK!=null &&
              this.ITAU_GNSOK.equals(other.getITAU_GNSOK()))) &&
            ((this.REPORTDATE==null && other.getREPORTDATE()==null) || 
             (this.REPORTDATE!=null &&
              this.REPORTDATE.equals(other.getREPORTDATE()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              this.REPORTEDBY.equals(other.getREPORTEDBY()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              this.TICKETID.equals(other.getTICKETID()))) &&
            ((this.TICKETSPEC==null && other.getTICKETSPEC()==null) || 
             (this.TICKETSPEC!=null &&
              java.util.Arrays.equals(this.TICKETSPEC, other.getTICKETSPEC()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              java.util.Arrays.equals(this.DOCLINKS, other.getDOCLINKS()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getAFFECTEDPERSON() != null) {
            _hashCode += getAFFECTEDPERSON().hashCode();
        }
        if (getCLASS() != null) {
            _hashCode += getCLASS().hashCode();
        }
        if (getCLASSIFICATIONID() != null) {
            _hashCode += getCLASSIFICATIONID().hashCode();
        }
        if (getCLASSSTRUCTUREID() != null) {
            _hashCode += getCLASSSTRUCTUREID().hashCode();
        }
        if (getCREATEDBY() != null) {
            _hashCode += getCREATEDBY().hashCode();
        }
        if (getCREATIONDATE() != null) {
            _hashCode += getCREATIONDATE().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getDESCRIPTION_LONGDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION_LONGDESCRIPTION().hashCode();
        }
        if (getEXTERNALSYSTEM() != null) {
            _hashCode += getEXTERNALSYSTEM().hashCode();
        }
        if (getITAU_GDISPOK() != null) {
            _hashCode += getITAU_GDISPOK().hashCode();
        }
        if (getITAU_GIQAGNSOK() != null) {
            _hashCode += getITAU_GIQAGNSOK().hashCode();
        }
        if (getITAU_GNSOK() != null) {
            _hashCode += getITAU_GNSOK().hashCode();
        }
        if (getREPORTDATE() != null) {
            _hashCode += getREPORTDATE().hashCode();
        }
        if (getREPORTEDBY() != null) {
            _hashCode += getREPORTEDBY().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        if (getTICKETID() != null) {
            _hashCode += getTICKETID().hashCode();
        }
        if (getTICKETSPEC() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETSPEC());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETSPEC(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOCLINKS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDOCLINKS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDOCLINKS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSR_SRType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSR_SRType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AFFECTEDPERSON");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "AFFECTEDPERSON"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);

        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOCATION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LOCATION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);

        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AFFECTEDPHONE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "AFFECTEDPHONE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        
        
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSIFICATIONID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSIFICATIONID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATIONDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATIONDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION_LONGDESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION_LONGDESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EXTERNALSYSTEM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "EXTERNALSYSTEM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GDISPOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GDISPOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GIQAGNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GIQAGNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSR_TICKETSPECType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSR_DOCLINKSType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
