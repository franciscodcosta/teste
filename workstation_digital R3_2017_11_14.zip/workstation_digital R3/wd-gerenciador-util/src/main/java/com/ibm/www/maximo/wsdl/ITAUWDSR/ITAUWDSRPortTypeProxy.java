package com.ibm.www.maximo.wsdl.ITAUWDSR;

public class ITAUWDSRPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRPortType iTAUWDSRPortType = null;
  
  public ITAUWDSRPortTypeProxy() {
    _initITAUWDSRPortTypeProxy();
  }
  
  public ITAUWDSRPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDSRPortTypeProxy();
  }
  
  private void _initITAUWDSRPortTypeProxy() {
    try {
      iTAUWDSRPortType = (new com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRLocator()).getITAUWDSRSOAP11Port();
      if (iTAUWDSRPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDSRPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDSRPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDSRPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDSRPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDSR.ITAUWDSRPortType getITAUWDSRPortType() {
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDSRResponseType queryITAUWDSR(com.ibm.www.maximo.QueryITAUWDSRType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType.queryITAUWDSR(parameters);
  }
  
  public com.ibm.www.maximo.SyncITAUWDSRResponseType syncITAUWDSR(com.ibm.www.maximo.SyncITAUWDSRType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType.syncITAUWDSR(parameters);
  }
  
  public com.ibm.www.maximo.UpdateITAUWDSRResponseType updateITAUWDSR(com.ibm.www.maximo.UpdateITAUWDSRType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType.updateITAUWDSR(parameters);
  }
  
  public com.ibm.www.maximo.CreateITAUWDSRResponseType createITAUWDSR(com.ibm.www.maximo.CreateITAUWDSRType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType.createITAUWDSR(parameters);
  }
  
  public com.ibm.www.maximo.DeleteITAUWDSRResponseType deleteITAUWDSR(com.ibm.www.maximo.DeleteITAUWDSRType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRPortType == null)
      _initITAUWDSRPortTypeProxy();
    return iTAUWDSRPortType.deleteITAUWDSR(parameters);
  }
  
  
}