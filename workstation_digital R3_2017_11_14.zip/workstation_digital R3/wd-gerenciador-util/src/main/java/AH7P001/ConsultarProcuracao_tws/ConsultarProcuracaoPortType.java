/**
 * ConsultarProcuracaoPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package AH7P001.ConsultarProcuracao_tws;

public interface ConsultarProcuracaoPortType extends java.rmi.Remote {
    public void consultarProcuracaoWorkstation(int idProcuracao, java.lang.String funcionalAprovador, java.lang.String usuarioAcesso, java.lang.String tokenAcesso, AH7P001.ConsultarProcuracao_tws.holders.ResumoProcuracaoWorkstationHolder resultadoConsulta, javax.xml.rpc.holders.IntHolder codigoRetorno, javax.xml.rpc.holders.StringHolder mensagemRetorno) throws java.rmi.RemoteException;
}
