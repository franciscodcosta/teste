package br.com.itau.WorkstationDigital.SolicitacaoViagens;

public class SI_SolicitacaoViagens_sync_outProxy implements br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_out {
  private String _endpoint = null;
  private br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_out sI_SolicitacaoViagens_sync_out = null;
  
  public SI_SolicitacaoViagens_sync_outProxy() {
    _initSI_SolicitacaoViagens_sync_outProxy();
  }
  
  public SI_SolicitacaoViagens_sync_outProxy(String endpoint) {
    _endpoint = endpoint;
    _initSI_SolicitacaoViagens_sync_outProxy();
  }
  
  private void _initSI_SolicitacaoViagens_sync_outProxy() {
    try {
      sI_SolicitacaoViagens_sync_out = (new br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_outServiceLocator()).getHTTPS_Port();
      if (sI_SolicitacaoViagens_sync_out != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sI_SolicitacaoViagens_sync_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sI_SolicitacaoViagens_sync_out)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sI_SolicitacaoViagens_sync_out != null)
      ((javax.xml.rpc.Stub)sI_SolicitacaoViagens_sync_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_out getSI_SolicitacaoViagens_sync_out() {
    if (sI_SolicitacaoViagens_sync_out == null)
      _initSI_SolicitacaoViagens_sync_outProxy();
    return sI_SolicitacaoViagens_sync_out;
  }
  
  public br.com.itau.WorkstationDigital.SolicitacaoViagens.DT_SolicitacaoViagens_response SI_SolicitacaoViagens_sync_out(br.com.itau.WorkstationDigital.SolicitacaoViagens.DT_SolicitacaoViagens MT_SolicitacaoViagens) throws java.rmi.RemoteException{
    if (sI_SolicitacaoViagens_sync_out == null)
      _initSI_SolicitacaoViagens_sync_outProxy();
    return sI_SolicitacaoViagens_sync_out.SI_SolicitacaoViagens_sync_out(MT_SolicitacaoViagens);
  }
  
  
}