package br.com.itau.wd.gerenciador.exception;


public class GerenciadorErrorInfo {
    
	private Erro erro;
	
	public GerenciadorErrorInfo() {
		// Construtor Default
	}
	
	public GerenciadorErrorInfo(String url, String message) {
		this.erro = new Erro(url, message);
	}
	
	public Erro getErro() {
		return erro;
	}

	public void setErro(Erro erro) {
		this.erro = erro;
	}

	public class Erro {

	    private String servico;
	    private String mensagem;

	    public Erro() {
	    	// Construtor Default
	    }
	    
	    public Erro(String servico, String mensagem) {
	        this.servico = servico;
	        this.mensagem = mensagem;
	    }

		public String getServico() {
			return servico;
		}

		public void setServico(String servico) {
			this.servico = servico;
		}

		public String getMensagem() {
			return mensagem;
		}

		public void setMensagem(String mensagem) {
			this.mensagem = mensagem;
		}
	}
}