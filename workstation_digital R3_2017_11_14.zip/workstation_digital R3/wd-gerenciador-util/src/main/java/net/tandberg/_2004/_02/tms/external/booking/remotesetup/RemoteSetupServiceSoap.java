/**
 * RemoteSetupServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking.remotesetup;

public interface RemoteSetupServiceSoap extends java.rmi.Remote {

    /**
     * Used to set a specific endpoint as a primary system for the
     * logged-in user. Returns true if the primary system was successfully
     * set for the current user.
     */
    public boolean setPrimarySystem(java.lang.String primSys) throws java.rmi.RemoteException;

    /**
     * Returns all users registered in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.User[] getUsers() throws java.rmi.RemoteException;

    /**
     * Returns all endpoints and rooms that can be booked by the current
     * user.
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem[] getSystemsForUser() throws java.rmi.RemoteException;

    /**
     * Returns all endpoints and rooms registered in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem[] getSystems() throws java.rmi.RemoteException;

    /**
     * Returns information about a specific system.
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem getSystemById(long TMSSystemId) throws java.rmi.RemoteException;

    /**
     * Generates a Cisco TMS Booking API account.
     */
    public java.lang.String generateConferenceAPIUser(java.lang.String userNameBase, java.lang.String encPassword, java.lang.String emailAddress, boolean sendNotifications) throws java.rmi.RemoteException;

    /**
     * Disable a ConferenceAPI user.
     */
    public void disableConferenceAPIUser(java.lang.String userName) throws java.rmi.RemoteException;

    /**
     * Checks the connection to the web services of Cisco TMS.
     */
    public boolean isAlive() throws java.rmi.RemoteException;

    /**
     * Checks whether the current user is a member of the Cisco TMS
     * Site Administrators group.
     */
    public boolean isTMSSiteAdmin() throws java.rmi.RemoteException;

    /**
     * Checks whether the current user is flagged as an Exchange Integration
     * user and has access to book on behalf of other users.
     */
    public boolean isTMSServiceUser() throws java.rmi.RemoteException;

    /**
     * Checks whether the current user is a member of a Cisco TMS
     * group that has permissions to book on behalf of other users.
     */
    public boolean isTMSBookOnBehalfUser() throws java.rmi.RemoteException;

    /**
     * Checks whether the specified user (not the current user) is
     * a member of a Cisco TMS group that has permissions to book on behalf
     * of other users.
     */
    public boolean isBookOnBehalfOfUser(net.tandberg._2004._02.tms.external.booking.remotesetup.User user) throws java.rmi.RemoteException;

    /**
     * Checks whether the current user can create local or Active
     * Directory accounts in the default user container on the Cisco TMS
     * server.
     */
    public boolean isLocalAdmin() throws java.rmi.RemoteException;

    /**
     * Returns an array of Language objects.
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.Language[] getConferenceLanguages() throws java.rmi.RemoteException;
}
