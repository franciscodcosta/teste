/**
 * TimeChange.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class TimeChange  implements java.io.Serializable {
    private int changeSecondAtDay;

    private net.tandberg._2004._02.tms.external.booking.TimeChangeAbsoluteRule absoluteRule;

    private net.tandberg._2004._02.tms.external.booking.TimeChangeRelativeRule relativeRule;

    public TimeChange() {
    }

    public TimeChange(
           int changeSecondAtDay,
           net.tandberg._2004._02.tms.external.booking.TimeChangeAbsoluteRule absoluteRule,
           net.tandberg._2004._02.tms.external.booking.TimeChangeRelativeRule relativeRule) {
           this.changeSecondAtDay = changeSecondAtDay;
           this.absoluteRule = absoluteRule;
           this.relativeRule = relativeRule;
    }


    /**
     * Gets the changeSecondAtDay value for this TimeChange.
     * 
     * @return changeSecondAtDay
     */
    public int getChangeSecondAtDay() {
        return changeSecondAtDay;
    }


    /**
     * Sets the changeSecondAtDay value for this TimeChange.
     * 
     * @param changeSecondAtDay
     */
    public void setChangeSecondAtDay(int changeSecondAtDay) {
        this.changeSecondAtDay = changeSecondAtDay;
    }


    /**
     * Gets the absoluteRule value for this TimeChange.
     * 
     * @return absoluteRule
     */
    public net.tandberg._2004._02.tms.external.booking.TimeChangeAbsoluteRule getAbsoluteRule() {
        return absoluteRule;
    }


    /**
     * Sets the absoluteRule value for this TimeChange.
     * 
     * @param absoluteRule
     */
    public void setAbsoluteRule(net.tandberg._2004._02.tms.external.booking.TimeChangeAbsoluteRule absoluteRule) {
        this.absoluteRule = absoluteRule;
    }


    /**
     * Gets the relativeRule value for this TimeChange.
     * 
     * @return relativeRule
     */
    public net.tandberg._2004._02.tms.external.booking.TimeChangeRelativeRule getRelativeRule() {
        return relativeRule;
    }


    /**
     * Sets the relativeRule value for this TimeChange.
     * 
     * @param relativeRule
     */
    public void setRelativeRule(net.tandberg._2004._02.tms.external.booking.TimeChangeRelativeRule relativeRule) {
        this.relativeRule = relativeRule;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TimeChange)) return false;
        TimeChange other = (TimeChange) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.changeSecondAtDay == other.getChangeSecondAtDay() &&
            ((this.absoluteRule==null && other.getAbsoluteRule()==null) || 
             (this.absoluteRule!=null &&
              this.absoluteRule.equals(other.getAbsoluteRule()))) &&
            ((this.relativeRule==null && other.getRelativeRule()==null) || 
             (this.relativeRule!=null &&
              this.relativeRule.equals(other.getRelativeRule())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getChangeSecondAtDay();
        if (getAbsoluteRule() != null) {
            _hashCode += getAbsoluteRule().hashCode();
        }
        if (getRelativeRule() != null) {
            _hashCode += getRelativeRule().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TimeChange.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChange"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("changeSecondAtDay");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ChangeSecondAtDay"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("absoluteRule");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "AbsoluteRule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChangeAbsoluteRule"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("relativeRule");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RelativeRule"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChangeRelativeRule"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
