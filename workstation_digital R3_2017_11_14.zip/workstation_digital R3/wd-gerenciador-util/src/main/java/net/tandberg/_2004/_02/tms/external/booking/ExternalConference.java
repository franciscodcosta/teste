/**
 * ExternalConference.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class ExternalConference  implements java.io.Serializable {
    private net.tandberg._2004._02.tms.external.booking.WebEx webEx;

    private net.tandberg._2004._02.tms.external.booking.ExternalHost externallyHosted;

    private net.tandberg._2004._02.tms.external.booking.WebExState webExState;

    public ExternalConference() {
    }

    public ExternalConference(
           net.tandberg._2004._02.tms.external.booking.WebEx webEx,
           net.tandberg._2004._02.tms.external.booking.ExternalHost externallyHosted,
           net.tandberg._2004._02.tms.external.booking.WebExState webExState) {
           this.webEx = webEx;
           this.externallyHosted = externallyHosted;
           this.webExState = webExState;
    }


    /**
     * Gets the webEx value for this ExternalConference.
     * 
     * @return webEx
     */
    public net.tandberg._2004._02.tms.external.booking.WebEx getWebEx() {
        return webEx;
    }


    /**
     * Sets the webEx value for this ExternalConference.
     * 
     * @param webEx
     */
    public void setWebEx(net.tandberg._2004._02.tms.external.booking.WebEx webEx) {
        this.webEx = webEx;
    }


    /**
     * Gets the externallyHosted value for this ExternalConference.
     * 
     * @return externallyHosted
     */
    public net.tandberg._2004._02.tms.external.booking.ExternalHost getExternallyHosted() {
        return externallyHosted;
    }


    /**
     * Sets the externallyHosted value for this ExternalConference.
     * 
     * @param externallyHosted
     */
    public void setExternallyHosted(net.tandberg._2004._02.tms.external.booking.ExternalHost externallyHosted) {
        this.externallyHosted = externallyHosted;
    }


    /**
     * Gets the webExState value for this ExternalConference.
     * 
     * @return webExState
     */
    public net.tandberg._2004._02.tms.external.booking.WebExState getWebExState() {
        return webExState;
    }


    /**
     * Sets the webExState value for this ExternalConference.
     * 
     * @param webExState
     */
    public void setWebExState(net.tandberg._2004._02.tms.external.booking.WebExState webExState) {
        this.webExState = webExState;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ExternalConference)) return false;
        ExternalConference other = (ExternalConference) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.webEx==null && other.getWebEx()==null) || 
             (this.webEx!=null &&
              this.webEx.equals(other.getWebEx()))) &&
            ((this.externallyHosted==null && other.getExternallyHosted()==null) || 
             (this.externallyHosted!=null &&
              this.externallyHosted.equals(other.getExternallyHosted()))) &&
            ((this.webExState==null && other.getWebExState()==null) || 
             (this.webExState!=null &&
              this.webExState.equals(other.getWebExState())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWebEx() != null) {
            _hashCode += getWebEx().hashCode();
        }
        if (getExternallyHosted() != null) {
            _hashCode += getExternallyHosted().hashCode();
        }
        if (getWebExState() != null) {
            _hashCode += getWebExState().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ExternalConference.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConference"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webEx");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebEx"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebEx"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externallyHosted");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternallyHosted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalHost"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webExState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExState"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
