/**
 * BookingServiceSoapStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class BookingServiceSoapStub extends org.apache.axis.client.Stub implements net.tandberg._2004._02.tms.external.booking.BookingServiceSoap {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[27];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetDefaultConference");
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetDefaultConferenceResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferencesForSystems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SystemIds"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceStatus"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceStatus"), net.tandberg._2004._02.tms.external.booking.ConferenceStatus.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferencesForSystemsResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferencesForUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "UserName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "StartTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EndTime"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"), java.util.Calendar.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceStatus"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceStatus"), net.tandberg._2004._02.tms.external.booking.ConferenceStatus.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferencesForUserResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceByIdResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRecurrentConferenceById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecurrentConferenceByIdResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecurrentConferenceByIdWithFirstOngoingOrPendingStartTimeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceIdByExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        oper.setReturnClass(int.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceIdByExternalIdResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceByExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceByExternalIdResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceInstanceByExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceInstanceByExternalIdResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SaveConferenceWithMode");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BookingMode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BookingMode"), net.tandberg._2004._02.tms.external.booking.BookingMode.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceResult"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.SaveConferenceResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceWithModeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SaveConference");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SaveConferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conferences"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "oneTransaction"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferencesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SaveConferenceRecInstance");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Conference.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceRecInstanceResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SaveConferenceRecInstanceWithMode");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BookingMode"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BookingMode"), net.tandberg._2004._02.tms.external.booking.BookingMode.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceResult"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.SaveConferenceResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceRecInstanceWithModeResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("EndConferenceById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("EndConferenceByExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteConferenceById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteConferenceRecInstanceById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteConferenceByExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteConferenceInstanceByExternaId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTransactionsSince");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "CurrentTransactionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfTransaction"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.Transaction[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTransactionsSinceResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Transaction"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTransactionsSinceWithExternalId");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "CurrentTransactionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"), long.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConferenceTransaction"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTransactionsSinceWithExternalIdResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTransaction"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetRecordingAliases");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "UserName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfRecordingDevice"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.RecordingDevice[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecordingAliasesResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecordingDevice"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceInviteMail");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConferenceId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Messages"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TypedMailMessage"), net.tandberg._2004._02.tms.external.booking.TypedMailMessage[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ContentTypes"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailContentType"), net.tandberg._2004._02.tms.external.booking.MailContentType[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Language"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConferenceMail"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.ConferenceMail[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceInviteMailResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetConferenceBookingEventMail");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"), net.tandberg._2004._02.tms.external.booking.Conference.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Message"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TypedMailMessage"), net.tandberg._2004._02.tms.external.booking.TypedMailMessage.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ContentTypes"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailContentType"), net.tandberg._2004._02.tms.external.booking.MailContentType[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Language"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConferenceMail"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.ConferenceMail[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceBookingEventMailResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetWebExSiteDefaults");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "siteUrl"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExSiteDefaults"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetWebExSiteDefaultsResult"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTimeZoneRulesById");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "idString"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfTimeZoneRule"));
        oper.setReturnClass(net.tandberg._2004._02.tms.external.booking.TimeZoneRule[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTimeZoneRulesByIdResult"));
        param = oper.getReturnParamDesc();
        param.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[26] = oper;

    }

    public BookingServiceSoapStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public BookingServiceSoapStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public BookingServiceSoapStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "AliasInfo");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.AliasInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfAliasInfo");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.AliasInfo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "AliasInfo");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "AliasInfo");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConference");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Conference[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConferenceMail");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceMail[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfConferenceTransaction");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTransaction");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTransaction");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfDayOfWeek");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.DayOfWeek[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfParticipant");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Participant[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfRecordingDevice");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecordingDevice[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecordingDevice");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecordingDevice");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfRecurrenceException");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecurrenceException[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "string");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfTimeZoneRule");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TimeZoneRule[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfTransaction");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Transaction[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Transaction");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Transaction");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfWebExError");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExError[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExError");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExError");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ArrayOfWebExWarning");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExWarning[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning");
            qName2 = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Bandwidth");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Bandwidth.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BandwidthOverride");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.BandwidthOverride.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BookingMode");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.BookingMode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Conference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceMail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceState");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceState.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceStatus");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTransaction");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceTransaction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ConferenceType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DataConferenceMode");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.DataConferenceMode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.DayOfWeek.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ElementsPossibleToExcludeInEmail");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(simplelistsf);
            cachedDeserFactories.add(simplelistdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EncryptionRequested");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.EncryptionRequested.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExceptionIdRange");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ExceptionIdRange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExceptionType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ExceptionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExtendOptionRequested");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ExtendOptionRequested.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConference");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ExternalConference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalHost");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ExternalHost.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailContentType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.MailContentType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailMessage");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.MailMessage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailMessageType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.MailMessageType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Participant.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.ParticipantType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PictureMode");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.PictureMode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecordingDevice");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecordingDevice.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceEndType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecurrenceEndType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecurrenceException.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrencePattern");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecurrencePattern.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurringFrequency");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.RecurringFrequency.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceResult");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.SaveConferenceResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChange");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TimeChange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChangeAbsoluteRule");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TimeChangeAbsoluteRule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChangeRelativeRule");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TimeChangeRelativeRule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TimeZoneRule.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Transaction");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.Transaction.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransactionType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TransactionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TypedMailMessage");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.TypedMailMessage.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebEx");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebEx.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExError");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExError.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExInstanceType");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExInstanceType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExSiteDefaults");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExState");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExState.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExTelephony");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExTelephony.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning");
            cachedSerQNames.add(qName);
            cls = net.tandberg._2004._02.tms.external.booking.WebExWarning.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getDefaultConference() throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetDefaultConference");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetDefaultConference"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForSystems(int[] systemIds, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferencesForSystems");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferencesForSystems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {systemIds, startTime, endTime, conferenceStatus});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForUser(java.lang.String userName, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferencesForUser");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferencesForUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName, startTime, endTime, conferenceStatus});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceById(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceById(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetRecurrentConferenceById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecurrentConferenceById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public int getConferenceIdByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceIdByExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceIdByExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId, recurrenceIdUTC});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Integer) _resp).intValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Integer) org.apache.axis.utils.JavaUtils.convert(_resp, int.class)).intValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceByExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceByExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceInstanceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceInstanceByExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceInstanceByExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId, recurrenceIdUTC});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/SaveConferenceWithMode");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceWithMode"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conference, bookingMode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.SaveConferenceResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.SaveConferenceResult) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.SaveConferenceResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference saveConference(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/SaveConference");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConference"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conference});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference[] saveConferences(net.tandberg._2004._02.tms.external.booking.Conference[] conferences, boolean oneTransaction) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/SaveConferences");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conferences, new java.lang.Boolean(oneTransaction)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Conference saveConferenceRecInstance(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/SaveConferenceRecInstance");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceRecInstance"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conference});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Conference) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Conference) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Conference.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceRecInstanceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/SaveConferenceRecInstanceWithMode");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SaveConferenceRecInstanceWithMode"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conference, bookingMode});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.SaveConferenceResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.SaveConferenceResult) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.SaveConferenceResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void endConferenceById(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/EndConferenceById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EndConferenceById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void endConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/EndConferenceByExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EndConferenceByExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId, recurrenceIdUTC});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void deleteConferenceById(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/DeleteConferenceById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DeleteConferenceById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void deleteConferenceRecInstanceById(int conferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/DeleteConferenceRecInstanceById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DeleteConferenceRecInstanceById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(conferenceId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void deleteConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/DeleteConferenceByExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DeleteConferenceByExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public void deleteConferenceInstanceByExternaId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/DeleteConferenceInstanceByExternaId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DeleteConferenceInstanceByExternaId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId, recurrenceIdUTC});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.Transaction[] getTransactionsSince(int currentTransactionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetTransactionsSince");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTransactionsSince"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Integer(currentTransactionId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.Transaction[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.Transaction[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.Transaction[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[] getTransactionsSinceWithExternalId(long currentTransactionId) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetTransactionsSinceWithExternalId");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTransactionsSinceWithExternalId"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {new java.lang.Long(currentTransactionId)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.RecordingDevice[] getRecordingAliases(java.lang.String userName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetRecordingAliases");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetRecordingAliases"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {userName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.RecordingDevice[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.RecordingDevice[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.RecordingDevice[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceInviteMail(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC, net.tandberg._2004._02.tms.external.booking.TypedMailMessage[] messages, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceInviteMail");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceInviteMail"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {externalSourceId, externalConferenceId, recurrenceIdUTC, messages, contentTypes, language});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceMail[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceMail[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.ConferenceMail[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceBookingEventMail(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.TypedMailMessage message, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetConferenceBookingEventMail");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetConferenceBookingEventMail"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {conference, message, contentTypes, language});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceMail[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.ConferenceMail[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.ConferenceMail[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults getWebExSiteDefaults(java.lang.String siteUrl) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetWebExSiteDefaults");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetWebExSiteDefaults"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {siteUrl});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] getTimeZoneRulesById(java.lang.String idString) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://tandberg.net/2004/02/tms/external/booking/GetTimeZoneRulesById");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GetTimeZoneRulesById"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {idString});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (net.tandberg._2004._02.tms.external.booking.TimeZoneRule[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (net.tandberg._2004._02.tms.external.booking.TimeZoneRule[]) org.apache.axis.utils.JavaUtils.convert(_resp, net.tandberg._2004._02.tms.external.booking.TimeZoneRule[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
