/**
 * Transaction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class Transaction  implements java.io.Serializable {
    private int transactionId;

    private int conferenceId;

    private net.tandberg._2004._02.tms.external.booking.TransactionType transType;

    private int performedByUserId;

    private java.lang.String participantIds;

    public Transaction() {
    }

    public Transaction(
           int transactionId,
           int conferenceId,
           net.tandberg._2004._02.tms.external.booking.TransactionType transType,
           int performedByUserId,
           java.lang.String participantIds) {
           this.transactionId = transactionId;
           this.conferenceId = conferenceId;
           this.transType = transType;
           this.performedByUserId = performedByUserId;
           this.participantIds = participantIds;
    }


    /**
     * Gets the transactionId value for this Transaction.
     * 
     * @return transactionId
     */
    public int getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this Transaction.
     * 
     * @param transactionId
     */
    public void setTransactionId(int transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the conferenceId value for this Transaction.
     * 
     * @return conferenceId
     */
    public int getConferenceId() {
        return conferenceId;
    }


    /**
     * Sets the conferenceId value for this Transaction.
     * 
     * @param conferenceId
     */
    public void setConferenceId(int conferenceId) {
        this.conferenceId = conferenceId;
    }


    /**
     * Gets the transType value for this Transaction.
     * 
     * @return transType
     */
    public net.tandberg._2004._02.tms.external.booking.TransactionType getTransType() {
        return transType;
    }


    /**
     * Sets the transType value for this Transaction.
     * 
     * @param transType
     */
    public void setTransType(net.tandberg._2004._02.tms.external.booking.TransactionType transType) {
        this.transType = transType;
    }


    /**
     * Gets the performedByUserId value for this Transaction.
     * 
     * @return performedByUserId
     */
    public int getPerformedByUserId() {
        return performedByUserId;
    }


    /**
     * Sets the performedByUserId value for this Transaction.
     * 
     * @param performedByUserId
     */
    public void setPerformedByUserId(int performedByUserId) {
        this.performedByUserId = performedByUserId;
    }


    /**
     * Gets the participantIds value for this Transaction.
     * 
     * @return participantIds
     */
    public java.lang.String getParticipantIds() {
        return participantIds;
    }


    /**
     * Sets the participantIds value for this Transaction.
     * 
     * @param participantIds
     */
    public void setParticipantIds(java.lang.String participantIds) {
        this.participantIds = participantIds;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Transaction)) return false;
        Transaction other = (Transaction) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.transactionId == other.getTransactionId() &&
            this.conferenceId == other.getConferenceId() &&
            ((this.transType==null && other.getTransType()==null) || 
             (this.transType!=null &&
              this.transType.equals(other.getTransType()))) &&
            this.performedByUserId == other.getPerformedByUserId() &&
            ((this.participantIds==null && other.getParticipantIds()==null) || 
             (this.participantIds!=null &&
              this.participantIds.equals(other.getParticipantIds())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getTransactionId();
        _hashCode += getConferenceId();
        if (getTransType() != null) {
            _hashCode += getTransType().hashCode();
        }
        _hashCode += getPerformedByUserId();
        if (getParticipantIds() != null) {
            _hashCode += getParticipantIds().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Transaction.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Transaction"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransactionType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("performedByUserId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PerformedByUserId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participantIds");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
