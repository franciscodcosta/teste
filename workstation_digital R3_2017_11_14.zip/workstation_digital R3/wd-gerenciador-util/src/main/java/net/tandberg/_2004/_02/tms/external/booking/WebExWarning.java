/**
 * WebExWarning.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class WebExWarning  implements java.io.Serializable {
    private java.lang.String warningCode;

    private java.lang.String warningDescription;

    public WebExWarning() {
    }

    public WebExWarning(
           java.lang.String warningCode,
           java.lang.String warningDescription) {
           this.warningCode = warningCode;
           this.warningDescription = warningDescription;
    }


    /**
     * Gets the warningCode value for this WebExWarning.
     * 
     * @return warningCode
     */
    public java.lang.String getWarningCode() {
        return warningCode;
    }


    /**
     * Sets the warningCode value for this WebExWarning.
     * 
     * @param warningCode
     */
    public void setWarningCode(java.lang.String warningCode) {
        this.warningCode = warningCode;
    }


    /**
     * Gets the warningDescription value for this WebExWarning.
     * 
     * @return warningDescription
     */
    public java.lang.String getWarningDescription() {
        return warningDescription;
    }


    /**
     * Sets the warningDescription value for this WebExWarning.
     * 
     * @param warningDescription
     */
    public void setWarningDescription(java.lang.String warningDescription) {
        this.warningDescription = warningDescription;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WebExWarning)) return false;
        WebExWarning other = (WebExWarning) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.warningCode==null && other.getWarningCode()==null) || 
             (this.warningCode!=null &&
              this.warningCode.equals(other.getWarningCode()))) &&
            ((this.warningDescription==null && other.getWarningDescription()==null) || 
             (this.warningDescription!=null &&
              this.warningDescription.equals(other.getWarningDescription())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWarningCode() != null) {
            _hashCode += getWarningCode().hashCode();
        }
        if (getWarningDescription() != null) {
            _hashCode += getWarningDescription().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WebExWarning.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("warningCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WarningCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("warningDescription");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WarningDescription"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
