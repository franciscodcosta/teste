package br.com.itau.wd.gerenciador.sep.service;

import static br.com.itau.wd.gerenciador.sep.util.Constants.MSG_ERRO_SEP_SERVICO_INEXISTENTE;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_SIGLA_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.SERVICO_CONSULTA_PENDENCIA;
import static br.com.itau.wd.gerenciador.util.Constants.SERVICO_NOTIFICACAO;
import static br.com.itau.wd.gerenciador.util.Constants.SERVICO_REGISTRAR_ACAO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.io.IOException;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import br.com.itau.wd.gerenciador.sep.dao.ServicoDao;
import br.com.itau.wd.gerenciador.sep.dto.ChaveDto;
import br.com.itau.wd.gerenciador.sep.dto.DadosDto;
import br.com.itau.wd.gerenciador.sep.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * <b>Serviço SEP</b>
 * Faz a orquestração das requisições recebidas
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Service
public class SEPService {

	private static final Logger logger = LoggerFactory.getLogger(SEPService.class);

	@Autowired
	ServicoDao dao;

	@Autowired
	HCSService hcsService;

	@Autowired
	KMSService kmsService;

	@Autowired
	SRService srService;

	@Resource
	private Environment env;

	/**
	 * Faz a orquestração das requisições recebidas
	 * 
	 * @param servico
	 * @param jsonRequisicao
	 * @param token
	 * @return
	 * @throws SEPException 
	 */
	public String executarServico(String servico, String jsonRequisicao, String token) throws SEPException {

		String jsonResposta;

		logger.info("***** SERVICE ENTRY POINT (SEP) *****");
		logger.info("SERVICO ........................ : " + servico);
		logger.info("JSON ........................... : " + jsonRequisicao);
		logger.info("TOKEN .......................... : " + token);

		// Obtém os dados do sistema
		DadosDto dados = obterDadosServico(servico, jsonRequisicao, token);

		logger.info("CHAVE EXTERNA .................. : " + dados.getChave().getChaveExterna());
		logger.info("CHAVE PRODUTO .................. : " + dados.getChave().getChaveProduto());
		logger.info("CODIGO SERVIÇO ................. : " + dados.getChave().getCodigoServico());
		logger.info("FUNCAO ATIVIDADE SISTEMA PRODUTO : " + dados.getChave().getFuncaoAtividadeSistemaProduto());
		logger.info("FUNCAO SISTEMA PRODUTO ......... : " + dados.getChave().getFuncaoSistemaProduto());
		logger.info("FUNCIONAL SISTEMA PRODUTO ...... : " + dados.getChave().getFuncionalSistemaProduto());
		logger.info("SIGLA SISTEMA .................. : " + dados.getEndpoint().getSiglaSistema());
		logger.info("URL SERVICO .................... : " + dados.getEndpoint().getUrlServico());
		logger.info("URL SERVICO NEGOCIO ............ : " + dados.getEndpoint().getUrlServicoNegocio());
		logger.info("SALVA KMS ...................... : " + dados.getEndpoint().isSalvaKms());
		logger.info("CONSULTA KMS ................... : " + dados.getEndpoint().isConsultaKms());

		// Verificar se o serviço esta disponível
		Boolean disponivel = hcsService.obterDisponibilidade(dados);
		
		logger.info("***** HEALTH CHECKER SERVICE (HCS) *****");
		logger.info("DISPONIBILIDADE ................ : " + disponivel);

		// Criar ou consultar a chave
		kmsService.verificarChave(dados);

		logger.info("***** KEY MANAGEMENT SERVICE (KMS) *****");

		// Envia os dados para processamento
		jsonResposta = srService.enviarDados(dados);

		logger.info("DADOS SAIDA");
		logger.info("JSON = " + jsonResposta);

		return jsonResposta;
	}

	/**
	 * Obtem os dados do serviço
	 * 
	 * @param servico
	 * @param json
	 * @param token
	 * @return
	 * @throws SEPException
	 */
	private DadosDto obterDadosServico(String servico, String json, String token) throws SEPException {
	
		DadosDto dadosDto = new DadosDto();

		// Obtém a descrição do serviço
		obterDescricaoServico(dadosDto, servico);
		
		// Obtém os dados do JSON e serviço
		obterDadosJson(dadosDto, json);

		// Se o token é enviado, adiciona ao mapa
		obterToken(dadosDto, token);

		// Obtém os dados da chave do serviço
		obterDadosChave(dadosDto);

		// Obtém o endpoint do serviço
		obterDadosEndpoint(dadosDto);
		
		return dadosDto;
	}
	
	/**
	 * Obtém a descrição do serviço
	 * 
	 * @param dadosDto
	 * @param servico
	 */
	private void obterDescricaoServico(DadosDto dadosDto, String servico) {
		
		dadosDto.setDescricaoServico(servico);
	}
	
	/**
	 * Obtem os dados do JSON
	 * 
	 * @param dadosDto
	 * @param json
	 * @throws SEPException
	 */
	private void obterDadosJson(DadosDto dadosDto, String json) throws SEPException {
		
		try {
			// Converte o JSON para o mapa
			Map<String, Object> dados = GerenciadorUtils.convertJsonToMapWd(json);
	
			dadosDto.setDados(dados);
		}
		catch (IOException ex) {
			
			throw new SEPException(ex);
		}
	}

	/**
	 * Verifica se o token é enviado
	 * 
	 * @param token
	 * @param dados
	 */
	private void obterToken(DadosDto dadosDto, String token) {
		
		// Se o token é enviado, adiciona ao mapa
		if (token != null && !STRING_EMPTY.equals(StringUtils.trimWhitespace(token))) {
			dadosDto.getDados().put(JSON_KEY_TOKEN, token);
		}
	}
	
	/**
	 * Obtém os dados do chave do serviço
	 * 
	 * @param dadosDto
	 * @throws SEPException 
	 */
	private void obterDadosChave(DadosDto dadosDto) throws SEPException {

		// Extrai as informações do JSON
		String chaveExterna = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_UID);
		String chaveProduto = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_CHAVE_PRODUTO);
		String siglaSistemaProduto = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_SIGLA_SISTEMA_PRODUTO);
		String funcionalSistemaProduto = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
		String funcaoSistemaProduto = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		String funcaoAtividadeSistemaProduto = GerenciadorUtils.obterDadoMap(dadosDto.getDados(), JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);

		dadosDto.getChave().setChaveExterna(chaveExterna);
		dadosDto.getChave().setChaveProduto(chaveProduto);
		dadosDto.getChave().setSiglaSistemaProduto(siglaSistemaProduto);
		dadosDto.getChave().setFuncaoSistemaProduto(funcaoSistemaProduto);
		dadosDto.getChave().setFuncaoAtividadeSistemaProduto(funcaoAtividadeSistemaProduto);
		dadosDto.getChave().setFuncionalSistemaProduto(funcionalSistemaProduto);
		
		// Obtém o código do serviço
		obterCodigoServico(dadosDto);
	}
	
	/**
	 * Obtem o endpoint do serviço
	 * 
	 * @param dadosDto
	 * @throws SEPException
	 */
	private void obterDadosEndpoint(DadosDto dadosDto) throws SEPException {
		
		// Executa o SR para obter as informações do endpoint
		EndpointDto endpointDto = srService.obterEndpoint(dadosDto);

		dadosDto.getEndpoint().setCodigoServico(endpointDto.getCodigoServico());
		dadosDto.getEndpoint().setConsultaKms(endpointDto.isConsultaKms());
		dadosDto.getEndpoint().setSalvaKms(endpointDto.isSalvaKms());
		dadosDto.getEndpoint().setSiglaSistema(endpointDto.getSiglaSistema());
		dadosDto.getEndpoint().setUrlServico(endpointDto.getUrlServico());
		dadosDto.getEndpoint().setUrlServicoNegocio(endpointDto.getUrlServicoNegocio());
	}
	
	/**
	 * Obtém o código do serviço a partir da descrição do serviço
	 * 
	 * @param dadosDto
	 * @param siglaSistemaProduto
	 * @param chaveExterna
	 * @return
	 * @throws SEPException
	 */
	private void obterCodigoServico(DadosDto dadosDto) throws SEPException {

		String descricaoServico = STRING_EMPTY;
		String codigoServico = STRING_EMPTY;

		try {

			switch(dadosDto.getDescricaoServico()) {

				case SERVICO_NOTIFICACAO:

					descricaoServico = obterDescricaoServicoNotificacao(dadosDto);
					break;

				case SERVICO_CONSULTA_PENDENCIA:
				case SERVICO_REGISTRAR_ACAO:	

					descricaoServico = obterDescricaoServicoConsulta(dadosDto);
					break;

				default:
					
					//Este serviço não depende da sigla do sistema produto
					descricaoServico = dadosDto.getDescricaoServico();
			}

			codigoServico = env.getRequiredProperty(descricaoServico.toLowerCase());
			dadosDto.getChave().setCodigoServico(codigoServico);
		}
		catch (IllegalStateException ex) {
			
			throw new SEPException(MSG_ERRO_SEP_SERVICO_INEXISTENTE, ex);
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}
	}
	
	/**
	 * Retorna a descrição do serviço de notificação
	 * 
	 * @param dadosDto
	 * @return
	 */
	private String obterDescricaoServicoNotificacao(DadosDto dadosDto) {
		
		//O serviço de notificação depende da sigla do sistema produto
		return String.format("%s_%s", dadosDto.getDescricaoServico(), dadosDto.getChave().getSiglaSistemaProduto());
	}

	/**
	 * Retorna a descrição do serviço de consulta
	 * 
	 * @param dadosDto
	 * @return
	 * @throws SEPException
	 */
	private String obterDescricaoServicoConsulta(DadosDto dadosDto) throws SEPException {
		
		//Os serviços de consulta pendência e registrar ação dependem da sigla do sistema produto.
		//Como esses serviços são originados de notificações é necessário obter a sigla do produto
		//a partir da chave externa.
		String siglaSistemaProduto = obterSiglaSistemaProduto(dadosDto.getChave().getChaveExterna());
		dadosDto.getDados().put(JSON_KEY_SIGLA_SISTEMA_PRODUTO, siglaSistemaProduto);
		
		return String.format("%s_%s", dadosDto.getDescricaoServico(), siglaSistemaProduto);
	}
	
	/**
	 * Retorna a sigla do serviço
	 * 
	 * @return
	 * @throws SEPException
	 */
	private String obterSiglaSistemaProduto(String codigoChaveExterna) throws SEPException {
		
		ChaveDto chave = dao.obterServico(codigoChaveExterna);

		return chave.getSiglaSistemaProduto();
	}	
}