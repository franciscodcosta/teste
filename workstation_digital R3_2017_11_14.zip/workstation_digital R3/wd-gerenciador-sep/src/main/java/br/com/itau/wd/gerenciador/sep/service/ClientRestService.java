package br.com.itau.wd.gerenciador.sep.service;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.sep.util.SEPUtils;

@Service
public class ClientRestService {

	private static final Logger logger = LoggerFactory.getLogger(ClientRestService.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	/**
	 * Obtem o JSON do endpoint
	 * 
	 * @param url
	 * @param method
	 * @param entity
	 * @return
	 * @throws SEPException
	 */
	public String enviarJson(String url, HttpMethod method, HttpEntity<?> entity) throws SEPException {
		
		String retorno = STRING_EMPTY;
		String responseBody = STRING_EMPTY;
	    boolean erro = false;

		try {

			ResponseEntity<String> response = restTemplate.exchange(url, method, entity, String.class);			

			retorno = response.getBody();
		}
		catch (HttpClientErrorException ex) {

			logger.error(ex.getResponseBodyAsString(), ex);
			responseBody = ex.getResponseBodyAsString();
		    erro = true;
		}
		catch (Exception ex) {
			
			logger.error(ex.getMessage(), ex);
			throw new SEPException(ex);
		}

		if (erro) {
			
			SEPUtils.tratarErro(responseBody);
		}

		return retorno;
	}
	
	/**
	 * Obtem o JSON do endpoint
	 * 
	 * @param url
	 * @param variables
	 * @return
	 * @throws SEPException
	 */
	public String enviarJson(String url, Object... variables) throws SEPException {
	
		String retorno = STRING_EMPTY;
		String responseBody = STRING_EMPTY;
	    boolean erro = false;

		try {

			ResponseEntity<String> response = restTemplate.getForEntity(url, String.class, variables);			

			retorno = response.getBody();
		}
		catch (HttpClientErrorException ex) {

			logger.error(ex.getResponseBodyAsString(), ex);
			responseBody = ex.getResponseBodyAsString();
		    erro = true;
		}
		catch (Exception ex) {
			
			logger.error(ex.getMessage(), ex);
			throw new SEPException(ex);
		}

		if (erro) {
			
			SEPUtils.tratarErro(responseBody);
		}

		return retorno;
	}
}