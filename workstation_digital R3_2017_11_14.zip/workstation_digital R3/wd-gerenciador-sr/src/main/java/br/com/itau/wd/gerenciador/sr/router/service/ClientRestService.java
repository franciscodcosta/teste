package br.com.itau.wd.gerenciador.sr.router.service;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.util.SRUtils;

@Service
public class ClientRestService {

	private static final Logger logger = LoggerFactory.getLogger(ClientRestService.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	/**
	 * Obtem o JSON do endpoint
	 * 
	 * @param url
	 * @param method
	 * @param entity
	 * @return88
	 * @throws SEPException
	 */
	public String enviarJson(String url, HttpMethod method, HttpEntity<?> entity) throws SRException {
		
		String retorno = STRING_EMPTY;
		String responseBody = STRING_EMPTY;
	    boolean erro = false;

		try {

			ResponseEntity<String> response = restTemplate.exchange(url, method, entity, String.class);			

			retorno = response.getBody();
		}
		catch (HttpClientErrorException ex) {

			logger.error(ex.getMessage(), ex);
			responseBody = ex.getResponseBodyAsString();
		    erro = true;
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}

		if (erro) {
			
			SRUtils.tratarErro(responseBody);
		}

		return retorno;
	}	
}