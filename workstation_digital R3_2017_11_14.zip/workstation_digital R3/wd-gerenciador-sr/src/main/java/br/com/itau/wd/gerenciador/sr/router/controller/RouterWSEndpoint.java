package br.com.itau.wd.gerenciador.sr.router.controller;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.router.service.RouterService;
import br.com.itau.wd.gerenciador.sr.service.soap.WDGerenciadorRequest;
import br.com.itau.wd.gerenciador.sr.service.soap.WDGerenciadorResponse;


@Endpoint
public class RouterWSEndpoint {

	@Autowired
	RouterService service;

	private static final Logger logger = LoggerFactory.getLogger(RouterWSEndpoint.class);	
	private static final String NAMESPACE_URI = "itau.com.br/wd/gerenciador/sr/service/soap";
	
	@PayloadRoot(namespace = NAMESPACE_URI, localPart = "WDGerenciadorRequest")
	@ResponsePayload
	public WDGerenciadorResponse executarSoap(@RequestPayload WDGerenciadorRequest request) {

		String dados = STRING_EMPTY;

		try {

			dados = service.executarSEP(request.getServico(), request.getJson(), null);
		} 
		catch (SRException ex) {

			logger.error(ex.getMensagem(), ex);
			dados = String.format("{\"erro\": {\"mensagem\": \"%s\"}}", ex.getMensagem());
		}

        WDGerenciadorResponse response = new WDGerenciadorResponse();
		response.setJson(dados);

		return response;
	}
}
