package br.com.itau.wd.gerenciador.adm.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WdGerenciadorAdmApplication {

	public static void main(String[] args) {
		SpringApplication.run(WdGerenciadorAdmApplication.class, args);
	}
}
