package br.com.itau.wd.gerenciador.kms.dao;

import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_CODIGO_ATIVIDADE_SISTEMA_INTERNO;
import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_CODIGO_CHAVE_SISTEMA_INTERNO;
import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_NUMERO_FUNCIONAL_COLABORADOR_CONGLOMERADO;
import static br.com.itau.wd.gerenciador.util.Constants.COLUMN_INDEX_SIGLA_SISTEMA;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.internal.SessionImpl;
import org.springframework.stereotype.Repository;

import br.com.itau.wd.gerenciador.kms.dto.ChaveDto;
import br.com.itau.wd.gerenciador.kms.exception.KMSException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * <b>KEY MANAGEMENT SERVICE (KMS) DAO</b>
 * Realiza o acesso a base de dados
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 *
 */
@Repository
public class KMSDao {

	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * Insere os dados e retorna a chave externa
	 * 
	 * @param chave
	 * @return
	 * @throws KMSException
	 */
	public String salvarChave(ChaveDto chave) throws KMSException {

		String codigoChaveExterna = STRING_EMPTY;

		try {

			Connection conexao = ((SessionImpl)entityManager.getDelegate()).connection();

			codigoChaveExterna = obterChaveExterna(conexao, chave);
		}
		catch (Exception ex) {

			throw new KMSException(ex);
		}

		return codigoChaveExterna;		
	}
	
	/**
	 * Retorna os dados da chave
	 * 
	 * @param codigoChaveExterna
	 * @return
	 * @throws KMSException
	 */
	@SuppressWarnings("unchecked")
	public List<ChaveDto> consultarChave(String codigoChaveExterna) throws KMSException {

		List<ChaveDto> listaChave = new ArrayList<>();

		try {

			Query procedure = entityManager.createNativeQuery("{call PRC_SEL_CHAVE (?)}");

			procedure.setParameter(1, codigoChaveExterna);

			List<Object[]> query = procedure.getResultList();
	
			if (query != null && !query.isEmpty()) {
	
				for (int i = 0; i < query.size(); i++) {

					Object[] row = query.get(i);
					ChaveDto chave = new ChaveDto();

					chave.setChaveExterna(codigoChaveExterna);
					chave.setChaveProduto(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_CODIGO_CHAVE_SISTEMA_INTERNO]));
					chave.setCodigoServico(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_CODIGO_ATIVIDADE_SISTEMA_INTERNO]));
					chave.setFuncionalSistemaProduto(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_NUMERO_FUNCIONAL_COLABORADOR_CONGLOMERADO]));
					chave.setFuncaoAtividadeSistemaProduto(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO]));
					chave.setFuncaoSistemaProduto(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_FUNCAO_SISTEMA_PRODUTO]));
					chave.setSiglaSistemaProduto(GerenciadorUtils.convertObjectToString(row[COLUMN_INDEX_SIGLA_SISTEMA]));

					listaChave.add(chave);
				}
			}
		}
		catch (Exception ex) {

			throw new KMSException(ex);
		}

		return listaChave;
	}
	
	/**
	 * Retorna a chave externa
	 * 
	 * @param conexao
	 * @param chave
	 * @return
	 * @throws KMSException
	 */
	private String obterChaveExterna(Connection conexao, ChaveDto chave) throws KMSException {
		
		String codigoChaveExterna = STRING_EMPTY;
		
		try (CallableStatement callableStatement = conexao.prepareCall("{call PRC_INS_CHAVE(?,?,?,?,?,?)}")) {

			callableStatement.setString(1, chave.getChaveProduto());
			callableStatement.setString(2, chave.getCodigoServico());
			callableStatement.setString(3, chave.getFuncaoSistemaProduto());
			callableStatement.setString(4, chave.getFuncaoAtividadeSistemaProduto());
			callableStatement.setString(5, chave.getFuncionalSistemaProduto());
			callableStatement.registerOutParameter(6, Types.VARCHAR);

			callableStatement.execute();

			codigoChaveExterna = callableStatement.getString(6);			
		}
		catch (Exception ex) {
			
			throw new KMSException(ex);
		}
		
		return codigoChaveExterna;
	}
}