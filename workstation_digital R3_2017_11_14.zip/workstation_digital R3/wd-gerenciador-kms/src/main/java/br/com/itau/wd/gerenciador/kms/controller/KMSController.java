package br.com.itau.wd.gerenciador.kms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.kms.dto.ChaveDto;
import br.com.itau.wd.gerenciador.kms.exception.KMSException;
import br.com.itau.wd.gerenciador.kms.service.KMSService;

/**
 * KEY MANAGEMENT SERVICE (KMS) Controller
 * 
 * Componente responsável pela conversão das chaves, tanto PARA-DE quanto DE-PARA, 
 * permitindo assim a padronização de chaves entre sistemas.
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@RestController
public class KMSController {

	@Autowired
	private KMSService service;

	/**
	 * Salva os dados e cria a chave
	 *
	 * @param codigoServico
	 * @param chaveProduto
	 * @param funcaoAtividadeSistemaProduto
	 * @param funcionalSistemaProduto
	 * @return
	 * @throws KMSException
	 */
	@RequestMapping(value="/chave", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String salvarChave(@RequestHeader(value="codigo_servico") String codigoServico,
							  @RequestHeader(value="chave_produto") String chaveProduto,
							  @RequestHeader(value="funcao_sistema_produto") String funcaoSistemaProduto, 				  
							  @RequestHeader(value="funcao_atividade_sistema_produto") String funcaoAtividadeSistemaProduto,
							  @RequestHeader(value="funcional_sistema_produto") String funcionalSistemaProduto) throws KMSException {

		ChaveDto chave = new ChaveDto();
		
		chave.setCodigoServico(codigoServico);
		chave.setChaveProduto(chaveProduto);
		chave.setFuncaoSistemaProduto(funcaoSistemaProduto);
		chave.setFuncaoAtividadeSistemaProduto(funcaoAtividadeSistemaProduto);
		chave.setFuncionalSistemaProduto(funcionalSistemaProduto);

		return service.salvarChave(chave);
	}

	/**
	 * Retorna os dados da chave
	 * 
	 * @param chave
	 * @return
	 * @throws KMSException 
	 */
	@RequestMapping(value="/chave", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public List<ChaveDto> consultarChave(@RequestParam(value="chave_externa") String codigoChaveExterna) throws KMSException {

		return service.consultarChave(codigoChaveExterna);
	}
}