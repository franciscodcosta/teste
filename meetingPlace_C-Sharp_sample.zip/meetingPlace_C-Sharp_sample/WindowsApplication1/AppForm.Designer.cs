namespace WindowsApplication1
{
    partial class AppForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AppForm));
            this.AppTabControl = new System.Windows.Forms.TabControl();
            this.LoginTabPage = new System.Windows.Forms.TabPage();
            this.LoginSubmitButton = new System.Windows.Forms.Button();
            this.LoginServerNameText = new System.Windows.Forms.TextBox();
            this.LoginPasswordText = new System.Windows.Forms.TextBox();
            this.LoginUsernameText = new System.Windows.Forms.TextBox();
            this.LoginServerNameLabel = new System.Windows.Forms.Label();
            this.LoginPasswordLabel = new System.Windows.Forms.Label();
            this.LoginUsernameLabel = new System.Windows.Forms.Label();
            this.MeetingTabPage = new System.Windows.Forms.TabPage();
            this.MeetingFilterGroupBox = new System.Windows.Forms.GroupBox();
            this.MeetingFilterWaitingCheckBox = new System.Windows.Forms.CheckBox();
            this.MeetingFilterStateLabel = new System.Windows.Forms.Label();
            this.MeetingFilterOwnerText = new System.Windows.Forms.TextBox();
            this.MeetingFilterOwnerLabel = new System.Windows.Forms.Label();
            this.MeetingFilterSubmitButton = new System.Windows.Forms.Button();
            this.MeetingFilterEndDatePicker = new System.Windows.Forms.DateTimePicker();
            this.MeetingFilterStartDatePicker = new System.Windows.Forms.DateTimePicker();
            this.MeetingFilterMaxResultsText = new System.Windows.Forms.TextBox();
            this.MeetingFilterSubjectText = new System.Windows.Forms.TextBox();
            this.MeetingFilterEndedCheckBox = new System.Windows.Forms.CheckBox();
            this.MeetingFilterInSessionCheckBox = new System.Windows.Forms.CheckBox();
            this.MeetingFilterNotStartedCheckBox = new System.Windows.Forms.CheckBox();
            this.MeetingFilterMaxResultsLabel = new System.Windows.Forms.Label();
            this.MeetingFilterEndDateLabel = new System.Windows.Forms.Label();
            this.MeetingFilterStartDateLabel = new System.Windows.Forms.Label();
            this.MeetingFilterSubjectLabel = new System.Windows.Forms.Label();
            this.MeetingServerNameLabel = new System.Windows.Forms.Label();
            this.LoginLabel = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.MeetingUserLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.AppTabControl.SuspendLayout();
            this.LoginTabPage.SuspendLayout();
            this.MeetingTabPage.SuspendLayout();
            this.MeetingFilterGroupBox.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // AppTabControl
            // 
            this.AppTabControl.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.AppTabControl.Controls.Add(this.LoginTabPage);
            this.AppTabControl.Controls.Add(this.MeetingTabPage);
            this.AppTabControl.Location = new System.Drawing.Point(-5, 50);
            this.AppTabControl.MaximumSize = new System.Drawing.Size(510, 729);
            this.AppTabControl.MinimumSize = new System.Drawing.Size(510, 650);
            this.AppTabControl.Name = "AppTabControl";
            this.AppTabControl.SelectedIndex = 0;
            this.AppTabControl.Size = new System.Drawing.Size(510, 650);
            this.AppTabControl.TabIndex = 1;
            // 
            // LoginTabPage
            // 
            this.LoginTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.LoginTabPage.Controls.Add(this.LoginSubmitButton);
            this.LoginTabPage.Controls.Add(this.LoginServerNameText);
            this.LoginTabPage.Controls.Add(this.LoginPasswordText);
            this.LoginTabPage.Controls.Add(this.LoginUsernameText);
            this.LoginTabPage.Controls.Add(this.LoginServerNameLabel);
            this.LoginTabPage.Controls.Add(this.LoginPasswordLabel);
            this.LoginTabPage.Controls.Add(this.LoginUsernameLabel);
            this.LoginTabPage.Location = new System.Drawing.Point(4, 27);
            this.LoginTabPage.Name = "LoginTabPage";
            this.LoginTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.LoginTabPage.Size = new System.Drawing.Size(502, 619);
            this.LoginTabPage.TabIndex = 0;
            this.LoginTabPage.Text = "tabPage1";
            // 
            // LoginSubmitButton
            // 
            this.LoginSubmitButton.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.LoginSubmitButton.Location = new System.Drawing.Point(217, 381);
            this.LoginSubmitButton.Name = "LoginSubmitButton";
            this.LoginSubmitButton.Size = new System.Drawing.Size(75, 25);
            this.LoginSubmitButton.TabIndex = 7;
            this.LoginSubmitButton.Text = "Login";
            this.LoginSubmitButton.UseVisualStyleBackColor = false;
            this.LoginSubmitButton.Click += new System.EventHandler(this.LoginSubmitButton_Click);
            // 
            // LoginServerNameText
            // 
            this.LoginServerNameText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LoginServerNameText.Location = new System.Drawing.Point(53, 341);
            this.LoginServerNameText.Name = "LoginServerNameText";
            this.LoginServerNameText.Size = new System.Drawing.Size(400, 21);
            this.LoginServerNameText.TabIndex = 6;
            // 
            // LoginPasswordText
            // 
            this.LoginPasswordText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LoginPasswordText.Location = new System.Drawing.Point(53, 290);
            this.LoginPasswordText.Name = "LoginPasswordText";
            this.LoginPasswordText.Size = new System.Drawing.Size(400, 21);
            this.LoginPasswordText.TabIndex = 5;
            this.LoginPasswordText.UseSystemPasswordChar = true;
            // 
            // LoginUsernameText
            // 
            this.LoginUsernameText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LoginUsernameText.Location = new System.Drawing.Point(53, 239);
            this.LoginUsernameText.Name = "LoginUsernameText";
            this.LoginUsernameText.Size = new System.Drawing.Size(400, 21);
            this.LoginUsernameText.TabIndex = 4;
            // 
            // LoginServerNameLabel
            // 
            this.LoginServerNameLabel.AutoSize = true;
            this.LoginServerNameLabel.Location = new System.Drawing.Point(50, 323);
            this.LoginServerNameLabel.Name = "LoginServerNameLabel";
            this.LoginServerNameLabel.Size = new System.Drawing.Size(77, 15);
            this.LoginServerNameLabel.TabIndex = 3;
            this.LoginServerNameLabel.Text = "Server name";
            // 
            // LoginPasswordLabel
            // 
            this.LoginPasswordLabel.AutoSize = true;
            this.LoginPasswordLabel.Location = new System.Drawing.Point(50, 272);
            this.LoginPasswordLabel.Name = "LoginPasswordLabel";
            this.LoginPasswordLabel.Size = new System.Drawing.Size(63, 15);
            this.LoginPasswordLabel.TabIndex = 2;
            this.LoginPasswordLabel.Text = "Password";
            // 
            // LoginUsernameLabel
            // 
            this.LoginUsernameLabel.AutoSize = true;
            this.LoginUsernameLabel.Location = new System.Drawing.Point(50, 214);
            this.LoginUsernameLabel.Name = "LoginUsernameLabel";
            this.LoginUsernameLabel.Size = new System.Drawing.Size(66, 15);
            this.LoginUsernameLabel.TabIndex = 1;
            this.LoginUsernameLabel.Text = "Username";
            // 
            // MeetingTabPage
            // 
            this.MeetingTabPage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.MeetingTabPage.Controls.Add(this.MeetingFilterGroupBox);
            this.MeetingTabPage.Controls.Add(this.MeetingServerNameLabel);
            this.MeetingTabPage.Location = new System.Drawing.Point(4, 27);
            this.MeetingTabPage.Name = "MeetingTabPage";
            this.MeetingTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.MeetingTabPage.Size = new System.Drawing.Size(502, 619);
            this.MeetingTabPage.TabIndex = 1;
            this.MeetingTabPage.Text = "tabPage2";
            // 
            // MeetingFilterGroupBox
            // 
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterWaitingCheckBox);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterStateLabel);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterOwnerText);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterOwnerLabel);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterSubmitButton);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterEndDatePicker);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterStartDatePicker);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterMaxResultsText);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterSubjectText);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterEndedCheckBox);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterInSessionCheckBox);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterNotStartedCheckBox);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterMaxResultsLabel);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterEndDateLabel);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterStartDateLabel);
            this.MeetingFilterGroupBox.Controls.Add(this.MeetingFilterSubjectLabel);
            this.MeetingFilterGroupBox.Location = new System.Drawing.Point(13, 115);
            this.MeetingFilterGroupBox.Name = "MeetingFilterGroupBox";
            this.MeetingFilterGroupBox.Size = new System.Drawing.Size(468, 269);
            this.MeetingFilterGroupBox.TabIndex = 1;
            this.MeetingFilterGroupBox.TabStop = false;
            this.MeetingFilterGroupBox.Text = "Meetings filter";
            // 
            // MeetingFilterWaitingCheckBox
            // 
            this.MeetingFilterWaitingCheckBox.AutoSize = true;
            this.MeetingFilterWaitingCheckBox.Checked = true;
            this.MeetingFilterWaitingCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MeetingFilterWaitingCheckBox.Location = new System.Drawing.Point(379, 172);
            this.MeetingFilterWaitingCheckBox.Name = "MeetingFilterWaitingCheckBox";
            this.MeetingFilterWaitingCheckBox.Size = new System.Drawing.Size(67, 19);
            this.MeetingFilterWaitingCheckBox.TabIndex = 15;
            this.MeetingFilterWaitingCheckBox.Text = "Waiting";
            this.MeetingFilterWaitingCheckBox.UseVisualStyleBackColor = true;
            // 
            // MeetingFilterStateLabel
            // 
            this.MeetingFilterStateLabel.AutoSize = true;
            this.MeetingFilterStateLabel.Location = new System.Drawing.Point(10, 173);
            this.MeetingFilterStateLabel.Name = "MeetingFilterStateLabel";
            this.MeetingFilterStateLabel.Size = new System.Drawing.Size(35, 15);
            this.MeetingFilterStateLabel.TabIndex = 14;
            this.MeetingFilterStateLabel.Text = "State";
            // 
            // MeetingFilterOwnerText
            // 
            this.MeetingFilterOwnerText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeetingFilterOwnerText.Location = new System.Drawing.Point(89, 36);
            this.MeetingFilterOwnerText.Name = "MeetingFilterOwnerText";
            this.MeetingFilterOwnerText.Size = new System.Drawing.Size(359, 21);
            this.MeetingFilterOwnerText.TabIndex = 13;
            // 
            // MeetingFilterOwnerLabel
            // 
            this.MeetingFilterOwnerLabel.AutoSize = true;
            this.MeetingFilterOwnerLabel.Location = new System.Drawing.Point(10, 38);
            this.MeetingFilterOwnerLabel.Name = "MeetingFilterOwnerLabel";
            this.MeetingFilterOwnerLabel.Size = new System.Drawing.Size(43, 15);
            this.MeetingFilterOwnerLabel.TabIndex = 12;
            this.MeetingFilterOwnerLabel.Text = "Owner";
            // 
            // MeetingFilterSubmitButton
            // 
            this.MeetingFilterSubmitButton.Location = new System.Drawing.Point(361, 215);
            this.MeetingFilterSubmitButton.Name = "MeetingFilterSubmitButton";
            this.MeetingFilterSubmitButton.Size = new System.Drawing.Size(87, 23);
            this.MeetingFilterSubmitButton.TabIndex = 11;
            this.MeetingFilterSubmitButton.Text = "Start search";
            this.MeetingFilterSubmitButton.UseVisualStyleBackColor = true;
            this.MeetingFilterSubmitButton.Click += new System.EventHandler(this.MeetingFilterSubmitButton_Click);
            // 
            // MeetingFilterEndDatePicker
            // 
            this.MeetingFilterEndDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.MeetingFilterEndDatePicker.Location = new System.Drawing.Point(89, 117);
            this.MeetingFilterEndDatePicker.Name = "MeetingFilterEndDatePicker";
            this.MeetingFilterEndDatePicker.Size = new System.Drawing.Size(102, 21);
            this.MeetingFilterEndDatePicker.TabIndex = 10;
            // 
            // MeetingFilterStartDatePicker
            // 
            this.MeetingFilterStartDatePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.MeetingFilterStartDatePicker.Location = new System.Drawing.Point(89, 90);
            this.MeetingFilterStartDatePicker.Name = "MeetingFilterStartDatePicker";
            this.MeetingFilterStartDatePicker.Size = new System.Drawing.Size(102, 21);
            this.MeetingFilterStartDatePicker.TabIndex = 9;
            // 
            // MeetingFilterMaxResultsText
            // 
            this.MeetingFilterMaxResultsText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeetingFilterMaxResultsText.Location = new System.Drawing.Point(89, 144);
            this.MeetingFilterMaxResultsText.Name = "MeetingFilterMaxResultsText";
            this.MeetingFilterMaxResultsText.Size = new System.Drawing.Size(102, 21);
            this.MeetingFilterMaxResultsText.TabIndex = 8;
            this.MeetingFilterMaxResultsText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.MeetingFilterMaxResultsText_KeyPress);
            // 
            // MeetingFilterSubjectText
            // 
            this.MeetingFilterSubjectText.AcceptsTab = true;
            this.MeetingFilterSubjectText.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MeetingFilterSubjectText.Location = new System.Drawing.Point(89, 63);
            this.MeetingFilterSubjectText.Name = "MeetingFilterSubjectText";
            this.MeetingFilterSubjectText.Size = new System.Drawing.Size(359, 21);
            this.MeetingFilterSubjectText.TabIndex = 7;
            // 
            // MeetingFilterEndedCheckBox
            // 
            this.MeetingFilterEndedCheckBox.AutoSize = true;
            this.MeetingFilterEndedCheckBox.Checked = true;
            this.MeetingFilterEndedCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MeetingFilterEndedCheckBox.Location = new System.Drawing.Point(299, 172);
            this.MeetingFilterEndedCheckBox.Name = "MeetingFilterEndedCheckBox";
            this.MeetingFilterEndedCheckBox.Size = new System.Drawing.Size(61, 19);
            this.MeetingFilterEndedCheckBox.TabIndex = 6;
            this.MeetingFilterEndedCheckBox.Text = "ended";
            this.MeetingFilterEndedCheckBox.UseVisualStyleBackColor = true;
            // 
            // MeetingFilterInSessionCheckBox
            // 
            this.MeetingFilterInSessionCheckBox.AutoSize = true;
            this.MeetingFilterInSessionCheckBox.Checked = true;
            this.MeetingFilterInSessionCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MeetingFilterInSessionCheckBox.Location = new System.Drawing.Point(195, 172);
            this.MeetingFilterInSessionCheckBox.Name = "MeetingFilterInSessionCheckBox";
            this.MeetingFilterInSessionCheckBox.Size = new System.Drawing.Size(85, 19);
            this.MeetingFilterInSessionCheckBox.TabIndex = 5;
            this.MeetingFilterInSessionCheckBox.Text = "In Session";
            this.MeetingFilterInSessionCheckBox.UseVisualStyleBackColor = true;
            // 
            // MeetingFilterNotStartedCheckBox
            // 
            this.MeetingFilterNotStartedCheckBox.AutoSize = true;
            this.MeetingFilterNotStartedCheckBox.Checked = true;
            this.MeetingFilterNotStartedCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.MeetingFilterNotStartedCheckBox.Location = new System.Drawing.Point(89, 172);
            this.MeetingFilterNotStartedCheckBox.Name = "MeetingFilterNotStartedCheckBox";
            this.MeetingFilterNotStartedCheckBox.Size = new System.Drawing.Size(87, 19);
            this.MeetingFilterNotStartedCheckBox.TabIndex = 4;
            this.MeetingFilterNotStartedCheckBox.Text = "Not Started";
            this.MeetingFilterNotStartedCheckBox.UseVisualStyleBackColor = true;
            // 
            // MeetingFilterMaxResultsLabel
            // 
            this.MeetingFilterMaxResultsLabel.AutoSize = true;
            this.MeetingFilterMaxResultsLabel.Location = new System.Drawing.Point(10, 146);
            this.MeetingFilterMaxResultsLabel.Name = "MeetingFilterMaxResultsLabel";
            this.MeetingFilterMaxResultsLabel.Size = new System.Drawing.Size(69, 15);
            this.MeetingFilterMaxResultsLabel.TabIndex = 3;
            this.MeetingFilterMaxResultsLabel.Text = "Max results";
            // 
            // MeetingFilterEndDateLabel
            // 
            this.MeetingFilterEndDateLabel.AutoSize = true;
            this.MeetingFilterEndDateLabel.Location = new System.Drawing.Point(10, 120);
            this.MeetingFilterEndDateLabel.Name = "MeetingFilterEndDateLabel";
            this.MeetingFilterEndDateLabel.Size = new System.Drawing.Size(56, 15);
            this.MeetingFilterEndDateLabel.TabIndex = 2;
            this.MeetingFilterEndDateLabel.Text = "End time";
            // 
            // MeetingFilterStartDateLabel
            // 
            this.MeetingFilterStartDateLabel.AutoSize = true;
            this.MeetingFilterStartDateLabel.Location = new System.Drawing.Point(10, 93);
            this.MeetingFilterStartDateLabel.Name = "MeetingFilterStartDateLabel";
            this.MeetingFilterStartDateLabel.Size = new System.Drawing.Size(59, 15);
            this.MeetingFilterStartDateLabel.TabIndex = 1;
            this.MeetingFilterStartDateLabel.Text = "Start time";
            // 
            // MeetingFilterSubjectLabel
            // 
            this.MeetingFilterSubjectLabel.AutoSize = true;
            this.MeetingFilterSubjectLabel.Location = new System.Drawing.Point(10, 65);
            this.MeetingFilterSubjectLabel.Name = "MeetingFilterSubjectLabel";
            this.MeetingFilterSubjectLabel.Size = new System.Drawing.Size(48, 15);
            this.MeetingFilterSubjectLabel.TabIndex = 0;
            this.MeetingFilterSubjectLabel.Text = "Subject";
            // 
            // MeetingServerNameLabel
            // 
            this.MeetingServerNameLabel.AutoSize = true;
            this.MeetingServerNameLabel.Location = new System.Drawing.Point(33, 26);
            this.MeetingServerNameLabel.Name = "MeetingServerNameLabel";
            this.MeetingServerNameLabel.Size = new System.Drawing.Size(41, 15);
            this.MeetingServerNameLabel.TabIndex = 0;
            this.MeetingServerNameLabel.Text = "label1";
            // 
            // LoginLabel
            // 
            this.LoginLabel.AutoSize = true;
            this.LoginLabel.Font = new System.Drawing.Font("Arial", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoginLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.LoginLabel.Location = new System.Drawing.Point(118, 228);
            this.LoginLabel.Name = "LoginLabel";
            this.LoginLabel.Size = new System.Drawing.Size(274, 26);
            this.LoginLabel.TabIndex = 0;
            this.LoginLabel.Text = "Cisco SDK .Net API Client";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.MeetingUserLabel);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.LoginLabel);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(483, 273);
            this.panel1.TabIndex = 2;
            // 
            // MeetingUserLabel
            // 
            this.MeetingUserLabel.AutoSize = true;
            this.MeetingUserLabel.Location = new System.Drawing.Point(6, 151);
            this.MeetingUserLabel.Name = "MeetingUserLabel";
            this.MeetingUserLabel.Size = new System.Drawing.Size(41, 15);
            this.MeetingUserLabel.TabIndex = 2;
            this.MeetingUserLabel.Text = "label1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.InitialImage")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 204);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(79, 50);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.InitialImage")));
            this.pictureBox2.Location = new System.Drawing.Point(149, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(209, 181);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // AppForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(484, 655);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.AppTabControl);
            this.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximumSize = new System.Drawing.Size(500, 694);
            this.MinimumSize = new System.Drawing.Size(500, 694);
            this.Name = "AppForm";
            this.Text = "Login";
            this.AppTabControl.ResumeLayout(false);
            this.LoginTabPage.ResumeLayout(false);
            this.LoginTabPage.PerformLayout();
            this.MeetingTabPage.ResumeLayout(false);
            this.MeetingTabPage.PerformLayout();
            this.MeetingFilterGroupBox.ResumeLayout(false);
            this.MeetingFilterGroupBox.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl AppTabControl;
        private System.Windows.Forms.TabPage LoginTabPage;
        private System.Windows.Forms.TabPage MeetingTabPage;
        private System.Windows.Forms.Label LoginLabel;
        private System.Windows.Forms.Label LoginUsernameLabel;
        private System.Windows.Forms.Button LoginSubmitButton;
        private System.Windows.Forms.TextBox LoginServerNameText;
        private System.Windows.Forms.TextBox LoginPasswordText;
        private System.Windows.Forms.TextBox LoginUsernameText;
        private System.Windows.Forms.Label LoginServerNameLabel;
        private System.Windows.Forms.Label LoginPasswordLabel;
        private System.Windows.Forms.Label MeetingServerNameLabel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label MeetingUserLabel;
        private System.Windows.Forms.GroupBox MeetingFilterGroupBox;
        private System.Windows.Forms.CheckBox MeetingFilterEndedCheckBox;
        private System.Windows.Forms.CheckBox MeetingFilterInSessionCheckBox;
        private System.Windows.Forms.CheckBox MeetingFilterNotStartedCheckBox;
        private System.Windows.Forms.Label MeetingFilterMaxResultsLabel;
        private System.Windows.Forms.Label MeetingFilterEndDateLabel;
        private System.Windows.Forms.Label MeetingFilterStartDateLabel;
        private System.Windows.Forms.Label MeetingFilterSubjectLabel;
        private System.Windows.Forms.DateTimePicker MeetingFilterEndDatePicker;
        private System.Windows.Forms.DateTimePicker MeetingFilterStartDatePicker;
        private System.Windows.Forms.TextBox MeetingFilterMaxResultsText;
        private System.Windows.Forms.TextBox MeetingFilterSubjectText;
        private System.Windows.Forms.Button MeetingFilterSubmitButton;
        private System.Windows.Forms.Label MeetingFilterOwnerLabel;
        private System.Windows.Forms.TextBox MeetingFilterOwnerText;
        private System.Windows.Forms.Label MeetingFilterStateLabel;
        private System.Windows.Forms.CheckBox MeetingFilterWaitingCheckBox;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}