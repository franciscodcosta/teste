using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using LService;
using System.Net;
using MtgService;
using System.Collections;

namespace WindowsApplication1
{
    public partial class AppForm : Form
    {
        private NetworkCredential networkCredential = null;
        private string serverName = null;

        private BasicUserInfo userInfo = null;

        private MeetingListForm meetingListForm = null;

        public AppForm()
        {
            InitializeComponent();
            initLoginPage();
        }

        private void initLoginPage()
        {
            this.SuspendLayout();
            this.Text = "Login";
            this.MeetingUserLabel.Text = String.Empty;
            this.AppTabControl.SelectedTab = this.LoginTabPage;
            this.ResumeLayout(false);
            this.LoginUsernameText.Focus();
        }

        private void initMeetingPage(bool attendandOrAdmin)
        {
            this.SuspendLayout();
            this.Text = "Search meetings";
            this.MeetingUserLabel.Text = this.userInfo.lastName + ", " + this.userInfo.firstName;
            this.AppTabControl.SelectedTab = this.MeetingTabPage;
            if (attendandOrAdmin)
            {
                MeetingFilterOwnerText.ReadOnly = false;
            }
            else
            {
                MeetingFilterOwnerText.ReadOnly = true;
                MeetingFilterOwnerText.Text = networkCredential.UserName;
            }
            this.ResumeLayout(false);
        }

        private void initAndShowMeetingListForm(MtgInfo[] mtgInfoArray)
        {
            meetingListForm = new MeetingListForm(mtgInfoArray);
            meetingListForm.FormClosed += new FormClosedEventHandler(meetingListForm_FormClosed);
            meetingListForm.Show();

        }

        private void disposeMeetingListForm()
        {
            if (meetingListForm != null)
            {
                meetingListForm.Dispose();
                meetingListForm = null;
            }
        }

        private void meetingListForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            disposeMeetingListForm();
        }
 
        private void LoginSubmitButton_Click(object sender, EventArgs e)
        {
            string username = LoginUsernameText.Text.Trim();
            string password = LoginPasswordText.Text.Trim();
            this.serverName = LoginServerNameText.Text.Trim();

            if (username.Equals(String.Empty) || password.Equals(String.Empty))
            {
                MessageBox.Show("Username and password are madatory", "Please enter the requested values", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (username.Equals(String.Empty))
                {
                    LoginUsernameText.Focus();
                }
                else
                {
                    LoginPasswordText.Focus();
                }
                return;
            }

            if (serverName.Equals(String.Empty))
            {
                MessageBox.Show("Server name is mandatory", "Please enter the requested values", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.LoginServerNameText.Focus();

                return;
            }

            LoginService loginService = new LoginService();
            loginService.Url = "http://" + this.serverName + "/webservices/services/LoginService";
            loginService.PreAuthenticate = false;
            
            try
            {
                this.userInfo = loginService.checkUserCredentials(username, password);
                this.networkCredential = new NetworkCredential(username, password);
                Console.WriteLine("UserInfo: " + userInfo.lastName + ", " + userInfo.firstName);

                bool attendantOrAdmin = false;

                if (userInfo.typeOfUser == TypeOfUserEnum.ATTENDANT || userInfo.typeOfUser == TypeOfUserEnum.SYSTEM_MGR)
                {
                    attendantOrAdmin = true;
                }
                
                initMeetingPage(attendantOrAdmin);
            }
            catch (Exception ex)
            {
                DialogResult result = MessageBox.Show("Wrong username and/or password. Please try again.", "Authentication failed", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            
                if (result == DialogResult.Retry)
                {
                    this.LoginUsernameText.Text = "";
                    this.LoginPasswordText.Text = "";
                    this.LoginUsernameText.Focus();
                }
            
            }
        }

        private void MeetingFilterSubmitButton_Click(object sender, EventArgs e)
        {
            disposeMeetingListForm();

            MeetingServiceImpl meetingService = new MeetingServiceImpl();
            meetingService.Url = "http://" + this.serverName + "/webservices/services/MeetingService";
            Console.WriteLine("MTG services URL: " + meetingService.Url);
            meetingService.Credentials = networkCredential;
            
            meetingService.PreAuthenticate = true;

            try
            {
                FindMeetingFilter filter = new FindMeetingFilter();
                if (!MeetingFilterOwnerText.Text.Trim().Equals(String.Empty))
                {
                    filter.userMtgRelation = UserMtgRelationEnum.OWNER;
                    filter.userMtgRelationSpecified = true;

                    filter.userId = MeetingFilterOwnerText.Text.Trim();
                }
                filter.subject = this.MeetingFilterSubjectText.Text.Trim();
                
                filter.startTime = DateTime.Parse(this.MeetingFilterStartDatePicker.Value.Date.ToShortDateString());
                filter.startTimeSpecified = true;

                filter.endTime = DateTime.Parse(this.MeetingFilterEndDatePicker.Value.Date.ToShortDateString());
                filter.endTimeSpecified = true;

                ArrayList states = new ArrayList();

                if (MeetingFilterEndedCheckBox.Checked)
                {
                    states.Add(MeetingStatusEnum.ENDED);
                }

                if (MeetingFilterInSessionCheckBox.Checked)
                {
                    states.Add(MeetingStatusEnum.IN_SESSION);
                }

                if (MeetingFilterNotStartedCheckBox.Checked)
                {
                    states.Add(MeetingStatusEnum.NOT_STARTED);
                }

                if (MeetingFilterWaitingCheckBox.Checked)
                {
                    states.Add(MeetingStatusEnum.WAITING_ROOM);
                }

                if (states.Count > 0)
                {
                    filter.statusSet = (MeetingStatusEnum?[])states.ToArray(typeof(MeetingStatusEnum?));
                }

                int max = 100;

                if (!this.MeetingFilterMaxResultsText.Text.Trim().Equals(String.Empty))
                {
                    max = int.Parse(this.MeetingFilterMaxResultsText.Text.Trim());
                }

                ShortMeetingInfo[] shortMeetingInfoArray = meetingService.findMeetingList(filter, max, userInfo.name);


                Console.WriteLine("start::" + filter.startTime.ToShortDateString() + ", end::" + filter.endTime.ToShortDateString());

                for (int i = 0; i < shortMeetingInfoArray.Length; i++)
                {
                    Console.WriteLine("MEETING INFO [" + i + "]" + shortMeetingInfoArray[i].dialableMeetingId + ", start=" + shortMeetingInfoArray[i].startTime.ToShortDateString());
                }

                if (shortMeetingInfoArray.Length > 0)
                {
                    MtgInfo[] mtgInfoArray = createMtgInfoArray(shortMeetingInfoArray);
                    initAndShowMeetingListForm(mtgInfoArray);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
        }

        private void MeetingFilterMaxResultsText_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8)
            {
                e.Handled = true;
            }
        }

        private MtgInfo[] createMtgInfoArray(ShortMeetingInfo[] shortMeetingInfoArray)
        {
            

            ArrayList mtgArrayList = new ArrayList();

            foreach (ShortMeetingInfo info in shortMeetingInfoArray)
            {
                MtgInfo mInfo = new MtgInfo();
                mInfo.UniqueMeetingId = info.uniqueMeetingId.ToString();
                mInfo.Subject = info.subject;
                mInfo.DialableMeetingId = info.dialableMeetingId;
                mInfo.StartDate = info.startTime.ToShortDateString();
                mInfo.Duration = info.durationMin.ToString();
                mInfo.OwnerName = info.ownerLastName + ", " + info.ownerFirstName;
                mInfo.OwnerUsername = info.ownerUsername;
                mInfo.Status = info.status.ToString();
                mInfo.MeetingType = info.meetingType.ToString();

                mtgArrayList.Add(mInfo);

            }

            return (MtgInfo[])mtgArrayList.ToArray(typeof(MtgInfo));
        }

    }
}