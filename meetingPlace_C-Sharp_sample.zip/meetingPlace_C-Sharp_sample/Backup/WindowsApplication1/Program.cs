using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Net;
using BlockEvtService;
using MtgService;

namespace WindowsApplication1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Console.WriteLine("Calling main");
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new AppForm());

            Console.WriteLine("END");

//            string ver = meetingService.getVersion();
//            Console.WriteLine("Creating blocking service");
//            BlockingEventService blockingEventService = new BlockingEventService();
//            blockingEventService.Url = "http://fractal.yuwanadu.com/webservices/services/BlockingEventService";

//            Console.WriteLine("Create credentials");
//            networkCredential = new NetworkCredential("admin", "cisco");
            
//            blockingEventService.Credentials = networkCredential;

//            blockingEventService.PreAuthenticate = true;

//            Console.WriteLine("Calling getVersion");
//            string ver = blockingEventService.getVersion();

//            Console.WriteLine("Version: " + ver);

//            Console.WriteLine("Creating meeting service");
//            MeetingService meetingService = new MeetingService();
//            meetingService.Url = "http://fractal.yuwanadu.com/webservices/services/MeetingService";
//            meetingService.Credentials = networkCredential;

//            meetingService.PreAuthenticate = true;

//            Console.WriteLine("Calling getVersion");
//            string mVer = meetingService.getVersion();

//            Console.WriteLine("Version: " + mVer);

//            Console.WriteLine("End: ");

            
        }
    }
}