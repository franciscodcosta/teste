using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace WindowsApplication1
{
    public partial class FixedSoapHttpClientProtocol : System.Web.Services.Protocols.SoapHttpClientProtocol
    {
        protected override System.Net.WebRequest GetWebRequest(Uri uri)
        {
            HttpWebRequest request = (HttpWebRequest)base.GetWebRequest(uri);

            if (PreAuthenticate)
            {
                NetworkCredential nc = Credentials.GetCredential(uri, "Basic");
                if (nc != null)
                {
                    byte[] cBuffer = new UTF8Encoding().GetBytes(nc.UserName + ":" + nc.Password);
                    request.Headers["Authorization"] = "Basic " + Convert.ToBase64String(cBuffer);
                }
            }
            else
            {
                throw new ApplicationException("No network credentials");
            }
            return request;
        }
    }
}
