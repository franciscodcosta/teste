using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MtgService;

namespace WindowsApplication1
{
    public partial class MeetingListForm : Form
    {
        public MeetingListForm(MtgInfo[] mtgInfoArray)
        {
            InitializeComponent();

            this.MeetingListDataGridView.DataSource = mtgInfoArray;
        }
    }
}