using System;
using System.Collections.Generic;
using System.Text;
using MtgService;

namespace WindowsApplication1
{
    public class MtgInfo
    {
        private string uniqueMeetingId;
        private string subject;
        private string dialableMeetingId;
        private string startDate;
        private string duration;
        private string ownerName;
        private string ownerUsername;
        private string status;
        private string meetingType;

        public MtgInfo()
        {

        }

        public string UniqueMeetingId
        {
            get
            {
                return uniqueMeetingId;
            }
            set
            {
                uniqueMeetingId = value;
            }
        }

        public string Subject
        {
            get
            {
                return subject;
            }
            set
            {
                subject = value;
            }
        }

        public string DialableMeetingId
        {
            get
            {
                return dialableMeetingId;
            }
            set
            {
                dialableMeetingId = value;
            }
        }

        public string StartDate
        {
            get
            {
                return startDate;
            }
            set
            {
                startDate = value;
            }
        }

        public string Duration
        {
            get
            {
                return duration;
            }
            set
            {
                duration = value;
            }
        }

        public string OwnerName
        {
            get
            {
                return ownerName;
            }
            set
            {
                ownerName = value;
            }
        }

        public string OwnerUsername
        {
            get
            {
                return ownerUsername;
            }
            set
            {
                ownerUsername = value;
            }
        }

        public string Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }
        }

        public string MeetingType
        {
            get
            {
                return meetingType;
            }
            set
            {
                meetingType = value;
            }
        }
    }
}
