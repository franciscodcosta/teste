package br.com.itau.WorkstationDigital.Consulta_Documento;

public class SI_Consulta_Documento_outProxy implements br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_out {
  private String _endpoint = null;
  private br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_out sI_Consulta_Documento_out = null;
  
  public SI_Consulta_Documento_outProxy() {
    _initSI_Consulta_Documento_outProxy();
  }
  
  public SI_Consulta_Documento_outProxy(String endpoint) {
    _endpoint = endpoint;
    _initSI_Consulta_Documento_outProxy();
  }

  private void _initSI_Consulta_Documento_outProxy() {
    try {
      sI_Consulta_Documento_out = (new br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_outServiceLocator()).getHTTPS_Port();
      
      if (sI_Consulta_Documento_out != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sI_Consulta_Documento_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sI_Consulta_Documento_out)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sI_Consulta_Documento_out != null)
      ((javax.xml.rpc.Stub)sI_Consulta_Documento_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_out getSI_Consulta_Documento_out() {
    if (sI_Consulta_Documento_out == null)
      _initSI_Consulta_Documento_outProxy();
    return sI_Consulta_Documento_out;
  }
  
  public br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_out SI_Consulta_Documento_out(br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_out MT_Consulta_Documento_out) throws java.rmi.RemoteException{
    if (sI_Consulta_Documento_out == null)
      _initSI_Consulta_Documento_outProxy();
    return sI_Consulta_Documento_out.SI_Consulta_Documento_out(MT_Consulta_Documento_out);
  }
  
  
}