package AH7P001.ConsultarProcuracao_tws;

public class ConsultarProcuracaoPortTypeProxy implements AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortType {
  private String _endpoint = null;
  private AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortType consultarProcuracaoPortType = null;
  
  public ConsultarProcuracaoPortTypeProxy() {
    _initConsultarProcuracaoPortTypeProxy();
  }
  
  public ConsultarProcuracaoPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarProcuracaoPortTypeProxy();
  }
  
  private void _initConsultarProcuracaoPortTypeProxy() {
    try {
      consultarProcuracaoPortType = (new AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoLocator()).getConsultarProcuracaoSoap();
      if (consultarProcuracaoPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarProcuracaoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarProcuracaoPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarProcuracaoPortType != null)
      ((javax.xml.rpc.Stub)consultarProcuracaoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortType getConsultarProcuracaoPortType() {
    if (consultarProcuracaoPortType == null)
      _initConsultarProcuracaoPortTypeProxy();
    return consultarProcuracaoPortType;
  }
  
  public void consultarProcuracaoWorkstation(int idProcuracao, java.lang.String funcionalAprovador, java.lang.String usuarioAcesso, java.lang.String tokenAcesso, AH7P001.ConsultarProcuracao_tws.holders.ResumoProcuracaoWorkstationHolder resultadoConsulta, javax.xml.rpc.holders.IntHolder codigoRetorno, javax.xml.rpc.holders.StringHolder mensagemRetorno) throws java.rmi.RemoteException{
    if (consultarProcuracaoPortType == null)
      _initConsultarProcuracaoPortTypeProxy();
    consultarProcuracaoPortType.consultarProcuracaoWorkstation(idProcuracao, funcionalAprovador, usuarioAcesso, tokenAcesso, resultadoConsulta, codigoRetorno, mensagemRetorno);
  }
  
  
}