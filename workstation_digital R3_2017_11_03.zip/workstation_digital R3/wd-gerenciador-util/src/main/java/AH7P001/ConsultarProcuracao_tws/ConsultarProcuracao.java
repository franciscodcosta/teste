/**
 * ConsultarProcuracao.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package AH7P001.ConsultarProcuracao_tws;

public interface ConsultarProcuracao extends javax.xml.rpc.Service {
    public java.lang.String getConsultarProcuracaoSoapAddress();

    public AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortType getConsultarProcuracaoSoap() throws javax.xml.rpc.ServiceException;

    public AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortType getConsultarProcuracaoSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
