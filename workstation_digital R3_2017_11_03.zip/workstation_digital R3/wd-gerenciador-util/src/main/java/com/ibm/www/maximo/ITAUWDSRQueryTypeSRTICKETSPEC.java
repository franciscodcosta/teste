/**
 * ITAUWDSRQueryTypeSRTICKETSPEC.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRQueryTypeSRTICKETSPEC  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] ALNVALUE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID;

    private com.ibm.www.maximo.MXStringQueryType[] CHANGEBY;

    private com.ibm.www.maximo.MXDateTimeQueryType[] CHANGEDATE;

    private com.ibm.www.maximo.MXLongQueryType[] CLASSSPECID;

    private com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID;

    private com.ibm.www.maximo.MXLongQueryType[] DISPLAYSEQUENCE;

    private com.ibm.www.maximo.MXStringQueryType[] LINKEDTOATTRIBUTE;

    private com.ibm.www.maximo.MXStringQueryType[] LINKEDTOSECTION;

    private com.ibm.www.maximo.MXBooleanQueryType[] MANDATORY;

    private com.ibm.www.maximo.MXStringQueryType[] MEASUREUNITID;

    private com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE;

    private com.ibm.www.maximo.MXStringQueryType[] ORGID;

    private com.ibm.www.maximo.MXLongQueryType[] REFOBJECTID;

    private com.ibm.www.maximo.MXStringQueryType[] REFOBJECTNAME;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] SECTION;

    private com.ibm.www.maximo.MXStringQueryType[] SITEID;

    private com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE;

    private com.ibm.www.maximo.MXLongQueryType[] TICKETSPECID;

    private java.lang.Boolean filter;  // attribute

    public ITAUWDSRQueryTypeSRTICKETSPEC() {
    }

    public ITAUWDSRQueryTypeSRTICKETSPEC(
           com.ibm.www.maximo.MXStringQueryType[] ALNVALUE,
           com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID,
           com.ibm.www.maximo.MXStringQueryType[] CHANGEBY,
           com.ibm.www.maximo.MXDateTimeQueryType[] CHANGEDATE,
           com.ibm.www.maximo.MXLongQueryType[] CLASSSPECID,
           com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXLongQueryType[] DISPLAYSEQUENCE,
           com.ibm.www.maximo.MXStringQueryType[] LINKEDTOATTRIBUTE,
           com.ibm.www.maximo.MXStringQueryType[] LINKEDTOSECTION,
           com.ibm.www.maximo.MXBooleanQueryType[] MANDATORY,
           com.ibm.www.maximo.MXStringQueryType[] MEASUREUNITID,
           com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE,
           com.ibm.www.maximo.MXStringQueryType[] ORGID,
           com.ibm.www.maximo.MXLongQueryType[] REFOBJECTID,
           com.ibm.www.maximo.MXStringQueryType[] REFOBJECTNAME,
           com.ibm.www.maximo.MXStringQueryType[] SECTION,
           com.ibm.www.maximo.MXStringQueryType[] SITEID,
           com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE,
           com.ibm.www.maximo.MXLongQueryType[] TICKETSPECID,
           java.lang.Boolean filter) {
           this.ALNVALUE = ALNVALUE;
           this.ASSETATTRID = ASSETATTRID;
           this.CHANGEBY = CHANGEBY;
           this.CHANGEDATE = CHANGEDATE;
           this.CLASSSPECID = CLASSSPECID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DISPLAYSEQUENCE = DISPLAYSEQUENCE;
           this.LINKEDTOATTRIBUTE = LINKEDTOATTRIBUTE;
           this.LINKEDTOSECTION = LINKEDTOSECTION;
           this.MANDATORY = MANDATORY;
           this.MEASUREUNITID = MEASUREUNITID;
           this.NUMVALUE = NUMVALUE;
           this.ORGID = ORGID;
           this.REFOBJECTID = REFOBJECTID;
           this.REFOBJECTNAME = REFOBJECTNAME;
           this.SECTION = SECTION;
           this.SITEID = SITEID;
           this.TABLEVALUE = TABLEVALUE;
           this.TICKETSPECID = TICKETSPECID;
           this.filter = filter;
    }


    /**
     * Gets the ALNVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return ALNVALUE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getALNVALUE() {
        return ALNVALUE;
    }


    /**
     * Sets the ALNVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param ALNVALUE
     */
    public void setALNVALUE(com.ibm.www.maximo.MXStringQueryType[] ALNVALUE) {
        this.ALNVALUE = ALNVALUE;
    }

    public com.ibm.www.maximo.MXStringQueryType getALNVALUE(int i) {
        return this.ALNVALUE[i];
    }

    public void setALNVALUE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ALNVALUE[i] = _value;
    }


    /**
     * Gets the ASSETATTRID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return ASSETATTRID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getASSETATTRID() {
        return ASSETATTRID;
    }


    /**
     * Sets the ASSETATTRID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param ASSETATTRID   * Unique Key Component
     */
    public void setASSETATTRID(com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID) {
        this.ASSETATTRID = ASSETATTRID;
    }

    public com.ibm.www.maximo.MXStringQueryType getASSETATTRID(int i) {
        return this.ASSETATTRID[i];
    }

    public void setASSETATTRID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ASSETATTRID[i] = _value;
    }


    /**
     * Gets the CHANGEBY value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return CHANGEBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCHANGEBY() {
        return CHANGEBY;
    }


    /**
     * Sets the CHANGEBY value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param CHANGEBY
     */
    public void setCHANGEBY(com.ibm.www.maximo.MXStringQueryType[] CHANGEBY) {
        this.CHANGEBY = CHANGEBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getCHANGEBY(int i) {
        return this.CHANGEBY[i];
    }

    public void setCHANGEBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CHANGEBY[i] = _value;
    }


    /**
     * Gets the CHANGEDATE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return CHANGEDATE
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getCHANGEDATE() {
        return CHANGEDATE;
    }


    /**
     * Sets the CHANGEDATE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param CHANGEDATE
     */
    public void setCHANGEDATE(com.ibm.www.maximo.MXDateTimeQueryType[] CHANGEDATE) {
        this.CHANGEDATE = CHANGEDATE;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getCHANGEDATE(int i) {
        return this.CHANGEDATE[i];
    }

    public void setCHANGEDATE(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.CHANGEDATE[i] = _value;
    }


    /**
     * Gets the CLASSSPECID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return CLASSSPECID
     */
    public com.ibm.www.maximo.MXLongQueryType[] getCLASSSPECID() {
        return CLASSSPECID;
    }


    /**
     * Sets the CLASSSPECID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param CLASSSPECID
     */
    public void setCLASSSPECID(com.ibm.www.maximo.MXLongQueryType[] CLASSSPECID) {
        this.CLASSSPECID = CLASSSPECID;
    }

    public com.ibm.www.maximo.MXLongQueryType getCLASSSPECID(int i) {
        return this.CLASSSPECID[i];
    }

    public void setCLASSSPECID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.CLASSSPECID[i] = _value;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return CLASSSTRUCTUREID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param CLASSSTRUCTUREID
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSSTRUCTUREID(int i) {
        return this.CLASSSTRUCTUREID[i];
    }

    public void setCLASSSTRUCTUREID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSSTRUCTUREID[i] = _value;
    }


    /**
     * Gets the DISPLAYSEQUENCE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return DISPLAYSEQUENCE
     */
    public com.ibm.www.maximo.MXLongQueryType[] getDISPLAYSEQUENCE() {
        return DISPLAYSEQUENCE;
    }


    /**
     * Sets the DISPLAYSEQUENCE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param DISPLAYSEQUENCE
     */
    public void setDISPLAYSEQUENCE(com.ibm.www.maximo.MXLongQueryType[] DISPLAYSEQUENCE) {
        this.DISPLAYSEQUENCE = DISPLAYSEQUENCE;
    }

    public com.ibm.www.maximo.MXLongQueryType getDISPLAYSEQUENCE(int i) {
        return this.DISPLAYSEQUENCE[i];
    }

    public void setDISPLAYSEQUENCE(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.DISPLAYSEQUENCE[i] = _value;
    }


    /**
     * Gets the LINKEDTOATTRIBUTE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return LINKEDTOATTRIBUTE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getLINKEDTOATTRIBUTE() {
        return LINKEDTOATTRIBUTE;
    }


    /**
     * Sets the LINKEDTOATTRIBUTE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param LINKEDTOATTRIBUTE
     */
    public void setLINKEDTOATTRIBUTE(com.ibm.www.maximo.MXStringQueryType[] LINKEDTOATTRIBUTE) {
        this.LINKEDTOATTRIBUTE = LINKEDTOATTRIBUTE;
    }

    public com.ibm.www.maximo.MXStringQueryType getLINKEDTOATTRIBUTE(int i) {
        return this.LINKEDTOATTRIBUTE[i];
    }

    public void setLINKEDTOATTRIBUTE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.LINKEDTOATTRIBUTE[i] = _value;
    }


    /**
     * Gets the LINKEDTOSECTION value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return LINKEDTOSECTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getLINKEDTOSECTION() {
        return LINKEDTOSECTION;
    }


    /**
     * Sets the LINKEDTOSECTION value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param LINKEDTOSECTION
     */
    public void setLINKEDTOSECTION(com.ibm.www.maximo.MXStringQueryType[] LINKEDTOSECTION) {
        this.LINKEDTOSECTION = LINKEDTOSECTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getLINKEDTOSECTION(int i) {
        return this.LINKEDTOSECTION[i];
    }

    public void setLINKEDTOSECTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.LINKEDTOSECTION[i] = _value;
    }


    /**
     * Gets the MANDATORY value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return MANDATORY
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getMANDATORY() {
        return MANDATORY;
    }


    /**
     * Sets the MANDATORY value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param MANDATORY
     */
    public void setMANDATORY(com.ibm.www.maximo.MXBooleanQueryType[] MANDATORY) {
        this.MANDATORY = MANDATORY;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getMANDATORY(int i) {
        return this.MANDATORY[i];
    }

    public void setMANDATORY(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.MANDATORY[i] = _value;
    }


    /**
     * Gets the MEASUREUNITID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return MEASUREUNITID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getMEASUREUNITID() {
        return MEASUREUNITID;
    }


    /**
     * Sets the MEASUREUNITID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param MEASUREUNITID
     */
    public void setMEASUREUNITID(com.ibm.www.maximo.MXStringQueryType[] MEASUREUNITID) {
        this.MEASUREUNITID = MEASUREUNITID;
    }

    public com.ibm.www.maximo.MXStringQueryType getMEASUREUNITID(int i) {
        return this.MEASUREUNITID[i];
    }

    public void setMEASUREUNITID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.MEASUREUNITID[i] = _value;
    }


    /**
     * Gets the NUMVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return NUMVALUE
     */
    public com.ibm.www.maximo.MXDoubleQueryType[] getNUMVALUE() {
        return NUMVALUE;
    }


    /**
     * Sets the NUMVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param NUMVALUE
     */
    public void setNUMVALUE(com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE) {
        this.NUMVALUE = NUMVALUE;
    }

    public com.ibm.www.maximo.MXDoubleQueryType getNUMVALUE(int i) {
        return this.NUMVALUE[i];
    }

    public void setNUMVALUE(int i, com.ibm.www.maximo.MXDoubleQueryType _value) {
        this.NUMVALUE[i] = _value;
    }


    /**
     * Gets the ORGID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return ORGID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getORGID() {
        return ORGID;
    }


    /**
     * Sets the ORGID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param ORGID
     */
    public void setORGID(com.ibm.www.maximo.MXStringQueryType[] ORGID) {
        this.ORGID = ORGID;
    }

    public com.ibm.www.maximo.MXStringQueryType getORGID(int i) {
        return this.ORGID[i];
    }

    public void setORGID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ORGID[i] = _value;
    }


    /**
     * Gets the REFOBJECTID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return REFOBJECTID
     */
    public com.ibm.www.maximo.MXLongQueryType[] getREFOBJECTID() {
        return REFOBJECTID;
    }


    /**
     * Sets the REFOBJECTID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param REFOBJECTID
     */
    public void setREFOBJECTID(com.ibm.www.maximo.MXLongQueryType[] REFOBJECTID) {
        this.REFOBJECTID = REFOBJECTID;
    }

    public com.ibm.www.maximo.MXLongQueryType getREFOBJECTID(int i) {
        return this.REFOBJECTID[i];
    }

    public void setREFOBJECTID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.REFOBJECTID[i] = _value;
    }


    /**
     * Gets the REFOBJECTNAME value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return REFOBJECTNAME
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREFOBJECTNAME() {
        return REFOBJECTNAME;
    }


    /**
     * Sets the REFOBJECTNAME value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param REFOBJECTNAME
     */
    public void setREFOBJECTNAME(com.ibm.www.maximo.MXStringQueryType[] REFOBJECTNAME) {
        this.REFOBJECTNAME = REFOBJECTNAME;
    }

    public com.ibm.www.maximo.MXStringQueryType getREFOBJECTNAME(int i) {
        return this.REFOBJECTNAME[i];
    }

    public void setREFOBJECTNAME(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REFOBJECTNAME[i] = _value;
    }


    /**
     * Gets the SECTION value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return SECTION   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSECTION() {
        return SECTION;
    }


    /**
     * Sets the SECTION value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param SECTION   * Unique Key Component
     */
    public void setSECTION(com.ibm.www.maximo.MXStringQueryType[] SECTION) {
        this.SECTION = SECTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getSECTION(int i) {
        return this.SECTION[i];
    }

    public void setSECTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SECTION[i] = _value;
    }


    /**
     * Gets the SITEID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return SITEID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param SITEID
     */
    public void setSITEID(com.ibm.www.maximo.MXStringQueryType[] SITEID) {
        this.SITEID = SITEID;
    }

    public com.ibm.www.maximo.MXStringQueryType getSITEID(int i) {
        return this.SITEID[i];
    }

    public void setSITEID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SITEID[i] = _value;
    }


    /**
     * Gets the TABLEVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return TABLEVALUE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTABLEVALUE() {
        return TABLEVALUE;
    }


    /**
     * Sets the TABLEVALUE value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param TABLEVALUE
     */
    public void setTABLEVALUE(com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE) {
        this.TABLEVALUE = TABLEVALUE;
    }

    public com.ibm.www.maximo.MXStringQueryType getTABLEVALUE(int i) {
        return this.TABLEVALUE[i];
    }

    public void setTABLEVALUE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TABLEVALUE[i] = _value;
    }


    /**
     * Gets the TICKETSPECID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return TICKETSPECID
     */
    public com.ibm.www.maximo.MXLongQueryType[] getTICKETSPECID() {
        return TICKETSPECID;
    }


    /**
     * Sets the TICKETSPECID value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param TICKETSPECID
     */
    public void setTICKETSPECID(com.ibm.www.maximo.MXLongQueryType[] TICKETSPECID) {
        this.TICKETSPECID = TICKETSPECID;
    }

    public com.ibm.www.maximo.MXLongQueryType getTICKETSPECID(int i) {
        return this.TICKETSPECID[i];
    }

    public void setTICKETSPECID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.TICKETSPECID[i] = _value;
    }


    /**
     * Gets the filter value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @return filter
     */
    public java.lang.Boolean getFilter() {
        return filter;
    }


    /**
     * Sets the filter value for this ITAUWDSRQueryTypeSRTICKETSPEC.
     * 
     * @param filter
     */
    public void setFilter(java.lang.Boolean filter) {
        this.filter = filter;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRQueryTypeSRTICKETSPEC)) return false;
        ITAUWDSRQueryTypeSRTICKETSPEC other = (ITAUWDSRQueryTypeSRTICKETSPEC) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ALNVALUE==null && other.getALNVALUE()==null) || 
             (this.ALNVALUE!=null &&
              java.util.Arrays.equals(this.ALNVALUE, other.getALNVALUE()))) &&
            ((this.ASSETATTRID==null && other.getASSETATTRID()==null) || 
             (this.ASSETATTRID!=null &&
              java.util.Arrays.equals(this.ASSETATTRID, other.getASSETATTRID()))) &&
            ((this.CHANGEBY==null && other.getCHANGEBY()==null) || 
             (this.CHANGEBY!=null &&
              java.util.Arrays.equals(this.CHANGEBY, other.getCHANGEBY()))) &&
            ((this.CHANGEDATE==null && other.getCHANGEDATE()==null) || 
             (this.CHANGEDATE!=null &&
              java.util.Arrays.equals(this.CHANGEDATE, other.getCHANGEDATE()))) &&
            ((this.CLASSSPECID==null && other.getCLASSSPECID()==null) || 
             (this.CLASSSPECID!=null &&
              java.util.Arrays.equals(this.CLASSSPECID, other.getCLASSSPECID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTUREID, other.getCLASSSTRUCTUREID()))) &&
            ((this.DISPLAYSEQUENCE==null && other.getDISPLAYSEQUENCE()==null) || 
             (this.DISPLAYSEQUENCE!=null &&
              java.util.Arrays.equals(this.DISPLAYSEQUENCE, other.getDISPLAYSEQUENCE()))) &&
            ((this.LINKEDTOATTRIBUTE==null && other.getLINKEDTOATTRIBUTE()==null) || 
             (this.LINKEDTOATTRIBUTE!=null &&
              java.util.Arrays.equals(this.LINKEDTOATTRIBUTE, other.getLINKEDTOATTRIBUTE()))) &&
            ((this.LINKEDTOSECTION==null && other.getLINKEDTOSECTION()==null) || 
             (this.LINKEDTOSECTION!=null &&
              java.util.Arrays.equals(this.LINKEDTOSECTION, other.getLINKEDTOSECTION()))) &&
            ((this.MANDATORY==null && other.getMANDATORY()==null) || 
             (this.MANDATORY!=null &&
              java.util.Arrays.equals(this.MANDATORY, other.getMANDATORY()))) &&
            ((this.MEASUREUNITID==null && other.getMEASUREUNITID()==null) || 
             (this.MEASUREUNITID!=null &&
              java.util.Arrays.equals(this.MEASUREUNITID, other.getMEASUREUNITID()))) &&
            ((this.NUMVALUE==null && other.getNUMVALUE()==null) || 
             (this.NUMVALUE!=null &&
              java.util.Arrays.equals(this.NUMVALUE, other.getNUMVALUE()))) &&
            ((this.ORGID==null && other.getORGID()==null) || 
             (this.ORGID!=null &&
              java.util.Arrays.equals(this.ORGID, other.getORGID()))) &&
            ((this.REFOBJECTID==null && other.getREFOBJECTID()==null) || 
             (this.REFOBJECTID!=null &&
              java.util.Arrays.equals(this.REFOBJECTID, other.getREFOBJECTID()))) &&
            ((this.REFOBJECTNAME==null && other.getREFOBJECTNAME()==null) || 
             (this.REFOBJECTNAME!=null &&
              java.util.Arrays.equals(this.REFOBJECTNAME, other.getREFOBJECTNAME()))) &&
            ((this.SECTION==null && other.getSECTION()==null) || 
             (this.SECTION!=null &&
              java.util.Arrays.equals(this.SECTION, other.getSECTION()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              java.util.Arrays.equals(this.SITEID, other.getSITEID()))) &&
            ((this.TABLEVALUE==null && other.getTABLEVALUE()==null) || 
             (this.TABLEVALUE!=null &&
              java.util.Arrays.equals(this.TABLEVALUE, other.getTABLEVALUE()))) &&
            ((this.TICKETSPECID==null && other.getTICKETSPECID()==null) || 
             (this.TICKETSPECID!=null &&
              java.util.Arrays.equals(this.TICKETSPECID, other.getTICKETSPECID()))) &&
            ((this.filter==null && other.getFilter()==null) || 
             (this.filter!=null &&
              this.filter.equals(other.getFilter())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getALNVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getALNVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getALNVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getASSETATTRID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getASSETATTRID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getASSETATTRID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCHANGEBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCHANGEBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCHANGEBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCHANGEDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCHANGEDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCHANGEDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSPECID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSPECID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSPECID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSTRUCTUREID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTUREID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTUREID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDISPLAYSEQUENCE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDISPLAYSEQUENCE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDISPLAYSEQUENCE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLINKEDTOATTRIBUTE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLINKEDTOATTRIBUTE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLINKEDTOATTRIBUTE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLINKEDTOSECTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getLINKEDTOSECTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getLINKEDTOSECTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMANDATORY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMANDATORY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMANDATORY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMEASUREUNITID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getMEASUREUNITID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getMEASUREUNITID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNUMVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNUMVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNUMVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getORGID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getORGID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getORGID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREFOBJECTID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREFOBJECTID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREFOBJECTID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREFOBJECTNAME() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREFOBJECTNAME());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREFOBJECTNAME(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSITEID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSITEID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSITEID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTABLEVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTABLEVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTABLEVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETSPECID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETSPECID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETSPECID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFilter() != null) {
            _hashCode += getFilter().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRQueryTypeSRTICKETSPEC.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRQueryType>SR>TICKETSPEC"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("filter");
        attrField.setXmlName(new javax.xml.namespace.QName("", "filter"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ALNVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ALNVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ASSETATTRID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ASSETATTRID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHANGEBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CHANGEBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CHANGEDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CHANGEDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSPECID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSPECID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DISPLAYSEQUENCE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DISPLAYSEQUENCE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LINKEDTOATTRIBUTE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LINKEDTOATTRIBUTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LINKEDTOSECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LINKEDTOSECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MANDATORY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MANDATORY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MEASUREUNITID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MEASUREUNITID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NUMVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NUMVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDoubleQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ORGID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ORGID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFOBJECTID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REFOBJECTID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REFOBJECTNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REFOBJECTNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TABLEVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TABLEVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETSPECID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETSPECID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
