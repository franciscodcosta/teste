package com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO;

public class ITAUWDSRRESUMOPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType iTAUWDSRRESUMOPortType = null;
  
  public ITAUWDSRRESUMOPortTypeProxy() {
    _initITAUWDSRRESUMOPortTypeProxy();
  }
  
  public ITAUWDSRRESUMOPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDSRRESUMOPortTypeProxy();
  }
  
  private void _initITAUWDSRRESUMOPortTypeProxy() {
    try {
      iTAUWDSRRESUMOPortType = (new com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOLocator()).getITAUWDSRRESUMOSOAP11Port();
      if (iTAUWDSRRESUMOPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDSRRESUMOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDSRRESUMOPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDSRRESUMOPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDSRRESUMOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType getITAUWDSRRESUMOPortType() {
    if (iTAUWDSRRESUMOPortType == null)
      _initITAUWDSRRESUMOPortTypeProxy();
    return iTAUWDSRRESUMOPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDSRRESUMOResponseType queryITAUWDSRRESUMO(com.ibm.www.maximo.QueryITAUWDSRRESUMOType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRRESUMOPortType == null)
      _initITAUWDSRRESUMOPortTypeProxy();
    return iTAUWDSRRESUMOPortType.queryITAUWDSRRESUMO(parameters);
  }
  
  
}