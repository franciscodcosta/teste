/**
 * ITAUWDANEXOQueryTypeSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDANEXOQueryTypeSR  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainQueryType[] CLASS;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] TICKETID;

    private com.ibm.www.maximo.ITAUWDANEXOQueryTypeSRDOCLINKS DOCLINKS;

    public ITAUWDANEXOQueryTypeSR() {
    }

    public ITAUWDANEXOQueryTypeSR(
           com.ibm.www.maximo.MXDomainQueryType[] CLASS,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK,
           com.ibm.www.maximo.MXStringQueryType[] TICKETID,
           com.ibm.www.maximo.ITAUWDANEXOQueryTypeSRDOCLINKS DOCLINKS) {
           this.CLASS = CLASS;
           this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
           this.TICKETID = TICKETID;
           this.DOCLINKS = DOCLINKS;
    }


    /**
     * Gets the CLASS value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainQueryType[] CLASS) {
        this.CLASS = CLASS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getCLASS(int i) {
        return this.CLASS[i];
    }

    public void setCLASS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.CLASS[i] = _value;
    }


    /**
     * Gets the ITAU_GIQAGNSOK value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @return ITAU_GIQAGNSOK
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU_GIQAGNSOK() {
        return ITAU_GIQAGNSOK;
    }


    /**
     * Sets the ITAU_GIQAGNSOK value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @param ITAU_GIQAGNSOK
     */
    public void setITAU_GIQAGNSOK(com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK) {
        this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU_GIQAGNSOK(int i) {
        return this.ITAU_GIQAGNSOK[i];
    }

    public void setITAU_GIQAGNSOK(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU_GIQAGNSOK[i] = _value;
    }


    /**
     * Gets the TICKETID value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
        this.TICKETID = TICKETID;
    }

    public com.ibm.www.maximo.MXStringQueryType getTICKETID(int i) {
        return this.TICKETID[i];
    }

    public void setTICKETID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TICKETID[i] = _value;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDANEXOQueryTypeSRDOCLINKS getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDANEXOQueryTypeSR.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDANEXOQueryTypeSRDOCLINKS DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDANEXOQueryTypeSR)) return false;
        ITAUWDANEXOQueryTypeSR other = (ITAUWDANEXOQueryTypeSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              java.util.Arrays.equals(this.CLASS, other.getCLASS()))) &&
            ((this.ITAU_GIQAGNSOK==null && other.getITAU_GIQAGNSOK()==null) || 
             (this.ITAU_GIQAGNSOK!=null &&
              java.util.Arrays.equals(this.ITAU_GIQAGNSOK, other.getITAU_GIQAGNSOK()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              java.util.Arrays.equals(this.TICKETID, other.getTICKETID()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              this.DOCLINKS.equals(other.getDOCLINKS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_GIQAGNSOK() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_GIQAGNSOK());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_GIQAGNSOK(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOCLINKS() != null) {
            _hashCode += getDOCLINKS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDANEXOQueryTypeSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDANEXOQueryType>SR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GIQAGNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GIQAGNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDANEXOQueryType>SR>DOCLINKS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
