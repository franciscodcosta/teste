/**
 * ITAUWDSRRESUMOQueryTypeSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRRESUMOQueryTypeSR  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainQueryType[] CLASS;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GDISPOK;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK;

    private com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GNSOK;

    private com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    private com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] TICKETID;

    public ITAUWDSRRESUMOQueryTypeSR() {
    }

    public ITAUWDSRRESUMOQueryTypeSR(
           com.ibm.www.maximo.MXDomainQueryType[] CLASS,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GDISPOK,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK,
           com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GNSOK,
           com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH,
           com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
           this.CLASS = CLASS;
           this.ITAU_GDISPOK = ITAU_GDISPOK;
           this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
           this.ITAU_GNSOK = ITAU_GNSOK;
           this.REPORTDATE = REPORTDATE;
           this.REPORTEDBY = REPORTEDBY;
           this.STATUS = STATUS;
           this.TARGETFINISH = TARGETFINISH;
           this.TICKETID = TICKETID;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainQueryType[] CLASS) {
        this.CLASS = CLASS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getCLASS(int i) {
        return this.CLASS[i];
    }

    public void setCLASS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.CLASS[i] = _value;
    }


    /**
     * Gets the ITAU_GDISPOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return ITAU_GDISPOK
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU_GDISPOK() {
        return ITAU_GDISPOK;
    }


    /**
     * Sets the ITAU_GDISPOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param ITAU_GDISPOK
     */
    public void setITAU_GDISPOK(com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GDISPOK) {
        this.ITAU_GDISPOK = ITAU_GDISPOK;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU_GDISPOK(int i) {
        return this.ITAU_GDISPOK[i];
    }

    public void setITAU_GDISPOK(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU_GDISPOK[i] = _value;
    }


    /**
     * Gets the ITAU_GIQAGNSOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return ITAU_GIQAGNSOK
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU_GIQAGNSOK() {
        return ITAU_GIQAGNSOK;
    }


    /**
     * Sets the ITAU_GIQAGNSOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param ITAU_GIQAGNSOK
     */
    public void setITAU_GIQAGNSOK(com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GIQAGNSOK) {
        this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU_GIQAGNSOK(int i) {
        return this.ITAU_GIQAGNSOK[i];
    }

    public void setITAU_GIQAGNSOK(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU_GIQAGNSOK[i] = _value;
    }


    /**
     * Gets the ITAU_GNSOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return ITAU_GNSOK
     */
    public com.ibm.www.maximo.MXBooleanQueryType[] getITAU_GNSOK() {
        return ITAU_GNSOK;
    }


    /**
     * Sets the ITAU_GNSOK value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param ITAU_GNSOK
     */
    public void setITAU_GNSOK(com.ibm.www.maximo.MXBooleanQueryType[] ITAU_GNSOK) {
        this.ITAU_GNSOK = ITAU_GNSOK;
    }

    public com.ibm.www.maximo.MXBooleanQueryType getITAU_GNSOK(int i) {
        return this.ITAU_GNSOK[i];
    }

    public void setITAU_GNSOK(int i, com.ibm.www.maximo.MXBooleanQueryType _value) {
        this.ITAU_GNSOK[i] = _value;
    }


    /**
     * Gets the REPORTDATE value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return REPORTDATE
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getREPORTDATE() {
        return REPORTDATE;
    }


    /**
     * Sets the REPORTDATE value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param REPORTDATE
     */
    public void setREPORTDATE(com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE) {
        this.REPORTDATE = REPORTDATE;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getREPORTDATE(int i) {
        return this.REPORTDATE[i];
    }

    public void setREPORTDATE(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.REPORTDATE[i] = _value;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDBY(int i) {
        return this.REPORTEDBY[i];
    }

    public void setREPORTEDBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDBY[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the TARGETFINISH value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return TARGETFINISH
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getTARGETFINISH() {
        return TARGETFINISH;
    }


    /**
     * Sets the TARGETFINISH value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param TARGETFINISH
     */
    public void setTARGETFINISH(com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH) {
        this.TARGETFINISH = TARGETFINISH;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getTARGETFINISH(int i) {
        return this.TARGETFINISH[i];
    }

    public void setTARGETFINISH(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.TARGETFINISH[i] = _value;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRRESUMOQueryTypeSR.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
        this.TICKETID = TICKETID;
    }

    public com.ibm.www.maximo.MXStringQueryType getTICKETID(int i) {
        return this.TICKETID[i];
    }

    public void setTICKETID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TICKETID[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRRESUMOQueryTypeSR)) return false;
        ITAUWDSRRESUMOQueryTypeSR other = (ITAUWDSRRESUMOQueryTypeSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              java.util.Arrays.equals(this.CLASS, other.getCLASS()))) &&
            ((this.ITAU_GDISPOK==null && other.getITAU_GDISPOK()==null) || 
             (this.ITAU_GDISPOK!=null &&
              java.util.Arrays.equals(this.ITAU_GDISPOK, other.getITAU_GDISPOK()))) &&
            ((this.ITAU_GIQAGNSOK==null && other.getITAU_GIQAGNSOK()==null) || 
             (this.ITAU_GIQAGNSOK!=null &&
              java.util.Arrays.equals(this.ITAU_GIQAGNSOK, other.getITAU_GIQAGNSOK()))) &&
            ((this.ITAU_GNSOK==null && other.getITAU_GNSOK()==null) || 
             (this.ITAU_GNSOK!=null &&
              java.util.Arrays.equals(this.ITAU_GNSOK, other.getITAU_GNSOK()))) &&
            ((this.REPORTDATE==null && other.getREPORTDATE()==null) || 
             (this.REPORTDATE!=null &&
              java.util.Arrays.equals(this.REPORTDATE, other.getREPORTDATE()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              java.util.Arrays.equals(this.REPORTEDBY, other.getREPORTEDBY()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.TARGETFINISH==null && other.getTARGETFINISH()==null) || 
             (this.TARGETFINISH!=null &&
              java.util.Arrays.equals(this.TARGETFINISH, other.getTARGETFINISH()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              java.util.Arrays.equals(this.TICKETID, other.getTICKETID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_GDISPOK() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_GDISPOK());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_GDISPOK(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_GIQAGNSOK() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_GIQAGNSOK());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_GIQAGNSOK(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_GNSOK() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_GNSOK());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_GNSOK(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTARGETFINISH() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTARGETFINISH());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTARGETFINISH(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRRESUMOQueryTypeSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRRESUMOQueryType>SR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GDISPOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GDISPOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GIQAGNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GIQAGNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TARGETFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TARGETFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
