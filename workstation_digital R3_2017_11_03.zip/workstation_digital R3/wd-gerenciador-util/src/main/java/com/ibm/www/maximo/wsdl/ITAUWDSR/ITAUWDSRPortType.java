/**
 * ITAUWDSRPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDSR;

public interface ITAUWDSRPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDSRResponseType queryITAUWDSR(com.ibm.www.maximo.QueryITAUWDSRType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.SyncITAUWDSRResponseType syncITAUWDSR(com.ibm.www.maximo.SyncITAUWDSRType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.UpdateITAUWDSRResponseType updateITAUWDSR(com.ibm.www.maximo.UpdateITAUWDSRType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.CreateITAUWDSRResponseType createITAUWDSR(com.ibm.www.maximo.CreateITAUWDSRType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.DeleteITAUWDSRResponseType deleteITAUWDSR(com.ibm.www.maximo.DeleteITAUWDSRType parameters) throws java.rmi.RemoteException;
}
