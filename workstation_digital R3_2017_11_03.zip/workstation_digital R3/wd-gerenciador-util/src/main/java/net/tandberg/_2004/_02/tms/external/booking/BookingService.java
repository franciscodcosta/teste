/**
 * BookingService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public interface BookingService extends javax.xml.rpc.Service {

/**
 * Refer to the Cisco TelePresence Management Suite Extension Booking
 * API Programming Reference Guide for more information.
 */
    public java.lang.String getBookingServiceSoapAddress();

    public net.tandberg._2004._02.tms.external.booking.BookingServiceSoap getBookingServiceSoap() throws javax.xml.rpc.ServiceException;

    public net.tandberg._2004._02.tms.external.booking.BookingServiceSoap getBookingServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
