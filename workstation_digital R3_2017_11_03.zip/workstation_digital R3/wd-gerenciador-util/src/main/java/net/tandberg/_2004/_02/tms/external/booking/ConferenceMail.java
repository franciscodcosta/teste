/**
 * ConferenceMail.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class ConferenceMail  implements java.io.Serializable {
    private net.tandberg._2004._02.tms.external.booking.MailContentType contentType;

    private java.lang.String mailContent;

    private java.lang.String mailSubject;

    public ConferenceMail() {
    }

    public ConferenceMail(
           net.tandberg._2004._02.tms.external.booking.MailContentType contentType,
           java.lang.String mailContent,
           java.lang.String mailSubject) {
           this.contentType = contentType;
           this.mailContent = mailContent;
           this.mailSubject = mailSubject;
    }


    /**
     * Gets the contentType value for this ConferenceMail.
     * 
     * @return contentType
     */
    public net.tandberg._2004._02.tms.external.booking.MailContentType getContentType() {
        return contentType;
    }


    /**
     * Sets the contentType value for this ConferenceMail.
     * 
     * @param contentType
     */
    public void setContentType(net.tandberg._2004._02.tms.external.booking.MailContentType contentType) {
        this.contentType = contentType;
    }


    /**
     * Gets the mailContent value for this ConferenceMail.
     * 
     * @return mailContent
     */
    public java.lang.String getMailContent() {
        return mailContent;
    }


    /**
     * Sets the mailContent value for this ConferenceMail.
     * 
     * @param mailContent
     */
    public void setMailContent(java.lang.String mailContent) {
        this.mailContent = mailContent;
    }


    /**
     * Gets the mailSubject value for this ConferenceMail.
     * 
     * @return mailSubject
     */
    public java.lang.String getMailSubject() {
        return mailSubject;
    }


    /**
     * Sets the mailSubject value for this ConferenceMail.
     * 
     * @param mailSubject
     */
    public void setMailSubject(java.lang.String mailSubject) {
        this.mailSubject = mailSubject;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConferenceMail)) return false;
        ConferenceMail other = (ConferenceMail) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.contentType==null && other.getContentType()==null) || 
             (this.contentType!=null &&
              this.contentType.equals(other.getContentType()))) &&
            ((this.mailContent==null && other.getMailContent()==null) || 
             (this.mailContent!=null &&
              this.mailContent.equals(other.getMailContent()))) &&
            ((this.mailSubject==null && other.getMailSubject()==null) || 
             (this.mailSubject!=null &&
              this.mailSubject.equals(other.getMailSubject())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getContentType() != null) {
            _hashCode += getContentType().hashCode();
        }
        if (getMailContent() != null) {
            _hashCode += getMailContent().hashCode();
        }
        if (getMailSubject() != null) {
            _hashCode += getMailSubject().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConferenceMail.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceMail"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contentType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ContentType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailContentType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailContent");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailContent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mailSubject");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MailSubject"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
