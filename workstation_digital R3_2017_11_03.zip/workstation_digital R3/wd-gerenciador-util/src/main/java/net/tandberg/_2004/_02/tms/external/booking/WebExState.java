/**
 * WebExState.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class WebExState  implements java.io.Serializable {
    private net.tandberg._2004._02.tms.external.booking.WebExInstanceType webExInstanceType;

    public WebExState() {
    }

    public WebExState(
           net.tandberg._2004._02.tms.external.booking.WebExInstanceType webExInstanceType) {
           this.webExInstanceType = webExInstanceType;
    }


    /**
     * Gets the webExInstanceType value for this WebExState.
     * 
     * @return webExInstanceType
     */
    public net.tandberg._2004._02.tms.external.booking.WebExInstanceType getWebExInstanceType() {
        return webExInstanceType;
    }


    /**
     * Sets the webExInstanceType value for this WebExState.
     * 
     * @param webExInstanceType
     */
    public void setWebExInstanceType(net.tandberg._2004._02.tms.external.booking.WebExInstanceType webExInstanceType) {
        this.webExInstanceType = webExInstanceType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WebExState)) return false;
        WebExState other = (WebExState) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.webExInstanceType==null && other.getWebExInstanceType()==null) || 
             (this.webExInstanceType!=null &&
              this.webExInstanceType.equals(other.getWebExInstanceType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWebExInstanceType() != null) {
            _hashCode += getWebExInstanceType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WebExState.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExState"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webExInstanceType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExInstanceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExInstanceType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
