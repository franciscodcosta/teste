package br.com.itau.wd.gerenciador.sr.router.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.router.service.RouterSoapService;

@RestController
@RequestMapping(value="/router/service")
public class RouterSOAPController {

	@Autowired
	RouterSoapService service;

	/**
	 * Executa o serviço soap
	 * 
	 * @param json
	 * @param endpoint
	 * @param endpointNegocio
	 * @return
	 * @throws SRException 
	 */
	@RequestMapping(value="/soap", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String executarSOAP(@RequestBody String json,
							   @RequestHeader(value="endpoint") String endpoint,
							   @RequestHeader(value="endpointnegocio") String endpointNegocio) throws SRException {

		return service.executarServico(endpoint, endpointNegocio, json);
	}	
}
