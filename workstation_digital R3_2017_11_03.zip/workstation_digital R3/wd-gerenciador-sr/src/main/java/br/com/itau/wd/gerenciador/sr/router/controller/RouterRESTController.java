package br.com.itau.wd.gerenciador.sr.router.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.router.service.RouterRestService;

@RestController
@RequestMapping(value="/router/service")
public class RouterRESTController {

	@Autowired
	RouterRestService service;

	/**
	 * Executa o serviço rest
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws SRException 
	 */
	@RequestMapping(value="/rest", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String executarREST(@RequestBody String json,
							   @RequestHeader(value="endpoint") String endpoint) throws SRException {

		return service.executarServico(endpoint, json);
	}
}