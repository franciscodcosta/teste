package br.com.itau.wd.gerenciador.sr.router.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.router.service.RouterSalesforceService;

@RestController
@RequestMapping(value="/router/service")
public class RouterSalesforceController {

	@Autowired
	RouterSalesforceService service;

	/**
	 * Executa o serviço Salesforce
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws SRException 
	 */
	@RequestMapping(value="/salesforce", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String executarSalesforce(@RequestBody String json,
			                         @RequestHeader(value="endpoint") String endpoint) throws SRException  {

		return service.executarServico(endpoint, json);
	}
}
