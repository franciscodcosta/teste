package br.com.itau.wd.gerenciador.sr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sr.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.service.SRService;

@RestController
public class SRController {

	@Autowired
	private SRService service;

	/**
	 * Obtem os dados do endpoint do serviço
	 * 
	 * @param codigoServico
	 * @return
	 * @throws SRException 
	 */
	@RequestMapping(value="/endpoint", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public EndpointDto obterEndpoint(@RequestParam(value="codigo_servico") String codigoServico) throws SRException {

		return service.obterEndpoint(codigoServico);
	}

	/**
	 * Obtem os dados dp endpoint do microserviço
	 * 
	 * @param codigoMicroServico
	 * @return
	 * @throws SRException
	 */
	@RequestMapping(value="/microservico", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public EndpointDto obterMicroServico(@RequestParam(value="codigo_microservico") int codigoMicroServico) throws SRException {

		return service.obterMicroServico(codigoMicroServico);
	}	
}
