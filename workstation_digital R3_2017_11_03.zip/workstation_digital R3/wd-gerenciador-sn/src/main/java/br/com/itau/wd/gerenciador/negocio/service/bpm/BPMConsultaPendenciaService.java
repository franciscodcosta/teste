package br.com.itau.wd.gerenciador.negocio.service.bpm;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CONTADOR_PAGINAS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_QTD_POR_PAGINA;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOTAL_PAGINAS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.annotation.Resource;
import javax.xml.rpc.holders.IntHolder;
import javax.xml.rpc.holders.StringHolder;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortTypeProxy;
import AH7P001.ConsultarProcuracao_tws.holders.ResumoProcuracaoWorkstationHolder;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class BPMConsultaPendenciaService {

	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		JsonObject objJsonRequisicao = new JsonObject();

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);
			
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_CONTADOR_PAGINAS, objJson.get(JSON_KEY_CONTADOR_PAGINAS).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_QTD_POR_PAGINA, objJson.get(JSON_KEY_QTD_POR_PAGINA).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_TOKEN, objJson.get(JSON_KEY_TOKEN).getAsString());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return objJsonRequisicao.toString();
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_UID, objJson.get(JSON_KEY_UID).getAsString());
		objJsonResposta.addProperty(JSON_KEY_TOTAL_PAGINAS, objJson.get(JSON_KEY_TOTAL_PAGINAS).getAsString());
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Consulta a pendência
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarPendencia(String json, String endpoint) throws NegocioException {
		
		String retorno = "";

		try {

			System.out.println("***** BPM *****");
			System.out.println("JSON REQUISIÇÃO = " + json);

			ConsultarProcuracaoPortTypeProxy proxy = new ConsultarProcuracaoPortTypeProxy();
			
			int idProcuracao = Integer.parseInt(GerenciadorUtils.obterDadoJson(json, "chave_produto"));
			String funcionalAprovador = GerenciadorUtils.obterDadoJson(json, "funcional_sistema_produto");
			String usuarioAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU);
			String tokenAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS);
			
			System.out.println("ID PROCURACAO = " + idProcuracao);
			System.out.println("FUNCIONAL APROVADOR = " + funcionalAprovador);
			System.out.println("USUARIO ACESSO = " + usuarioAcesso);
			System.out.println("TOKEN ACESSO = " + tokenAcesso);
			
			ResumoProcuracaoWorkstationHolder resultadoConsulta = new ResumoProcuracaoWorkstationHolder();
			IntHolder codigoRetorno = new IntHolder();
			StringHolder mensagemRetorno = new StringHolder();
			
			proxy.setEndpoint(endpoint);
			proxy.consultarProcuracaoWorkstation(idProcuracao, funcionalAprovador, usuarioAcesso, tokenAcesso, resultadoConsulta, codigoRetorno, mensagemRetorno);
			
			if(codigoRetorno.value != 0){
				throw new NegocioException(mensagemRetorno.value);
			} else {		
				
				Calendar data = resultadoConsulta.value.getDataSolicitacaoAprovacao();
				final DateFormat df1 = new SimpleDateFormat("dd-MM-yyyy");
				final DateFormat df2 = new SimpleDateFormat("HH:mm:ss");
				
				retorno = "{\"status\":\"S\"," +
							"\"total_paginas\":\"1\"," +
							"\"dados\":{\"solicitante_nome\":\"" + resultadoConsulta.value.getSolicitanteNome() + "\"," +
							"\"area_solicitacao_procuracao\":\"" + resultadoConsulta.value.getAreaSolicitacaoProcuracao() + "\"," +
							"\"tipo_instrumento\":\"" + resultadoConsulta.value.getTipoInstrumento() + "\"," +
							"\"nome_poder\":\"" + resultadoConsulta.value.getNomePoder() + "\"," +
							"\"texto_descricao_poder\":\"" + StringEscapeUtils.escapeJava(resultadoConsulta.value.getTextoDescricaoPoder()) + "\"," +
							"\"dt_ss_aprovacao\":\"" + df1.format(data.getTime()) + " " + df2.format(data.getTime()) + "\"," +
							"\"id_procuracao\":\"" + resultadoConsulta.value.getIdProcuracao() + "\"," +
							"\"id_tarefa\":\"" + resultadoConsulta.value.getIdTarefa() + "\"}}";
			}
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
}