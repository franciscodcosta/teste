package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_SIGLA_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;

import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;

/**
 * Máximo Service - Notificação
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoNotificacaoService {

	/**
	 * Monta o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonRequisicao = new JsonObject();

			objJsonRequisicao.addProperty(JSON_KEY_UID, objJson.get(JSON_KEY_UID).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_SIGLA_SISTEMA_PRODUTO, objJson.get(JSON_KEY_SIGLA_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO).getAsString());

			return objJsonRequisicao.toString();
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonResposta = new JsonObject();

			objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
			objJsonResposta.addProperty(JSON_KEY_STATUS, objJson.get(JSON_KEY_STATUS).getAsString());

			return objJsonResposta.toString();
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
	}
}