package br.com.itau.wd.gerenciador.negocio.service.sap;

import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD;
import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_USERNAME;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CONTADOR_PAGINAS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_QTD_POR_PAGINA;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_SIGLA_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOTAL_PAGINAS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_SENHA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_USUARIO;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_BPM;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SAP;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;
import static br.com.itau.wd.gerenciador.util.Constants.TLS_V1;

import java.io.IOException;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_out;
import br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_out;
import br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_out;
import br.com.itau.WorkstationDigital.Consulta_Documento.SI_Consulta_Documento_outProxy;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class SAPConsultaPendenciaService {

	private static final Logger logger = LoggerFactory.getLogger(SAPConsultaPendenciaService.class);
	
	@Resource
	private Environment env;
	
	/**
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 * @throws Exception 
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			String siglaSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_SIGLA_SISTEMA_PRODUTO);

			Map<String, String> mapDePara = new HashMap<>();

			switch (siglaSistemaProduto.toUpperCase()) {
			
				case SIGLA_SISTEMA_SAP:

					criarMapaRequisicaoSap(mapDePara);
					break;
					
				case SIGLA_SISTEMA_BPM:

					criarMapaRequisicaoBpm(mapDePara);
					break;
					
				default:
			}

			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return retorno;
	}

	/**
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException 
	 * @throws IOException 
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, String> mapDePara = new HashMap<>();
	
			criarMapaResposta(mapDePara);
	
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara);
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Faz o processamento do SAP
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	public String obterJsonRespostaSap(String endpoint, String json) throws NegocioException {

		StringBuilder retorno = new StringBuilder();

		try {

			// Configurar TLS
			NegocioUtils.configurarTls(TLS_V1);

			String chaveProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CHAVE_PRODUTO);
			String contadorPaginas = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CONTADOR_PAGINAS);
			String funcaoAtividadeSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
			String funcaoSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
			String qtdPorPagina = GerenciadorUtils.obterDadoJson(json, JSON_KEY_QTD_POR_PAGINA);
			String tokenOauth = GerenciadorUtils.obterDadoJson(json, JSON_KEY_TOKEN);

			System.out.println("***** CONSULTA PENDENCIA (SAP) *****");
			System.out.println("ENDPOINT ....................... : " + endpoint);
			System.out.println("JSON ........................... : " + json);
			System.out.println("CHAVE PRODUTO .................. : " + chaveProduto);
			System.out.println("CONTADOR PAGINAS ............... : " + contadorPaginas);
			System.out.println("FUNCAO ATIVIDADE SISTEMA PRODUTO : " + funcaoAtividadeSistemaProduto);
			System.out.println("FUNCAO SISTEMA PRODUTO ......... : " + funcaoSistemaProduto);
			System.out.println("QTD POR PAGINA ................. : " + qtdPorPagina);
			System.out.println("TOKEN .......................... : " + tokenOauth);
			
			if (logger.isDebugEnabled()) {
				logger.info("***** CONSULTA PENDENCIA (SAP) *****");
				logger.info("ENDPOINT ....................... : " + endpoint);
				logger.info("JSON ........................... : " + json);
				logger.info("CHAVE PRODUTO .................. : " + chaveProduto);
				logger.info("CONTADOR PAGINAS ............... : " + contadorPaginas);
				logger.info("FUNCAO ATIVIDADE SISTEMA PRODUTO : " + funcaoAtividadeSistemaProduto);
				logger.info("FUNCAO SISTEMA PRODUTO ......... : " + funcaoSistemaProduto);
				logger.info("QTD POR PAGINA ................. : " + qtdPorPagina);
				logger.info("TOKEN .......................... : " + tokenOauth);
			}
			
			DT_Consulta_Documento_out dtConsultaDocumentoOut = new DT_Consulta_Documento_out();

			dtConsultaDocumentoOut.setChave_produto(chaveProduto);
			dtConsultaDocumentoOut.setContador_paginas(new BigInteger("0" + contadorPaginas));
			dtConsultaDocumentoOut.setFuncao_atividade_sistema_produto(funcaoAtividadeSistemaProduto);
			dtConsultaDocumentoOut.setFuncao_sistema_produto(funcaoSistemaProduto);
			dtConsultaDocumentoOut.setQtd_por_pagina(new BigInteger("0" + qtdPorPagina));
			dtConsultaDocumentoOut.setToken_oauth(tokenOauth);

			SI_Consulta_Documento_outProxy proxy = new SI_Consulta_Documento_outProxy(endpoint);

			SI_Consulta_Documento_out siConsultaDocumentoOut = proxy.getSI_Consulta_Documento_out();
		    ((javax.xml.rpc.Stub)siConsultaDocumentoOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_USERNAME, env.getRequiredProperty(PROPERTY_KEY_SAP_USUARIO));
		    ((javax.xml.rpc.Stub)siConsultaDocumentoOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD, env.getRequiredProperty(PROPERTY_KEY_SAP_SENHA));

			DT_Consulta_Documento_Response_out resposta = proxy.SI_Consulta_Documento_out(dtConsultaDocumentoOut);

			if ("S".equalsIgnoreCase(resposta.getLog_status().getStatus())) {

				retorno.append("{");
				retorno.append(String.format("\"%s\":\"%s\",", JSON_KEY_FUNCAO_SISTEMA_PRODUTO, funcaoSistemaProduto));
				retorno.append(String.format("\"%s\":\"%s\",", JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, funcaoAtividadeSistemaProduto));
				retorno.append(String.format("\"%s\":\"%s\",", JSON_KEY_CHAVE_PRODUTO, chaveProduto));
				retorno.append(String.format("\"%s\":\"%s\",", JSON_KEY_TOTAL_PAGINAS, resposta.getTotal_paginas()));
				retorno.append(String.format("\"%s\":%s", JSON_KEY_DADOS, resposta.getDados()));
				retorno.append("}");
			}
			else {

				throw new NegocioException(resposta.getLog_status().getMensagem());
			}
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno.toString();
	}
	
	/**
	 * Cria o mapa de requisição do SAP
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRequisicaoSap(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
		mapDePara.put(JSON_KEY_CONTADOR_PAGINAS, JSON_KEY_CONTADOR_PAGINAS);
		mapDePara.put(JSON_KEY_QTD_POR_PAGINA, JSON_KEY_QTD_POR_PAGINA);
		mapDePara.put(JSON_KEY_TOKEN, JSON_KEY_TOKEN);
	}

	/**
	 * Cria o mapa de requisição do BPM
	 * 
	 * @param mapDePara
	 */
	private void criarMapaRequisicaoBpm(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
		mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
		mapDePara.put(JSON_KEY_CONTADOR_PAGINAS, JSON_KEY_CONTADOR_PAGINAS);
		mapDePara.put(JSON_KEY_QTD_POR_PAGINA, JSON_KEY_QTD_POR_PAGINA);
		mapDePara.put(JSON_KEY_TOKEN, JSON_KEY_TOKEN);
	}

	/**
	 * Cria o mapa de resposta
	 * 
	 * @param mapDePara
	 */
	private void criarMapaResposta(Map<String, String> mapDePara) {
		
		mapDePara.put(JSON_KEY_UID, JSON_KEY_UID);
		mapDePara.put(JSON_KEY_TOTAL_PAGINAS, JSON_KEY_TOTAL_PAGINAS);
		mapDePara.put(JSON_KEY_DADOS, JSON_KEY_DADOS);
	}
}