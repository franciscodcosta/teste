package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.Conference;
import net.tandberg._2004._02.tms.external.booking.ConferenceStatus;

@Service
public class TMSConsultaSalasTeleconferenciaService {

	private static final Logger logger = LoggerFactory.getLogger(TMSConsultaSalasTeleconferenciaService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, objJson.get(JSON_KEY_TMS_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_TMS_DADOS, objJson.get(JSON_KEY_TMS_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consulta salas teleconferencia
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarSalasTeleconferencia(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - CONSULTA SALAS TELECONFERENCIA *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Envia os dados
			Conference[] conferencias = enviarDados(json, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(conferencias, json);

		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(Conference[] resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, "");

		objJsonRet.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		JsonArray objJsonArrayConferencias = new JsonArray();
		
		for (Conference conferencia : resposta) {

			JsonObject objJsonConferencia = new JsonObject();
			
			objJsonConferencia.addProperty("a", conferencia.getBillingCode());
			objJsonConferencia.addProperty("b", conferencia.getConfBundleId());
			
			objJsonArrayConferencias.add(objJsonConferencia);
		}

		objJsonDados.add("lista", objJsonArrayConferencias);

		objJsonRet.add(JSON_KEY_TMS_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private Conference[] enviarDados(String json, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();

		String userName = "";
		Calendar startTime = null;
		Calendar endTime = null;
		ConferenceStatus conferenceStatus = ConferenceStatus.All;
		
		proxy.setEndpoint(endpoint);
		//((BookingServiceSoapStub)proxy.get).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		//((BookingServiceSoapStub)proxy.getITAUWDSRPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));

		//Envia os dados
		return proxy.getConferencesForUser(userName, startTime, endTime, conferenceStatus);
	}	
}