package br.com.itau.wd.gerenciador.negocio.service.bpm;

import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_URL_CONSULTA_PENDENCIA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_URL_REGISTRAR_ACAO;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.annotation.Resource;
import javax.xml.rpc.holders.IntHolder;
import javax.xml.rpc.holders.StringHolder;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;

import AH7P001.AprovarProcuracao_tws.AprovarProcuracaoPortTypeProxy;
import AH7P001.ConsultarProcuracao_tws.ConsultarProcuracaoPortTypeProxy;
import AH7P001.ConsultarProcuracao_tws.holders.ResumoProcuracaoWorkstationHolder;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class BPMService {

	@Resource
	private Environment env;
	
	/**
	 * Consulta a pendência
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String consultaPendencia(String json) throws NegocioException {
		
		String retorno = "";

		try {

			System.out.println("***** BPM *****");
			System.out.println("JSON REQUISIÇÃO = " + json);

			ConsultarProcuracaoPortTypeProxy proxy = new ConsultarProcuracaoPortTypeProxy();
			
			int idProcuracao = Integer.parseInt(GerenciadorUtils.obterDadoJson(json, "chave_produto"));
			String funcionalAprovador = GerenciadorUtils.obterDadoJson(json, "funcional_sistema_produto");
			String usuarioAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU);
			String tokenAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS);
			
			System.out.println("ID PROCURACAO = " + idProcuracao);
			System.out.println("FUNCIONAL APROVADOR = " + funcionalAprovador);
			System.out.println("USUARIO ACESSO = " + usuarioAcesso);
			System.out.println("TOKEN ACESSO = " + tokenAcesso);
			
			ResumoProcuracaoWorkstationHolder resultadoConsulta = new ResumoProcuracaoWorkstationHolder();
			IntHolder codigoRetorno = new IntHolder();
			StringHolder mensagemRetorno = new StringHolder();
			
			proxy.setEndpoint(env.getRequiredProperty(PROPERTY_KEY_URL_CONSULTA_PENDENCIA));
			proxy.consultarProcuracaoWorkstation(idProcuracao, funcionalAprovador, usuarioAcesso, tokenAcesso, resultadoConsulta, codigoRetorno, mensagemRetorno);
			
			if(codigoRetorno.value != 0){
				throw new NegocioException(mensagemRetorno.value);
			} else {		
				
				Calendar data = resultadoConsulta.value.getDataSolicitacaoAprovacao();
				final DateFormat df1 = new SimpleDateFormat("dd-MM-yyyy");
				final DateFormat df2 = new SimpleDateFormat("HH:mm:ss");
				
				retorno = "{\"status\":\"S\"," +
							"\"total_paginas\":\"1\"," +
							"\"dados\":{\"solicitante_nome\":\"" + resultadoConsulta.value.getSolicitanteNome() + "\"," +
							"\"area_solicitacao_procuracao\":\"" + resultadoConsulta.value.getAreaSolicitacaoProcuracao() + "\"," +
							"\"tipo_instrumento\":\"" + resultadoConsulta.value.getTipoInstrumento() + "\"," +
							"\"nome_poder\":\"" + resultadoConsulta.value.getNomePoder() + "\"," +
							"\"texto_descricao_poder\":\"" + StringEscapeUtils.escapeJava(resultadoConsulta.value.getTextoDescricaoPoder()) + "\"," +
							"\"dt_ss_aprovacao\":\"" + df1.format(data.getTime()) + " " + df2.format(data.getTime()) + "\"," +
							"\"id_procuracao\":\"" + resultadoConsulta.value.getIdProcuracao() + "\"," +
							"\"id_tarefa\":\"" + resultadoConsulta.value.getIdTarefa() + "\"}}";
			}
			
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Registrar a ação
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String registrarAcao(String json) throws NegocioException {
		
		String retorno = "";
		
		try {
			
			System.out.println("***** BPM *****");
			System.out.println("JSON REQUISIÇÃO = " + json);

			AprovarProcuracaoPortTypeProxy proxy = new AprovarProcuracaoPortTypeProxy();
			
			int identificadorProcuracao = Integer.parseInt(GerenciadorUtils.obterDadoJson(json, "chave_produto"));
			String textoJustificativaWorkstation = GerenciadorUtils.obterDadoJson(json, "comentario");
			String funcaoSistemaProduto = GerenciadorUtils.obterDadoJson(json, "funcao_sistema_produto");
			String mensagem = GerenciadorUtils.obterDadoJson(json, "mensagem");
			String usuarioAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU);
			String tokenAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS);
			
			System.out.println("ID PROCURACAO = " + identificadorProcuracao);
			System.out.println("TEXTO JUSTIFICATIVA = " + textoJustificativaWorkstation);
			System.out.println("FUNCAO SISTEMA PRODUTO = " + funcaoSistemaProduto);
			System.out.println("MENSAGEM = " + mensagem);
			System.out.println("USUARIO ACESSO = " + usuarioAcesso);
			System.out.println("TOKEN ACESSO = " + tokenAcesso);
			
			//no campo mensagem - funcional
			//taskID
			String[] v = mensagem.split("\\;");
			String funcionalDiretor = v[0];
			int idTarefa = Integer.parseInt(v[1]);
			System.out.println("FUNCIONAL DIRETOR = " + funcionalDiretor);
			System.out.println("ID TAREFA = " + idTarefa);
			
			String procuracaoValidada = funcaoSistemaProduto.equalsIgnoreCase("0004")?"true":"false";
			
			ResumoProcuracaoWorkstationHolder resultadoConsulta = new ResumoProcuracaoWorkstationHolder();
			IntHolder codigoRetorno = new IntHolder();
			StringHolder mensagemRetorno = new StringHolder();
						
			proxy.setEndpoint(env.getRequiredProperty(PROPERTY_KEY_URL_REGISTRAR_ACAO));
			proxy.aprovarProcuracao(identificadorProcuracao, procuracaoValidada, textoJustificativaWorkstation, funcionalDiretor, idTarefa, usuarioAcesso, tokenAcesso, codigoRetorno, mensagemRetorno);

			if(codigoRetorno.value == 0){
				retorno = "{\"status\":\"S\"}";
			} else if(codigoRetorno.value == 2){	
				retorno = "{\"status\":\"A\"}";
			} else if(codigoRetorno.value == 3){
				retorno = "{\"status\":\"R\"}";
			} else{
				System.out.println("Retorno erro BPM = " + mensagemRetorno.value);
				retorno = "{\"status\":\"E\"}";
			}
		}
		catch (HttpServerErrorException ex) {
			
			throw new NegocioException(ex.getResponseBodyAsString());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
}