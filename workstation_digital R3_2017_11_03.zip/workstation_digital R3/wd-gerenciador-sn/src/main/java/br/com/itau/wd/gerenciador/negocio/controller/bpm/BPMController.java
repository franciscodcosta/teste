package br.com.itau.wd.gerenciador.negocio.controller.bpm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.bpm.BPMService;

/**
 * BPM Controller
 * 
 * Componente responsável pela comunicação com o BPM
 * 
 * @author ITAÚ
 *
 */
@RestController
@RequestMapping(value="/bpm1")
public class BPMController {

	@Autowired
	private BPMService service;

	/**
	 * Consulta a pendência
	 *
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/consulta_pendencia", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String consultaPendencia(@RequestBody String json) throws NegocioException {

		return service.consultaPendencia(json);
	}
	
	/**
	 * Registra a ação
	 *
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/registrar_acao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String registrarAcao(@RequestBody String json) throws NegocioException {

		return service.registrarAcao(json);
	}
}