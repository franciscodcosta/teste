package br.com.itau.wd.gerenciador.sep.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.notificacao.NotificacaoController;
import br.com.itau.wd.gerenciador.negocio.service.notificacao.NotificacaoService;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {NotificacaoController.class, NotificacaoService.class})
@AutoConfigureMockMvc
public class WdGerenciadorSEPNotificacaoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private NotificacaoService service;

	@Test
	public void verificaJsonRequisicaoSAP() throws Exception {

		String json = "{\"uid\": \"F058E523-3E96-491F-A295-7D9701442E22\", \"sigla_sistema_produto\": \"SAP\", \"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"funcional_sistema_produto\": \"003764305\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRequisicaoSP2() throws Exception {

		String json = "{\"chave_produto\": \"804136360\", \"sigla_sistema_produto\": \"SP2\", \"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"funcional_sistema_produto\": \"003764305\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRequisicaoBPM() throws Exception {

		String json = "{\"uid\": \"0B23AC66-E27F-419D-94D1-7E4825F14557\", \"sigla_sistema_produto\": \"AH7\", \"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"funcional_sistema_produto\": \"003764305\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaSAP() throws Exception {

		String json = "{\"uid\": \"F058E523-3E96-491F-A295-7D9701442E22\", \"status\": \"S\"}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}

	@Test
	public void verificaJsonRespostaSP2() throws Exception {

		String json = "\"chave_produto\": \"804136360\", \"status\": \"S\"}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaBPM() throws Exception {

		String json = "{\"uid\": \"0B23AC66-E27F-419D-94D1-7E4825F14557\", \"status\": \"S\"}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
}