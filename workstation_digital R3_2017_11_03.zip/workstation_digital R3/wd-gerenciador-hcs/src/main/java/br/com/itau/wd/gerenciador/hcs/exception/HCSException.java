package br.com.itau.wd.gerenciador.hcs.exception;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.springframework.web.client.HttpClientErrorException;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;

public class HCSException extends Exception {

	private static final long serialVersionUID = 1L;
	private final String mensagem;
	private final String url;
	private final Throwable causa;

	public HCSException(String mensagem) {
		
		this.mensagem = mensagem;
		this.url = STRING_EMPTY;
		this.causa = null;
	}
	
	public HCSException(GerenciadorErrorInfo errorInfo) {

		this.mensagem = errorInfo.getErro().getMensagem();
		this.url = errorInfo.getErro().getServico();
		this.causa = null;
	}
	
	public HCSException(Throwable ex) {
		
		if (ex instanceof HCSException) {
			this.mensagem = ((HCSException)ex).getMensagem();
			this.url = ((HCSException)ex).getUrl();
		}
		else if (ex instanceof HttpClientErrorException) {
			this.mensagem = ((HttpClientErrorException)ex).getResponseBodyAsString();
			this.url = STRING_EMPTY;
		}
		else {
			this.mensagem = ex.getMessage();
			this.url = STRING_EMPTY;
		}

		this.causa = ex;
	}

	public String getMensagem() {
		return mensagem;
	}

	public String getUrl() {
		return url;
	}
	
	public Throwable getCausa() {
		return causa;
	}
}
