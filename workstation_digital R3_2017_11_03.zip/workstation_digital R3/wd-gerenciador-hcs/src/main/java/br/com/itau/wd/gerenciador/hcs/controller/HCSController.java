package br.com.itau.wd.gerenciador.hcs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.hcs.exception.HCSException;
import br.com.itau.wd.gerenciador.hcs.service.HCSService;

/**
 * HEALTH CHECKER SERVICE (HCS) Controller
 * 
 * @author ITAÚ
 *
 */
@RestController
public class HCSController {

	@Autowired
	HCSService service;

	/**
	 * Retorna a disponbildade do serviço
	 * 
	 * @param servico
	 * @return
	 * @throws HCSException 
	 */
	@RequestMapping(value="/disponibilidade", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
	public boolean verificarDisponibilidade(@RequestParam(value="servico") String servico) throws HCSException {

		return service.verificarDisponibilidade(servico);
	}
}
