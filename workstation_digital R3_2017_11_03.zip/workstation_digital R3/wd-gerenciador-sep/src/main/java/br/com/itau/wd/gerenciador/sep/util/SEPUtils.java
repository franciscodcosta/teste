package br.com.itau.wd.gerenciador.sep.util;

import java.io.IOException;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;

public class SEPUtils {

	private SEPUtils() {}
	
	/**
	 * Trata o erro da requisição rest
	 * 
	 * @param responseBody
	 * @throws SEPException
	 */
	public static void tratarErro(String responseBody) throws SEPException {

		try {
			GerenciadorErrorInfo error = new ObjectMapper().readValue(responseBody, GerenciadorErrorInfo.class);
			throw new SEPException(error);
		} 
		catch (IOException ex) {
			throw new SEPException(ex);
		}
	}
}