package br.com.itau.wd.gerenciador.sep.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@ComponentScan(basePackages = {"br.com.itau.wd.gerenciador.sep.*"})
@PropertySources({
    @PropertySource(value="file:${app.properties}", ignoreResourceNotFound=false)
})
public class WDGerenciadorSEPApplication {

	public static void main(String[] args) {
		SpringApplication.run(WDGerenciadorSEPApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
}