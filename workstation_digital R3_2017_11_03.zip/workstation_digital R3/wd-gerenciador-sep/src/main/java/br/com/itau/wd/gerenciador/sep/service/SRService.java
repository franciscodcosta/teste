package br.com.itau.wd.gerenciador.sep.service;

import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_ENDPOINT;
import static br.com.itau.wd.gerenciador.sep.util.Constants.MSG_ERRO_SR_ENDPOINT_INVALIDO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.MICRO_SERVICO_SR;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_MAINFRAME;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_REST;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_SALESFORCE;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_SOAP;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.sep.dao.MicroServicoDao;
import br.com.itau.wd.gerenciador.sep.dto.DadosDto;
import br.com.itau.wd.gerenciador.sep.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * Serviço SR
 * Realiza o envio dos dados para o Salesforce ou Sistema Produto
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Service
public class SRService {

	@Autowired
	MicroServicoDao dao;

	@Autowired
	ClientRestService clientRest;

	@Resource
	private Environment env;

	/**
	 * Envia os dados para serem processados no Salesforce ou Sistema Produto
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException 
	 */
	public String enviarDados(DadosDto dados) throws SEPException {

		// Retorna o JSON da requisição
		String jsonRequisicao = obterJsonRequisicao(dados);

		// Retorna o JSON do processamento
		String jsonRouter = obterJsonRouter(dados, jsonRequisicao);

		// Retorna o JSON da resposta
		return obterJsonResposta(dados, jsonRouter);
	}

	/**
	 * Obtem o JSON da requisição
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException
	 */
	private String obterJsonRequisicao(DadosDto dados) throws SEPException {

		String json = STRING_EMPTY;

		try {
			// Verifica se existe o serviço de negócio
			if (dados.isExisteServicoNegocio()) {
				// Envia o JSON para o serviço de negócio
				json = obterJsonNegocioRequisicao(dados);
			}
			else {
				// Envia o JSON dos dados
				json = dados.getDadosJson();
			}
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}
		
		return json;
	}
	
	/**
	 * Obter o JSON da resposta
	 * 
	 * @param dados
	 * @param jsonRouter
	 * @return
	 * @throws SEPException
	 */
	private String obterJsonResposta(DadosDto dados, String jsonRouter) throws SEPException {
	
		String json = STRING_EMPTY;

		try {
			// Verifica se existe o serviço de negócio
			if (dados.isExisteServicoNegocio()) {
				// Envia o JSON para o serviço de negócio
				json = obterJsonNegocioResposta(dados, jsonRouter); 
			}
			else {
				// Envia o JSON dos dados
				json = jsonRouter;
			}
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}
		
		return json;
	}

	/**
	 * Envia os dados a serem processados
	 * 
	 * @param dados
	 * @param json
	 * @return
	 * @throws SEPException
	 */
	private String obterJsonRouter(DadosDto dados, String json) throws SEPException {

		String jsonRouter;

		// Verifica o tipo de endpoint
		switch (dados.getEndpoint().getTipoEndpoint()) {

			case ROUTER_ENDPOINT_SALESFORCE:

				jsonRouter = executarSalesforce(dados, json);
				break;

			case ROUTER_ENDPOINT_REST:
				
				jsonRouter = executarRest(dados, json);
        		break;

			case ROUTER_ENDPOINT_SOAP:

				jsonRouter = executarSoap(dados, json);
        		break;
        		
			case ROUTER_ENDPOINT_MAINFRAME:
				
				jsonRouter = executarMainframe(dados, json);
				break;

        	default:	

        		throw new SEPException(MSG_ERRO_SR_ENDPOINT_INVALIDO);
        }
		
		return jsonRouter;
	}
	
	/**
	 * Envia o JSON para o Salesforce
	 * 
	 * @param dados
	 * @param json
	 * @return
	 * @throws SEPException 
	 */
	private String executarSalesforce(DadosDto dados, String json) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.add(HTTP_HEADER_ENDPOINT, dados.getEndpoint().getUrlServico());

			HttpEntity<String> entity = new HttpEntity<>(json, headers);

			String url = String.format("%s/router/service/salesforce", obterEndpointSr());

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return retorno;
	}

	/**
	 * Envia o JSON para o endpoint REST
	 * 
	 * @param dados
	 * @param json
	 * @return
	 * @throws SEPException 
	 */
	private String executarRest(DadosDto dados, String json) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.add(HTTP_HEADER_ENDPOINT, dados.getEndpoint().getUrlServico());

			HttpEntity<String> entity = new HttpEntity<>(json, headers);

			String url = String.format("%s/router/service/rest", obterEndpointSr());			
			
			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return retorno;
	}

	/**
	 * Envia o JSON para o endpoint do serviço de negócio
	 * 
	 * @param dados
	 * @param json
	 * @return
	 * @throws SEPException 
	 */
	private String executarSoap(DadosDto dados, String json) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.set(HTTP_HEADER_ENDPOINT, dados.getEndpoint().getUrlServico());

			HttpEntity<String> entity = new HttpEntity<>(json, headers);			

			String url = String.format("%s/soap", dados.getEndpoint().getUrlServicoNegocio());

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}

		return retorno;
	}

	/**
	 * Envia o JSON para o endpoint do serviço de negócio
	 * 
	 * @param dados
	 * @param json
	 * @return
	 * @throws SEPException 
	 */
	private String executarMainframe(DadosDto dados, String json) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();

			HttpEntity<String> entity = new HttpEntity<>(json, headers);			

			String url = String.format("%s/mainframe", dados.getEndpoint().getUrlServicoNegocio());

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obtém o JSON de requisição do serviço de negócio.
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException 
	 */
	private String obterJsonNegocioRequisicao(DadosDto dados) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpEntity<String> entity = new HttpEntity<>(dados.getDadosJson());
			
			String url = String.format("%s/requisicao", dados.getEndpoint().getUrlServicoNegocio());

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return retorno;
	}

	/**
	 * Obtém o JSON de resposta do serviço de negócio.
	 * 
	 * @param negocio
	 * @param json
	 * @return
	 * @throws SEPException 
	 */
	private String obterJsonNegocioResposta(DadosDto dados, String json) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			//Pode ser que algumas das informações que serão usadas no JSON de retorno não
			//são encontradas no JSON de saida do sistema produto ou salesforce mas se encontram
			//no JSON de entrada. Por isso o conteúdo do JSON de entrada que não se encontra no
			//JSON de saída são anexados neste.
			Map<String, Object> map = GerenciadorUtils.convertJsonToMap(json);

			for (Entry<String, Object> entry : dados.getDados().entrySet()) {
				//Se a chave não existir no JSON de retorno e se essa chave não for igual a DADOS acrescenta no JSON
				if (!map.containsKey(entry.getKey()) && !entry.getKey().equalsIgnoreCase(JSON_KEY_DADOS)) {
					map.put(entry.getKey(), entry.getValue().toString());
				}
			}

			HttpEntity<String> entity = new HttpEntity<>(GerenciadorUtils.convertMapToJson(map));			

			String url = String.format("%s/resposta", dados.getEndpoint().getUrlServicoNegocio());

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return retorno;
	}

	/**
	 * Retorna o endpoint do serviço 
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException 
	 */
	public EndpointDto obterEndpoint(DadosDto dados) throws SEPException {

		EndpointDto endpoint = null;

		try {

			String url = String.format("%s/endpoint?codigo_servico={codigo_servico}", obterEndpointSr());

			String retorno = clientRest.enviarJson(url, dados.getChave().getCodigoServico());

			endpoint = obterDadosEndpoint(retorno);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return endpoint;
	}
	
	/**
	 * Obtem os dados do endpoint
	 * 
	 * @param json
	 * @return
	 */
	private EndpointDto obterDadosEndpoint(String json) {
		
    	String codigoServico = GerenciadorUtils.obterDadoJson(json, "codigoServico");
    	String urlServico = GerenciadorUtils.obterDadoJson(json, "urlServico");
    	String urlServicoNegocio = GerenciadorUtils.obterDadoJson(json, "urlServicoNegocio");
    	String siglaSistema = GerenciadorUtils.obterDadoJson(json, "siglaSistema");
    	boolean salvaKms = Boolean.parseBoolean(GerenciadorUtils.obterDadoJson(json, "salvaKms"));
    	boolean consultaKms = Boolean.parseBoolean(GerenciadorUtils.obterDadoJson(json, "consultaKms"));

		EndpointDto endpoint = new EndpointDto();

    	endpoint.setCodigoServico(codigoServico);
    	endpoint.setUrlServico(urlServico);
    	endpoint.setUrlServicoNegocio(urlServicoNegocio);
    	endpoint.setSiglaSistema(siglaSistema);
    	endpoint.setSalvaKms(salvaKms);
    	endpoint.setConsultaKms(consultaKms);

		return endpoint;
	}
	
	/**
	 * Retorna o endpoint do microserviço SR
	 * 
	 * @return
	 * @throws SEPException
	 */
	private String obterEndpointSr() throws SEPException {
		
		EndpointDto microServico = dao.obterMicroServico(MICRO_SERVICO_SR);
		
		return microServico.getUrlServico();
	}
}