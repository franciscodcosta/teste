package br.com.itau.wd.gerenciador.sep.config;

import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_CLIENT_ID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_DATASOURCE;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_DIALECT;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_DRIVER_CLASS;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_SENHA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_URL;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_HIBERNATE_CONNECTION_USERNAME;

import java.util.Properties;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.hibernate.ejb.HibernatePersistence;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import br.com.itau.SCConexaoDSHibernateDataSource;

@Configuration
public class DataSourceConfig {

	@Resource
	private Environment env;

    @Bean
    public DataSource dataSource() {

    	SCConexaoDSHibernateDataSource dataSource = new SCConexaoDSHibernateDataSource();

    	dataSource.setDataSourceName(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_DATASOURCE));
    	dataSource.setDriverClassName(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_DRIVER_CLASS));
    	dataSource.setUrl(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_URL));
    	dataSource.setUserName(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_USERNAME));
    	dataSource.setPassword(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_SENHA));
    	dataSource.setToken(env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_TOKEN));

        return dataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
   	
        LocalContainerEntityManagerFactoryBean entityManagerFactoryBean = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactoryBean.setDataSource(dataSource());
        entityManagerFactoryBean.setPersistenceProviderClass(HibernatePersistence.class);
        entityManagerFactoryBean.setPackagesToScan("com.itau.sc.conexao.hibernate");
        entityManagerFactoryBean.setJpaProperties(hibProperties());

        return entityManagerFactoryBean;
    }

    private Properties hibProperties() {

        Properties properties = new Properties();

        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_CLIENT_ID, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_CLIENT_ID));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_TOKEN, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_TOKEN));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_USERNAME, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_USERNAME));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_SENHA, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_SENHA));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_DRIVER_CLASS, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_DRIVER_CLASS));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_URL, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_URL));
        properties.put(PROPERTY_KEY_HIBERNATE_CONNECTION_DIALECT, env.getRequiredProperty(PROPERTY_KEY_HIBERNATE_CONNECTION_DIALECT));
        
        return properties;
    } 
}