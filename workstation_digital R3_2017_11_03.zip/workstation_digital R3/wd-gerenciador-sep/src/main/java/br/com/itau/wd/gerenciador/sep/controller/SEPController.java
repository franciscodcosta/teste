package br.com.itau.wd.gerenciador.sep.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.sep.service.SEPService;

/**
 * SERVICE ENTRY POINT (SEP)
 * Componente responsável pela orquestração das requisições recebidas.
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@RestController
public class SEPController {

	@Autowired
	SEPService service;

	/**
	 * Executa o SEP
	 * 
	 * @param json
	 * @param servico
	 * @param token
	 * @return
	 * @throws SEPException
	 */
	@RequestMapping(value="/servico", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)	
	public String executarServico(@RequestBody String json,
								  @RequestHeader(value="servico") String servico,
								  @RequestHeader(value="token", required=false) String token) throws SEPException {

		return service.executarServico(servico, json, token);
	}
}