package br.com.itau.wd.gerenciador.sr;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.sr.controller.SRController;
import br.com.itau.wd.gerenciador.sr.router.controller.RouterController;
import br.com.itau.wd.gerenciador.sr.router.controller.RouterRESTController;
import br.com.itau.wd.gerenciador.sr.router.controller.RouterSOAPController;
import br.com.itau.wd.gerenciador.sr.router.controller.RouterSalesforceController;
import br.com.itau.wd.gerenciador.sr.router.service.RouterRestService;
import br.com.itau.wd.gerenciador.sr.router.service.RouterSoapService;
import br.com.itau.wd.gerenciador.sr.router.service.RouterSalesforceService;
import br.com.itau.wd.gerenciador.sr.router.service.RouterService;
import br.com.itau.wd.gerenciador.sr.service.SRService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SRController.class, RouterController.class, RouterSalesforceController.class, RouterRESTController.class, RouterSOAPController.class,
		                   SRService.class, RouterService.class, RouterSalesforceService.class, RouterRestService.class, RouterSoapService.class})
@AutoConfigureMockMvc
public class WdGerenciadorSRApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SRService srService;
	
	@MockBean
	private RouterService routerService;
	
	@MockBean
	private RouterRestService routerRESTService;

	@MockBean
	private RouterSoapService routerSOAPService;
	
	@MockBean
	private RouterSalesforceService salesforceService;
	
	@InjectMocks
    private RouterSalesforceController routerSalesforceController;

	/*@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        this.mockSalesforceMvc = MockMvcBuilders.standaloneSetup(routerSalesforceController).setViewResolvers(viewResolver).build();
    }*/

	// ============
	//     SEP
	// ============
	
	@Test
	public void verificaJSONRetornoSEPEnviadoPelaNotificacaoSAP() throws Exception {

		String json = "{\"UID\":\"F3AAEFE1-9CF0-4041-870E-0B5CB9B5C541\",\"status\": \"S\"}";
		Mockito.when(routerService.executarSEP(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/rest/{servico}", "notificacao")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"SAP\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0003\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"00733094;0003000692;99;000000211421\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	@Test
	public void verificaJSONRetornoSEPEnviadoPelaNotificacaoSP2() throws Exception {

		String json = "{\"chave_produto\":\"003764305\",\"status\": \"S\"}";
		Mockito.when(routerService.executarSEP(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/rest/{servico}", "notificacao")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"SP2\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0024\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"003764305\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}

	@Test
	public void verificaJSONRetornoSEPEnviadoPelaNotificacaoBPM() throws Exception {

		String json = "{\"UID\":\"3E3132A8-501E-40AD-B080-27E5C7538138\",\"status\": \"S\"}";
		Mockito.when(routerService.executarSEP(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/rest/{servico}", "notificacao")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"AH7\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0005\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"123\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	// ==========
	// SALESFORCE
	// ==========	
	
	@Test
	public void verificaJSONRetornoSalesforceEnviadoPelaNotificacaoSAP() throws Exception {

		String json = "{\"status\": \"S\"}";
		Mockito.when(salesforceService.executarServico(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/service/salesforce")
				.header("endpoint", "/services/apexrest/notification")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"UID\":\"F3AAEFE1-9CF0-4041-870E-0B5CB9B5C541\",\"SIGLA_SISTEMA_PRODUTO\":\"SAP\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0004\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"00733094;0003000692;99;000000211421\"}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	@Test
	public void verificaJSONRetornoSalesforceEnviadoPelaNotificacaoSP2() throws Exception {

		String json = "{\"status\": \"S\"}";
		Mockito.when(salesforceService.executarServico(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/service/salesforce")
				.header("endpoint", "/services/apexrest/notification")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"SIGLA_SISTEMA_PRODUTO\":\"SP2\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0004\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"003764305\"}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	@Test
	public void verificaJSONRetornoSalesforceEnviadoPelaNotificacaoBPM() throws Exception {

		String json = "{\"status\": \"S\"}";
		Mockito.when(salesforceService.executarServico(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/service/salesforce")
				.header("endpoint", "/services/apexrest/notification")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"UID\":\"101D5006-EB60-4D5E-B2F9-CF5FBB2D3DBF\",\"SIGLA_SISTEMA_PRODUTO\":\"AH7\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0004\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"123\"}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	// =============
	//     REST
	// =============

	@Test
	public void verificaJSONRetornoRESTEnviadoPeloSP2() throws Exception {

		String json = "{\"chave_produto\": \"999999999\": \"dados\": {\"funcionarios\" : [{\"id_funcionario\": \"99999999999\"}]}";
		Mockito.when(routerRESTService.executarServico(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/service/rest")
				.header("endpoint", "http://sp3broker.itau/SP3_WD_Ponto_0003Web/rest/consulta_marcacao_ponto")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"funcao_sistema_produto\":\"0006\", \"funcao_atividade_sistema_produto\":\"0010\", \"chave_produto\":\"999999999\", \"data_jornada\":\"10/01/2017\", \"justificativa\":\"xxxxx\", \"acertos\": [ {\"data_acerto\":\"10/10/2017\", \"hora_acerto\":\"09:30\", \"codigo_acerto\":\"A\", \"id_ocorrencia\":\"12345678\", \"codigo_motivo\":\"1234567890\"}]}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
	
	// =============
	//     SOAP
	// =============

	@Test
	public void verificaJSONRetornoSOAP() throws Exception {

		String json = "{\"chave_produto\": \"999999999\": \"dados\": {\"funcionarios\" : [{\"id_funcionario\": \"99999999999\"}]}";
		Mockito.when(routerSOAPService.executarServico(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/router/service/soap")
				.header("endpoint", "http://sp3broker.itau/SP3_WD_Ponto_0003Web/rest/consulta_marcacao_ponto")
				.header("endpointnegocio", "http://sp3broker.itau/SP3_WD_Ponto_0003Web/rest/consulta_marcacao_ponto")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"funcao_sistema_produto\":\"0006\", \"funcao_atividade_sistema_produto\":\"0010\", \"chave_produto\":\"999999999\", \"data_jornada\":\"10/01/2017\", \"justificativa\":\"xxxxx\", \"acertos\": [ {\"data_acerto\":\"10/10/2017\", \"hora_acerto\":\"09:30\", \"codigo_acerto\":\"A\", \"id_ocorrencia\":\"12345678\", \"codigo_motivo\":\"1234567890\"}]}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(view().name(json));
	}
}