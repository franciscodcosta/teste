package br.com.itau.wd.gerenciador.sr.util;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import javax.net.ssl.SSLContext;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

public class SRUtils {
	
	private SRUtils() {}

	/**
	 * Trata o erro da requisição rest
	 * 
	 * @param responseBody
	 * @throws SRException 
	 */
	public static void tratarErro(String responseBody) throws SRException {
		
		GerenciadorErrorInfo errorInfo = GerenciadorUtils.obterErrorInfo(responseBody);
		
		if (errorInfo != null) {
			throw new SRException(errorInfo);
		}
	}
	
	/**
	 * Configura o TLS
	 * 
	 * @param tls
	 * @throws SRException 
	 */
	public static void configurarTls(String tls) throws SRException {
		
		try {
			SSLContext ctx = SSLContext.getInstance(tls);
			ctx.init(null, null, null);
			SSLContext.setDefault(ctx);
		}
		catch (NoSuchAlgorithmException | KeyManagementException ex) {
			throw new SRException(ex);
		}
	}
}