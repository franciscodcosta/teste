package br.com.itau.wd.gerenciador.sr.router.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.router.service.RouterService;

@RestController
public class RouterController {

	@Autowired
	RouterService service;

	/**
	 * Executa o serviço SEP
	 * 
	 * @param servico
	 * @param json
	 * @param token
	 * @return
	 * @throws SRException
	 */
	@RequestMapping(value = "/router/rest/{servico}", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String executarSEP(@PathVariable(value = "servico") String servico, 
							  @RequestBody String json,
							  @RequestHeader(value = "token", required = false) String token) throws SRException {

		return service.executarSEP(servico, json, token);
	}
}