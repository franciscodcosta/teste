package br.com.itau.wd.gerenciador.sr.dto;

public class LoginSalesforceDto {

	private String accessToken;
	private String instanceUrl;
	
	public String getAccessToken() {
		return accessToken;
	}
	
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	public String getInstanceUrl() {
		return instanceUrl;
	}
	
	public void setInstanceUrl(String instanceUrl) {
		this.instanceUrl = instanceUrl;
	}
}