package br.com.itau.wd.gerenciador.sr.dto;

public class EndpointDto {

	private String codigoServico;
	private String siglaSistema;
	private String urlServico;
	private String urlServicoNegocio;
	private boolean isSalvaKms;
	private boolean isConsultaKms;
	
	public String getCodigoServico() {
		return codigoServico;
	}
	
	public void setCodigoServico(String codigoServico) {
		this.codigoServico = codigoServico;
	}
	
	public String getSiglaSistema() {
		return siglaSistema;
	}

	public void setSiglaSistema(String siglaSistema) {
		this.siglaSistema = siglaSistema;
	}

	public String getUrlServico() {
		return urlServico;
	}
	
	public void setUrlServico(String urlServico) {
		this.urlServico = urlServico;
	}

	public String getUrlServicoNegocio() {
		return urlServicoNegocio;
	}

	public void setUrlServicoNegocio(String urlServicoNegocio) {
		this.urlServicoNegocio = urlServicoNegocio;
	}

	public boolean isSalvaKms() {
		return isSalvaKms;
	}

	public void setSalvaKms(boolean isSalvaKms) {
		this.isSalvaKms = isSalvaKms;
	}

	public boolean isConsultaKms() {
		return isConsultaKms;
	}

	public void setConsultaKms(boolean isConsultaKms) {
		this.isConsultaKms = isConsultaKms;
	}
}