package br.com.itau.wd.gerenciador.sr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.sr.dao.EndpointDao;
import br.com.itau.wd.gerenciador.sr.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;


@Service
public class SRService {

	@Autowired
	private EndpointDao dao;	

	/**
	 * Retorna os dados do endpoint do serviço
	 * 
	 * @param codigoServico
	 * @return
	 * @throws SRException 
	 */
	public EndpointDto obterEndpoint(String codigoServico) throws SRException {

		return dao.obterEndpoint(codigoServico);
	}

	/**
	 * Retorna os dados do endpoint do microserviço
	 * 
	 * @param codigoMicroServico
	 * @return
	 * @throws SRException
	 */
	public EndpointDto obterMicroServico(int codigoMicroServico) throws SRException {

		return dao.obterMicroServico(codigoMicroServico);
	}	
}