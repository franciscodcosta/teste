/**
 * WebExTelephony.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class WebExTelephony  implements java.io.Serializable {
    private java.lang.String localCallInTollNumber;

    private java.lang.String localCallInTollFreeNumber;

    private java.lang.String globalCallInNumberUrl;

    private java.lang.String pstnDialInNumber;

    private java.lang.String dtmfSequence;

    private java.lang.String participantAccessCode;

    public WebExTelephony() {
    }

    public WebExTelephony(
           java.lang.String localCallInTollNumber,
           java.lang.String localCallInTollFreeNumber,
           java.lang.String globalCallInNumberUrl,
           java.lang.String pstnDialInNumber,
           java.lang.String dtmfSequence,
           java.lang.String participantAccessCode) {
           this.localCallInTollNumber = localCallInTollNumber;
           this.localCallInTollFreeNumber = localCallInTollFreeNumber;
           this.globalCallInNumberUrl = globalCallInNumberUrl;
           this.pstnDialInNumber = pstnDialInNumber;
           this.dtmfSequence = dtmfSequence;
           this.participantAccessCode = participantAccessCode;
    }


    /**
     * Gets the localCallInTollNumber value for this WebExTelephony.
     * 
     * @return localCallInTollNumber
     */
    public java.lang.String getLocalCallInTollNumber() {
        return localCallInTollNumber;
    }


    /**
     * Sets the localCallInTollNumber value for this WebExTelephony.
     * 
     * @param localCallInTollNumber
     */
    public void setLocalCallInTollNumber(java.lang.String localCallInTollNumber) {
        this.localCallInTollNumber = localCallInTollNumber;
    }


    /**
     * Gets the localCallInTollFreeNumber value for this WebExTelephony.
     * 
     * @return localCallInTollFreeNumber
     */
    public java.lang.String getLocalCallInTollFreeNumber() {
        return localCallInTollFreeNumber;
    }


    /**
     * Sets the localCallInTollFreeNumber value for this WebExTelephony.
     * 
     * @param localCallInTollFreeNumber
     */
    public void setLocalCallInTollFreeNumber(java.lang.String localCallInTollFreeNumber) {
        this.localCallInTollFreeNumber = localCallInTollFreeNumber;
    }


    /**
     * Gets the globalCallInNumberUrl value for this WebExTelephony.
     * 
     * @return globalCallInNumberUrl
     */
    public java.lang.String getGlobalCallInNumberUrl() {
        return globalCallInNumberUrl;
    }


    /**
     * Sets the globalCallInNumberUrl value for this WebExTelephony.
     * 
     * @param globalCallInNumberUrl
     */
    public void setGlobalCallInNumberUrl(java.lang.String globalCallInNumberUrl) {
        this.globalCallInNumberUrl = globalCallInNumberUrl;
    }


    /**
     * Gets the pstnDialInNumber value for this WebExTelephony.
     * 
     * @return pstnDialInNumber
     */
    public java.lang.String getPstnDialInNumber() {
        return pstnDialInNumber;
    }


    /**
     * Sets the pstnDialInNumber value for this WebExTelephony.
     * 
     * @param pstnDialInNumber
     */
    public void setPstnDialInNumber(java.lang.String pstnDialInNumber) {
        this.pstnDialInNumber = pstnDialInNumber;
    }


    /**
     * Gets the dtmfSequence value for this WebExTelephony.
     * 
     * @return dtmfSequence
     */
    public java.lang.String getDtmfSequence() {
        return dtmfSequence;
    }


    /**
     * Sets the dtmfSequence value for this WebExTelephony.
     * 
     * @param dtmfSequence
     */
    public void setDtmfSequence(java.lang.String dtmfSequence) {
        this.dtmfSequence = dtmfSequence;
    }


    /**
     * Gets the participantAccessCode value for this WebExTelephony.
     * 
     * @return participantAccessCode
     */
    public java.lang.String getParticipantAccessCode() {
        return participantAccessCode;
    }


    /**
     * Sets the participantAccessCode value for this WebExTelephony.
     * 
     * @param participantAccessCode
     */
    public void setParticipantAccessCode(java.lang.String participantAccessCode) {
        this.participantAccessCode = participantAccessCode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WebExTelephony)) return false;
        WebExTelephony other = (WebExTelephony) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.localCallInTollNumber==null && other.getLocalCallInTollNumber()==null) || 
             (this.localCallInTollNumber!=null &&
              this.localCallInTollNumber.equals(other.getLocalCallInTollNumber()))) &&
            ((this.localCallInTollFreeNumber==null && other.getLocalCallInTollFreeNumber()==null) || 
             (this.localCallInTollFreeNumber!=null &&
              this.localCallInTollFreeNumber.equals(other.getLocalCallInTollFreeNumber()))) &&
            ((this.globalCallInNumberUrl==null && other.getGlobalCallInNumberUrl()==null) || 
             (this.globalCallInNumberUrl!=null &&
              this.globalCallInNumberUrl.equals(other.getGlobalCallInNumberUrl()))) &&
            ((this.pstnDialInNumber==null && other.getPstnDialInNumber()==null) || 
             (this.pstnDialInNumber!=null &&
              this.pstnDialInNumber.equals(other.getPstnDialInNumber()))) &&
            ((this.dtmfSequence==null && other.getDtmfSequence()==null) || 
             (this.dtmfSequence!=null &&
              this.dtmfSequence.equals(other.getDtmfSequence()))) &&
            ((this.participantAccessCode==null && other.getParticipantAccessCode()==null) || 
             (this.participantAccessCode!=null &&
              this.participantAccessCode.equals(other.getParticipantAccessCode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getLocalCallInTollNumber() != null) {
            _hashCode += getLocalCallInTollNumber().hashCode();
        }
        if (getLocalCallInTollFreeNumber() != null) {
            _hashCode += getLocalCallInTollFreeNumber().hashCode();
        }
        if (getGlobalCallInNumberUrl() != null) {
            _hashCode += getGlobalCallInNumberUrl().hashCode();
        }
        if (getPstnDialInNumber() != null) {
            _hashCode += getPstnDialInNumber().hashCode();
        }
        if (getDtmfSequence() != null) {
            _hashCode += getDtmfSequence().hashCode();
        }
        if (getParticipantAccessCode() != null) {
            _hashCode += getParticipantAccessCode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WebExTelephony.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExTelephony"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("localCallInTollNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "LocalCallInTollNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("localCallInTollFreeNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "LocalCallInTollFreeNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("globalCallInNumberUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "GlobalCallInNumberUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pstnDialInNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PstnDialInNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dtmfSequence");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DtmfSequence"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participantAccessCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantAccessCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
