/**
 * TimeZoneRule.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class TimeZoneRule  implements java.io.Serializable {
    private java.util.Calendar validFrom;

    private java.lang.String id;

    private java.lang.String displayName;

    private int baseOffsetInMinutes;

    private net.tandberg._2004._02.tms.external.booking.TimeChange daylight;

    private int daylightOffsetInMinutes;

    private net.tandberg._2004._02.tms.external.booking.TimeChange standard;

    public TimeZoneRule() {
    }

    public TimeZoneRule(
           java.util.Calendar validFrom,
           java.lang.String id,
           java.lang.String displayName,
           int baseOffsetInMinutes,
           net.tandberg._2004._02.tms.external.booking.TimeChange daylight,
           int daylightOffsetInMinutes,
           net.tandberg._2004._02.tms.external.booking.TimeChange standard) {
           this.validFrom = validFrom;
           this.id = id;
           this.displayName = displayName;
           this.baseOffsetInMinutes = baseOffsetInMinutes;
           this.daylight = daylight;
           this.daylightOffsetInMinutes = daylightOffsetInMinutes;
           this.standard = standard;
    }


    /**
     * Gets the validFrom value for this TimeZoneRule.
     * 
     * @return validFrom
     */
    public java.util.Calendar getValidFrom() {
        return validFrom;
    }


    /**
     * Sets the validFrom value for this TimeZoneRule.
     * 
     * @param validFrom
     */
    public void setValidFrom(java.util.Calendar validFrom) {
        this.validFrom = validFrom;
    }


    /**
     * Gets the id value for this TimeZoneRule.
     * 
     * @return id
     */
    public java.lang.String getId() {
        return id;
    }


    /**
     * Sets the id value for this TimeZoneRule.
     * 
     * @param id
     */
    public void setId(java.lang.String id) {
        this.id = id;
    }


    /**
     * Gets the displayName value for this TimeZoneRule.
     * 
     * @return displayName
     */
    public java.lang.String getDisplayName() {
        return displayName;
    }


    /**
     * Sets the displayName value for this TimeZoneRule.
     * 
     * @param displayName
     */
    public void setDisplayName(java.lang.String displayName) {
        this.displayName = displayName;
    }


    /**
     * Gets the baseOffsetInMinutes value for this TimeZoneRule.
     * 
     * @return baseOffsetInMinutes
     */
    public int getBaseOffsetInMinutes() {
        return baseOffsetInMinutes;
    }


    /**
     * Sets the baseOffsetInMinutes value for this TimeZoneRule.
     * 
     * @param baseOffsetInMinutes
     */
    public void setBaseOffsetInMinutes(int baseOffsetInMinutes) {
        this.baseOffsetInMinutes = baseOffsetInMinutes;
    }


    /**
     * Gets the daylight value for this TimeZoneRule.
     * 
     * @return daylight
     */
    public net.tandberg._2004._02.tms.external.booking.TimeChange getDaylight() {
        return daylight;
    }


    /**
     * Sets the daylight value for this TimeZoneRule.
     * 
     * @param daylight
     */
    public void setDaylight(net.tandberg._2004._02.tms.external.booking.TimeChange daylight) {
        this.daylight = daylight;
    }


    /**
     * Gets the daylightOffsetInMinutes value for this TimeZoneRule.
     * 
     * @return daylightOffsetInMinutes
     */
    public int getDaylightOffsetInMinutes() {
        return daylightOffsetInMinutes;
    }


    /**
     * Sets the daylightOffsetInMinutes value for this TimeZoneRule.
     * 
     * @param daylightOffsetInMinutes
     */
    public void setDaylightOffsetInMinutes(int daylightOffsetInMinutes) {
        this.daylightOffsetInMinutes = daylightOffsetInMinutes;
    }


    /**
     * Gets the standard value for this TimeZoneRule.
     * 
     * @return standard
     */
    public net.tandberg._2004._02.tms.external.booking.TimeChange getStandard() {
        return standard;
    }


    /**
     * Sets the standard value for this TimeZoneRule.
     * 
     * @param standard
     */
    public void setStandard(net.tandberg._2004._02.tms.external.booking.TimeChange standard) {
        this.standard = standard;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TimeZoneRule)) return false;
        TimeZoneRule other = (TimeZoneRule) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.validFrom==null && other.getValidFrom()==null) || 
             (this.validFrom!=null &&
              this.validFrom.equals(other.getValidFrom()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.displayName==null && other.getDisplayName()==null) || 
             (this.displayName!=null &&
              this.displayName.equals(other.getDisplayName()))) &&
            this.baseOffsetInMinutes == other.getBaseOffsetInMinutes() &&
            ((this.daylight==null && other.getDaylight()==null) || 
             (this.daylight!=null &&
              this.daylight.equals(other.getDaylight()))) &&
            this.daylightOffsetInMinutes == other.getDaylightOffsetInMinutes() &&
            ((this.standard==null && other.getStandard()==null) || 
             (this.standard!=null &&
              this.standard.equals(other.getStandard())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getValidFrom() != null) {
            _hashCode += getValidFrom().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getDisplayName() != null) {
            _hashCode += getDisplayName().hashCode();
        }
        _hashCode += getBaseOffsetInMinutes();
        if (getDaylight() != null) {
            _hashCode += getDaylight().hashCode();
        }
        _hashCode += getDaylightOffsetInMinutes();
        if (getStandard() != null) {
            _hashCode += getStandard().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TimeZoneRule.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validFrom");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ValidFrom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("displayName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DisplayName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("baseOffsetInMinutes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BaseOffsetInMinutes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("daylight");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Daylight"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChange"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("daylightOffsetInMinutes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DaylightOffsetInMinutes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("standard");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Standard"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeChange"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
