/**
 * TimeZone.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking.remotesetup;

public class TimeZone  implements java.io.Serializable {
    private java.lang.String timezoneName;

    private java.lang.String startTimeDTS;

    private java.lang.String endTimeDTS;

    private java.lang.String GMTOffset;

    public TimeZone() {
    }

    public TimeZone(
           java.lang.String timezoneName,
           java.lang.String startTimeDTS,
           java.lang.String endTimeDTS,
           java.lang.String GMTOffset) {
           this.timezoneName = timezoneName;
           this.startTimeDTS = startTimeDTS;
           this.endTimeDTS = endTimeDTS;
           this.GMTOffset = GMTOffset;
    }


    /**
     * Gets the timezoneName value for this TimeZone.
     * 
     * @return timezoneName
     */
    public java.lang.String getTimezoneName() {
        return timezoneName;
    }


    /**
     * Sets the timezoneName value for this TimeZone.
     * 
     * @param timezoneName
     */
    public void setTimezoneName(java.lang.String timezoneName) {
        this.timezoneName = timezoneName;
    }


    /**
     * Gets the startTimeDTS value for this TimeZone.
     * 
     * @return startTimeDTS
     */
    public java.lang.String getStartTimeDTS() {
        return startTimeDTS;
    }


    /**
     * Sets the startTimeDTS value for this TimeZone.
     * 
     * @param startTimeDTS
     */
    public void setStartTimeDTS(java.lang.String startTimeDTS) {
        this.startTimeDTS = startTimeDTS;
    }


    /**
     * Gets the endTimeDTS value for this TimeZone.
     * 
     * @return endTimeDTS
     */
    public java.lang.String getEndTimeDTS() {
        return endTimeDTS;
    }


    /**
     * Sets the endTimeDTS value for this TimeZone.
     * 
     * @param endTimeDTS
     */
    public void setEndTimeDTS(java.lang.String endTimeDTS) {
        this.endTimeDTS = endTimeDTS;
    }


    /**
     * Gets the GMTOffset value for this TimeZone.
     * 
     * @return GMTOffset
     */
    public java.lang.String getGMTOffset() {
        return GMTOffset;
    }


    /**
     * Sets the GMTOffset value for this TimeZone.
     * 
     * @param GMTOffset
     */
    public void setGMTOffset(java.lang.String GMTOffset) {
        this.GMTOffset = GMTOffset;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TimeZone)) return false;
        TimeZone other = (TimeZone) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.timezoneName==null && other.getTimezoneName()==null) || 
             (this.timezoneName!=null &&
              this.timezoneName.equals(other.getTimezoneName()))) &&
            ((this.startTimeDTS==null && other.getStartTimeDTS()==null) || 
             (this.startTimeDTS!=null &&
              this.startTimeDTS.equals(other.getStartTimeDTS()))) &&
            ((this.endTimeDTS==null && other.getEndTimeDTS()==null) || 
             (this.endTimeDTS!=null &&
              this.endTimeDTS.equals(other.getEndTimeDTS()))) &&
            ((this.GMTOffset==null && other.getGMTOffset()==null) || 
             (this.GMTOffset!=null &&
              this.GMTOffset.equals(other.getGMTOffset())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTimezoneName() != null) {
            _hashCode += getTimezoneName().hashCode();
        }
        if (getStartTimeDTS() != null) {
            _hashCode += getStartTimeDTS().hashCode();
        }
        if (getEndTimeDTS() != null) {
            _hashCode += getEndTimeDTS().hashCode();
        }
        if (getGMTOffset() != null) {
            _hashCode += getGMTOffset().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TimeZone.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "TimeZone"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timezoneName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "TimezoneName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startTimeDTS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "StartTimeDTS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endTimeDTS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "EndTimeDTS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("GMTOffset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "GMTOffset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
