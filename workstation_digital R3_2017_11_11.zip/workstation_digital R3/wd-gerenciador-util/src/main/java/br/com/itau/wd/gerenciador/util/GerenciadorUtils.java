package br.com.itau.wd.gerenciador.util;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATI_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;


public class GerenciadorUtils {

	private GerenciadorUtils() {}

	/**
	 * Converte o JSON para Map do Workstation Digital
	 * 
	 * @param json
	 * @return
	 * @throws IOException 
	 */
	@SuppressWarnings("unchecked")
	public static Map<String, Object> convertJsonToMapWd(String json) throws IOException {

		Map<String, Object> dados = new HashMap<String, Object>();
		Map<String, Object> map = convertJsonToMap(json);

		for (Entry<String, Object> entry : map.entrySet()) {
			Map<String, Object> mapDados = (Map<String, Object>) entry.getValue();
			for (Entry<String, Object> entryDados : mapDados.entrySet()) {
				dados.put(obterTagJson(entryDados.getKey()), entryDados.getValue());
			}
			break;
		}

		return dados;
	}
	
	/**
	 * Convert JSON para Map
	 * 
	 * @param json
	 * @return
	 * @throws IOException 
	 */
	public static Map<String, Object> convertJsonToMap(String json) throws IOException {

		return new ObjectMapper().readValue(json, new TypeReference<Map<String, Object>>(){});
	}
	
	/**
	 * Converte Map para JSON
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException 
	 * @throws JsonProcessingException 
	 */
	public static String convertMapToJson(Map<String, Object> dados) throws JsonProcessingException  {

		return new ObjectMapper().writeValueAsString(dados);
	}
	
	/**
	 * Extrai o dado do map
	 * 
	 * @param map
	 * @param dado
	 * @return
	 */
	public static String obterDadoMap(Map<String, Object> dados, String key) {
		
		return dados.containsKey(key) ? convertObjectToString(dados.get(key)) : STRING_EMPTY;
	}
	
	/**
	 * Extrai o dado do JSON
 	 *
	 * @param json
	 * @param key
	 * @return
	 */
	public static String obterDadoJson(String json, String key) {

		String dado = STRING_EMPTY;
		JsonElement objJsonElement = new JsonParser().parse(json);

		if (objJsonElement.isJsonObject()) {
			
			JsonElement objJsonObject = objJsonElement.getAsJsonObject().get(key);
			
			if (objJsonObject != null) {
				if (objJsonObject.isJsonObject()) {
					dado = objJsonObject.toString();
				} else if (objJsonObject.isJsonPrimitive()) {
					dado = objJsonObject.getAsString();
				}
			}
		}

		return dado;
	}
	
	/**
	 * Verifica se a tag do JSON existe
	 * 
	 * @param json
	 * @param key
	 * @return
	 */
	public static boolean existeTagJson(String json, String key) {

		boolean existe = false;
		JsonElement objJsonElement = new JsonParser().parse(json);

		if (objJsonElement.isJsonObject()) {
			
			JsonElement objJsonObject = objJsonElement.getAsJsonObject().get(key);
			
			if (objJsonObject != null) {
				existe = true;
			}
		}

		return existe;
	}

	/**
	 * Convert Object para String
	 * 
	 * @param dado
	 * @return
	 */
	public static String convertObjectToString(Object dado) {
		
		return (dado != null) ? StringUtils.trimWhitespace(dado.toString()) : STRING_EMPTY;
	}
	
	/**
	 * Convert UTF-8 para ISO-8859-1
	 * 
	 * @param dado
	 * @return
	 */
	public static String convertUTF8toISO(String dado) {
		
        Charset utf8charset = Charset.forName("UTF-8");
        Charset iso88591charset = Charset.forName("ISO-8859-1");

        ByteBuffer inputBuffer = ByteBuffer.wrap(dado.getBytes());

        // decode UTF-8
        CharBuffer data = utf8charset.decode(inputBuffer);

        // encode ISO-8559-1
        ByteBuffer outputBuffer = iso88591charset.encode(data);
        byte[] outputData = outputBuffer.array();

        return new String(outputData);
    }

	/**
	 * Obtem a informa��o do erro
	 * 
	 * @param json
	 * @return
	 */
	public static GerenciadorErrorInfo obterErrorInfo(String json) {
		
		GerenciadorErrorInfo errorInfo = new GerenciadorErrorInfo();

		JsonElement objJsonElement = new JsonParser().parse(json);

		if (objJsonElement.isJsonObject()) {

			JsonElement objJsonErro = objJsonElement.getAsJsonObject().get("erro");
			
			if (objJsonErro != null && objJsonErro.isJsonObject()) { 
				
				//Mensagem do Gerenciador
				String servico = objJsonErro.getAsJsonObject().get("servico").getAsString();
				String mensagem = objJsonErro.getAsJsonObject().get("mensagem").getAsString();

				errorInfo = new GerenciadorErrorInfo(servico, mensagem);
			}
			else {

				// Mensagens Gen�ricas
				if (existeTagJson(json, "Message")) {
					errorInfo = new GerenciadorErrorInfo("", objJsonElement.getAsJsonObject().get("Message").getAsString());
				} 
				else if (existeTagJson(json, "message")) {
					errorInfo = new GerenciadorErrorInfo("", objJsonElement.getAsJsonObject().get("message").getAsString());
				}
			}
		}
		
		return errorInfo;
	}
	
	/**
	 * Converte tag JSON 
	 * 
	 * @param json
	 * @return
	 */
	private static String obterTagJson(String tag) {

		if (tag.equalsIgnoreCase(JSON_KEY_FUNCAO_ATI_SISTEMA_PRODUTO)) {
			return JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
		} else {
			return tag.toLowerCase();
		}
	}
}