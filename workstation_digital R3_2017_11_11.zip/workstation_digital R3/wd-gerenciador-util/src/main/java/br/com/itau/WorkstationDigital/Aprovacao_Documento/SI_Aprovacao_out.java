/**
 * SI_Aprovacao_out.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.itau.WorkstationDigital.Aprovacao_Documento;

public interface SI_Aprovacao_out extends java.rmi.Remote {
    public br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_Response_out SI_Aprovacao_out(br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_out MT_Aprovacao_out) throws java.rmi.RemoteException;
}
