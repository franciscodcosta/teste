/**
 * ITAUWDWODETAILQueryTypeWOCHANGE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDWODETAILQueryTypeWOCHANGE  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXLongQueryType[] ITAU_MIMPACTO;

    private com.ibm.www.maximo.MXStringQueryType[] ITAU_MOTMUD;

    private com.ibm.www.maximo.MXLongQueryType[] ITAU_MPROBIMPACTO;

    private com.ibm.www.maximo.MXLongQueryType[] ITAU_MRISCO;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY;

    private com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDFINISH;

    private com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDSTART;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] SITEID;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] WONUM;

    private com.ibm.www.maximo.MXStringQueryType[] WORKTYPE;

    public ITAUWDWODETAILQueryTypeWOCHANGE() {
    }

    public ITAUWDWODETAILQueryTypeWOCHANGE(
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXLongQueryType[] ITAU_MIMPACTO,
           com.ibm.www.maximo.MXStringQueryType[] ITAU_MOTMUD,
           com.ibm.www.maximo.MXLongQueryType[] ITAU_MPROBIMPACTO,
           com.ibm.www.maximo.MXLongQueryType[] ITAU_MRISCO,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY,
           com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDFINISH,
           com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDSTART,
           com.ibm.www.maximo.MXStringQueryType[] SITEID,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXStringQueryType[] WONUM,
           com.ibm.www.maximo.MXStringQueryType[] WORKTYPE) {
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU_MIMPACTO = ITAU_MIMPACTO;
           this.ITAU_MOTMUD = ITAU_MOTMUD;
           this.ITAU_MPROBIMPACTO = ITAU_MPROBIMPACTO;
           this.ITAU_MRISCO = ITAU_MRISCO;
           this.REPORTEDBY = REPORTEDBY;
           this.SCHEDFINISH = SCHEDFINISH;
           this.SCHEDSTART = SCHEDSTART;
           this.SITEID = SITEID;
           this.STATUS = STATUS;
           this.WONUM = WONUM;
           this.WORKTYPE = WORKTYPE;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the ITAU_MIMPACTO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return ITAU_MIMPACTO
     */
    public com.ibm.www.maximo.MXLongQueryType[] getITAU_MIMPACTO() {
        return ITAU_MIMPACTO;
    }


    /**
     * Sets the ITAU_MIMPACTO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param ITAU_MIMPACTO
     */
    public void setITAU_MIMPACTO(com.ibm.www.maximo.MXLongQueryType[] ITAU_MIMPACTO) {
        this.ITAU_MIMPACTO = ITAU_MIMPACTO;
    }

    public com.ibm.www.maximo.MXLongQueryType getITAU_MIMPACTO(int i) {
        return this.ITAU_MIMPACTO[i];
    }

    public void setITAU_MIMPACTO(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.ITAU_MIMPACTO[i] = _value;
    }


    /**
     * Gets the ITAU_MOTMUD value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return ITAU_MOTMUD
     */
    public com.ibm.www.maximo.MXStringQueryType[] getITAU_MOTMUD() {
        return ITAU_MOTMUD;
    }


    /**
     * Sets the ITAU_MOTMUD value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param ITAU_MOTMUD
     */
    public void setITAU_MOTMUD(com.ibm.www.maximo.MXStringQueryType[] ITAU_MOTMUD) {
        this.ITAU_MOTMUD = ITAU_MOTMUD;
    }

    public com.ibm.www.maximo.MXStringQueryType getITAU_MOTMUD(int i) {
        return this.ITAU_MOTMUD[i];
    }

    public void setITAU_MOTMUD(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ITAU_MOTMUD[i] = _value;
    }


    /**
     * Gets the ITAU_MPROBIMPACTO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return ITAU_MPROBIMPACTO
     */
    public com.ibm.www.maximo.MXLongQueryType[] getITAU_MPROBIMPACTO() {
        return ITAU_MPROBIMPACTO;
    }


    /**
     * Sets the ITAU_MPROBIMPACTO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param ITAU_MPROBIMPACTO
     */
    public void setITAU_MPROBIMPACTO(com.ibm.www.maximo.MXLongQueryType[] ITAU_MPROBIMPACTO) {
        this.ITAU_MPROBIMPACTO = ITAU_MPROBIMPACTO;
    }

    public com.ibm.www.maximo.MXLongQueryType getITAU_MPROBIMPACTO(int i) {
        return this.ITAU_MPROBIMPACTO[i];
    }

    public void setITAU_MPROBIMPACTO(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.ITAU_MPROBIMPACTO[i] = _value;
    }


    /**
     * Gets the ITAU_MRISCO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return ITAU_MRISCO
     */
    public com.ibm.www.maximo.MXLongQueryType[] getITAU_MRISCO() {
        return ITAU_MRISCO;
    }


    /**
     * Sets the ITAU_MRISCO value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param ITAU_MRISCO
     */
    public void setITAU_MRISCO(com.ibm.www.maximo.MXLongQueryType[] ITAU_MRISCO) {
        this.ITAU_MRISCO = ITAU_MRISCO;
    }

    public com.ibm.www.maximo.MXLongQueryType getITAU_MRISCO(int i) {
        return this.ITAU_MRISCO[i];
    }

    public void setITAU_MRISCO(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.ITAU_MRISCO[i] = _value;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDBY(int i) {
        return this.REPORTEDBY[i];
    }

    public void setREPORTEDBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDBY[i] = _value;
    }


    /**
     * Gets the SCHEDFINISH value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return SCHEDFINISH
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getSCHEDFINISH() {
        return SCHEDFINISH;
    }


    /**
     * Sets the SCHEDFINISH value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param SCHEDFINISH
     */
    public void setSCHEDFINISH(com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDFINISH) {
        this.SCHEDFINISH = SCHEDFINISH;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getSCHEDFINISH(int i) {
        return this.SCHEDFINISH[i];
    }

    public void setSCHEDFINISH(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.SCHEDFINISH[i] = _value;
    }


    /**
     * Gets the SCHEDSTART value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return SCHEDSTART
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getSCHEDSTART() {
        return SCHEDSTART;
    }


    /**
     * Sets the SCHEDSTART value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param SCHEDSTART
     */
    public void setSCHEDSTART(com.ibm.www.maximo.MXDateTimeQueryType[] SCHEDSTART) {
        this.SCHEDSTART = SCHEDSTART;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getSCHEDSTART(int i) {
        return this.SCHEDSTART[i];
    }

    public void setSCHEDSTART(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.SCHEDSTART[i] = _value;
    }


    /**
     * Gets the SITEID value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringQueryType[] SITEID) {
        this.SITEID = SITEID;
    }

    public com.ibm.www.maximo.MXStringQueryType getSITEID(int i) {
        return this.SITEID[i];
    }

    public void setSITEID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SITEID[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the WONUM value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return WONUM   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getWONUM() {
        return WONUM;
    }


    /**
     * Sets the WONUM value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param WONUM   * Unique Key Component
     */
    public void setWONUM(com.ibm.www.maximo.MXStringQueryType[] WONUM) {
        this.WONUM = WONUM;
    }

    public com.ibm.www.maximo.MXStringQueryType getWONUM(int i) {
        return this.WONUM[i];
    }

    public void setWONUM(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.WONUM[i] = _value;
    }


    /**
     * Gets the WORKTYPE value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @return WORKTYPE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getWORKTYPE() {
        return WORKTYPE;
    }


    /**
     * Sets the WORKTYPE value for this ITAUWDWODETAILQueryTypeWOCHANGE.
     * 
     * @param WORKTYPE
     */
    public void setWORKTYPE(com.ibm.www.maximo.MXStringQueryType[] WORKTYPE) {
        this.WORKTYPE = WORKTYPE;
    }

    public com.ibm.www.maximo.MXStringQueryType getWORKTYPE(int i) {
        return this.WORKTYPE[i];
    }

    public void setWORKTYPE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.WORKTYPE[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDWODETAILQueryTypeWOCHANGE)) return false;
        ITAUWDWODETAILQueryTypeWOCHANGE other = (ITAUWDWODETAILQueryTypeWOCHANGE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.ITAU_MIMPACTO==null && other.getITAU_MIMPACTO()==null) || 
             (this.ITAU_MIMPACTO!=null &&
              java.util.Arrays.equals(this.ITAU_MIMPACTO, other.getITAU_MIMPACTO()))) &&
            ((this.ITAU_MOTMUD==null && other.getITAU_MOTMUD()==null) || 
             (this.ITAU_MOTMUD!=null &&
              java.util.Arrays.equals(this.ITAU_MOTMUD, other.getITAU_MOTMUD()))) &&
            ((this.ITAU_MPROBIMPACTO==null && other.getITAU_MPROBIMPACTO()==null) || 
             (this.ITAU_MPROBIMPACTO!=null &&
              java.util.Arrays.equals(this.ITAU_MPROBIMPACTO, other.getITAU_MPROBIMPACTO()))) &&
            ((this.ITAU_MRISCO==null && other.getITAU_MRISCO()==null) || 
             (this.ITAU_MRISCO!=null &&
              java.util.Arrays.equals(this.ITAU_MRISCO, other.getITAU_MRISCO()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              java.util.Arrays.equals(this.REPORTEDBY, other.getREPORTEDBY()))) &&
            ((this.SCHEDFINISH==null && other.getSCHEDFINISH()==null) || 
             (this.SCHEDFINISH!=null &&
              java.util.Arrays.equals(this.SCHEDFINISH, other.getSCHEDFINISH()))) &&
            ((this.SCHEDSTART==null && other.getSCHEDSTART()==null) || 
             (this.SCHEDSTART!=null &&
              java.util.Arrays.equals(this.SCHEDSTART, other.getSCHEDSTART()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              java.util.Arrays.equals(this.SITEID, other.getSITEID()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.WONUM==null && other.getWONUM()==null) || 
             (this.WONUM!=null &&
              java.util.Arrays.equals(this.WONUM, other.getWONUM()))) &&
            ((this.WORKTYPE==null && other.getWORKTYPE()==null) || 
             (this.WORKTYPE!=null &&
              java.util.Arrays.equals(this.WORKTYPE, other.getWORKTYPE())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_MIMPACTO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_MIMPACTO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_MIMPACTO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_MOTMUD() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_MOTMUD());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_MOTMUD(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_MPROBIMPACTO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_MPROBIMPACTO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_MPROBIMPACTO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_MRISCO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_MRISCO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_MRISCO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSCHEDFINISH() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSCHEDFINISH());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSCHEDFINISH(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSCHEDSTART() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSCHEDSTART());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSCHEDSTART(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSITEID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSITEID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSITEID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWONUM() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWONUM());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWONUM(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWORKTYPE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWORKTYPE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWORKTYPE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDWODETAILQueryTypeWOCHANGE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDWODETAILQueryType>WOCHANGE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MIMPACTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MIMPACTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MOTMUD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MOTMUD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MPROBIMPACTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MPROBIMPACTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_MRISCO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_MRISCO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCHEDFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SCHEDFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SCHEDSTART");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SCHEDSTART"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
