/**
 * ITAUWDANEXOPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDANEXO;

public interface ITAUWDANEXOPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDANEXOResponseType queryITAUWDANEXO(com.ibm.www.maximo.QueryITAUWDANEXOType parameters) throws java.rmi.RemoteException;
}
