/**
 * ITAUWDCLASS_CLASSSPECType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDCLASS_CLASSSPECType  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType ASSETATTRID;

    private com.ibm.www.maximo.MXStringType DOMAINID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType ORGID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType SECTION;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType SITEID;

    private com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType[] ASSETATTRIBUTE;

    private com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType[] ALNDOMAIN;

    private com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType[] NUMERICDOMAIN;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDCLASS_CLASSSPECType() {
    }

    public ITAUWDCLASS_CLASSSPECType(
           com.ibm.www.maximo.MXStringType ASSETATTRID,
           com.ibm.www.maximo.MXStringType DOMAINID,
           com.ibm.www.maximo.MXStringType ORGID,
           com.ibm.www.maximo.MXStringType SECTION,
           com.ibm.www.maximo.MXStringType SITEID,
           com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType[] ASSETATTRIBUTE,
           com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType[] ALNDOMAIN,
           com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType[] NUMERICDOMAIN,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.ASSETATTRID = ASSETATTRID;
           this.DOMAINID = DOMAINID;
           this.ORGID = ORGID;
           this.SECTION = SECTION;
           this.SITEID = SITEID;
           this.ASSETATTRIBUTE = ASSETATTRIBUTE;
           this.ALNDOMAIN = ALNDOMAIN;
           this.NUMERICDOMAIN = NUMERICDOMAIN;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the ASSETATTRID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return ASSETATTRID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getASSETATTRID() {
        return ASSETATTRID;
    }


    /**
     * Sets the ASSETATTRID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param ASSETATTRID   * Unique Key Component
     */
    public void setASSETATTRID(com.ibm.www.maximo.MXStringType ASSETATTRID) {
        this.ASSETATTRID = ASSETATTRID;
    }


    /**
     * Gets the DOMAINID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return DOMAINID
     */
    public com.ibm.www.maximo.MXStringType getDOMAINID() {
        return DOMAINID;
    }


    /**
     * Sets the DOMAINID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param DOMAINID
     */
    public void setDOMAINID(com.ibm.www.maximo.MXStringType DOMAINID) {
        this.DOMAINID = DOMAINID;
    }


    /**
     * Gets the ORGID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return ORGID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getORGID() {
        return ORGID;
    }


    /**
     * Sets the ORGID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param ORGID   * Unique Key Component
     */
    public void setORGID(com.ibm.www.maximo.MXStringType ORGID) {
        this.ORGID = ORGID;
    }


    /**
     * Gets the SECTION value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return SECTION   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getSECTION() {
        return SECTION;
    }


    /**
     * Sets the SECTION value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param SECTION   * Unique Key Component
     */
    public void setSECTION(com.ibm.www.maximo.MXStringType SECTION) {
        this.SECTION = SECTION;
    }


    /**
     * Gets the SITEID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringType SITEID) {
        this.SITEID = SITEID;
    }


    /**
     * Gets the ASSETATTRIBUTE value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return ASSETATTRIBUTE
     */
    public com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType[] getASSETATTRIBUTE() {
        return ASSETATTRIBUTE;
    }


    /**
     * Sets the ASSETATTRIBUTE value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param ASSETATTRIBUTE
     */
    public void setASSETATTRIBUTE(com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType[] ASSETATTRIBUTE) {
        this.ASSETATTRIBUTE = ASSETATTRIBUTE;
    }

    public com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType getASSETATTRIBUTE(int i) {
        return this.ASSETATTRIBUTE[i];
    }

    public void setASSETATTRIBUTE(int i, com.ibm.www.maximo.ITAUWDCLASS_ASSETATTRIBUTEType _value) {
        this.ASSETATTRIBUTE[i] = _value;
    }


    /**
     * Gets the ALNDOMAIN value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return ALNDOMAIN
     */
    public com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType[] getALNDOMAIN() {
        return ALNDOMAIN;
    }


    /**
     * Sets the ALNDOMAIN value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param ALNDOMAIN
     */
    public void setALNDOMAIN(com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType[] ALNDOMAIN) {
        this.ALNDOMAIN = ALNDOMAIN;
    }

    public com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType getALNDOMAIN(int i) {
        return this.ALNDOMAIN[i];
    }

    public void setALNDOMAIN(int i, com.ibm.www.maximo.ITAUWDCLASS_ALNDOMAINType _value) {
        this.ALNDOMAIN[i] = _value;
    }


    /**
     * Gets the NUMERICDOMAIN value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return NUMERICDOMAIN
     */
    public com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType[] getNUMERICDOMAIN() {
        return NUMERICDOMAIN;
    }


    /**
     * Sets the NUMERICDOMAIN value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param NUMERICDOMAIN
     */
    public void setNUMERICDOMAIN(com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType[] NUMERICDOMAIN) {
        this.NUMERICDOMAIN = NUMERICDOMAIN;
    }

    public com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType getNUMERICDOMAIN(int i) {
        return this.NUMERICDOMAIN[i];
    }

    public void setNUMERICDOMAIN(int i, com.ibm.www.maximo.ITAUWDCLASS_NUMERICDOMAINType _value) {
        this.NUMERICDOMAIN[i] = _value;
    }


    /**
     * Gets the action value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDCLASS_CLASSSPECType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDCLASS_CLASSSPECType)) return false;
        ITAUWDCLASS_CLASSSPECType other = (ITAUWDCLASS_CLASSSPECType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ASSETATTRID==null && other.getASSETATTRID()==null) || 
             (this.ASSETATTRID!=null &&
              this.ASSETATTRID.equals(other.getASSETATTRID()))) &&
            ((this.DOMAINID==null && other.getDOMAINID()==null) || 
             (this.DOMAINID!=null &&
              this.DOMAINID.equals(other.getDOMAINID()))) &&
            ((this.ORGID==null && other.getORGID()==null) || 
             (this.ORGID!=null &&
              this.ORGID.equals(other.getORGID()))) &&
            ((this.SECTION==null && other.getSECTION()==null) || 
             (this.SECTION!=null &&
              this.SECTION.equals(other.getSECTION()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              this.SITEID.equals(other.getSITEID()))) &&
            ((this.ASSETATTRIBUTE==null && other.getASSETATTRIBUTE()==null) || 
             (this.ASSETATTRIBUTE!=null &&
              java.util.Arrays.equals(this.ASSETATTRIBUTE, other.getASSETATTRIBUTE()))) &&
            ((this.ALNDOMAIN==null && other.getALNDOMAIN()==null) || 
             (this.ALNDOMAIN!=null &&
              java.util.Arrays.equals(this.ALNDOMAIN, other.getALNDOMAIN()))) &&
            ((this.NUMERICDOMAIN==null && other.getNUMERICDOMAIN()==null) || 
             (this.NUMERICDOMAIN!=null &&
              java.util.Arrays.equals(this.NUMERICDOMAIN, other.getNUMERICDOMAIN()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getASSETATTRID() != null) {
            _hashCode += getASSETATTRID().hashCode();
        }
        if (getDOMAINID() != null) {
            _hashCode += getDOMAINID().hashCode();
        }
        if (getORGID() != null) {
            _hashCode += getORGID().hashCode();
        }
        if (getSECTION() != null) {
            _hashCode += getSECTION().hashCode();
        }
        if (getSITEID() != null) {
            _hashCode += getSITEID().hashCode();
        }
        if (getASSETATTRIBUTE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getASSETATTRIBUTE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getASSETATTRIBUTE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getALNDOMAIN() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getALNDOMAIN());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getALNDOMAIN(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNUMERICDOMAIN() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNUMERICDOMAIN());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNUMERICDOMAIN(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDCLASS_CLASSSPECType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_CLASSSPECType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ASSETATTRID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ASSETATTRID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOMAINID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOMAINID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ORGID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ORGID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ASSETATTRIBUTE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ASSETATTRIBUTE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_ASSETATTRIBUTEType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ALNDOMAIN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ALNDOMAIN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_ALNDOMAINType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NUMERICDOMAIN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NUMERICDOMAIN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_NUMERICDOMAINType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
