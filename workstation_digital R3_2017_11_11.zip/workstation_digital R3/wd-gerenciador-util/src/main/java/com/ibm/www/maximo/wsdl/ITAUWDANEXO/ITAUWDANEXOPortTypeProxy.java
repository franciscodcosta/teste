package com.ibm.www.maximo.wsdl.ITAUWDANEXO;

public class ITAUWDANEXOPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOPortType iTAUWDANEXOPortType = null;
  
  public ITAUWDANEXOPortTypeProxy() {
    _initITAUWDANEXOPortTypeProxy();
  }
  
  public ITAUWDANEXOPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDANEXOPortTypeProxy();
  }
  
  private void _initITAUWDANEXOPortTypeProxy() {
    try {
      iTAUWDANEXOPortType = (new com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOLocator()).getITAUWDANEXOSOAP11Port();
      if (iTAUWDANEXOPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDANEXOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDANEXOPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDANEXOPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDANEXOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDANEXO.ITAUWDANEXOPortType getITAUWDANEXOPortType() {
    if (iTAUWDANEXOPortType == null)
      _initITAUWDANEXOPortTypeProxy();
    return iTAUWDANEXOPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDANEXOResponseType queryITAUWDANEXO(com.ibm.www.maximo.QueryITAUWDANEXOType parameters) throws java.rmi.RemoteException{
    if (iTAUWDANEXOPortType == null)
      _initITAUWDANEXOPortTypeProxy();
    return iTAUWDANEXOPortType.queryITAUWDANEXO(parameters);
  }
  
  
}