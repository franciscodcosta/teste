/**
 * ITAUWDCLASSQueryTypeCLASSSTRUCTURE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDCLASSQueryTypeCLASSSTRUCTURE  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.ITAUWDCLASSQueryTypeCLASSSTRUCTURECLASSSPEC CLASSSPEC;

    public ITAUWDCLASSQueryTypeCLASSSTRUCTURE() {
    }

    public ITAUWDCLASSQueryTypeCLASSSTRUCTURE(
           com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID,
           com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.ITAUWDCLASSQueryTypeCLASSSTRUCTURECLASSSPEC CLASSSPEC) {
           this.CLASSIFICATIONID = CLASSIFICATIONID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DESCRIPTION = DESCRIPTION;
           this.CLASSSPEC = CLASSSPEC;
    }


    /**
     * Gets the CLASSIFICATIONID value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @return CLASSIFICATIONID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSIFICATIONID() {
        return CLASSIFICATIONID;
    }


    /**
     * Sets the CLASSIFICATIONID value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @param CLASSIFICATIONID
     */
    public void setCLASSIFICATIONID(com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID) {
        this.CLASSIFICATIONID = CLASSIFICATIONID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSIFICATIONID(int i) {
        return this.CLASSIFICATIONID[i];
    }

    public void setCLASSIFICATIONID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSIFICATIONID[i] = _value;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @return CLASSSTRUCTUREID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @param CLASSSTRUCTUREID   * Unique Key Component
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSSTRUCTUREID(int i) {
        return this.CLASSSTRUCTUREID[i];
    }

    public void setCLASSSTRUCTUREID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSSTRUCTUREID[i] = _value;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the CLASSSPEC value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @return CLASSSPEC
     */
    public com.ibm.www.maximo.ITAUWDCLASSQueryTypeCLASSSTRUCTURECLASSSPEC getCLASSSPEC() {
        return CLASSSPEC;
    }


    /**
     * Sets the CLASSSPEC value for this ITAUWDCLASSQueryTypeCLASSSTRUCTURE.
     * 
     * @param CLASSSPEC
     */
    public void setCLASSSPEC(com.ibm.www.maximo.ITAUWDCLASSQueryTypeCLASSSTRUCTURECLASSSPEC CLASSSPEC) {
        this.CLASSSPEC = CLASSSPEC;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDCLASSQueryTypeCLASSSTRUCTURE)) return false;
        ITAUWDCLASSQueryTypeCLASSSTRUCTURE other = (ITAUWDCLASSQueryTypeCLASSSTRUCTURE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASSIFICATIONID==null && other.getCLASSIFICATIONID()==null) || 
             (this.CLASSIFICATIONID!=null &&
              java.util.Arrays.equals(this.CLASSIFICATIONID, other.getCLASSIFICATIONID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTUREID, other.getCLASSSTRUCTUREID()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.CLASSSPEC==null && other.getCLASSSPEC()==null) || 
             (this.CLASSSPEC!=null &&
              this.CLASSSPEC.equals(other.getCLASSSPEC())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASSIFICATIONID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSIFICATIONID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSIFICATIONID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSTRUCTUREID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTUREID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTUREID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSPEC() != null) {
            _hashCode += getCLASSSPEC().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDCLASSQueryTypeCLASSSTRUCTURE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDCLASSQueryType>CLASSSTRUCTURE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSIFICATIONID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSIFICATIONID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDCLASSQueryType>CLASSSTRUCTURE>CLASSSPEC"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
