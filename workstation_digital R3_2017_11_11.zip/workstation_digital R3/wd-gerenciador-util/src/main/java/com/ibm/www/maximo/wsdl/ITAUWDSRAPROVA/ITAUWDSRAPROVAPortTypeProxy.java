package com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA;

public class ITAUWDSRAPROVAPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVAPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVAPortType iTAUWDSRAPROVAPortType = null;
  
  public ITAUWDSRAPROVAPortTypeProxy() {
    _initITAUWDSRAPROVAPortTypeProxy();
  }
  
  public ITAUWDSRAPROVAPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDSRAPROVAPortTypeProxy();
  }
  
  private void _initITAUWDSRAPROVAPortTypeProxy() {
    try {
      iTAUWDSRAPROVAPortType = (new com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVALocator()).getITAUWDSRAPROVASOAP11Port();
      if (iTAUWDSRAPROVAPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDSRAPROVAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDSRAPROVAPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDSRAPROVAPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDSRAPROVAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVAPortType getITAUWDSRAPROVAPortType() {
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType queryITAUWDSRAPROVA(com.ibm.www.maximo.QueryITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType.queryITAUWDSRAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType syncITAUWDSRAPROVA(com.ibm.www.maximo.SyncITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType.syncITAUWDSRAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType updateITAUWDSRAPROVA(com.ibm.www.maximo.UpdateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType.updateITAUWDSRAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType createITAUWDSRAPROVA(com.ibm.www.maximo.CreateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType.createITAUWDSRAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType deleteITAUWDSRAPROVA(com.ibm.www.maximo.DeleteITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRAPROVAPortType == null)
      _initITAUWDSRAPROVAPortTypeProxy();
    return iTAUWDSRAPROVAPortType.deleteITAUWDSRAPROVA(parameters);
  }
  
  
}