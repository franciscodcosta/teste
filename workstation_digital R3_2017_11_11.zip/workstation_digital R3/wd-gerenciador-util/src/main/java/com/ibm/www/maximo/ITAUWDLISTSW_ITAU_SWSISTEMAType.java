/**
 * ITAUWDLISTSW_ITAU_SWSISTEMAType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDLISTSW_ITAU_SWSISTEMAType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    private com.ibm.www.maximo.MXBooleanType CORPORATIVO;

    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXBooleanType ITAU;

    private com.ibm.www.maximo.MXBooleanType ITAU_SWREDE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType ITAU_SWSISTEMAID;

    private com.ibm.www.maximo.MXBooleanType LICENCIADO;

    private com.ibm.www.maximo.MXBooleanType RESTRITO;

    private com.ibm.www.maximo.MXStringType TIPO;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDLISTSW_ITAU_SWSISTEMAType() {
    }

    public ITAUWDLISTSW_ITAU_SWSISTEMAType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXBooleanType CORPORATIVO,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXBooleanType ITAU,
           com.ibm.www.maximo.MXBooleanType ITAU_SWREDE,
           com.ibm.www.maximo.MXLongType ITAU_SWSISTEMAID,
           com.ibm.www.maximo.MXBooleanType LICENCIADO,
           com.ibm.www.maximo.MXBooleanType RESTRITO,
           com.ibm.www.maximo.MXStringType TIPO,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.CORPORATIVO = CORPORATIVO;
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU = ITAU;
           this.ITAU_SWREDE = ITAU_SWREDE;
           this.ITAU_SWSISTEMAID = ITAU_SWSISTEMAID;
           this.LICENCIADO = LICENCIADO;
           this.RESTRITO = RESTRITO;
           this.TIPO = TIPO;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the CORPORATIVO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return CORPORATIVO
     */
    public com.ibm.www.maximo.MXBooleanType getCORPORATIVO() {
        return CORPORATIVO;
    }


    /**
     * Sets the CORPORATIVO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param CORPORATIVO
     */
    public void setCORPORATIVO(com.ibm.www.maximo.MXBooleanType CORPORATIVO) {
        this.CORPORATIVO = CORPORATIVO;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the ITAU value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return ITAU
     */
    public com.ibm.www.maximo.MXBooleanType getITAU() {
        return ITAU;
    }


    /**
     * Sets the ITAU value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param ITAU
     */
    public void setITAU(com.ibm.www.maximo.MXBooleanType ITAU) {
        this.ITAU = ITAU;
    }


    /**
     * Gets the ITAU_SWREDE value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return ITAU_SWREDE
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_SWREDE() {
        return ITAU_SWREDE;
    }


    /**
     * Sets the ITAU_SWREDE value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param ITAU_SWREDE
     */
    public void setITAU_SWREDE(com.ibm.www.maximo.MXBooleanType ITAU_SWREDE) {
        this.ITAU_SWREDE = ITAU_SWREDE;
    }


    /**
     * Gets the ITAU_SWSISTEMAID value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return ITAU_SWSISTEMAID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getITAU_SWSISTEMAID() {
        return ITAU_SWSISTEMAID;
    }


    /**
     * Sets the ITAU_SWSISTEMAID value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param ITAU_SWSISTEMAID   * Unique Key Component
     */
    public void setITAU_SWSISTEMAID(com.ibm.www.maximo.MXLongType ITAU_SWSISTEMAID) {
        this.ITAU_SWSISTEMAID = ITAU_SWSISTEMAID;
    }


    /**
     * Gets the LICENCIADO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return LICENCIADO
     */
    public com.ibm.www.maximo.MXBooleanType getLICENCIADO() {
        return LICENCIADO;
    }


    /**
     * Sets the LICENCIADO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param LICENCIADO
     */
    public void setLICENCIADO(com.ibm.www.maximo.MXBooleanType LICENCIADO) {
        this.LICENCIADO = LICENCIADO;
    }


    /**
     * Gets the RESTRITO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return RESTRITO
     */
    public com.ibm.www.maximo.MXBooleanType getRESTRITO() {
        return RESTRITO;
    }


    /**
     * Sets the RESTRITO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param RESTRITO
     */
    public void setRESTRITO(com.ibm.www.maximo.MXBooleanType RESTRITO) {
        this.RESTRITO = RESTRITO;
    }


    /**
     * Gets the TIPO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return TIPO
     */
    public com.ibm.www.maximo.MXStringType getTIPO() {
        return TIPO;
    }


    /**
     * Sets the TIPO value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param TIPO
     */
    public void setTIPO(com.ibm.www.maximo.MXStringType TIPO) {
        this.TIPO = TIPO;
    }


    /**
     * Gets the action value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDLISTSW_ITAU_SWSISTEMAType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDLISTSW_ITAU_SWSISTEMAType)) return false;
        ITAUWDLISTSW_ITAU_SWSISTEMAType other = (ITAUWDLISTSW_ITAU_SWSISTEMAType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.CORPORATIVO==null && other.getCORPORATIVO()==null) || 
             (this.CORPORATIVO!=null &&
              this.CORPORATIVO.equals(other.getCORPORATIVO()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.ITAU==null && other.getITAU()==null) || 
             (this.ITAU!=null &&
              this.ITAU.equals(other.getITAU()))) &&
            ((this.ITAU_SWREDE==null && other.getITAU_SWREDE()==null) || 
             (this.ITAU_SWREDE!=null &&
              this.ITAU_SWREDE.equals(other.getITAU_SWREDE()))) &&
            ((this.ITAU_SWSISTEMAID==null && other.getITAU_SWSISTEMAID()==null) || 
             (this.ITAU_SWSISTEMAID!=null &&
              this.ITAU_SWSISTEMAID.equals(other.getITAU_SWSISTEMAID()))) &&
            ((this.LICENCIADO==null && other.getLICENCIADO()==null) || 
             (this.LICENCIADO!=null &&
              this.LICENCIADO.equals(other.getLICENCIADO()))) &&
            ((this.RESTRITO==null && other.getRESTRITO()==null) || 
             (this.RESTRITO!=null &&
              this.RESTRITO.equals(other.getRESTRITO()))) &&
            ((this.TIPO==null && other.getTIPO()==null) || 
             (this.TIPO!=null &&
              this.TIPO.equals(other.getTIPO()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getCORPORATIVO() != null) {
            _hashCode += getCORPORATIVO().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getITAU() != null) {
            _hashCode += getITAU().hashCode();
        }
        if (getITAU_SWREDE() != null) {
            _hashCode += getITAU_SWREDE().hashCode();
        }
        if (getITAU_SWSISTEMAID() != null) {
            _hashCode += getITAU_SWSISTEMAID().hashCode();
        }
        if (getLICENCIADO() != null) {
            _hashCode += getLICENCIADO().hashCode();
        }
        if (getRESTRITO() != null) {
            _hashCode += getRESTRITO().hashCode();
        }
        if (getTIPO() != null) {
            _hashCode += getTIPO().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDLISTSW_ITAU_SWSISTEMAType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDLISTSW_ITAU_SWSISTEMAType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CORPORATIVO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CORPORATIVO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_SWREDE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_SWREDE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_SWSISTEMAID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_SWSISTEMAID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LICENCIADO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LICENCIADO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("RESTRITO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "RESTRITO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TIPO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TIPO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
