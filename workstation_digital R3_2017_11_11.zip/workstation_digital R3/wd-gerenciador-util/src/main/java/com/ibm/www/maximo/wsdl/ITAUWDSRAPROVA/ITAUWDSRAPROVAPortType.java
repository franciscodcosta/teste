/**
 * ITAUWDSRAPROVAPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA;

public interface ITAUWDSRAPROVAPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType queryITAUWDSRAPROVA(com.ibm.www.maximo.QueryITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType syncITAUWDSRAPROVA(com.ibm.www.maximo.SyncITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType updateITAUWDSRAPROVA(com.ibm.www.maximo.UpdateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType createITAUWDSRAPROVA(com.ibm.www.maximo.CreateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType deleteITAUWDSRAPROVA(com.ibm.www.maximo.DeleteITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException;
}
