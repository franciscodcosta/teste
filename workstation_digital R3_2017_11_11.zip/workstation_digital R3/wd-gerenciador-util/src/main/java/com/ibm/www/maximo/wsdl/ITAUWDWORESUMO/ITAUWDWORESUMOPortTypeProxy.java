package com.ibm.www.maximo.wsdl.ITAUWDWORESUMO;

public class ITAUWDWORESUMOPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOPortType iTAUWDWORESUMOPortType = null;
  
  public ITAUWDWORESUMOPortTypeProxy() {
    _initITAUWDWORESUMOPortTypeProxy();
  }
  
  public ITAUWDWORESUMOPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDWORESUMOPortTypeProxy();
  }
  
  private void _initITAUWDWORESUMOPortTypeProxy() {
    try {
      iTAUWDWORESUMOPortType = (new com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOLocator()).getITAUWDWORESUMOSOAP11Port();
      if (iTAUWDWORESUMOPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDWORESUMOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDWORESUMOPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDWORESUMOPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDWORESUMOPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOPortType getITAUWDWORESUMOPortType() {
    if (iTAUWDWORESUMOPortType == null)
      _initITAUWDWORESUMOPortTypeProxy();
    return iTAUWDWORESUMOPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDWORESUMOResponseType queryITAUWDWORESUMO(com.ibm.www.maximo.QueryITAUWDWORESUMOType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWORESUMOPortType == null)
      _initITAUWDWORESUMOPortTypeProxy();
    return iTAUWDWORESUMOPortType.queryITAUWDWORESUMO(parameters);
  }
  
  
}