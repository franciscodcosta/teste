/**
 * ITAUWDCLASSPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDCLASS;

public interface ITAUWDCLASSPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDCLASSResponseType queryITAUWDCLASS(com.ibm.www.maximo.QueryITAUWDCLASSType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.SyncITAUWDCLASSResponseType syncITAUWDCLASS(com.ibm.www.maximo.SyncITAUWDCLASSType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.UpdateITAUWDCLASSResponseType updateITAUWDCLASS(com.ibm.www.maximo.UpdateITAUWDCLASSType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.CreateITAUWDCLASSResponseType createITAUWDCLASS(com.ibm.www.maximo.CreateITAUWDCLASSType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.DeleteITAUWDCLASSResponseType deleteITAUWDCLASS(com.ibm.www.maximo.DeleteITAUWDCLASSType parameters) throws java.rmi.RemoteException;
}
