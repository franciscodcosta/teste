/**
 * ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID;

    private com.ibm.www.maximo.MXLongType CLASSSTRUCTUREUID;

    public ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE() {
    }

    public ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE(
           com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXLongType CLASSSTRUCTUREUID) {
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.CLASSSTRUCTUREUID = CLASSSTRUCTUREUID;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.
     * 
     * @return CLASSSTRUCTUREID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.
     * 
     * @param CLASSSTRUCTUREID   * Unique Key Component
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }


    /**
     * Gets the CLASSSTRUCTUREUID value for this ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.
     * 
     * @return CLASSSTRUCTUREUID
     */
    public com.ibm.www.maximo.MXLongType getCLASSSTRUCTUREUID() {
        return CLASSSTRUCTUREUID;
    }


    /**
     * Sets the CLASSSTRUCTUREUID value for this ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.
     * 
     * @param CLASSSTRUCTUREUID
     */
    public void setCLASSSTRUCTUREUID(com.ibm.www.maximo.MXLongType CLASSSTRUCTUREUID) {
        this.CLASSSTRUCTUREUID = CLASSSTRUCTUREUID;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE)) return false;
        ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE other = (ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              this.CLASSSTRUCTUREID.equals(other.getCLASSSTRUCTUREID()))) &&
            ((this.CLASSSTRUCTUREUID==null && other.getCLASSSTRUCTUREUID()==null) || 
             (this.CLASSSTRUCTUREUID!=null &&
              this.CLASSSTRUCTUREUID.equals(other.getCLASSSTRUCTUREUID())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASSSTRUCTUREID() != null) {
            _hashCode += getCLASSSTRUCTUREID().hashCode();
        }
        if (getCLASSSTRUCTUREUID() != null) {
            _hashCode += getCLASSSTRUCTUREUID().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDCLASSCombinedKeySetTypeCLASSSTRUCTURE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDCLASSCombinedKeySetType>CLASSSTRUCTURE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
