/**
 * ITAUWDWORESUMOQueryTypeWOCHANGE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDWORESUMOQueryTypeWOCHANGE  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] SITEID;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] WONUM;

    public ITAUWDWORESUMOQueryTypeWOCHANGE() {
    }

    public ITAUWDWORESUMOQueryTypeWOCHANGE(
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXStringQueryType[] SITEID,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXStringQueryType[] WONUM) {
           this.DESCRIPTION = DESCRIPTION;
           this.SITEID = SITEID;
           this.STATUS = STATUS;
           this.WONUM = WONUM;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the SITEID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringQueryType[] SITEID) {
        this.SITEID = SITEID;
    }

    public com.ibm.www.maximo.MXStringQueryType getSITEID(int i) {
        return this.SITEID[i];
    }

    public void setSITEID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SITEID[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the WONUM value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return WONUM   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getWONUM() {
        return WONUM;
    }


    /**
     * Sets the WONUM value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param WONUM   * Unique Key Component
     */
    public void setWONUM(com.ibm.www.maximo.MXStringQueryType[] WONUM) {
        this.WONUM = WONUM;
    }

    public com.ibm.www.maximo.MXStringQueryType getWONUM(int i) {
        return this.WONUM[i];
    }

    public void setWONUM(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.WONUM[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDWORESUMOQueryTypeWOCHANGE)) return false;
        ITAUWDWORESUMOQueryTypeWOCHANGE other = (ITAUWDWORESUMOQueryTypeWOCHANGE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              java.util.Arrays.equals(this.SITEID, other.getSITEID()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.WONUM==null && other.getWONUM()==null) || 
             (this.WONUM!=null &&
              java.util.Arrays.equals(this.WONUM, other.getWONUM())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSITEID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSITEID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSITEID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWONUM() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWONUM());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWONUM(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDWORESUMOQueryTypeWOCHANGE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDWORESUMOQueryType>WOCHANGE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
