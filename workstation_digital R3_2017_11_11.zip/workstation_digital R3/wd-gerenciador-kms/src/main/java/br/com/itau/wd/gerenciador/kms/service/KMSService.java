package br.com.itau.wd.gerenciador.kms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.kms.dao.KMSDao;
import br.com.itau.wd.gerenciador.kms.dto.ChaveDto;
import br.com.itau.wd.gerenciador.kms.exception.KMSException;

/**
 * KEY MANAGEMENT SERVICE (KMS) Service
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Service
public class KMSService {

	@Autowired
	private KMSDao dao;

	/**
	 * cria a chave e insere os dados
	 * 
	 * @param chave
	 * @return
	 * @throws KMSException
	 */
	public String salvarChave(ChaveDto chave) throws KMSException {

		return dao.salvarChave(chave);		
	}

	/**
	 * Consulta os dados da chave
	 * 
	 * @param codigoChaveExterna
	 * @return
	 * @throws KMSException 
	 */
	public List<ChaveDto> consultarChave(String codigoChaveExterna) throws KMSException {

		return dao.consultarChave(codigoChaveExterna);
	}
}