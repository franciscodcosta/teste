package br.com.itau.wd.gerenciador.sep.service;

import static br.com.itau.wd.gerenciador.util.Constants.MICRO_SERVICO_HCS;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.sep.dao.MicroServicoDao;
import br.com.itau.wd.gerenciador.sep.dto.DadosDto;
import br.com.itau.wd.gerenciador.sep.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;

/**
 * <b>Serviço HCS</b>
 * Verifica se o serviço esta disponível 
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Service
public class HCSService {

	@Autowired
	MicroServicoDao dao;
	
	@Autowired
	ClientRestService clientRest;
	
	/**
	 * Retorna a disponibilidade do serviço
	 * 
	 * @param endpoint
	 * @return
	 * @throws SEPException 
	 */
	public Boolean obterDisponibilidade(DadosDto dadosDto) throws SEPException {

		boolean disponibilidade = false;

		try {

		    String url = String.format("%s/disponibilidade?servico={servico}", obterEndpointHcs());		
	
		    String retorno = clientRest.enviarJson(url, dadosDto.getEndpoint().getUrlServico());
	
		    disponibilidade = Boolean.valueOf(retorno);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}

		return disponibilidade;
	}

	/**
	 * Retorna o endpoint do microserviço HCS
	 * 
	 * @return
	 * @throws SEPException
	 */
	private String obterEndpointHcs() throws SEPException {
		
		EndpointDto microServico = dao.obterMicroServico(MICRO_SERVICO_HCS);
		
		return microServico.getUrlServico();
	}	
}