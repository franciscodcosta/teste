package br.com.itau.wd.gerenciador.sep.application;

import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_CONNECTION_REQUEST_TIMEOUT;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_CONNECT_TIMEOUT;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_POOL_MAX_PER_ROUTE;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_POOL_MAX_TOTAL;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SOCKET_TIMEOUT;

import javax.annotation.Resource;

import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@ComponentScan(basePackages = {"br.com.itau.wd.gerenciador.sep.*"})
@PropertySources({
    @PropertySource(value="file:${app.properties}", ignoreResourceNotFound=false)
})
public class WDGerenciadorSEPApplication {

	@Resource
	private Environment env;
	
	public static void main(String[] args) {
		SpringApplication.run(WDGerenciadorSEPApplication.class, args);
	}

	@Bean
	public PoolingHttpClientConnectionManager poolingHttpClientConnectionManager() {
		
		PoolingHttpClientConnectionManager result = new PoolingHttpClientConnectionManager();
		
		int maxTotal = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_POOL_MAX_TOTAL));
		int maxPerRoute = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_POOL_MAX_PER_ROUTE));

	    result.setMaxTotal(maxTotal);
	    result.setDefaultMaxPerRoute(maxPerRoute);

	    return result;
	}

	@Bean
	public RequestConfig requestConfig() {
	
		int connectionTRequestTimeout = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_CONNECTION_REQUEST_TIMEOUT));
		int connectTimeout = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_CONNECT_TIMEOUT));
		int socketTimeout = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_SOCKET_TIMEOUT));

	    return RequestConfig.custom()
	    		.setConnectionRequestTimeout(connectionTRequestTimeout)
	    		.setConnectTimeout(connectTimeout)
	    		.setSocketTimeout(socketTimeout)
	    		.build();
	}
	
	@Bean
	public CloseableHttpClient httpClient(PoolingHttpClientConnectionManager poolingHttpClientConnectionManager, RequestConfig requestConfig) {
		 
		 return HttpClientBuilder
				 .create()
				 .setConnectionManager(poolingHttpClientConnectionManager)
				 .setDefaultRequestConfig(requestConfig)
				 .build();
	}

	@Bean
	public RestTemplate restTemplate(HttpClient httpClient) {
		
	    HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
	    requestFactory.setHttpClient(httpClient);

	    return new RestTemplate(requestFactory);
	}
}