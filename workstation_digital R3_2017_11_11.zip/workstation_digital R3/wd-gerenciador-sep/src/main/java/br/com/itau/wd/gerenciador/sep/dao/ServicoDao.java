package br.com.itau.wd.gerenciador.sep.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.internal.SessionImpl;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.itau.wd.gerenciador.sep.dto.ChaveDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * Serviço DAO
 * Retorna os dados do serviço
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Repository
@Transactional
public class ServicoDao {

	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * Retorna os dados do serviço
	 * 
	 * @param codigoChaveExterna
	 * @return
	 * @throws SEPException
	 */
	public ChaveDto obterServico(String codigoChaveExterna) throws SEPException {
		
		ChaveDto chave = null;

		try {

			Connection conexao = ((SessionImpl) entityManager.getDelegate()).connection();
			chave = obterSiglaServico(conexao, codigoChaveExterna);
		} 
		catch (Exception ex) {

			throw new SEPException(ex);
		}

		return chave;		
	}
	
	/**
	 * Obtem o endpoint do microserviço
	 * 
	 * @param conexao
	 * @param codigoMicroServico
	 * @return
	 * @throws SEPException
	 */
	private ChaveDto obterSiglaServico(Connection conexao, String codigoChaveExterna) throws SEPException {

		ChaveDto chave = new ChaveDto();

		try (CallableStatement callableStatement = conexao.prepareCall("{call PRC_SEL_SERVICO(?,?)}")) {

			callableStatement.setString(1, codigoChaveExterna);
			callableStatement.registerOutParameter(2, Types.CHAR, 3);

			callableStatement.execute();

			String siglaSistemaProduto = GerenciadorUtils.convertObjectToString(callableStatement.getString(2));			

			chave.setSiglaSistemaProduto(siglaSistemaProduto);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}
		
		return chave;
	}
}