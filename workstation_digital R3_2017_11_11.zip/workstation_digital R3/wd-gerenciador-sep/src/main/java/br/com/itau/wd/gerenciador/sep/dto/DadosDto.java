package br.com.itau.wd.gerenciador.sep.dto;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.HashMap;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

public class DadosDto {

	private String descricaoServico;
	private ChaveDto chave;
	private EndpointDto endpoint;
	private Map<String, Object> dados;

	public DadosDto() {
		chave = new ChaveDto();
		endpoint = new EndpointDto();
		dados = new HashMap<>();
	}
	
	public String getDescricaoServico() {
		return descricaoServico.toLowerCase();
	}

	public void setDescricaoServico(String descricaoServico) {
		this.descricaoServico = descricaoServico;
	}

	public ChaveDto getChave() {
		return chave;
	}

	public EndpointDto getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(EndpointDto endpoint) {
		this.endpoint = endpoint;
	}
	
	public Map<String, Object> getDados() {
		return dados;
	}
	
	public void setDados(Map<String, Object> dados) {
		this.dados = dados;
	}

	public String getDadosJson() throws JsonProcessingException  {
		return GerenciadorUtils.convertMapToJson(dados);
	}

	/**
	 * Verifica se existe o serviço de negócio
	 * 
	 * @return
	 */
	public boolean isExisteServicoNegocio() {
		return !STRING_EMPTY.equals(StringUtils.trimWhitespace(endpoint.getUrlServicoNegocio()));
	}
	
	/**
	 * Verifica se o JSON contém a tag específica
	 * 
	 * @return
	 */
	public boolean isExisteTag(String key) {
		return dados.containsKey(key);
	}
}