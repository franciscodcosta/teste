package br.com.itau.wd.gerenciador.hcs.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.hcs.dao.HCSDao;
import br.com.itau.wd.gerenciador.hcs.exception.HCSException;

/**
 * HEALTH CHECKER SERVICE (HCS) Service
 * 
 * @author ITAÚ
 *
 */
@Service
public class HCSService {

	@Autowired
	HCSDao dao;
	
	/**
	 * Verifica a disponibilidade do microserviço
	 * 
	 * @param servico
	 * @return
	 * @throws HCSException 
	 */
	public boolean verificarDisponibilidade(String servico) throws HCSException {
		
		return dao.verificarDisponibilidade(servico);
	}
}