package br.com.itau.wd.gerenciador.sep.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.sap.SAPConsultaPendenciaController;
import br.com.itau.wd.gerenciador.negocio.service.sap.SAPConsultaPendenciaService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SAPConsultaPendenciaController.class, SAPConsultaPendenciaService.class})
@AutoConfigureMockMvc
public class WdGerenciadorSEPConsultarpendenciaApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SAPConsultaPendenciaService service;

	@Test
	public void verificaJsonRequisicaoSAP() throws Exception {

		String json = "{\"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"chave_produto\": \"4500013014;000004875877\", \"contador_paginas\": \"1\", \"qtd_por_pagina\": \"1\", \"token\": \"adf0948d26d85130395f731867cc3263\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRequisicaoBPM() throws Exception {

		String json = "{\"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"funcional_sistema_produto\": \"003764305\",  \"chave_produto\": \"123\", \"contador_paginas\": \"1\", \"qtd_por_pagina\": \"1\", \"token\": \"adf0948d26d85130395f731867cc3263\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaSAP() throws Exception {

		String json = "{\"uid\":\"F058E523-3E96-491F-A295-7D9701442E22\", \"total_paginas\":\"1\", \"dados\": {\"descricao\":\"teste\"}}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaBMP() throws Exception {

		String json = "{\"uid\":\"F058E523-3E96-491F-A295-7D9701442E22\", \"total_paginas\":\"1\", \"dados\": {\"descricao\":\"teste\"}}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonChamadaSAP() throws Exception {
		
		String json = "{\"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"chave_produto\": \"123\", \"total_paginas\": \"1\", \"dados\": {\"descricao\":\"teste\"}}";
		String endpoint = "http://vczx162cto.corp1.rc.itau:51500/XISOAPAdapter/MessageServlet?senderParty=&senderService=EB8&receiverParty=&receiverService=&interface=SI_Consulta_Documento_out&interfaceNamespace=http://itau.com.br/WorkstationDigital/Consulta_Documento";
		Mockito.when(service.obterJsonRespostaSap(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/sap").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).header("endpoint", endpoint).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}	
}
