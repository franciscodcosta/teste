package br.com.itau.wd.gerenciador.negocio.service.bpm;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_BPM_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_BPM_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_COMENTARIO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_MENSAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS;

import javax.annotation.Resource;
import javax.xml.rpc.holders.IntHolder;
import javax.xml.rpc.holders.StringHolder;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import AH7P001.AprovarProcuracao_tws.AprovarProcuracaoPortTypeProxy;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class BPMRegistraAcaoService {

	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		JsonObject objJsonRequisicao = new JsonObject();

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);
			
			objJsonRequisicao.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_COMENTARIO, objJson.get(JSON_KEY_COMENTARIO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_MENSAGEM, objJson.get(JSON_KEY_MENSAGEM).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_TOKEN, objJson.get(JSON_KEY_TOKEN).getAsString());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return objJsonRequisicao.toString();
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_BPM_CHAVE_PRODUTO, objJson.get(JSON_KEY_BPM_CHAVE_PRODUTO).getAsString());
		objJsonResposta.addProperty(JSON_KEY_BPM_STATUS, objJson.get(JSON_KEY_BPM_STATUS).getAsString());

		return objJsonResposta.toString();
	}
	
	/**
	 * Registrar a ação
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String registrarAcao(String json, String endpoint) throws NegocioException {
		
		String retorno = "";
		
		try {
			
			System.out.println("***** BPM *****");
			System.out.println("JSON REQUISIÇÃO = " + json);

			AprovarProcuracaoPortTypeProxy proxy = new AprovarProcuracaoPortTypeProxy();
			
			int identificadorProcuracao = Integer.parseInt(GerenciadorUtils.obterDadoJson(json, "chave_produto"));
			String textoJustificativaWorkstation = GerenciadorUtils.obterDadoJson(json, "comentario");
			String funcaoSistemaProduto = GerenciadorUtils.obterDadoJson(json, "funcao_sistema_produto");
			String mensagem = GerenciadorUtils.obterDadoJson(json, "mensagem");
			String usuarioAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU);
			String tokenAcesso = env.getRequiredProperty(PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS);
			
			System.out.println("ID PROCURACAO = " + identificadorProcuracao);
			System.out.println("TEXTO JUSTIFICATIVA = " + textoJustificativaWorkstation);
			System.out.println("FUNCAO SISTEMA PRODUTO = " + funcaoSistemaProduto);
			System.out.println("MENSAGEM = " + mensagem);
			System.out.println("USUARIO ACESSO = " + usuarioAcesso);
			System.out.println("TOKEN ACESSO = " + tokenAcesso);
			
			//no campo mensagem - funcional
			//taskID
			String[] v = mensagem.split("\\;");
			String funcionalDiretor = v[0];
			int idTarefa = Integer.parseInt(v[1]);
			System.out.println("FUNCIONAL DIRETOR = " + funcionalDiretor);
			System.out.println("ID TAREFA = " + idTarefa);
			
			String procuracaoValidada = funcaoSistemaProduto.equalsIgnoreCase("0004")?"true":"false";
			
			IntHolder codigoRetorno = new IntHolder();
			StringHolder mensagemRetorno = new StringHolder();

			proxy.setEndpoint(endpoint);
			proxy.aprovarProcuracao(identificadorProcuracao, procuracaoValidada, textoJustificativaWorkstation, funcionalDiretor, idTarefa, usuarioAcesso, tokenAcesso, codigoRetorno, mensagemRetorno);

			if (codigoRetorno.value == 0){
				retorno = "{\"status\":\"S\"}";
			} else if(codigoRetorno.value == 2){	
				retorno = "{\"status\":\"A\"}";
			} else if(codigoRetorno.value == 3){
				retorno = "{\"status\":\"R\"}";
			} else{
				System.out.println("Retorno erro BPM = " + mensagemRetorno.value);
				retorno = "{\"status\":\"E\"}";
			}
		}
		catch (HttpServerErrorException ex) {
			
			throw new NegocioException(ex.getResponseBodyAsString());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}	
}