package br.com.itau.wd.gerenciador.negocio.dto.tms;

public class Sala {

	private int id;
	private String horaInicio;
	private String horaFim;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getHoraInicio() {
		return horaInicio;
	}
	
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	
	public String getHoraFim() {
		return horaFim;
	}
	
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
}