package br.com.itau.wd.gerenciador.negocio.service.rainbow;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_ID_SOLICITACAO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_MENSAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.STATUS_ZEROS_OK;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Service;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class RainbowService {

	/**
	 * Retorna o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			Map<String, Object> dados = GerenciadorUtils.convertJsonToMap(json);

			String funcaoSistemaProduto = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
			String funcaoAtividadeSistemaProduto = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
			String chaveProduto = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_CHAVE_PRODUTO);
			String token = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_TOKEN);

			Map<String, Object> map = new HashMap<>();

			map.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, funcaoSistemaProduto);
			map.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, funcaoAtividadeSistemaProduto);
			map.put(JSON_KEY_CHAVE_PRODUTO, chaveProduto);
			map.put(JSON_KEY_TOKEN, token);
			
			obterDados(map, dados);

			retorno = GerenciadorUtils.convertMapToJson(map);
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Retorna o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, Object> dados = GerenciadorUtils.convertJsonToMap(json);

			String status = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_STATUS);
			String mensagem = GerenciadorUtils.obterDadoMap(dados, JSON_KEY_MENSAGEM);

			Map<String, Object> map = new HashMap<>();
			
			map.put(JSON_KEY_STATUS, status);
			map.put(JSON_KEY_MENSAGEM, mensagem);

			if (GerenciadorUtils.existeTagJson(json, JSON_KEY_ID_SOLICITACAO)) {

				String idSolicitacao = GerenciadorUtils.obterDadoJson(json, JSON_KEY_ID_SOLICITACAO);
				map.put(JSON_KEY_ID_SOLICITACAO, idSolicitacao);
			}

			if (GerenciadorUtils.existeTagJson(json, JSON_KEY_UID)) {

				String uid = GerenciadorUtils.obterDadoJson(json, JSON_KEY_UID);
				map.put(JSON_KEY_UID, uid);
			}

			if (GerenciadorUtils.existeTagJson(json, JSON_KEY_CHAVE_PRODUTO)) {

				String chaveProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CHAVE_PRODUTO);
				map.put(JSON_KEY_CHAVE_PRODUTO, chaveProduto);
			}

			if (STATUS_ZEROS_OK.equalsIgnoreCase(status)) {

				//Verifica se possui dados a serem enviados
				if (GerenciadorUtils.existeTagJson(json, JSON_KEY_DADOS)) {

					map.put(JSON_KEY_DADOS, dados.get(JSON_KEY_DADOS));
				}
			}

			retorno = GerenciadorUtils.convertMapToJson(map);
		} 
		catch (Exception ex) {
	
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	@SuppressWarnings("unchecked")
	private void obterDados(Map<String, Object> map, Map<String, Object> dados) {

		if (dados.get(JSON_KEY_DADOS) != null) {
			Map<String, Object> mapDados = (Map<String, Object>) dados.get(JSON_KEY_DADOS);
	
			for (Entry<String, Object> entryDados : mapDados.entrySet()) {
				map.put(entryDados.getKey(), entryDados.getValue());
			}
		}
	}
}