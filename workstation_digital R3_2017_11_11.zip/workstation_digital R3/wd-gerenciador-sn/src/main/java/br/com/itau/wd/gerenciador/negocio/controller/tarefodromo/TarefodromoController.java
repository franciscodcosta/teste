package br.com.itau.wd.gerenciador.negocio.controller.tarefodromo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.tarefodromo.TarefodromoService;

@RestController
@RequestMapping(value="/tarefodromo")
public class TarefodromoController {

	@Autowired
	TarefodromoService service;

	/**
	 * Retorna o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException
	 */
	@RequestMapping(value="/requisicao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonRequisicao(@RequestBody String json) throws NegocioException {

		return service.obterJsonRequisicao(json);
	}

	/**
	 * Retorna o JSON da resposta
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException
	 */
	@RequestMapping(value="/resposta", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonResposta(@RequestBody String json) throws NegocioException {

		return service.obterJsonResposta(json);
	}

	/**
	 * Consulta Pendência
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/mainframe", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String consultaPendencia(@RequestBody String json) throws NegocioException {
		
		return service.consultaPendencia(json);
	}
}