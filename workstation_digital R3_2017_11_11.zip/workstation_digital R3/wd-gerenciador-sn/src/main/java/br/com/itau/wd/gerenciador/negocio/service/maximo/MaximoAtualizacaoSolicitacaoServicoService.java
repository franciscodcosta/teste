package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_MAXIMO_SR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLIENTVIEWABLE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CREATEBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCUMENTDATA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ANEXOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_LOGS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_TICKETS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LOGTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETUID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_URLTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRATUALIZACombinedKeySetTypeSR;
import com.ibm.www.maximo.ITAUWDSRATUALIZA_DOCLINKSType;
import com.ibm.www.maximo.ITAUWDSRATUALIZA_SRType;
import com.ibm.www.maximo.ITAUWDSRATUALIZA_WORKLOGType;
import com.ibm.www.maximo.MXBinaryType;
import com.ibm.www.maximo.MXBooleanType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.SyncITAUWDSRATUALIZAResponseType;
import com.ibm.www.maximo.SyncITAUWDSRATUALIZAType;
import com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZAPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA.ITAUWDSRATUALIZASOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Atualizar Solicitação de Serviço
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoAtualizacaoSolicitacaoServicoService {
	
	private static final Logger logger = LoggerFactory.getLogger(MaximoAtualizacaoSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Atualiza a solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String atualizarSolicitacaoServico(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - ATUALIZA SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			SyncITAUWDSRATUALIZAType objeto = obterObjeto(json);
			
			//Envia os dados
			SyncITAUWDSRATUALIZAResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - ATUALIZA SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private SyncITAUWDSRATUALIZAType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String TICKETID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);
		String STATUS = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_STATUS);

		ITAUWDSRATUALIZA_SRType SRType = new ITAUWDSRATUALIZA_SRType();

		MXDomainType CLASS = new MXDomainType();
		CLASS.set_value(CONSTANTE_MAXIMO_SR);
		CLASS.setMaxvalue(CONSTANTE_MAXIMO_SR);

		SRType.setCLASS(CLASS);
		SRType.setTICKETID(new MXStringType(TICKETID));
		SRType.setSTATUS(new MXDomainType(STATUS));

		// Anexos
		JsonArray objJsonArrayAnexos = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_ANEXOS);
		
		ITAUWDSRATUALIZA_DOCLINKSType[] DOCLINKSType = new ITAUWDSRATUALIZA_DOCLINKSType[objJsonArrayAnexos.size()];

		for (int i = 0; i < objJsonArrayAnexos.size(); i++) {

			JsonObject objJsonAnexo = (JsonObject)objJsonArrayAnexos.get(i);

			String DOCTYPE = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_DOCTYPE);
			String URLTYPE = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_URLTYPE);
			String DOCUMENTDATA = NegocioUtils.obterDadoJson(objJsonAnexo, JSON_KEY_MAXIMO_DOCUMENTDATA);

			DOCLINKSType[i] = new ITAUWDSRATUALIZA_DOCLINKSType();

			DOCLINKSType[i].setDOCTYPE(new MXStringType(DOCTYPE));
			DOCLINKSType[i].setURLTYPE(new MXStringType(URLTYPE));
			DOCLINKSType[i].setDOCUMENTDATA(new MXBinaryType(DOCUMENTDATA));
		}

		SRType.setDOCLINKS(DOCLINKSType);

		//Logs
		JsonArray objJsonArrayLogs = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_LOGS);

		ITAUWDSRATUALIZA_WORKLOGType[] WORKLOGType = new ITAUWDSRATUALIZA_WORKLOGType[objJsonArrayLogs.size()];

		for (int i = 0; i < objJsonArrayLogs.size(); i++) {

			JsonObject objJsonLog = (JsonObject)objJsonArrayLogs.get(i);

			String DESCRIPTION = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_DESCRIPTION);
			String DESCRIPTION_LONGDESCRIPTION = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION);
			String LOGTYPE = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_LOGTYPE);
			String CLIENTVIEWABLE = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_CLIENTVIEWABLE);
			String CREATEBY = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_CREATEBY);
			
			WORKLOGType[i] = new ITAUWDSRATUALIZA_WORKLOGType();

			WORKLOGType[i].setDESCRIPTION(new MXStringType(DESCRIPTION));
			WORKLOGType[i].setDESCRIPTION_LONGDESCRIPTION(new MXStringType(DESCRIPTION_LONGDESCRIPTION));
			WORKLOGType[i].setLOGTYPE(new MXDomainType(LOGTYPE));
			WORKLOGType[i].setCLIENTVIEWABLE(new MXBooleanType(NegocioUtils.converterBoolean(CLIENTVIEWABLE)));
			WORKLOGType[i].setCREATEBY(new MXStringType(CREATEBY));
		}

		SRType.setWORKLOG(WORKLOGType);

		SyncITAUWDSRATUALIZAType objeto = new SyncITAUWDSRATUALIZAType();
		objeto.setITAUWDSRATUALIZASet(new ITAUWDSRATUALIZA_SRType[] {SRType});

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(SyncITAUWDSRATUALIZAResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		ITAUWDSRATUALIZACombinedKeySetTypeSR[] combinedKeySetTypeSr = resposta.getITAUWDSRATUALIZASet();
		
		JsonArray objJsonArrayTickets = new JsonArray();
		
		for (ITAUWDSRATUALIZACombinedKeySetTypeSR CombinedKeySetTypeSR : combinedKeySetTypeSr) {

			MXStringType TICKETID = CombinedKeySetTypeSR.getTICKETID();
			MXLongType TICKETUID = CombinedKeySetTypeSR.getTICKETUID();
			
			JsonObject objJsonTicket = new JsonObject();
			
			objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETID, NegocioUtils.converterObjetoParaString(TICKETID));
			objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETUID, NegocioUtils.converterObjetoParaString(TICKETUID));
			
			objJsonArrayTickets.add(objJsonTicket);
		}

		objJsonDados.add(JSON_KEY_MAXIMO_LISTA_TICKETS, objJsonArrayTickets);
		
		objJsonRet.add(JSON_KEY_CHAVE_PRODUTO, objJsonDados);

		return objJsonRet.toString();
	}

	/**
	 * Enviar os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private SyncITAUWDSRATUALIZAResponseType enviarDados(SyncITAUWDSRATUALIZAType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDSRATUALIZAPortTypeProxy proxy = new ITAUWDSRATUALIZAPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDSRATUALIZASOAP11BindingStub)proxy.getITAUWDSRATUALIZAPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRATUALIZASOAP11BindingStub)proxy.getITAUWDSRATUALIZAPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		//Envia os dados
		return proxy.syncITAUWDSRATUALIZA(objeto);
	}
}