package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLIENTVIEWABLE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CREATEBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_NUMERO_MUDANCA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LOGTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDWOAPROVA_WOCHANGEType;
import com.ibm.www.maximo.ITAUWDWOAPROVA_WORKLOGType;
import com.ibm.www.maximo.MXBooleanType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.SyncITAUWDWOAPROVAResponseType;
import com.ibm.www.maximo.SyncITAUWDWOAPROVAType;
import com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVAPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVASOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Aprovar Mudanças 
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoAprovacaoMudancasService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoAprovacaoMudancasService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Aprova mudanças
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String aprovarMudancas(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - APROVA GMUD - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Converte o JSON para o objeto de entrada
			SyncITAUWDWOAPROVAType objeto = obterObjeto(json);
			
			//Envia os dados
			SyncITAUWDWOAPROVAResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - APROVA GMUD - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private SyncITAUWDWOAPROVAType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String WONUM = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_GMUD_NUMERO_MUDANCA);
		String STATUS = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_GMUD_STATUS);

		ITAUWDWOAPROVA_WOCHANGEType WOCHANGEType = new ITAUWDWOAPROVA_WOCHANGEType();

		WOCHANGEType.setWONUM(new MXStringType(WONUM));
		WOCHANGEType.setSTATUS(new MXDomainType(STATUS));

		//Log
		ITAUWDWOAPROVA_WORKLOGType[] WORKLOGType = new ITAUWDWOAPROVA_WORKLOGType[1];

		String DESCRIPTION = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_DESCRIPTION);
		String DESCRIPTION_LONGDESCRIPTION = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION);
		String LOGTYPE = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_LOGTYPE);
		String CLIENTVIEWABLE = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_CLIENTVIEWABLE);
		String CREATEBY = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_CREATEBY);

		WORKLOGType[0] = new ITAUWDWOAPROVA_WORKLOGType();

		WORKLOGType[0].setDESCRIPTION(new MXStringType(DESCRIPTION));
		WORKLOGType[0].setDESCRIPTION_LONGDESCRIPTION(new MXStringType(DESCRIPTION_LONGDESCRIPTION));
		WORKLOGType[0].setLOGTYPE(new MXDomainType(LOGTYPE));
		WORKLOGType[0].setCLIENTVIEWABLE(new MXBooleanType(NegocioUtils.converterBoolean(CLIENTVIEWABLE)));
		WORKLOGType[0].setCREATEBY(new MXStringType(CREATEBY));

		WOCHANGEType.setWORKLOG(WORKLOGType);

		SyncITAUWDWOAPROVAType objeto = new SyncITAUWDWOAPROVAType();
		objeto.setITAUWDWOAPROVASet(new ITAUWDWOAPROVA_WOCHANGEType[] {WOCHANGEType});

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(SyncITAUWDWOAPROVAResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private SyncITAUWDWOAPROVAResponseType enviarDados(SyncITAUWDWOAPROVAType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDWOAPROVAPortTypeProxy proxy = new ITAUWDWOAPROVAPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDWOAPROVASOAP11BindingStub)proxy.getITAUWDWOAPROVAPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDWOAPROVASOAP11BindingStub)proxy.getITAUWDWOAPROVAPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		//Envia os dados
		return proxy.syncITAUWDWOAPROVA(objeto);
	}
}