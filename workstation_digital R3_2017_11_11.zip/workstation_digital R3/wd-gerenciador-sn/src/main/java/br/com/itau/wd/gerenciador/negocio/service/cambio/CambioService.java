package br.com.itau.wd.gerenciador.negocio.service.cambio;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_CAMBIO_CONTEXTOCANAL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_AGENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_CHAVE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_CODIGOCANAL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_CODRET;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_COLABORADOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_CONTA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_DADOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_FREQUENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_FUNCIONAL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_HEADER;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_INDALTGNI;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_INDFUNC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_MSGRET;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_PANICO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_RAMOATIV;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SEGMENTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SPI;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SPREADFIN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SPREADHIS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SPREADMAX;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SPREADMIN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_SQLCODE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_STATUSIS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_CAMBIO_VALOR;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_CANAL;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL;

import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class CambioService {

	/**
	 * Monta o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 * @throws Exception 
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		JsonObject objJsonRequisicao = new JsonObject();

		try {

			String funcional = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCIONAL);
			String codigoCanal = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CODIGO_CANAL);

			JsonObject objJsonHeader = new JsonObject();
			
			//Chave
			objJsonHeader.addProperty(JSON_KEY_CAMBIO_CHAVE, CONSTANTE_CAMBIO_CONTEXTOCANAL);
			
			//Valor
			JsonObject objJsonCanal = new JsonObject();
			objJsonCanal.addProperty(JSON_KEY_CAMBIO_CODIGOCANAL, codigoCanal);
			
			objJsonHeader.add(JSON_KEY_CAMBIO_VALOR, objJsonCanal);

			JsonArray objJsonArrayHeader = new JsonArray();
			objJsonArrayHeader.add(objJsonHeader);
			
			objJsonRequisicao.add(JSON_KEY_CAMBIO_HEADER, objJsonArrayHeader);
			objJsonRequisicao.addProperty(JSON_KEY_CAMBIO_FUNCIONAL, funcional);
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return objJsonRequisicao.toString();
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJsonResposta = new JsonObject();
		JsonElement objJsonElement = new JsonParser().parse(json);

		if (objJsonElement.isJsonObject()) {
		
			JsonObject objJson = objJsonElement.getAsJsonObject();

			JsonObject objJsonDados = new JsonObject();

			objJsonDados.addProperty(JSON_KEY_CAMBIO_CODRET, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_CODRET));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SQLCODE, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SQLCODE));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_MSGRET, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_MSGRET));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SEGMENTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SEGMENTO));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_RAMOATIV, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_RAMOATIV));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_COLABORADOR, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_COLABORADOR));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SPI, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SPI));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_FREQUENCIA, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_FREQUENCIA));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_AGENCIA, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_AGENCIA));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_CONTA, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_CONTA));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_PANICO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_PANICO));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SPREADHIS, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SPREADHIS));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SPREADFIN, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SPREADFIN));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SPREADMAX, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SPREADMAX));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_SPREADMIN, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_SPREADMIN));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_INDALTGNI, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_INDALTGNI));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_INDFUNC, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_INDFUNC));
			objJsonDados.addProperty(JSON_KEY_CAMBIO_STATUSIS, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CAMBIO_STATUSIS));		

			objJsonResposta.addProperty(JSON_KEY_CAMBIO_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_FUNCIONAL));
			objJsonResposta.add(JSON_KEY_CAMBIO_DADOS, objJsonDados);
		}

		return objJsonResposta.toString();
	}
}