package br.com.itau.wd.gerenciador.negocio.service.bpm;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_SIGLA_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import javax.annotation.Resource;

import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Enviar dados de notificação de uma dada pendência para atuação de um usuário no salesforce
 * 
 * @author Itaú
 *
 */
@Service
public class BPMNotificacaoService {

	@Resource
	private Environment env;
	
	/**
	 * Monta o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException 
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonRequisicao = new JsonObject();

			objJsonRequisicao.addProperty(JSON_KEY_UID, NegocioUtils.obterDadoJson(objJson, JSON_KEY_UID));
			objJsonRequisicao.addProperty(JSON_KEY_SIGLA_SISTEMA_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_SIGLA_SISTEMA_PRODUTO));
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_FUNCAO_SISTEMA_PRODUTO));
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO));
			objJsonRequisicao.addProperty(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO));

			retorno = objJsonRequisicao.toString();
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return retorno;
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonResposta = new JsonObject();

			objJsonResposta.addProperty(JSON_KEY_UID, NegocioUtils.obterDadoJson(objJson, JSON_KEY_UID));
			objJsonResposta.addProperty(JSON_KEY_STATUS, NegocioUtils.obterDadoJson(objJson, JSON_KEY_STATUS));

			retorno = objJsonResposta.toString();
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}
}