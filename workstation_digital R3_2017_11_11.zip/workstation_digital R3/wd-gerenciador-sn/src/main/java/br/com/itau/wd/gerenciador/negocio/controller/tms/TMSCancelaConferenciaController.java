package br.com.itau.wd.gerenciador.negocio.controller.tms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.tms.TMSCancelaConferenciaService;

@RestController
@RequestMapping(value="/tms/cancela/conferencia") 
public class TMSCancelaConferenciaController {

	/**
	 * TMS Controller
	 * 
	 * @author ITAÚ
	 *
	 */
	@Autowired
	private TMSCancelaConferenciaService service;

	/**
	 * Retorna o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	@RequestMapping(value="/requisicao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonRequisicao(@RequestBody String json) throws NegocioException {

		return service.obterJsonRequisicao(json);
	}

	/**
	 * Retorna o JSON da resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/resposta", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonResposta(@RequestBody String json) throws NegocioException {

		return service.obterJsonResposta(json);
	}
	
	/**
	 * Cancela a conferência 
	 *
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/cancela/conferencia", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String cancelarConferencia(@RequestBody String json, @RequestHeader(value="endpoint") String endpoint) throws NegocioException {

		return service.cancelarConferencia(json, endpoint);
	}
}