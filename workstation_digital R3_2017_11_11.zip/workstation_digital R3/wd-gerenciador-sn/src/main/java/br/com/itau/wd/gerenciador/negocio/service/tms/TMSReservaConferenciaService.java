package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DADOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DATA_REUNIAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_FIM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_INICIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_LINK;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_MENSAGEM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_PIN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_RECORRENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_REUNIAO_RECORRENTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_SENHA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_USER;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.dto.tms.ConferenciaEntrada;
import br.com.itau.wd.gerenciador.negocio.dto.tms.ConferenciaSaida;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapStub;
import net.tandberg._2004._02.tms.external.booking.Conference;
import net.tandberg._2004._02.tms.external.booking.ConferenceStatus;
import net.tandberg._2004._02.tms.external.booking.ConferenceType;

@Service
public class TMSReservaConferenciaService {

	private static final Logger logger = LoggerFactory.getLogger(TMSReservaConferenciaService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, objJson.get(JSON_KEY_TMS_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_TMS_DADOS, objJson.get(JSON_KEY_TMS_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Reserva conferência
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String reservarConferencia(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - RESERVA CONFERENCIA *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Obter objeto
			ConferenciaEntrada conferenciaEntrada = obterObjeto(json);
			
			//Envia os dados
			ConferenciaSaida conferenciaSaida = enviarDados(conferenciaEntrada, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(conferenciaSaida, json);

		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obter o objeto
	 * 
	 * @param json
	 * @return
	 */
	private ConferenciaEntrada obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String dataReuniao = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_DATA_REUNIAO);
		String reuniaoRecorrente = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_REUNIAO_RECORRENTE);
		String recorrencia = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_RECORRENCIA);
		String horaInicio = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_INICIO);
		String horaFim = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_FIM);

		ConferenciaEntrada conferencia = new ConferenciaEntrada();

		conferencia.setDataReuniao(dataReuniao);
		conferencia.setReuniaoRecorrente(reuniaoRecorrente);
		conferencia.setRecorrencia(recorrencia);
		conferencia.setHoraInicio(horaInicio);
		conferencia.setHoraFim(horaFim);

		return conferencia;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(ConferenciaSaida resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, STRING_EMPTY);

		objJsonRet.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		objJsonDados.addProperty(JSON_KEY_TMS_LINK, resposta.getLink());
		objJsonDados.addProperty(JSON_KEY_TMS_PIN, resposta.getPin());
		objJsonDados.addProperty(JSON_KEY_TMS_SENHA, resposta.getSenha());
		objJsonDados.addProperty(JSON_KEY_TMS_STATUS, resposta.getStatus());
		objJsonDados.addProperty(JSON_KEY_TMS_MENSAGEM, resposta.getMensagem());

		objJsonRet.add(JSON_KEY_TMS_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private ConferenciaSaida enviarDados(ConferenciaEntrada conferencia, String endpoint) throws RemoteException {
	
		ConferenciaSaida resposta = new ConferenciaSaida();

		//Configura o Proxy
		BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();

		String userName = "";
		Calendar startTime = null;
		Calendar endTime = null;
		ConferenceStatus conferenceStatus = ConferenceStatus.All;

		proxy.setEndpoint(endpoint);
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));

		Conference conference = proxy.getDefaultConference();

		//conference.setExternalPrimaryKey("x");
		conference.setStartTimeUTC(conferencia.getHoraInicio());
		conference.setEndTimeUTC(conferencia.getHoraFim());
		conference.setConferenceType(ConferenceType.fromString("Reservation Only"));
		
		//Envia os dados
		conference = proxy.saveConference(conference);
		
		String senha = conference.getPassword();
		String link = conference.getWebConferenceAttendeeUri();
		int pin = conference.getConferenceId();
		
		return resposta;
	}	
}