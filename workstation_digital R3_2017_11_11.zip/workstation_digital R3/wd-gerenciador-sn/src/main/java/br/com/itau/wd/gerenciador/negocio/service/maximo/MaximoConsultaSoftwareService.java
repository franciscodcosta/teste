package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_MAXIMO_SOFTWARE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_SOFTWARE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_CORPORATIVO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_DESCRICAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_ITAU;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWREDE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWSISTEMAID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_LICENCIADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_RESTRITO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_SOFTWARE_TIPO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDLISTSWQueryType;
import com.ibm.www.maximo.ITAUWDLISTSWQueryTypeITAU_SWSISTEMA;
import com.ibm.www.maximo.ITAUWDLISTSW_ITAU_SWSISTEMAType;
import com.ibm.www.maximo.MXBooleanType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDLISTSWResponseType;
import com.ibm.www.maximo.QueryITAUWDLISTSWType;
import com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDLISTSW.ITAUWDLISTSWSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Software
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaSoftwareService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaSoftwareService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar Software
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarSoftware(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA SOFTWARE - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDLISTSWType objeto = obterObjeto(json);
			
			//Enviar os dados
			QueryITAUWDLISTSWResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA SOFTWARE - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDLISTSWType obterObjeto(String json) {
		
		ITAUWDLISTSWQueryTypeITAU_SWSISTEMA swSistema = new ITAUWDLISTSWQueryTypeITAU_SWSISTEMA();
		swSistema.setTIPO(new MXStringQueryType[] {new MXStringQueryType(CONSTANTE_MAXIMO_SOFTWARE)});

		ITAUWDLISTSWQueryType QueryType = new ITAUWDLISTSWQueryType();
		QueryType.setITAU_SWSISTEMA(swSistema);

		QueryITAUWDLISTSWType objeto = new QueryITAUWDLISTSWType();
		objeto.setITAUWDLISTSWQuery(QueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDLISTSWResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		JsonObject objJsonDados = new JsonObject();

		if (resposta.getITAUWDLISTSWSet().length > 0) {

			JsonArray objJsonArraySoftware = new JsonArray(); 
			
			for (ITAUWDLISTSW_ITAU_SWSISTEMAType SWSISTEMAType : resposta.getITAUWDLISTSWSet()) {

				MXBooleanType CORPORATIVO = SWSISTEMAType.getCORPORATIVO();
				MXStringType DESCRIPTION = SWSISTEMAType.getDESCRIPTION();
				MXBooleanType ITAU = SWSISTEMAType.getITAU();
				MXBooleanType ITAU_SWREDE = SWSISTEMAType.getITAU_SWREDE();
				MXLongType ITAU_SWSISTEMAID = SWSISTEMAType.getITAU_SWSISTEMAID();
				MXBooleanType LICENCIADO = SWSISTEMAType.getLICENCIADO();
				MXBooleanType RESTRITO = SWSISTEMAType.getRESTRITO();
				MXStringType TIPO = SWSISTEMAType.getTIPO();			

				JsonObject objJsonSoftware = new JsonObject(); 

				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_CORPORATIVO, NegocioUtils.converterObjetoParaString(CORPORATIVO));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_DESCRICAO, NegocioUtils.converterObjetoParaString(DESCRIPTION));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_ITAU, NegocioUtils.converterObjetoParaString(ITAU));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWREDE, NegocioUtils.converterObjetoParaString(ITAU_SWREDE));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWSISTEMAID, NegocioUtils.converterObjetoParaString(ITAU_SWSISTEMAID));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_LICENCIADO, NegocioUtils.converterObjetoParaString(LICENCIADO));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_RESTRITO, NegocioUtils.converterObjetoParaString(RESTRITO));
				objJsonSoftware.addProperty(JSON_KEY_MAXIMO_SOFTWARE_TIPO, NegocioUtils.converterObjetoParaString(TIPO));

				objJsonArraySoftware.add(objJsonSoftware);
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_SOFTWARE, objJsonArraySoftware);
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_MAXIMO_CODIGO_RETORNO, STRING_EMPTY);
			objJsonDados.addProperty(JSON_KEY_MAXIMO_DESCRICAO_RETORNO, STRING_EMPTY);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Enviar os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDLISTSWResponseType enviarDados(QueryITAUWDLISTSWType objeto, String endpoint) throws RemoteException { 
	
		//Configura o Proxy
		ITAUWDLISTSWPortTypeProxy proxy = new ITAUWDLISTSWPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDLISTSWSOAP11BindingStub)proxy.getITAUWDLISTSWPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDLISTSWSOAP11BindingStub)proxy.getITAUWDLISTSWPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDLISTSW(objeto);
	}	
}