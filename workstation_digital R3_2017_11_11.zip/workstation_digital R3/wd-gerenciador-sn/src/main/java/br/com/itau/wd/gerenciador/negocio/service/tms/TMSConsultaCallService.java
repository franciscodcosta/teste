package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DADOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DATA_REUNIAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_FIM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_INICIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_QTDE_HORAS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_QTDE_PESSOAS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_RECORRENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_REUNIAO_RECORRENTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_USER;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;
import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.dto.tms.ConferenciaEntrada;
import br.com.itau.wd.gerenciador.negocio.dto.tms.ConferenciaSaida;
import br.com.itau.wd.gerenciador.negocio.dto.tms.Sala;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapStub;
import net.tandberg._2004._02.tms.external.booking.Conference;
import net.tandberg._2004._02.tms.external.booking.ConferenceStatus;
import net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoapStub;
import net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem;

@Service
public class TMSConsultaCallService {

	private static final Logger logger = LoggerFactory.getLogger(TMSConsultaCallService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, objJson.get(JSON_KEY_TMS_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_TMS_DADOS, objJson.get(JSON_KEY_TMS_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Consulta Call
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarCall(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - CONSULTA CALL *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Obter objeto
			ConferenciaEntrada conferenciaEntrada = obterObjeto(json);
			
			//Envia os dados
			ConferenciaSaida conferenciaSaida = enviarDados(conferenciaEntrada, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(conferenciaSaida, json);
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obter o objeto
	 * 
	 * @param json
	 * @return
	 */
	private ConferenciaEntrada obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String dataReuniao = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_DATA_REUNIAO);
		String reuniaoRecorrente = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_REUNIAO_RECORRENTE);
		String recorrencia = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_RECORRENCIA);
		String qtdeHoras = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_QTDE_HORAS);
		String qtdePessoas = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_QTDE_PESSOAS);

		ConferenciaEntrada conferencia = new ConferenciaEntrada();

		conferencia.setDataReuniao(dataReuniao);
		conferencia.setReuniaoRecorrente(reuniaoRecorrente);
		conferencia.setRecorrencia(recorrencia);
		conferencia.setQtdeHoras(qtdeHoras);
		conferencia.setQtdePessoas(qtdePessoas);

		return conferencia;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(ConferenciaSaida resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, STRING_EMPTY);

		objJsonRet.addProperty(JSON_KEY_TMS_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		JsonArray objJsonArraySala = new JsonArray();
		
		for (Sala sala : resposta.getSalas()) {

			JsonObject objJsonSala = new JsonObject();
			
			objJsonSala.addProperty(JSON_KEY_TMS_HORA_INICIO, sala.getHoraInicio());
			objJsonSala.addProperty(JSON_KEY_TMS_HORA_FIM, sala.getHoraFim());
			
			objJsonArraySala.add(objJsonSala);
		}

		objJsonDados.add("salas", objJsonArraySala);
		
		objJsonRet.add(JSON_KEY_TMS_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private ConferenciaSaida enviarDados(ConferenciaEntrada conferencia, String endpoint) throws RemoteException {
	
		ConferenciaSaida resposta = new ConferenciaSaida();

		TMSSystem[] salasTMS = TMSGetSystems();
		
		//Configura o Proxy
		BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();		
				
		proxy.setEndpoint(endpoint);
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));

		int[] systemIds = getSystemsId(salasTMS);
		Calendar startTime = Calendar.getInstance();
		Calendar endTime = Calendar.getInstance();
		
		Conference[] conference = proxy.getConferencesForSystems(systemIds, startTime, endTime, ConferenceStatus.Pending);

		for (Conference conf : conference) {
			
			Sala sala = new Sala();
			
			sala.setId(conf.getConferenceId());
			sala.setHoraInicio(conf.getStartTimeUTC());
			sala.setHoraFim(conf.getEndTimeUTC());
			
			resposta.getSalas().add(sala);
		}
		
		return resposta;
	}

    private TMSSystem[] TMSGetSystems() throws RemoteException {
        
        RemoteSetupServiceSoapProxy proxy = new RemoteSetupServiceSoapProxy();
        
		proxy.setEndpoint("");
		((RemoteSetupServiceSoapStub)proxy.getRemoteSetupServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
		((RemoteSetupServiceSoapStub)proxy.getRemoteSetupServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));
        
		return proxy.getSystems();
    }
    
    /**
     * 
     * @param tms
     * @return
     */
    private int[] getSystemsId(TMSSystem[] tms) {
    	
    	int[] ids = new int[tms.length];
    	
    	for (int i = 0; i < tms.length; i++) {
    		ids[i] = (int)tms[i].getSystemId();
    	}

    	return ids;
    }
}