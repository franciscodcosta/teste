package br.com.itau.wd.gerenciador.wam.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WdGerenciadorWamApplication {

	public static void main(String[] args) {
		SpringApplication.run(WdGerenciadorWamApplication.class, args);
	}
}
