package br.com.itau.util;

public class Constants {

	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_CLIENT_ID = "hibernate.connection.client_id";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_TOKEN = "hibernate.connection.token";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_DATASOURCE = "hibernate.connection.datasource";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_USERNAME = "hibernate.connection.username";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_PASSWORD = "hibernate.connection.password";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_DRIVER_CLASS = "hibernate.connection.driver_class";
	public static final String PROPERTY_NAME_HIBERNATE_CONNECTION_URL = "hibernate.connection.url";
	
	public Constants() {}
}
