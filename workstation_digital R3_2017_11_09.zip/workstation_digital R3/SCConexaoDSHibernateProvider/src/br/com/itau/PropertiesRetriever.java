package br.com.itau;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesRetriever {

	private static final String PATH = "/";
	private Properties properties = new Properties();
	
	public PropertiesRetriever() throws IOException
	{
		String file = "db.properties";
		InputStream stream = getClass().getResourceAsStream(PATH + file);
		properties.load(stream);
	}

	/**
	 * Recupera uma propriedade do arquivo .properties indicado no construtor.
	 * 
	 * @param key
	 *            A chave da propriedade no arquivo .properties.
	 * @return O valor da propriedade.
	 */
	public String getProperty(String key)
	{
		return properties.getProperty(key);
	}
}
