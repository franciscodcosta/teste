/**
 * ResumoProcuracaoWorkstationHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package AH7P001.ConsultarProcuracao_tws.holders;

public final class ResumoProcuracaoWorkstationHolder implements javax.xml.rpc.holders.Holder {
    public AH7P001.ConsultarProcuracao_tws.ResumoProcuracaoWorkstation value;

    public ResumoProcuracaoWorkstationHolder() {
    }

    public ResumoProcuracaoWorkstationHolder(AH7P001.ConsultarProcuracao_tws.ResumoProcuracaoWorkstation value) {
        this.value = value;
    }

}
