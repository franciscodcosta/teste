/**
 * AprovarProcuracaoPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package AH7P001.AprovarProcuracao_tws;

public interface AprovarProcuracaoPortType extends java.rmi.Remote {
    public void aprovarProcuracao(int identificadorProcuracao, java.lang.String procuracaoValidada, java.lang.String textoJustificativaWorkstation, java.lang.String funcionalDiretor, int idTarefa, java.lang.String usuarioAcesso, java.lang.String tokenAcesso, javax.xml.rpc.holders.IntHolder codigoRetorno, javax.xml.rpc.holders.StringHolder mensagemRetorno) throws java.rmi.RemoteException;
}
