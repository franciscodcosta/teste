/**
 * BookingServiceSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public interface BookingServiceSoap extends java.rmi.Remote {

    /**
     * Creates a default conference object based on the conference
     * settings specified in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getDefaultConference() throws java.rmi.RemoteException;

    /**
     * Returns all conferences for a list of systems between two dates.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForSystems(int[] systemIds, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException;

    /**
     * Returns all conferences owned by a particular user between
     * two dates.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForUser(java.lang.String userName, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException;

    /**
     * Gets the available information about a particular conference.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceById(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Returns a Conference object with the given ConferenceId. If
     * the conference is a recurrent conference, existing exceptions to the
     * recurrent series are returned in the RecurrencePattern Exceptions
     * array of the returned Conference object.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceById(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Returns a Conference object with the given ConferenceId. If
     * the conference is a recurrent conference, existing exceptions to the
     * recurrent series are returned in the RecurrencePattern Exceptions
     * array of the returned Conference object. The start time of the conference
     * will be mapped to the first ongoing or pending conference instance.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Looks up a conference that has been updated in the external
     * source, and that must be updated in Cisco TMS.
     */
    public int getConferenceIdByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException;

    /**
     * Gets the conference with the given ExternalSourceId and ExternalConferenceId.
     * If the conference is a recurrent conference, existing exceptions to
     * the recurrent series are returned in the RecurrencePattern Exceptions
     * array of the returned Conference object.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException;

    /**
     * Gets the conference instance with the given ExternalSourceId,
     * ExternalConferenceId and RecurrenceIdUTC.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getConferenceInstanceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException;

    /**
     * Saves a conference in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException;

    /**
     * Saves a conference in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference saveConference(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException;

    /**
     * Saves a list of conferences to Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference[] saveConferences(net.tandberg._2004._02.tms.external.booking.Conference[] conferences, boolean oneTransaction) throws java.rmi.RemoteException;

    /**
     * Saves an instance of a recurring conference in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.Conference saveConferenceRecInstance(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException;

    /**
     * Saves an instance of a recurring conference in Cisco TMS.
     */
    public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceRecInstanceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException;

    /**
     * Ends an ongoing conference with the given ConferenceId.
     */
    public void endConferenceById(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Ends an ongoing conference with the given ConferenceId.
     */
    public void endConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException;

    /**
     * Deletes a conference with the given ConferenceId.
     */
    public void deleteConferenceById(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Deletes an occurrence of a recurring conference with the given
     * ConferenceId.
     */
    public void deleteConferenceRecInstanceById(int conferenceId) throws java.rmi.RemoteException;

    /**
     * Deletes the conference with the given ExternalSourceId and
     * ExternalConferenceId.
     */
    public void deleteConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException;

    /**
     * Deletes the instance of a recurring conference with the given
     * ExternalSourceId, ExternalConferenceId and RecurrenceIdUTC.
     */
    public void deleteConferenceInstanceByExternaId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException;

    /**
     * Gets a list of conference create, update and delete operations
     * that must be performed in order to keep a mirrored conference database
     * synchronized.
     */
    public net.tandberg._2004._02.tms.external.booking.Transaction[] getTransactionsSince(int currentTransactionId) throws java.rmi.RemoteException;

    /**
     * Gets a list of conference create, update and delete operations
     * that must be performed in order to keep a mirrored conference database
     * synchronized.
     */
    public net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[] getTransactionsSinceWithExternalId(long currentTransactionId) throws java.rmi.RemoteException;

    /**
     * Returns recording alias information for a specific user.
     */
    public net.tandberg._2004._02.tms.external.booking.RecordingDevice[] getRecordingAliases(java.lang.String userName) throws java.rmi.RemoteException;

    /**
     * Returns a list of conference invitation email contents. A blank
     * Language will return the conference language.
     */
    public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceInviteMail(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC, net.tandberg._2004._02.tms.external.booking.TypedMailMessage[] messages, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException;

    /**
     * Returns a list of conference booking event email contents.
     * A blank Language will return the conference language. Used to retrieve
     * content for email notifications on booking events; not invites, typically
     * errors or warnings.
     */
    public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceBookingEventMail(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.TypedMailMessage message, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException;

    /**
     * Returns the configuration of a WebEx site.
     */
    public net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults getWebExSiteDefaults(java.lang.String siteUrl) throws java.rmi.RemoteException;

    /**
     * Get the available time zone rules for the given time zone.
     */
    public net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] getTimeZoneRulesById(java.lang.String idString) throws java.rmi.RemoteException;
}
