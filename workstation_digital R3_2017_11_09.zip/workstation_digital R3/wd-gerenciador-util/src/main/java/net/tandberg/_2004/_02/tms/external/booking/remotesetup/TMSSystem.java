/**
 * TMSSystem.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking.remotesetup;

public class TMSSystem  implements java.io.Serializable {
    private long systemId;

    private java.lang.String systemName;

    private java.lang.String contact;

    private java.lang.String manufacturer;

    private java.lang.String description;

    private java.lang.String systemType;

    private java.lang.String networkAddress;

    private java.lang.String location;

    private java.lang.String ISDNNumber;

    private java.lang.String QNumber;

    private java.lang.String webInterfaceURL;

    private java.lang.String SIPUri;

    private java.lang.String h323Id;

    private java.lang.String e164Alias;

    private net.tandberg._2004._02.tms.external.booking.remotesetup.TimeZone timeZone;

    private net.tandberg._2004._02.tms.external.booking.remotesetup.SystemCategoryOverride systemCategory;

    private net.tandberg._2004._02.tms.external.booking.remotesetup.SystemStatusOverride systemStatus;

    public TMSSystem() {
    }

    public TMSSystem(
           long systemId,
           java.lang.String systemName,
           java.lang.String contact,
           java.lang.String manufacturer,
           java.lang.String description,
           java.lang.String systemType,
           java.lang.String networkAddress,
           java.lang.String location,
           java.lang.String ISDNNumber,
           java.lang.String QNumber,
           java.lang.String webInterfaceURL,
           java.lang.String SIPUri,
           java.lang.String h323Id,
           java.lang.String e164Alias,
           net.tandberg._2004._02.tms.external.booking.remotesetup.TimeZone timeZone,
           net.tandberg._2004._02.tms.external.booking.remotesetup.SystemCategoryOverride systemCategory,
           net.tandberg._2004._02.tms.external.booking.remotesetup.SystemStatusOverride systemStatus) {
           this.systemId = systemId;
           this.systemName = systemName;
           this.contact = contact;
           this.manufacturer = manufacturer;
           this.description = description;
           this.systemType = systemType;
           this.networkAddress = networkAddress;
           this.location = location;
           this.ISDNNumber = ISDNNumber;
           this.QNumber = QNumber;
           this.webInterfaceURL = webInterfaceURL;
           this.SIPUri = SIPUri;
           this.h323Id = h323Id;
           this.e164Alias = e164Alias;
           this.timeZone = timeZone;
           this.systemCategory = systemCategory;
           this.systemStatus = systemStatus;
    }


    /**
     * Gets the systemId value for this TMSSystem.
     * 
     * @return systemId
     */
    public long getSystemId() {
        return systemId;
    }


    /**
     * Sets the systemId value for this TMSSystem.
     * 
     * @param systemId
     */
    public void setSystemId(long systemId) {
        this.systemId = systemId;
    }


    /**
     * Gets the systemName value for this TMSSystem.
     * 
     * @return systemName
     */
    public java.lang.String getSystemName() {
        return systemName;
    }


    /**
     * Sets the systemName value for this TMSSystem.
     * 
     * @param systemName
     */
    public void setSystemName(java.lang.String systemName) {
        this.systemName = systemName;
    }


    /**
     * Gets the contact value for this TMSSystem.
     * 
     * @return contact
     */
    public java.lang.String getContact() {
        return contact;
    }


    /**
     * Sets the contact value for this TMSSystem.
     * 
     * @param contact
     */
    public void setContact(java.lang.String contact) {
        this.contact = contact;
    }


    /**
     * Gets the manufacturer value for this TMSSystem.
     * 
     * @return manufacturer
     */
    public java.lang.String getManufacturer() {
        return manufacturer;
    }


    /**
     * Sets the manufacturer value for this TMSSystem.
     * 
     * @param manufacturer
     */
    public void setManufacturer(java.lang.String manufacturer) {
        this.manufacturer = manufacturer;
    }


    /**
     * Gets the description value for this TMSSystem.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this TMSSystem.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the systemType value for this TMSSystem.
     * 
     * @return systemType
     */
    public java.lang.String getSystemType() {
        return systemType;
    }


    /**
     * Sets the systemType value for this TMSSystem.
     * 
     * @param systemType
     */
    public void setSystemType(java.lang.String systemType) {
        this.systemType = systemType;
    }


    /**
     * Gets the networkAddress value for this TMSSystem.
     * 
     * @return networkAddress
     */
    public java.lang.String getNetworkAddress() {
        return networkAddress;
    }


    /**
     * Sets the networkAddress value for this TMSSystem.
     * 
     * @param networkAddress
     */
    public void setNetworkAddress(java.lang.String networkAddress) {
        this.networkAddress = networkAddress;
    }


    /**
     * Gets the location value for this TMSSystem.
     * 
     * @return location
     */
    public java.lang.String getLocation() {
        return location;
    }


    /**
     * Sets the location value for this TMSSystem.
     * 
     * @param location
     */
    public void setLocation(java.lang.String location) {
        this.location = location;
    }


    /**
     * Gets the ISDNNumber value for this TMSSystem.
     * 
     * @return ISDNNumber
     */
    public java.lang.String getISDNNumber() {
        return ISDNNumber;
    }


    /**
     * Sets the ISDNNumber value for this TMSSystem.
     * 
     * @param ISDNNumber
     */
    public void setISDNNumber(java.lang.String ISDNNumber) {
        this.ISDNNumber = ISDNNumber;
    }


    /**
     * Gets the QNumber value for this TMSSystem.
     * 
     * @return QNumber
     */
    public java.lang.String getQNumber() {
        return QNumber;
    }


    /**
     * Sets the QNumber value for this TMSSystem.
     * 
     * @param QNumber
     */
    public void setQNumber(java.lang.String QNumber) {
        this.QNumber = QNumber;
    }


    /**
     * Gets the webInterfaceURL value for this TMSSystem.
     * 
     * @return webInterfaceURL
     */
    public java.lang.String getWebInterfaceURL() {
        return webInterfaceURL;
    }


    /**
     * Sets the webInterfaceURL value for this TMSSystem.
     * 
     * @param webInterfaceURL
     */
    public void setWebInterfaceURL(java.lang.String webInterfaceURL) {
        this.webInterfaceURL = webInterfaceURL;
    }


    /**
     * Gets the SIPUri value for this TMSSystem.
     * 
     * @return SIPUri
     */
    public java.lang.String getSIPUri() {
        return SIPUri;
    }


    /**
     * Sets the SIPUri value for this TMSSystem.
     * 
     * @param SIPUri
     */
    public void setSIPUri(java.lang.String SIPUri) {
        this.SIPUri = SIPUri;
    }


    /**
     * Gets the h323Id value for this TMSSystem.
     * 
     * @return h323Id
     */
    public java.lang.String getH323Id() {
        return h323Id;
    }


    /**
     * Sets the h323Id value for this TMSSystem.
     * 
     * @param h323Id
     */
    public void setH323Id(java.lang.String h323Id) {
        this.h323Id = h323Id;
    }


    /**
     * Gets the e164Alias value for this TMSSystem.
     * 
     * @return e164Alias
     */
    public java.lang.String getE164Alias() {
        return e164Alias;
    }


    /**
     * Sets the e164Alias value for this TMSSystem.
     * 
     * @param e164Alias
     */
    public void setE164Alias(java.lang.String e164Alias) {
        this.e164Alias = e164Alias;
    }


    /**
     * Gets the timeZone value for this TMSSystem.
     * 
     * @return timeZone
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.TimeZone getTimeZone() {
        return timeZone;
    }


    /**
     * Sets the timeZone value for this TMSSystem.
     * 
     * @param timeZone
     */
    public void setTimeZone(net.tandberg._2004._02.tms.external.booking.remotesetup.TimeZone timeZone) {
        this.timeZone = timeZone;
    }


    /**
     * Gets the systemCategory value for this TMSSystem.
     * 
     * @return systemCategory
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.SystemCategoryOverride getSystemCategory() {
        return systemCategory;
    }


    /**
     * Sets the systemCategory value for this TMSSystem.
     * 
     * @param systemCategory
     */
    public void setSystemCategory(net.tandberg._2004._02.tms.external.booking.remotesetup.SystemCategoryOverride systemCategory) {
        this.systemCategory = systemCategory;
    }


    /**
     * Gets the systemStatus value for this TMSSystem.
     * 
     * @return systemStatus
     */
    public net.tandberg._2004._02.tms.external.booking.remotesetup.SystemStatusOverride getSystemStatus() {
        return systemStatus;
    }


    /**
     * Sets the systemStatus value for this TMSSystem.
     * 
     * @param systemStatus
     */
    public void setSystemStatus(net.tandberg._2004._02.tms.external.booking.remotesetup.SystemStatusOverride systemStatus) {
        this.systemStatus = systemStatus;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TMSSystem)) return false;
        TMSSystem other = (TMSSystem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.systemId == other.getSystemId() &&
            ((this.systemName==null && other.getSystemName()==null) || 
             (this.systemName!=null &&
              this.systemName.equals(other.getSystemName()))) &&
            ((this.contact==null && other.getContact()==null) || 
             (this.contact!=null &&
              this.contact.equals(other.getContact()))) &&
            ((this.manufacturer==null && other.getManufacturer()==null) || 
             (this.manufacturer!=null &&
              this.manufacturer.equals(other.getManufacturer()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.systemType==null && other.getSystemType()==null) || 
             (this.systemType!=null &&
              this.systemType.equals(other.getSystemType()))) &&
            ((this.networkAddress==null && other.getNetworkAddress()==null) || 
             (this.networkAddress!=null &&
              this.networkAddress.equals(other.getNetworkAddress()))) &&
            ((this.location==null && other.getLocation()==null) || 
             (this.location!=null &&
              this.location.equals(other.getLocation()))) &&
            ((this.ISDNNumber==null && other.getISDNNumber()==null) || 
             (this.ISDNNumber!=null &&
              this.ISDNNumber.equals(other.getISDNNumber()))) &&
            ((this.QNumber==null && other.getQNumber()==null) || 
             (this.QNumber!=null &&
              this.QNumber.equals(other.getQNumber()))) &&
            ((this.webInterfaceURL==null && other.getWebInterfaceURL()==null) || 
             (this.webInterfaceURL!=null &&
              this.webInterfaceURL.equals(other.getWebInterfaceURL()))) &&
            ((this.SIPUri==null && other.getSIPUri()==null) || 
             (this.SIPUri!=null &&
              this.SIPUri.equals(other.getSIPUri()))) &&
            ((this.h323Id==null && other.getH323Id()==null) || 
             (this.h323Id!=null &&
              this.h323Id.equals(other.getH323Id()))) &&
            ((this.e164Alias==null && other.getE164Alias()==null) || 
             (this.e164Alias!=null &&
              this.e164Alias.equals(other.getE164Alias()))) &&
            ((this.timeZone==null && other.getTimeZone()==null) || 
             (this.timeZone!=null &&
              this.timeZone.equals(other.getTimeZone()))) &&
            ((this.systemCategory==null && other.getSystemCategory()==null) || 
             (this.systemCategory!=null &&
              this.systemCategory.equals(other.getSystemCategory()))) &&
            ((this.systemStatus==null && other.getSystemStatus()==null) || 
             (this.systemStatus!=null &&
              this.systemStatus.equals(other.getSystemStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getSystemId()).hashCode();
        if (getSystemName() != null) {
            _hashCode += getSystemName().hashCode();
        }
        if (getContact() != null) {
            _hashCode += getContact().hashCode();
        }
        if (getManufacturer() != null) {
            _hashCode += getManufacturer().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getSystemType() != null) {
            _hashCode += getSystemType().hashCode();
        }
        if (getNetworkAddress() != null) {
            _hashCode += getNetworkAddress().hashCode();
        }
        if (getLocation() != null) {
            _hashCode += getLocation().hashCode();
        }
        if (getISDNNumber() != null) {
            _hashCode += getISDNNumber().hashCode();
        }
        if (getQNumber() != null) {
            _hashCode += getQNumber().hashCode();
        }
        if (getWebInterfaceURL() != null) {
            _hashCode += getWebInterfaceURL().hashCode();
        }
        if (getSIPUri() != null) {
            _hashCode += getSIPUri().hashCode();
        }
        if (getH323Id() != null) {
            _hashCode += getH323Id().hashCode();
        }
        if (getE164Alias() != null) {
            _hashCode += getE164Alias().hashCode();
        }
        if (getTimeZone() != null) {
            _hashCode += getTimeZone().hashCode();
        }
        if (getSystemCategory() != null) {
            _hashCode += getSystemCategory().hashCode();
        }
        if (getSystemStatus() != null) {
            _hashCode += getSystemStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TMSSystem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "TMSSystem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contact");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "Contact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "Manufacturer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "Description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("networkAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "NetworkAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "Location"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ISDNNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "ISDNNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("QNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "QNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webInterfaceURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "WebInterfaceURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SIPUri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SIPUri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("h323Id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "H323Id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("e164Alias");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "E164Alias"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timeZone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "TimeZone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "TimeZone"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemCategoryOverride"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("systemStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/remotesetup/", "SystemStatusOverride"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
