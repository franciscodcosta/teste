package net.tandberg._2004._02.tms.external.booking;

public class BookingServiceSoapProxy implements net.tandberg._2004._02.tms.external.booking.BookingServiceSoap {
  private String _endpoint = null;
  private net.tandberg._2004._02.tms.external.booking.BookingServiceSoap bookingServiceSoap = null;
  
  public BookingServiceSoapProxy() {
    _initBookingServiceSoapProxy();
  }
  
  public BookingServiceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initBookingServiceSoapProxy();
  }
  
  private void _initBookingServiceSoapProxy() {
    try {
      bookingServiceSoap = (new net.tandberg._2004._02.tms.external.booking.BookingServiceLocator()).getBookingServiceSoap();
      if (bookingServiceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)bookingServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)bookingServiceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (bookingServiceSoap != null)
      ((javax.xml.rpc.Stub)bookingServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public net.tandberg._2004._02.tms.external.booking.BookingServiceSoap getBookingServiceSoap() {
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap;
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getDefaultConference() throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getDefaultConference();
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForSystems(int[] systemIds, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferencesForSystems(systemIds, startTime, endTime, conferenceStatus);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference[] getConferencesForUser(java.lang.String userName, java.util.Calendar startTime, java.util.Calendar endTime, net.tandberg._2004._02.tms.external.booking.ConferenceStatus conferenceStatus) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferencesForUser(userName, startTime, endTime, conferenceStatus);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getConferenceById(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceById(conferenceId);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceById(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getRecurrentConferenceById(conferenceId);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getRecurrentConferenceByIdWithFirstOngoingOrPendingStartTime(conferenceId);
  }
  
  public int getConferenceIdByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceIdByExternalId(externalSourceId, externalConferenceId, recurrenceIdUTC);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceByExternalId(externalSourceId, externalConferenceId);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference getConferenceInstanceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceInstanceByExternalId(externalSourceId, externalConferenceId, recurrenceIdUTC);
  }
  
  public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.saveConferenceWithMode(conference, bookingMode);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference saveConference(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.saveConference(conference);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference[] saveConferences(net.tandberg._2004._02.tms.external.booking.Conference[] conferences, boolean oneTransaction) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.saveConferences(conferences, oneTransaction);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Conference saveConferenceRecInstance(net.tandberg._2004._02.tms.external.booking.Conference conference) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.saveConferenceRecInstance(conference);
  }
  
  public net.tandberg._2004._02.tms.external.booking.SaveConferenceResult saveConferenceRecInstanceWithMode(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.BookingMode bookingMode) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.saveConferenceRecInstanceWithMode(conference, bookingMode);
  }
  
  public void endConferenceById(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.endConferenceById(conferenceId);
  }
  
  public void endConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.endConferenceByExternalId(externalSourceId, externalConferenceId, recurrenceIdUTC);
  }
  
  public void deleteConferenceById(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.deleteConferenceById(conferenceId);
  }
  
  public void deleteConferenceRecInstanceById(int conferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.deleteConferenceRecInstanceById(conferenceId);
  }
  
  public void deleteConferenceByExternalId(java.lang.String externalSourceId, java.lang.String externalConferenceId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.deleteConferenceByExternalId(externalSourceId, externalConferenceId);
  }
  
  public void deleteConferenceInstanceByExternaId(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    bookingServiceSoap.deleteConferenceInstanceByExternaId(externalSourceId, externalConferenceId, recurrenceIdUTC);
  }
  
  public net.tandberg._2004._02.tms.external.booking.Transaction[] getTransactionsSince(int currentTransactionId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getTransactionsSince(currentTransactionId);
  }
  
  public net.tandberg._2004._02.tms.external.booking.ConferenceTransaction[] getTransactionsSinceWithExternalId(long currentTransactionId) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getTransactionsSinceWithExternalId(currentTransactionId);
  }
  
  public net.tandberg._2004._02.tms.external.booking.RecordingDevice[] getRecordingAliases(java.lang.String userName) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getRecordingAliases(userName);
  }
  
  public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceInviteMail(java.lang.String externalSourceId, java.lang.String externalConferenceId, java.lang.String recurrenceIdUTC, net.tandberg._2004._02.tms.external.booking.TypedMailMessage[] messages, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceInviteMail(externalSourceId, externalConferenceId, recurrenceIdUTC, messages, contentTypes, language);
  }
  
  public net.tandberg._2004._02.tms.external.booking.ConferenceMail[] getConferenceBookingEventMail(net.tandberg._2004._02.tms.external.booking.Conference conference, net.tandberg._2004._02.tms.external.booking.TypedMailMessage message, net.tandberg._2004._02.tms.external.booking.MailContentType[] contentTypes, java.lang.String language) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getConferenceBookingEventMail(conference, message, contentTypes, language);
  }
  
  public net.tandberg._2004._02.tms.external.booking.WebExSiteDefaults getWebExSiteDefaults(java.lang.String siteUrl) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getWebExSiteDefaults(siteUrl);
  }
  
  public net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] getTimeZoneRulesById(java.lang.String idString) throws java.rmi.RemoteException{
    if (bookingServiceSoap == null)
      _initBookingServiceSoapProxy();
    return bookingServiceSoap.getTimeZoneRulesById(idString);
  }
  
  
}