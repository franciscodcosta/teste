/**
 * RecurrencePattern.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class RecurrencePattern  implements java.io.Serializable {
    private net.tandberg._2004._02.tms.external.booking.RecurringFrequency frequencyType;

    private int interval;

    private net.tandberg._2004._02.tms.external.booking.DayOfWeek[] daysOfWeek;

    private net.tandberg._2004._02.tms.external.booking.DayOfWeek firstDayOfWeek;

    private int bySetPosition;

    private java.math.BigInteger byMonthDay;

    private net.tandberg._2004._02.tms.external.booking.RecurrenceEndType patternEndType;

    private java.lang.String patternEndDateUTC;

    private java.lang.String firstOccurrenceRecInstanceIdUTC;

    private int patternInstances;

    private net.tandberg._2004._02.tms.external.booking.RecurrenceException[] exceptions;

    public RecurrencePattern() {
    }

    public RecurrencePattern(
           net.tandberg._2004._02.tms.external.booking.RecurringFrequency frequencyType,
           int interval,
           net.tandberg._2004._02.tms.external.booking.DayOfWeek[] daysOfWeek,
           net.tandberg._2004._02.tms.external.booking.DayOfWeek firstDayOfWeek,
           int bySetPosition,
           java.math.BigInteger byMonthDay,
           net.tandberg._2004._02.tms.external.booking.RecurrenceEndType patternEndType,
           java.lang.String patternEndDateUTC,
           java.lang.String firstOccurrenceRecInstanceIdUTC,
           int patternInstances,
           net.tandberg._2004._02.tms.external.booking.RecurrenceException[] exceptions) {
           this.frequencyType = frequencyType;
           this.interval = interval;
           this.daysOfWeek = daysOfWeek;
           this.firstDayOfWeek = firstDayOfWeek;
           this.bySetPosition = bySetPosition;
           this.byMonthDay = byMonthDay;
           this.patternEndType = patternEndType;
           this.patternEndDateUTC = patternEndDateUTC;
           this.firstOccurrenceRecInstanceIdUTC = firstOccurrenceRecInstanceIdUTC;
           this.patternInstances = patternInstances;
           this.exceptions = exceptions;
    }


    /**
     * Gets the frequencyType value for this RecurrencePattern.
     * 
     * @return frequencyType
     */
    public net.tandberg._2004._02.tms.external.booking.RecurringFrequency getFrequencyType() {
        return frequencyType;
    }


    /**
     * Sets the frequencyType value for this RecurrencePattern.
     * 
     * @param frequencyType
     */
    public void setFrequencyType(net.tandberg._2004._02.tms.external.booking.RecurringFrequency frequencyType) {
        this.frequencyType = frequencyType;
    }


    /**
     * Gets the interval value for this RecurrencePattern.
     * 
     * @return interval
     */
    public int getInterval() {
        return interval;
    }


    /**
     * Sets the interval value for this RecurrencePattern.
     * 
     * @param interval
     */
    public void setInterval(int interval) {
        this.interval = interval;
    }


    /**
     * Gets the daysOfWeek value for this RecurrencePattern.
     * 
     * @return daysOfWeek
     */
    public net.tandberg._2004._02.tms.external.booking.DayOfWeek[] getDaysOfWeek() {
        return daysOfWeek;
    }


    /**
     * Sets the daysOfWeek value for this RecurrencePattern.
     * 
     * @param daysOfWeek
     */
    public void setDaysOfWeek(net.tandberg._2004._02.tms.external.booking.DayOfWeek[] daysOfWeek) {
        this.daysOfWeek = daysOfWeek;
    }


    /**
     * Gets the firstDayOfWeek value for this RecurrencePattern.
     * 
     * @return firstDayOfWeek
     */
    public net.tandberg._2004._02.tms.external.booking.DayOfWeek getFirstDayOfWeek() {
        return firstDayOfWeek;
    }


    /**
     * Sets the firstDayOfWeek value for this RecurrencePattern.
     * 
     * @param firstDayOfWeek
     */
    public void setFirstDayOfWeek(net.tandberg._2004._02.tms.external.booking.DayOfWeek firstDayOfWeek) {
        this.firstDayOfWeek = firstDayOfWeek;
    }


    /**
     * Gets the bySetPosition value for this RecurrencePattern.
     * 
     * @return bySetPosition
     */
    public int getBySetPosition() {
        return bySetPosition;
    }


    /**
     * Sets the bySetPosition value for this RecurrencePattern.
     * 
     * @param bySetPosition
     */
    public void setBySetPosition(int bySetPosition) {
        this.bySetPosition = bySetPosition;
    }


    /**
     * Gets the byMonthDay value for this RecurrencePattern.
     * 
     * @return byMonthDay
     */
    public java.math.BigInteger getByMonthDay() {
        return byMonthDay;
    }


    /**
     * Sets the byMonthDay value for this RecurrencePattern.
     * 
     * @param byMonthDay
     */
    public void setByMonthDay(java.math.BigInteger byMonthDay) {
        this.byMonthDay = byMonthDay;
    }


    /**
     * Gets the patternEndType value for this RecurrencePattern.
     * 
     * @return patternEndType
     */
    public net.tandberg._2004._02.tms.external.booking.RecurrenceEndType getPatternEndType() {
        return patternEndType;
    }


    /**
     * Sets the patternEndType value for this RecurrencePattern.
     * 
     * @param patternEndType
     */
    public void setPatternEndType(net.tandberg._2004._02.tms.external.booking.RecurrenceEndType patternEndType) {
        this.patternEndType = patternEndType;
    }


    /**
     * Gets the patternEndDateUTC value for this RecurrencePattern.
     * 
     * @return patternEndDateUTC
     */
    public java.lang.String getPatternEndDateUTC() {
        return patternEndDateUTC;
    }


    /**
     * Sets the patternEndDateUTC value for this RecurrencePattern.
     * 
     * @param patternEndDateUTC
     */
    public void setPatternEndDateUTC(java.lang.String patternEndDateUTC) {
        this.patternEndDateUTC = patternEndDateUTC;
    }


    /**
     * Gets the firstOccurrenceRecInstanceIdUTC value for this RecurrencePattern.
     * 
     * @return firstOccurrenceRecInstanceIdUTC
     */
    public java.lang.String getFirstOccurrenceRecInstanceIdUTC() {
        return firstOccurrenceRecInstanceIdUTC;
    }


    /**
     * Sets the firstOccurrenceRecInstanceIdUTC value for this RecurrencePattern.
     * 
     * @param firstOccurrenceRecInstanceIdUTC
     */
    public void setFirstOccurrenceRecInstanceIdUTC(java.lang.String firstOccurrenceRecInstanceIdUTC) {
        this.firstOccurrenceRecInstanceIdUTC = firstOccurrenceRecInstanceIdUTC;
    }


    /**
     * Gets the patternInstances value for this RecurrencePattern.
     * 
     * @return patternInstances
     */
    public int getPatternInstances() {
        return patternInstances;
    }


    /**
     * Sets the patternInstances value for this RecurrencePattern.
     * 
     * @param patternInstances
     */
    public void setPatternInstances(int patternInstances) {
        this.patternInstances = patternInstances;
    }


    /**
     * Gets the exceptions value for this RecurrencePattern.
     * 
     * @return exceptions
     */
    public net.tandberg._2004._02.tms.external.booking.RecurrenceException[] getExceptions() {
        return exceptions;
    }


    /**
     * Sets the exceptions value for this RecurrencePattern.
     * 
     * @param exceptions
     */
    public void setExceptions(net.tandberg._2004._02.tms.external.booking.RecurrenceException[] exceptions) {
        this.exceptions = exceptions;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RecurrencePattern)) return false;
        RecurrencePattern other = (RecurrencePattern) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.frequencyType==null && other.getFrequencyType()==null) || 
             (this.frequencyType!=null &&
              this.frequencyType.equals(other.getFrequencyType()))) &&
            this.interval == other.getInterval() &&
            ((this.daysOfWeek==null && other.getDaysOfWeek()==null) || 
             (this.daysOfWeek!=null &&
              java.util.Arrays.equals(this.daysOfWeek, other.getDaysOfWeek()))) &&
            ((this.firstDayOfWeek==null && other.getFirstDayOfWeek()==null) || 
             (this.firstDayOfWeek!=null &&
              this.firstDayOfWeek.equals(other.getFirstDayOfWeek()))) &&
            this.bySetPosition == other.getBySetPosition() &&
            ((this.byMonthDay==null && other.getByMonthDay()==null) || 
             (this.byMonthDay!=null &&
              this.byMonthDay.equals(other.getByMonthDay()))) &&
            ((this.patternEndType==null && other.getPatternEndType()==null) || 
             (this.patternEndType!=null &&
              this.patternEndType.equals(other.getPatternEndType()))) &&
            ((this.patternEndDateUTC==null && other.getPatternEndDateUTC()==null) || 
             (this.patternEndDateUTC!=null &&
              this.patternEndDateUTC.equals(other.getPatternEndDateUTC()))) &&
            ((this.firstOccurrenceRecInstanceIdUTC==null && other.getFirstOccurrenceRecInstanceIdUTC()==null) || 
             (this.firstOccurrenceRecInstanceIdUTC!=null &&
              this.firstOccurrenceRecInstanceIdUTC.equals(other.getFirstOccurrenceRecInstanceIdUTC()))) &&
            this.patternInstances == other.getPatternInstances() &&
            ((this.exceptions==null && other.getExceptions()==null) || 
             (this.exceptions!=null &&
              java.util.Arrays.equals(this.exceptions, other.getExceptions())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFrequencyType() != null) {
            _hashCode += getFrequencyType().hashCode();
        }
        _hashCode += getInterval();
        if (getDaysOfWeek() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDaysOfWeek());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDaysOfWeek(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFirstDayOfWeek() != null) {
            _hashCode += getFirstDayOfWeek().hashCode();
        }
        _hashCode += getBySetPosition();
        if (getByMonthDay() != null) {
            _hashCode += getByMonthDay().hashCode();
        }
        if (getPatternEndType() != null) {
            _hashCode += getPatternEndType().hashCode();
        }
        if (getPatternEndDateUTC() != null) {
            _hashCode += getPatternEndDateUTC().hashCode();
        }
        if (getFirstOccurrenceRecInstanceIdUTC() != null) {
            _hashCode += getFirstOccurrenceRecInstanceIdUTC().hashCode();
        }
        _hashCode += getPatternInstances();
        if (getExceptions() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExceptions());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExceptions(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RecurrencePattern.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrencePattern"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("frequencyType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "FrequencyType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurringFrequency"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("interval");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Interval"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("daysOfWeek");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DaysOfWeek"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstDayOfWeek");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "FirstDayOfWeek"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DayOfWeek"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bySetPosition");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BySetPosition"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("byMonthDay");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ByMonthDay"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patternEndType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PatternEndType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceEndType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patternEndDateUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PatternEndDateUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstOccurrenceRecInstanceIdUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "FirstOccurrenceRecInstanceIdUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patternInstances");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PatternInstances"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exceptions");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Exceptions"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
