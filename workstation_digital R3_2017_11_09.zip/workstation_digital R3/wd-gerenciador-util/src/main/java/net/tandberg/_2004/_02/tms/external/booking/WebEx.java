/**
 * WebEx.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class WebEx  implements java.io.Serializable {
    private java.lang.String meetingKey;

    private java.lang.String sipUrl;

    private java.lang.String[] elementsToExclude;

    private java.lang.String meetingPassword;

    private java.lang.String joinMeetingUrl;

    private java.lang.String hostMeetingUrl;

    private java.lang.String hostKey;

    private java.lang.String joinBeforeHostTime;

    private net.tandberg._2004._02.tms.external.booking.WebExTelephony telephony;

    private boolean tmsShouldUpdateMeeting;

    private java.lang.String siteUrl;

    private boolean usePstn;

    private boolean ownedExternally;

    private net.tandberg._2004._02.tms.external.booking.WebExWarning[] warnings;

    private net.tandberg._2004._02.tms.external.booking.WebExError[] errors;

    public WebEx() {
    }

    public WebEx(
           java.lang.String meetingKey,
           java.lang.String sipUrl,
           java.lang.String[] elementsToExclude,
           java.lang.String meetingPassword,
           java.lang.String joinMeetingUrl,
           java.lang.String hostMeetingUrl,
           java.lang.String hostKey,
           java.lang.String joinBeforeHostTime,
           net.tandberg._2004._02.tms.external.booking.WebExTelephony telephony,
           boolean tmsShouldUpdateMeeting,
           java.lang.String siteUrl,
           boolean usePstn,
           boolean ownedExternally,
           net.tandberg._2004._02.tms.external.booking.WebExWarning[] warnings,
           net.tandberg._2004._02.tms.external.booking.WebExError[] errors) {
           this.meetingKey = meetingKey;
           this.sipUrl = sipUrl;
           this.elementsToExclude = elementsToExclude;
           this.meetingPassword = meetingPassword;
           this.joinMeetingUrl = joinMeetingUrl;
           this.hostMeetingUrl = hostMeetingUrl;
           this.hostKey = hostKey;
           this.joinBeforeHostTime = joinBeforeHostTime;
           this.telephony = telephony;
           this.tmsShouldUpdateMeeting = tmsShouldUpdateMeeting;
           this.siteUrl = siteUrl;
           this.usePstn = usePstn;
           this.ownedExternally = ownedExternally;
           this.warnings = warnings;
           this.errors = errors;
    }


    /**
     * Gets the meetingKey value for this WebEx.
     * 
     * @return meetingKey
     */
    public java.lang.String getMeetingKey() {
        return meetingKey;
    }


    /**
     * Sets the meetingKey value for this WebEx.
     * 
     * @param meetingKey
     */
    public void setMeetingKey(java.lang.String meetingKey) {
        this.meetingKey = meetingKey;
    }


    /**
     * Gets the sipUrl value for this WebEx.
     * 
     * @return sipUrl
     */
    public java.lang.String getSipUrl() {
        return sipUrl;
    }


    /**
     * Sets the sipUrl value for this WebEx.
     * 
     * @param sipUrl
     */
    public void setSipUrl(java.lang.String sipUrl) {
        this.sipUrl = sipUrl;
    }


    /**
     * Gets the elementsToExclude value for this WebEx.
     * 
     * @return elementsToExclude
     */
    public java.lang.String[] getElementsToExclude() {
        return elementsToExclude;
    }


    /**
     * Sets the elementsToExclude value for this WebEx.
     * 
     * @param elementsToExclude
     */
    public void setElementsToExclude(java.lang.String[] elementsToExclude) {
        this.elementsToExclude = elementsToExclude;
    }


    /**
     * Gets the meetingPassword value for this WebEx.
     * 
     * @return meetingPassword
     */
    public java.lang.String getMeetingPassword() {
        return meetingPassword;
    }


    /**
     * Sets the meetingPassword value for this WebEx.
     * 
     * @param meetingPassword
     */
    public void setMeetingPassword(java.lang.String meetingPassword) {
        this.meetingPassword = meetingPassword;
    }


    /**
     * Gets the joinMeetingUrl value for this WebEx.
     * 
     * @return joinMeetingUrl
     */
    public java.lang.String getJoinMeetingUrl() {
        return joinMeetingUrl;
    }


    /**
     * Sets the joinMeetingUrl value for this WebEx.
     * 
     * @param joinMeetingUrl
     */
    public void setJoinMeetingUrl(java.lang.String joinMeetingUrl) {
        this.joinMeetingUrl = joinMeetingUrl;
    }


    /**
     * Gets the hostMeetingUrl value for this WebEx.
     * 
     * @return hostMeetingUrl
     */
    public java.lang.String getHostMeetingUrl() {
        return hostMeetingUrl;
    }


    /**
     * Sets the hostMeetingUrl value for this WebEx.
     * 
     * @param hostMeetingUrl
     */
    public void setHostMeetingUrl(java.lang.String hostMeetingUrl) {
        this.hostMeetingUrl = hostMeetingUrl;
    }


    /**
     * Gets the hostKey value for this WebEx.
     * 
     * @return hostKey
     */
    public java.lang.String getHostKey() {
        return hostKey;
    }


    /**
     * Sets the hostKey value for this WebEx.
     * 
     * @param hostKey
     */
    public void setHostKey(java.lang.String hostKey) {
        this.hostKey = hostKey;
    }


    /**
     * Gets the joinBeforeHostTime value for this WebEx.
     * 
     * @return joinBeforeHostTime
     */
    public java.lang.String getJoinBeforeHostTime() {
        return joinBeforeHostTime;
    }


    /**
     * Sets the joinBeforeHostTime value for this WebEx.
     * 
     * @param joinBeforeHostTime
     */
    public void setJoinBeforeHostTime(java.lang.String joinBeforeHostTime) {
        this.joinBeforeHostTime = joinBeforeHostTime;
    }


    /**
     * Gets the telephony value for this WebEx.
     * 
     * @return telephony
     */
    public net.tandberg._2004._02.tms.external.booking.WebExTelephony getTelephony() {
        return telephony;
    }


    /**
     * Sets the telephony value for this WebEx.
     * 
     * @param telephony
     */
    public void setTelephony(net.tandberg._2004._02.tms.external.booking.WebExTelephony telephony) {
        this.telephony = telephony;
    }


    /**
     * Gets the tmsShouldUpdateMeeting value for this WebEx.
     * 
     * @return tmsShouldUpdateMeeting
     */
    public boolean isTmsShouldUpdateMeeting() {
        return tmsShouldUpdateMeeting;
    }


    /**
     * Sets the tmsShouldUpdateMeeting value for this WebEx.
     * 
     * @param tmsShouldUpdateMeeting
     */
    public void setTmsShouldUpdateMeeting(boolean tmsShouldUpdateMeeting) {
        this.tmsShouldUpdateMeeting = tmsShouldUpdateMeeting;
    }


    /**
     * Gets the siteUrl value for this WebEx.
     * 
     * @return siteUrl
     */
    public java.lang.String getSiteUrl() {
        return siteUrl;
    }


    /**
     * Sets the siteUrl value for this WebEx.
     * 
     * @param siteUrl
     */
    public void setSiteUrl(java.lang.String siteUrl) {
        this.siteUrl = siteUrl;
    }


    /**
     * Gets the usePstn value for this WebEx.
     * 
     * @return usePstn
     */
    public boolean isUsePstn() {
        return usePstn;
    }


    /**
     * Sets the usePstn value for this WebEx.
     * 
     * @param usePstn
     */
    public void setUsePstn(boolean usePstn) {
        this.usePstn = usePstn;
    }


    /**
     * Gets the ownedExternally value for this WebEx.
     * 
     * @return ownedExternally
     */
    public boolean isOwnedExternally() {
        return ownedExternally;
    }


    /**
     * Sets the ownedExternally value for this WebEx.
     * 
     * @param ownedExternally
     */
    public void setOwnedExternally(boolean ownedExternally) {
        this.ownedExternally = ownedExternally;
    }


    /**
     * Gets the warnings value for this WebEx.
     * 
     * @return warnings
     */
    public net.tandberg._2004._02.tms.external.booking.WebExWarning[] getWarnings() {
        return warnings;
    }


    /**
     * Sets the warnings value for this WebEx.
     * 
     * @param warnings
     */
    public void setWarnings(net.tandberg._2004._02.tms.external.booking.WebExWarning[] warnings) {
        this.warnings = warnings;
    }


    /**
     * Gets the errors value for this WebEx.
     * 
     * @return errors
     */
    public net.tandberg._2004._02.tms.external.booking.WebExError[] getErrors() {
        return errors;
    }


    /**
     * Sets the errors value for this WebEx.
     * 
     * @param errors
     */
    public void setErrors(net.tandberg._2004._02.tms.external.booking.WebExError[] errors) {
        this.errors = errors;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof WebEx)) return false;
        WebEx other = (WebEx) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.meetingKey==null && other.getMeetingKey()==null) || 
             (this.meetingKey!=null &&
              this.meetingKey.equals(other.getMeetingKey()))) &&
            ((this.sipUrl==null && other.getSipUrl()==null) || 
             (this.sipUrl!=null &&
              this.sipUrl.equals(other.getSipUrl()))) &&
            ((this.elementsToExclude==null && other.getElementsToExclude()==null) || 
             (this.elementsToExclude!=null &&
              java.util.Arrays.equals(this.elementsToExclude, other.getElementsToExclude()))) &&
            ((this.meetingPassword==null && other.getMeetingPassword()==null) || 
             (this.meetingPassword!=null &&
              this.meetingPassword.equals(other.getMeetingPassword()))) &&
            ((this.joinMeetingUrl==null && other.getJoinMeetingUrl()==null) || 
             (this.joinMeetingUrl!=null &&
              this.joinMeetingUrl.equals(other.getJoinMeetingUrl()))) &&
            ((this.hostMeetingUrl==null && other.getHostMeetingUrl()==null) || 
             (this.hostMeetingUrl!=null &&
              this.hostMeetingUrl.equals(other.getHostMeetingUrl()))) &&
            ((this.hostKey==null && other.getHostKey()==null) || 
             (this.hostKey!=null &&
              this.hostKey.equals(other.getHostKey()))) &&
            ((this.joinBeforeHostTime==null && other.getJoinBeforeHostTime()==null) || 
             (this.joinBeforeHostTime!=null &&
              this.joinBeforeHostTime.equals(other.getJoinBeforeHostTime()))) &&
            ((this.telephony==null && other.getTelephony()==null) || 
             (this.telephony!=null &&
              this.telephony.equals(other.getTelephony()))) &&
            this.tmsShouldUpdateMeeting == other.isTmsShouldUpdateMeeting() &&
            ((this.siteUrl==null && other.getSiteUrl()==null) || 
             (this.siteUrl!=null &&
              this.siteUrl.equals(other.getSiteUrl()))) &&
            this.usePstn == other.isUsePstn() &&
            this.ownedExternally == other.isOwnedExternally() &&
            ((this.warnings==null && other.getWarnings()==null) || 
             (this.warnings!=null &&
              java.util.Arrays.equals(this.warnings, other.getWarnings()))) &&
            ((this.errors==null && other.getErrors()==null) || 
             (this.errors!=null &&
              java.util.Arrays.equals(this.errors, other.getErrors())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMeetingKey() != null) {
            _hashCode += getMeetingKey().hashCode();
        }
        if (getSipUrl() != null) {
            _hashCode += getSipUrl().hashCode();
        }
        if (getElementsToExclude() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getElementsToExclude());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getElementsToExclude(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getMeetingPassword() != null) {
            _hashCode += getMeetingPassword().hashCode();
        }
        if (getJoinMeetingUrl() != null) {
            _hashCode += getJoinMeetingUrl().hashCode();
        }
        if (getHostMeetingUrl() != null) {
            _hashCode += getHostMeetingUrl().hashCode();
        }
        if (getHostKey() != null) {
            _hashCode += getHostKey().hashCode();
        }
        if (getJoinBeforeHostTime() != null) {
            _hashCode += getJoinBeforeHostTime().hashCode();
        }
        if (getTelephony() != null) {
            _hashCode += getTelephony().hashCode();
        }
        _hashCode += (isTmsShouldUpdateMeeting() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getSiteUrl() != null) {
            _hashCode += getSiteUrl().hashCode();
        }
        _hashCode += (isUsePstn() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isOwnedExternally() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getWarnings() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWarnings());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWarnings(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getErrors() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getErrors());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getErrors(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(WebEx.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebEx"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("meetingKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MeetingKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sipUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SipUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("elementsToExclude");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ElementsToExclude"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ElementsPossibleToExcludeInEmail"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("meetingPassword");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MeetingPassword"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("joinMeetingUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "JoinMeetingUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hostMeetingUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "HostMeetingUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hostKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "HostKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("joinBeforeHostTime");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "JoinBeforeHostTime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telephony");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Telephony"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExTelephony"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tmsShouldUpdateMeeting");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TmsShouldUpdateMeeting"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("siteUrl");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SiteUrl"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usePstn");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "UsePstn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownedExternally");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnedExternally"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("warnings");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Warnings"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExWarning"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("errors");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Errors"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExError"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebExError"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
