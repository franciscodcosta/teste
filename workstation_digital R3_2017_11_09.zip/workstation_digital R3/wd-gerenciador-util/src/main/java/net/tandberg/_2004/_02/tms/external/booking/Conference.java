/**
 * Conference.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class Conference  implements java.io.Serializable {
    private int conferenceId;

    private java.lang.String title;

    private java.lang.String startTimeUTC;

    private java.lang.String endTimeUTC;

    private java.lang.String recurrenceInstanceIdUTC;

    private java.lang.String recurrenceInstanceType;

    private java.lang.String firstOccurrenceRecInstanceIdUTC;

    private net.tandberg._2004._02.tms.external.booking.RecurrencePattern recurrencePattern;

    private long ownerId;

    private java.lang.String ownerUserName;

    private java.lang.String ownerFirstName;

    private java.lang.String ownerLastName;

    private java.lang.String ownerEmailAddress;

    private net.tandberg._2004._02.tms.external.booking.ConferenceType conferenceType;

    private net.tandberg._2004._02.tms.external.booking.Bandwidth bandwidth;

    private net.tandberg._2004._02.tms.external.booking.PictureMode pictureMode;

    private net.tandberg._2004._02.tms.external.booking.EncryptionRequested encrypted;

    private net.tandberg._2004._02.tms.external.booking.DataConferenceMode dataConference;

    private net.tandberg._2004._02.tms.external.booking.ExtendOptionRequested showExtendOption;

    private java.lang.String password;

    private java.lang.String billingCode;

    private boolean ISDNRestrict;

    private net.tandberg._2004._02.tms.external.booking.ExternalConference externalConference;

    private java.lang.String emailTo;

    private java.lang.String confBundleId;

    private java.lang.String confOwnerId;

    private java.lang.String conferenceInfoText;

    private java.lang.String conferenceInfoHtml;

    private java.lang.String userMessageText;

    private java.lang.String externalSourceId;

    private java.lang.String externalPrimaryKey;

    private java.lang.String detachedFromExternalSourceId;

    private java.lang.String detachedFromExternalPrimaryKey;

    private net.tandberg._2004._02.tms.external.booking.Participant[] participants;

    private java.lang.String recordedConferenceUri;

    private java.lang.String webConferencePresenterUri;

    private java.lang.String webConferenceAttendeeUri;

    private net.tandberg._2004._02.tms.external.booking.BandwidthOverride ISDNBandwidth;

    private net.tandberg._2004._02.tms.external.booking.BandwidthOverride IPBandwidth;

    private java.lang.String conferenceLanguage;

    private net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] conferenceTimeZoneRules;

    private net.tandberg._2004._02.tms.external.booking.ConferenceState conferenceState;

    private java.math.BigInteger version;

    private java.lang.String location;

    private java.lang.String invitees;

    private java.lang.String secretCode;

    private java.lang.String meetingSource;

    public Conference() {
    }

    public Conference(
           int conferenceId,
           java.lang.String title,
           java.lang.String startTimeUTC,
           java.lang.String endTimeUTC,
           java.lang.String recurrenceInstanceIdUTC,
           java.lang.String recurrenceInstanceType,
           java.lang.String firstOccurrenceRecInstanceIdUTC,
           net.tandberg._2004._02.tms.external.booking.RecurrencePattern recurrencePattern,
           long ownerId,
           java.lang.String ownerUserName,
           java.lang.String ownerFirstName,
           java.lang.String ownerLastName,
           java.lang.String ownerEmailAddress,
           net.tandberg._2004._02.tms.external.booking.ConferenceType conferenceType,
           net.tandberg._2004._02.tms.external.booking.Bandwidth bandwidth,
           net.tandberg._2004._02.tms.external.booking.PictureMode pictureMode,
           net.tandberg._2004._02.tms.external.booking.EncryptionRequested encrypted,
           net.tandberg._2004._02.tms.external.booking.DataConferenceMode dataConference,
           net.tandberg._2004._02.tms.external.booking.ExtendOptionRequested showExtendOption,
           java.lang.String password,
           java.lang.String billingCode,
           boolean ISDNRestrict,
           net.tandberg._2004._02.tms.external.booking.ExternalConference externalConference,
           java.lang.String emailTo,
           java.lang.String confBundleId,
           java.lang.String confOwnerId,
           java.lang.String conferenceInfoText,
           java.lang.String conferenceInfoHtml,
           java.lang.String userMessageText,
           java.lang.String externalSourceId,
           java.lang.String externalPrimaryKey,
           java.lang.String detachedFromExternalSourceId,
           java.lang.String detachedFromExternalPrimaryKey,
           net.tandberg._2004._02.tms.external.booking.Participant[] participants,
           java.lang.String recordedConferenceUri,
           java.lang.String webConferencePresenterUri,
           java.lang.String webConferenceAttendeeUri,
           net.tandberg._2004._02.tms.external.booking.BandwidthOverride ISDNBandwidth,
           net.tandberg._2004._02.tms.external.booking.BandwidthOverride IPBandwidth,
           java.lang.String conferenceLanguage,
           net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] conferenceTimeZoneRules,
           net.tandberg._2004._02.tms.external.booking.ConferenceState conferenceState,
           java.math.BigInteger version,
           java.lang.String location,
           java.lang.String invitees,
           java.lang.String secretCode,
           java.lang.String meetingSource) {
           this.conferenceId = conferenceId;
           this.title = title;
           this.startTimeUTC = startTimeUTC;
           this.endTimeUTC = endTimeUTC;
           this.recurrenceInstanceIdUTC = recurrenceInstanceIdUTC;
           this.recurrenceInstanceType = recurrenceInstanceType;
           this.firstOccurrenceRecInstanceIdUTC = firstOccurrenceRecInstanceIdUTC;
           this.recurrencePattern = recurrencePattern;
           this.ownerId = ownerId;
           this.ownerUserName = ownerUserName;
           this.ownerFirstName = ownerFirstName;
           this.ownerLastName = ownerLastName;
           this.ownerEmailAddress = ownerEmailAddress;
           this.conferenceType = conferenceType;
           this.bandwidth = bandwidth;
           this.pictureMode = pictureMode;
           this.encrypted = encrypted;
           this.dataConference = dataConference;
           this.showExtendOption = showExtendOption;
           this.password = password;
           this.billingCode = billingCode;
           this.ISDNRestrict = ISDNRestrict;
           this.externalConference = externalConference;
           this.emailTo = emailTo;
           this.confBundleId = confBundleId;
           this.confOwnerId = confOwnerId;
           this.conferenceInfoText = conferenceInfoText;
           this.conferenceInfoHtml = conferenceInfoHtml;
           this.userMessageText = userMessageText;
           this.externalSourceId = externalSourceId;
           this.externalPrimaryKey = externalPrimaryKey;
           this.detachedFromExternalSourceId = detachedFromExternalSourceId;
           this.detachedFromExternalPrimaryKey = detachedFromExternalPrimaryKey;
           this.participants = participants;
           this.recordedConferenceUri = recordedConferenceUri;
           this.webConferencePresenterUri = webConferencePresenterUri;
           this.webConferenceAttendeeUri = webConferenceAttendeeUri;
           this.ISDNBandwidth = ISDNBandwidth;
           this.IPBandwidth = IPBandwidth;
           this.conferenceLanguage = conferenceLanguage;
           this.conferenceTimeZoneRules = conferenceTimeZoneRules;
           this.conferenceState = conferenceState;
           this.version = version;
           this.location = location;
           this.invitees = invitees;
           this.secretCode = secretCode;
           this.meetingSource = meetingSource;
    }


    /**
     * Gets the conferenceId value for this Conference.
     * 
     * @return conferenceId
     */
    public int getConferenceId() {
        return conferenceId;
    }


    /**
     * Sets the conferenceId value for this Conference.
     * 
     * @param conferenceId
     */
    public void setConferenceId(int conferenceId) {
        this.conferenceId = conferenceId;
    }


    /**
     * Gets the title value for this Conference.
     * 
     * @return title
     */
    public java.lang.String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this Conference.
     * 
     * @param title
     */
    public void setTitle(java.lang.String title) {
        this.title = title;
    }


    /**
     * Gets the startTimeUTC value for this Conference.
     * 
     * @return startTimeUTC
     */
    public java.lang.String getStartTimeUTC() {
        return startTimeUTC;
    }


    /**
     * Sets the startTimeUTC value for this Conference.
     * 
     * @param startTimeUTC
     */
    public void setStartTimeUTC(java.lang.String startTimeUTC) {
        this.startTimeUTC = startTimeUTC;
    }


    /**
     * Gets the endTimeUTC value for this Conference.
     * 
     * @return endTimeUTC
     */
    public java.lang.String getEndTimeUTC() {
        return endTimeUTC;
    }


    /**
     * Sets the endTimeUTC value for this Conference.
     * 
     * @param endTimeUTC
     */
    public void setEndTimeUTC(java.lang.String endTimeUTC) {
        this.endTimeUTC = endTimeUTC;
    }


    /**
     * Gets the recurrenceInstanceIdUTC value for this Conference.
     * 
     * @return recurrenceInstanceIdUTC
     */
    public java.lang.String getRecurrenceInstanceIdUTC() {
        return recurrenceInstanceIdUTC;
    }


    /**
     * Sets the recurrenceInstanceIdUTC value for this Conference.
     * 
     * @param recurrenceInstanceIdUTC
     */
    public void setRecurrenceInstanceIdUTC(java.lang.String recurrenceInstanceIdUTC) {
        this.recurrenceInstanceIdUTC = recurrenceInstanceIdUTC;
    }


    /**
     * Gets the recurrenceInstanceType value for this Conference.
     * 
     * @return recurrenceInstanceType
     */
    public java.lang.String getRecurrenceInstanceType() {
        return recurrenceInstanceType;
    }


    /**
     * Sets the recurrenceInstanceType value for this Conference.
     * 
     * @param recurrenceInstanceType
     */
    public void setRecurrenceInstanceType(java.lang.String recurrenceInstanceType) {
        this.recurrenceInstanceType = recurrenceInstanceType;
    }


    /**
     * Gets the firstOccurrenceRecInstanceIdUTC value for this Conference.
     * 
     * @return firstOccurrenceRecInstanceIdUTC
     */
    public java.lang.String getFirstOccurrenceRecInstanceIdUTC() {
        return firstOccurrenceRecInstanceIdUTC;
    }


    /**
     * Sets the firstOccurrenceRecInstanceIdUTC value for this Conference.
     * 
     * @param firstOccurrenceRecInstanceIdUTC
     */
    public void setFirstOccurrenceRecInstanceIdUTC(java.lang.String firstOccurrenceRecInstanceIdUTC) {
        this.firstOccurrenceRecInstanceIdUTC = firstOccurrenceRecInstanceIdUTC;
    }


    /**
     * Gets the recurrencePattern value for this Conference.
     * 
     * @return recurrencePattern
     */
    public net.tandberg._2004._02.tms.external.booking.RecurrencePattern getRecurrencePattern() {
        return recurrencePattern;
    }


    /**
     * Sets the recurrencePattern value for this Conference.
     * 
     * @param recurrencePattern
     */
    public void setRecurrencePattern(net.tandberg._2004._02.tms.external.booking.RecurrencePattern recurrencePattern) {
        this.recurrencePattern = recurrencePattern;
    }


    /**
     * Gets the ownerId value for this Conference.
     * 
     * @return ownerId
     */
    public long getOwnerId() {
        return ownerId;
    }


    /**
     * Sets the ownerId value for this Conference.
     * 
     * @param ownerId
     */
    public void setOwnerId(long ownerId) {
        this.ownerId = ownerId;
    }


    /**
     * Gets the ownerUserName value for this Conference.
     * 
     * @return ownerUserName
     */
    public java.lang.String getOwnerUserName() {
        return ownerUserName;
    }


    /**
     * Sets the ownerUserName value for this Conference.
     * 
     * @param ownerUserName
     */
    public void setOwnerUserName(java.lang.String ownerUserName) {
        this.ownerUserName = ownerUserName;
    }


    /**
     * Gets the ownerFirstName value for this Conference.
     * 
     * @return ownerFirstName
     */
    public java.lang.String getOwnerFirstName() {
        return ownerFirstName;
    }


    /**
     * Sets the ownerFirstName value for this Conference.
     * 
     * @param ownerFirstName
     */
    public void setOwnerFirstName(java.lang.String ownerFirstName) {
        this.ownerFirstName = ownerFirstName;
    }


    /**
     * Gets the ownerLastName value for this Conference.
     * 
     * @return ownerLastName
     */
    public java.lang.String getOwnerLastName() {
        return ownerLastName;
    }


    /**
     * Sets the ownerLastName value for this Conference.
     * 
     * @param ownerLastName
     */
    public void setOwnerLastName(java.lang.String ownerLastName) {
        this.ownerLastName = ownerLastName;
    }


    /**
     * Gets the ownerEmailAddress value for this Conference.
     * 
     * @return ownerEmailAddress
     */
    public java.lang.String getOwnerEmailAddress() {
        return ownerEmailAddress;
    }


    /**
     * Sets the ownerEmailAddress value for this Conference.
     * 
     * @param ownerEmailAddress
     */
    public void setOwnerEmailAddress(java.lang.String ownerEmailAddress) {
        this.ownerEmailAddress = ownerEmailAddress;
    }


    /**
     * Gets the conferenceType value for this Conference.
     * 
     * @return conferenceType
     */
    public net.tandberg._2004._02.tms.external.booking.ConferenceType getConferenceType() {
        return conferenceType;
    }


    /**
     * Sets the conferenceType value for this Conference.
     * 
     * @param conferenceType
     */
    public void setConferenceType(net.tandberg._2004._02.tms.external.booking.ConferenceType conferenceType) {
        this.conferenceType = conferenceType;
    }


    /**
     * Gets the bandwidth value for this Conference.
     * 
     * @return bandwidth
     */
    public net.tandberg._2004._02.tms.external.booking.Bandwidth getBandwidth() {
        return bandwidth;
    }


    /**
     * Sets the bandwidth value for this Conference.
     * 
     * @param bandwidth
     */
    public void setBandwidth(net.tandberg._2004._02.tms.external.booking.Bandwidth bandwidth) {
        this.bandwidth = bandwidth;
    }


    /**
     * Gets the pictureMode value for this Conference.
     * 
     * @return pictureMode
     */
    public net.tandberg._2004._02.tms.external.booking.PictureMode getPictureMode() {
        return pictureMode;
    }


    /**
     * Sets the pictureMode value for this Conference.
     * 
     * @param pictureMode
     */
    public void setPictureMode(net.tandberg._2004._02.tms.external.booking.PictureMode pictureMode) {
        this.pictureMode = pictureMode;
    }


    /**
     * Gets the encrypted value for this Conference.
     * 
     * @return encrypted
     */
    public net.tandberg._2004._02.tms.external.booking.EncryptionRequested getEncrypted() {
        return encrypted;
    }


    /**
     * Sets the encrypted value for this Conference.
     * 
     * @param encrypted
     */
    public void setEncrypted(net.tandberg._2004._02.tms.external.booking.EncryptionRequested encrypted) {
        this.encrypted = encrypted;
    }


    /**
     * Gets the dataConference value for this Conference.
     * 
     * @return dataConference
     */
    public net.tandberg._2004._02.tms.external.booking.DataConferenceMode getDataConference() {
        return dataConference;
    }


    /**
     * Sets the dataConference value for this Conference.
     * 
     * @param dataConference
     */
    public void setDataConference(net.tandberg._2004._02.tms.external.booking.DataConferenceMode dataConference) {
        this.dataConference = dataConference;
    }


    /**
     * Gets the showExtendOption value for this Conference.
     * 
     * @return showExtendOption
     */
    public net.tandberg._2004._02.tms.external.booking.ExtendOptionRequested getShowExtendOption() {
        return showExtendOption;
    }


    /**
     * Sets the showExtendOption value for this Conference.
     * 
     * @param showExtendOption
     */
    public void setShowExtendOption(net.tandberg._2004._02.tms.external.booking.ExtendOptionRequested showExtendOption) {
        this.showExtendOption = showExtendOption;
    }


    /**
     * Gets the password value for this Conference.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this Conference.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the billingCode value for this Conference.
     * 
     * @return billingCode
     */
    public java.lang.String getBillingCode() {
        return billingCode;
    }


    /**
     * Sets the billingCode value for this Conference.
     * 
     * @param billingCode
     */
    public void setBillingCode(java.lang.String billingCode) {
        this.billingCode = billingCode;
    }


    /**
     * Gets the ISDNRestrict value for this Conference.
     * 
     * @return ISDNRestrict
     */
    public boolean isISDNRestrict() {
        return ISDNRestrict;
    }


    /**
     * Sets the ISDNRestrict value for this Conference.
     * 
     * @param ISDNRestrict
     */
    public void setISDNRestrict(boolean ISDNRestrict) {
        this.ISDNRestrict = ISDNRestrict;
    }


    /**
     * Gets the externalConference value for this Conference.
     * 
     * @return externalConference
     */
    public net.tandberg._2004._02.tms.external.booking.ExternalConference getExternalConference() {
        return externalConference;
    }


    /**
     * Sets the externalConference value for this Conference.
     * 
     * @param externalConference
     */
    public void setExternalConference(net.tandberg._2004._02.tms.external.booking.ExternalConference externalConference) {
        this.externalConference = externalConference;
    }


    /**
     * Gets the emailTo value for this Conference.
     * 
     * @return emailTo
     */
    public java.lang.String getEmailTo() {
        return emailTo;
    }


    /**
     * Sets the emailTo value for this Conference.
     * 
     * @param emailTo
     */
    public void setEmailTo(java.lang.String emailTo) {
        this.emailTo = emailTo;
    }


    /**
     * Gets the confBundleId value for this Conference.
     * 
     * @return confBundleId
     */
    public java.lang.String getConfBundleId() {
        return confBundleId;
    }


    /**
     * Sets the confBundleId value for this Conference.
     * 
     * @param confBundleId
     */
    public void setConfBundleId(java.lang.String confBundleId) {
        this.confBundleId = confBundleId;
    }


    /**
     * Gets the confOwnerId value for this Conference.
     * 
     * @return confOwnerId
     */
    public java.lang.String getConfOwnerId() {
        return confOwnerId;
    }


    /**
     * Sets the confOwnerId value for this Conference.
     * 
     * @param confOwnerId
     */
    public void setConfOwnerId(java.lang.String confOwnerId) {
        this.confOwnerId = confOwnerId;
    }


    /**
     * Gets the conferenceInfoText value for this Conference.
     * 
     * @return conferenceInfoText
     */
    public java.lang.String getConferenceInfoText() {
        return conferenceInfoText;
    }


    /**
     * Sets the conferenceInfoText value for this Conference.
     * 
     * @param conferenceInfoText
     */
    public void setConferenceInfoText(java.lang.String conferenceInfoText) {
        this.conferenceInfoText = conferenceInfoText;
    }


    /**
     * Gets the conferenceInfoHtml value for this Conference.
     * 
     * @return conferenceInfoHtml
     */
    public java.lang.String getConferenceInfoHtml() {
        return conferenceInfoHtml;
    }


    /**
     * Sets the conferenceInfoHtml value for this Conference.
     * 
     * @param conferenceInfoHtml
     */
    public void setConferenceInfoHtml(java.lang.String conferenceInfoHtml) {
        this.conferenceInfoHtml = conferenceInfoHtml;
    }


    /**
     * Gets the userMessageText value for this Conference.
     * 
     * @return userMessageText
     */
    public java.lang.String getUserMessageText() {
        return userMessageText;
    }


    /**
     * Sets the userMessageText value for this Conference.
     * 
     * @param userMessageText
     */
    public void setUserMessageText(java.lang.String userMessageText) {
        this.userMessageText = userMessageText;
    }


    /**
     * Gets the externalSourceId value for this Conference.
     * 
     * @return externalSourceId
     */
    public java.lang.String getExternalSourceId() {
        return externalSourceId;
    }


    /**
     * Sets the externalSourceId value for this Conference.
     * 
     * @param externalSourceId
     */
    public void setExternalSourceId(java.lang.String externalSourceId) {
        this.externalSourceId = externalSourceId;
    }


    /**
     * Gets the externalPrimaryKey value for this Conference.
     * 
     * @return externalPrimaryKey
     */
    public java.lang.String getExternalPrimaryKey() {
        return externalPrimaryKey;
    }


    /**
     * Sets the externalPrimaryKey value for this Conference.
     * 
     * @param externalPrimaryKey
     */
    public void setExternalPrimaryKey(java.lang.String externalPrimaryKey) {
        this.externalPrimaryKey = externalPrimaryKey;
    }


    /**
     * Gets the detachedFromExternalSourceId value for this Conference.
     * 
     * @return detachedFromExternalSourceId
     */
    public java.lang.String getDetachedFromExternalSourceId() {
        return detachedFromExternalSourceId;
    }


    /**
     * Sets the detachedFromExternalSourceId value for this Conference.
     * 
     * @param detachedFromExternalSourceId
     */
    public void setDetachedFromExternalSourceId(java.lang.String detachedFromExternalSourceId) {
        this.detachedFromExternalSourceId = detachedFromExternalSourceId;
    }


    /**
     * Gets the detachedFromExternalPrimaryKey value for this Conference.
     * 
     * @return detachedFromExternalPrimaryKey
     */
    public java.lang.String getDetachedFromExternalPrimaryKey() {
        return detachedFromExternalPrimaryKey;
    }


    /**
     * Sets the detachedFromExternalPrimaryKey value for this Conference.
     * 
     * @param detachedFromExternalPrimaryKey
     */
    public void setDetachedFromExternalPrimaryKey(java.lang.String detachedFromExternalPrimaryKey) {
        this.detachedFromExternalPrimaryKey = detachedFromExternalPrimaryKey;
    }


    /**
     * Gets the participants value for this Conference.
     * 
     * @return participants
     */
    public net.tandberg._2004._02.tms.external.booking.Participant[] getParticipants() {
        return participants;
    }


    /**
     * Sets the participants value for this Conference.
     * 
     * @param participants
     */
    public void setParticipants(net.tandberg._2004._02.tms.external.booking.Participant[] participants) {
        this.participants = participants;
    }


    /**
     * Gets the recordedConferenceUri value for this Conference.
     * 
     * @return recordedConferenceUri
     */
    public java.lang.String getRecordedConferenceUri() {
        return recordedConferenceUri;
    }


    /**
     * Sets the recordedConferenceUri value for this Conference.
     * 
     * @param recordedConferenceUri
     */
    public void setRecordedConferenceUri(java.lang.String recordedConferenceUri) {
        this.recordedConferenceUri = recordedConferenceUri;
    }


    /**
     * Gets the webConferencePresenterUri value for this Conference.
     * 
     * @return webConferencePresenterUri
     */
    public java.lang.String getWebConferencePresenterUri() {
        return webConferencePresenterUri;
    }


    /**
     * Sets the webConferencePresenterUri value for this Conference.
     * 
     * @param webConferencePresenterUri
     */
    public void setWebConferencePresenterUri(java.lang.String webConferencePresenterUri) {
        this.webConferencePresenterUri = webConferencePresenterUri;
    }


    /**
     * Gets the webConferenceAttendeeUri value for this Conference.
     * 
     * @return webConferenceAttendeeUri
     */
    public java.lang.String getWebConferenceAttendeeUri() {
        return webConferenceAttendeeUri;
    }


    /**
     * Sets the webConferenceAttendeeUri value for this Conference.
     * 
     * @param webConferenceAttendeeUri
     */
    public void setWebConferenceAttendeeUri(java.lang.String webConferenceAttendeeUri) {
        this.webConferenceAttendeeUri = webConferenceAttendeeUri;
    }


    /**
     * Gets the ISDNBandwidth value for this Conference.
     * 
     * @return ISDNBandwidth
     */
    public net.tandberg._2004._02.tms.external.booking.BandwidthOverride getISDNBandwidth() {
        return ISDNBandwidth;
    }


    /**
     * Sets the ISDNBandwidth value for this Conference.
     * 
     * @param ISDNBandwidth
     */
    public void setISDNBandwidth(net.tandberg._2004._02.tms.external.booking.BandwidthOverride ISDNBandwidth) {
        this.ISDNBandwidth = ISDNBandwidth;
    }


    /**
     * Gets the IPBandwidth value for this Conference.
     * 
     * @return IPBandwidth
     */
    public net.tandberg._2004._02.tms.external.booking.BandwidthOverride getIPBandwidth() {
        return IPBandwidth;
    }


    /**
     * Sets the IPBandwidth value for this Conference.
     * 
     * @param IPBandwidth
     */
    public void setIPBandwidth(net.tandberg._2004._02.tms.external.booking.BandwidthOverride IPBandwidth) {
        this.IPBandwidth = IPBandwidth;
    }


    /**
     * Gets the conferenceLanguage value for this Conference.
     * 
     * @return conferenceLanguage
     */
    public java.lang.String getConferenceLanguage() {
        return conferenceLanguage;
    }


    /**
     * Sets the conferenceLanguage value for this Conference.
     * 
     * @param conferenceLanguage
     */
    public void setConferenceLanguage(java.lang.String conferenceLanguage) {
        this.conferenceLanguage = conferenceLanguage;
    }


    /**
     * Gets the conferenceTimeZoneRules value for this Conference.
     * 
     * @return conferenceTimeZoneRules
     */
    public net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] getConferenceTimeZoneRules() {
        return conferenceTimeZoneRules;
    }


    /**
     * Sets the conferenceTimeZoneRules value for this Conference.
     * 
     * @param conferenceTimeZoneRules
     */
    public void setConferenceTimeZoneRules(net.tandberg._2004._02.tms.external.booking.TimeZoneRule[] conferenceTimeZoneRules) {
        this.conferenceTimeZoneRules = conferenceTimeZoneRules;
    }


    /**
     * Gets the conferenceState value for this Conference.
     * 
     * @return conferenceState
     */
    public net.tandberg._2004._02.tms.external.booking.ConferenceState getConferenceState() {
        return conferenceState;
    }


    /**
     * Sets the conferenceState value for this Conference.
     * 
     * @param conferenceState
     */
    public void setConferenceState(net.tandberg._2004._02.tms.external.booking.ConferenceState conferenceState) {
        this.conferenceState = conferenceState;
    }


    /**
     * Gets the version value for this Conference.
     * 
     * @return version
     */
    public java.math.BigInteger getVersion() {
        return version;
    }


    /**
     * Sets the version value for this Conference.
     * 
     * @param version
     */
    public void setVersion(java.math.BigInteger version) {
        this.version = version;
    }


    /**
     * Gets the location value for this Conference.
     * 
     * @return location
     */
    public java.lang.String getLocation() {
        return location;
    }


    /**
     * Sets the location value for this Conference.
     * 
     * @param location
     */
    public void setLocation(java.lang.String location) {
        this.location = location;
    }


    /**
     * Gets the invitees value for this Conference.
     * 
     * @return invitees
     */
    public java.lang.String getInvitees() {
        return invitees;
    }


    /**
     * Sets the invitees value for this Conference.
     * 
     * @param invitees
     */
    public void setInvitees(java.lang.String invitees) {
        this.invitees = invitees;
    }


    /**
     * Gets the secretCode value for this Conference.
     * 
     * @return secretCode
     */
    public java.lang.String getSecretCode() {
        return secretCode;
    }


    /**
     * Sets the secretCode value for this Conference.
     * 
     * @param secretCode
     */
    public void setSecretCode(java.lang.String secretCode) {
        this.secretCode = secretCode;
    }


    /**
     * Gets the meetingSource value for this Conference.
     * 
     * @return meetingSource
     */
    public java.lang.String getMeetingSource() {
        return meetingSource;
    }


    /**
     * Sets the meetingSource value for this Conference.
     * 
     * @param meetingSource
     */
    public void setMeetingSource(java.lang.String meetingSource) {
        this.meetingSource = meetingSource;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Conference)) return false;
        Conference other = (Conference) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.conferenceId == other.getConferenceId() &&
            ((this.title==null && other.getTitle()==null) || 
             (this.title!=null &&
              this.title.equals(other.getTitle()))) &&
            ((this.startTimeUTC==null && other.getStartTimeUTC()==null) || 
             (this.startTimeUTC!=null &&
              this.startTimeUTC.equals(other.getStartTimeUTC()))) &&
            ((this.endTimeUTC==null && other.getEndTimeUTC()==null) || 
             (this.endTimeUTC!=null &&
              this.endTimeUTC.equals(other.getEndTimeUTC()))) &&
            ((this.recurrenceInstanceIdUTC==null && other.getRecurrenceInstanceIdUTC()==null) || 
             (this.recurrenceInstanceIdUTC!=null &&
              this.recurrenceInstanceIdUTC.equals(other.getRecurrenceInstanceIdUTC()))) &&
            ((this.recurrenceInstanceType==null && other.getRecurrenceInstanceType()==null) || 
             (this.recurrenceInstanceType!=null &&
              this.recurrenceInstanceType.equals(other.getRecurrenceInstanceType()))) &&
            ((this.firstOccurrenceRecInstanceIdUTC==null && other.getFirstOccurrenceRecInstanceIdUTC()==null) || 
             (this.firstOccurrenceRecInstanceIdUTC!=null &&
              this.firstOccurrenceRecInstanceIdUTC.equals(other.getFirstOccurrenceRecInstanceIdUTC()))) &&
            ((this.recurrencePattern==null && other.getRecurrencePattern()==null) || 
             (this.recurrencePattern!=null &&
              this.recurrencePattern.equals(other.getRecurrencePattern()))) &&
            this.ownerId == other.getOwnerId() &&
            ((this.ownerUserName==null && other.getOwnerUserName()==null) || 
             (this.ownerUserName!=null &&
              this.ownerUserName.equals(other.getOwnerUserName()))) &&
            ((this.ownerFirstName==null && other.getOwnerFirstName()==null) || 
             (this.ownerFirstName!=null &&
              this.ownerFirstName.equals(other.getOwnerFirstName()))) &&
            ((this.ownerLastName==null && other.getOwnerLastName()==null) || 
             (this.ownerLastName!=null &&
              this.ownerLastName.equals(other.getOwnerLastName()))) &&
            ((this.ownerEmailAddress==null && other.getOwnerEmailAddress()==null) || 
             (this.ownerEmailAddress!=null &&
              this.ownerEmailAddress.equals(other.getOwnerEmailAddress()))) &&
            ((this.conferenceType==null && other.getConferenceType()==null) || 
             (this.conferenceType!=null &&
              this.conferenceType.equals(other.getConferenceType()))) &&
            ((this.bandwidth==null && other.getBandwidth()==null) || 
             (this.bandwidth!=null &&
              this.bandwidth.equals(other.getBandwidth()))) &&
            ((this.pictureMode==null && other.getPictureMode()==null) || 
             (this.pictureMode!=null &&
              this.pictureMode.equals(other.getPictureMode()))) &&
            ((this.encrypted==null && other.getEncrypted()==null) || 
             (this.encrypted!=null &&
              this.encrypted.equals(other.getEncrypted()))) &&
            ((this.dataConference==null && other.getDataConference()==null) || 
             (this.dataConference!=null &&
              this.dataConference.equals(other.getDataConference()))) &&
            ((this.showExtendOption==null && other.getShowExtendOption()==null) || 
             (this.showExtendOption!=null &&
              this.showExtendOption.equals(other.getShowExtendOption()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.billingCode==null && other.getBillingCode()==null) || 
             (this.billingCode!=null &&
              this.billingCode.equals(other.getBillingCode()))) &&
            this.ISDNRestrict == other.isISDNRestrict() &&
            ((this.externalConference==null && other.getExternalConference()==null) || 
             (this.externalConference!=null &&
              this.externalConference.equals(other.getExternalConference()))) &&
            ((this.emailTo==null && other.getEmailTo()==null) || 
             (this.emailTo!=null &&
              this.emailTo.equals(other.getEmailTo()))) &&
            ((this.confBundleId==null && other.getConfBundleId()==null) || 
             (this.confBundleId!=null &&
              this.confBundleId.equals(other.getConfBundleId()))) &&
            ((this.confOwnerId==null && other.getConfOwnerId()==null) || 
             (this.confOwnerId!=null &&
              this.confOwnerId.equals(other.getConfOwnerId()))) &&
            ((this.conferenceInfoText==null && other.getConferenceInfoText()==null) || 
             (this.conferenceInfoText!=null &&
              this.conferenceInfoText.equals(other.getConferenceInfoText()))) &&
            ((this.conferenceInfoHtml==null && other.getConferenceInfoHtml()==null) || 
             (this.conferenceInfoHtml!=null &&
              this.conferenceInfoHtml.equals(other.getConferenceInfoHtml()))) &&
            ((this.userMessageText==null && other.getUserMessageText()==null) || 
             (this.userMessageText!=null &&
              this.userMessageText.equals(other.getUserMessageText()))) &&
            ((this.externalSourceId==null && other.getExternalSourceId()==null) || 
             (this.externalSourceId!=null &&
              this.externalSourceId.equals(other.getExternalSourceId()))) &&
            ((this.externalPrimaryKey==null && other.getExternalPrimaryKey()==null) || 
             (this.externalPrimaryKey!=null &&
              this.externalPrimaryKey.equals(other.getExternalPrimaryKey()))) &&
            ((this.detachedFromExternalSourceId==null && other.getDetachedFromExternalSourceId()==null) || 
             (this.detachedFromExternalSourceId!=null &&
              this.detachedFromExternalSourceId.equals(other.getDetachedFromExternalSourceId()))) &&
            ((this.detachedFromExternalPrimaryKey==null && other.getDetachedFromExternalPrimaryKey()==null) || 
             (this.detachedFromExternalPrimaryKey!=null &&
              this.detachedFromExternalPrimaryKey.equals(other.getDetachedFromExternalPrimaryKey()))) &&
            ((this.participants==null && other.getParticipants()==null) || 
             (this.participants!=null &&
              java.util.Arrays.equals(this.participants, other.getParticipants()))) &&
            ((this.recordedConferenceUri==null && other.getRecordedConferenceUri()==null) || 
             (this.recordedConferenceUri!=null &&
              this.recordedConferenceUri.equals(other.getRecordedConferenceUri()))) &&
            ((this.webConferencePresenterUri==null && other.getWebConferencePresenterUri()==null) || 
             (this.webConferencePresenterUri!=null &&
              this.webConferencePresenterUri.equals(other.getWebConferencePresenterUri()))) &&
            ((this.webConferenceAttendeeUri==null && other.getWebConferenceAttendeeUri()==null) || 
             (this.webConferenceAttendeeUri!=null &&
              this.webConferenceAttendeeUri.equals(other.getWebConferenceAttendeeUri()))) &&
            ((this.ISDNBandwidth==null && other.getISDNBandwidth()==null) || 
             (this.ISDNBandwidth!=null &&
              this.ISDNBandwidth.equals(other.getISDNBandwidth()))) &&
            ((this.IPBandwidth==null && other.getIPBandwidth()==null) || 
             (this.IPBandwidth!=null &&
              this.IPBandwidth.equals(other.getIPBandwidth()))) &&
            ((this.conferenceLanguage==null && other.getConferenceLanguage()==null) || 
             (this.conferenceLanguage!=null &&
              this.conferenceLanguage.equals(other.getConferenceLanguage()))) &&
            ((this.conferenceTimeZoneRules==null && other.getConferenceTimeZoneRules()==null) || 
             (this.conferenceTimeZoneRules!=null &&
              java.util.Arrays.equals(this.conferenceTimeZoneRules, other.getConferenceTimeZoneRules()))) &&
            ((this.conferenceState==null && other.getConferenceState()==null) || 
             (this.conferenceState!=null &&
              this.conferenceState.equals(other.getConferenceState()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion()))) &&
            ((this.location==null && other.getLocation()==null) || 
             (this.location!=null &&
              this.location.equals(other.getLocation()))) &&
            ((this.invitees==null && other.getInvitees()==null) || 
             (this.invitees!=null &&
              this.invitees.equals(other.getInvitees()))) &&
            ((this.secretCode==null && other.getSecretCode()==null) || 
             (this.secretCode!=null &&
              this.secretCode.equals(other.getSecretCode()))) &&
            ((this.meetingSource==null && other.getMeetingSource()==null) || 
             (this.meetingSource!=null &&
              this.meetingSource.equals(other.getMeetingSource())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getConferenceId();
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        if (getStartTimeUTC() != null) {
            _hashCode += getStartTimeUTC().hashCode();
        }
        if (getEndTimeUTC() != null) {
            _hashCode += getEndTimeUTC().hashCode();
        }
        if (getRecurrenceInstanceIdUTC() != null) {
            _hashCode += getRecurrenceInstanceIdUTC().hashCode();
        }
        if (getRecurrenceInstanceType() != null) {
            _hashCode += getRecurrenceInstanceType().hashCode();
        }
        if (getFirstOccurrenceRecInstanceIdUTC() != null) {
            _hashCode += getFirstOccurrenceRecInstanceIdUTC().hashCode();
        }
        if (getRecurrencePattern() != null) {
            _hashCode += getRecurrencePattern().hashCode();
        }
        _hashCode += new Long(getOwnerId()).hashCode();
        if (getOwnerUserName() != null) {
            _hashCode += getOwnerUserName().hashCode();
        }
        if (getOwnerFirstName() != null) {
            _hashCode += getOwnerFirstName().hashCode();
        }
        if (getOwnerLastName() != null) {
            _hashCode += getOwnerLastName().hashCode();
        }
        if (getOwnerEmailAddress() != null) {
            _hashCode += getOwnerEmailAddress().hashCode();
        }
        if (getConferenceType() != null) {
            _hashCode += getConferenceType().hashCode();
        }
        if (getBandwidth() != null) {
            _hashCode += getBandwidth().hashCode();
        }
        if (getPictureMode() != null) {
            _hashCode += getPictureMode().hashCode();
        }
        if (getEncrypted() != null) {
            _hashCode += getEncrypted().hashCode();
        }
        if (getDataConference() != null) {
            _hashCode += getDataConference().hashCode();
        }
        if (getShowExtendOption() != null) {
            _hashCode += getShowExtendOption().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getBillingCode() != null) {
            _hashCode += getBillingCode().hashCode();
        }
        _hashCode += (isISDNRestrict() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getExternalConference() != null) {
            _hashCode += getExternalConference().hashCode();
        }
        if (getEmailTo() != null) {
            _hashCode += getEmailTo().hashCode();
        }
        if (getConfBundleId() != null) {
            _hashCode += getConfBundleId().hashCode();
        }
        if (getConfOwnerId() != null) {
            _hashCode += getConfOwnerId().hashCode();
        }
        if (getConferenceInfoText() != null) {
            _hashCode += getConferenceInfoText().hashCode();
        }
        if (getConferenceInfoHtml() != null) {
            _hashCode += getConferenceInfoHtml().hashCode();
        }
        if (getUserMessageText() != null) {
            _hashCode += getUserMessageText().hashCode();
        }
        if (getExternalSourceId() != null) {
            _hashCode += getExternalSourceId().hashCode();
        }
        if (getExternalPrimaryKey() != null) {
            _hashCode += getExternalPrimaryKey().hashCode();
        }
        if (getDetachedFromExternalSourceId() != null) {
            _hashCode += getDetachedFromExternalSourceId().hashCode();
        }
        if (getDetachedFromExternalPrimaryKey() != null) {
            _hashCode += getDetachedFromExternalPrimaryKey().hashCode();
        }
        if (getParticipants() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getParticipants());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getParticipants(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getRecordedConferenceUri() != null) {
            _hashCode += getRecordedConferenceUri().hashCode();
        }
        if (getWebConferencePresenterUri() != null) {
            _hashCode += getWebConferencePresenterUri().hashCode();
        }
        if (getWebConferenceAttendeeUri() != null) {
            _hashCode += getWebConferenceAttendeeUri().hashCode();
        }
        if (getISDNBandwidth() != null) {
            _hashCode += getISDNBandwidth().hashCode();
        }
        if (getIPBandwidth() != null) {
            _hashCode += getIPBandwidth().hashCode();
        }
        if (getConferenceLanguage() != null) {
            _hashCode += getConferenceLanguage().hashCode();
        }
        if (getConferenceTimeZoneRules() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getConferenceTimeZoneRules());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getConferenceTimeZoneRules(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getConferenceState() != null) {
            _hashCode += getConferenceState().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        if (getLocation() != null) {
            _hashCode += getLocation().hashCode();
        }
        if (getInvitees() != null) {
            _hashCode += getInvitees().hashCode();
        }
        if (getSecretCode() != null) {
            _hashCode += getSecretCode().hashCode();
        }
        if (getMeetingSource() != null) {
            _hashCode += getMeetingSource().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Conference.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startTimeUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "StartTimeUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("endTimeUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EndTimeUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrenceInstanceIdUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceInstanceIdUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrenceInstanceType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceInstanceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("firstOccurrenceRecInstanceIdUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "FirstOccurrenceRecInstanceIdUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrencePattern");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrencePattern"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrencePattern"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerUserName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnerUserName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerFirstName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnerFirstName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerLastName");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnerLastName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerEmailAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "OwnerEmailAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bandwidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Bandwidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Bandwidth"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("pictureMode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PictureMode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PictureMode"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encrypted");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Encrypted"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EncryptionRequested"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataConference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DataConference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DataConferenceMode"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("showExtendOption");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ShowExtendOption"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExtendOptionRequested"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("billingCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BillingCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ISDNRestrict");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ISDNRestrict"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalConference");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConference"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalConference"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailTo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EmailTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("confBundleId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConfBundleId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("confOwnerId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConfOwnerId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceInfoText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceInfoText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceInfoHtml");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceInfoHtml"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userMessageText");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "UserMessageText"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalSourceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalPrimaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalPrimaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detachedFromExternalSourceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DetachedFromExternalSourceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detachedFromExternalPrimaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "DetachedFromExternalPrimaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participants");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participants"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recordedConferenceUri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecordedConferenceUri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webConferencePresenterUri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebConferencePresenterUri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("webConferenceAttendeeUri");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "WebConferenceAttendeeUri"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ISDNBandwidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ISDNBandwidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BandwidthOverride"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("IPBandwidth");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "IPBandwidth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "BandwidthOverride"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceLanguage");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceLanguage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceTimeZoneRules");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTimeZoneRules"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TimeZoneRule"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conferenceState");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceState"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Location"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("invitees");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Invitees"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("secretCode");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "SecretCode"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("meetingSource");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "MeetingSource"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
