/**
 * Bandwidth.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class Bandwidth implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected Bandwidth(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "1b/64kbps";
    public static final java.lang.String _value2 = "2b/128kbps";
    public static final java.lang.String _value3 = "3b/192kbps";
    public static final java.lang.String _value4 = "4b/256kbps";
    public static final java.lang.String _value5 = "5b/320kbps";
    public static final java.lang.String _value6 = "6b/384kbps";
    public static final java.lang.String _value7 = "8b/512kbps";
    public static final java.lang.String _value8 = "12b/768kbps";
    public static final java.lang.String _value9 = "18b/1152kbps";
    public static final java.lang.String _value10 = "23b/1472kbps";
    public static final java.lang.String _value11 = "30b/1920kbps";
    public static final java.lang.String _value12 = "32b/2048kbps";
    public static final java.lang.String _value13 = "48b/3072kbps";
    public static final java.lang.String _value14 = "64b/4096kbps";
    public static final java.lang.String _value15 = "7b/448kbps";
    public static final java.lang.String _value16 = "40b/2560kbps";
    public static final java.lang.String _value17 = "96b/6144kbps";
    public static final java.lang.String _value18 = "Max";
    public static final java.lang.String _value19 = "6000kbps";
    public static final java.lang.String _value20 = "Default";
    public static final Bandwidth value1 = new Bandwidth(_value1);
    public static final Bandwidth value2 = new Bandwidth(_value2);
    public static final Bandwidth value3 = new Bandwidth(_value3);
    public static final Bandwidth value4 = new Bandwidth(_value4);
    public static final Bandwidth value5 = new Bandwidth(_value5);
    public static final Bandwidth value6 = new Bandwidth(_value6);
    public static final Bandwidth value7 = new Bandwidth(_value7);
    public static final Bandwidth value8 = new Bandwidth(_value8);
    public static final Bandwidth value9 = new Bandwidth(_value9);
    public static final Bandwidth value10 = new Bandwidth(_value10);
    public static final Bandwidth value11 = new Bandwidth(_value11);
    public static final Bandwidth value12 = new Bandwidth(_value12);
    public static final Bandwidth value13 = new Bandwidth(_value13);
    public static final Bandwidth value14 = new Bandwidth(_value14);
    public static final Bandwidth value15 = new Bandwidth(_value15);
    public static final Bandwidth value16 = new Bandwidth(_value16);
    public static final Bandwidth value17 = new Bandwidth(_value17);
    public static final Bandwidth value18 = new Bandwidth(_value18);
    public static final Bandwidth value19 = new Bandwidth(_value19);
    public static final Bandwidth value20 = new Bandwidth(_value20);
    public java.lang.String getValue() { return _value_;}
    public static Bandwidth fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        Bandwidth enumeration = (Bandwidth)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static Bandwidth fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Bandwidth.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Bandwidth"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
