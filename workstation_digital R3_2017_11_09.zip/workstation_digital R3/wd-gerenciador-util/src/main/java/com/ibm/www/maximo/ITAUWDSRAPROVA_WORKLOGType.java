/**
 * ITAUWDSRAPROVA_WORKLOGType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRAPROVA_WORKLOGType  implements java.io.Serializable {
    private com.ibm.www.maximo.MXBooleanType CLIENTVIEWABLE;

    private com.ibm.www.maximo.MXStringType CREATEBY;

    private com.ibm.www.maximo.MXDateTimeType CREATEDATE;

    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION;

    private com.ibm.www.maximo.MXDomainType LOGTYPE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType WORKLOGID;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDSRAPROVA_WORKLOGType() {
    }

    public ITAUWDSRAPROVA_WORKLOGType(
           com.ibm.www.maximo.MXBooleanType CLIENTVIEWABLE,
           com.ibm.www.maximo.MXStringType CREATEBY,
           com.ibm.www.maximo.MXDateTimeType CREATEDATE,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION,
           com.ibm.www.maximo.MXDomainType LOGTYPE,
           com.ibm.www.maximo.MXLongType WORKLOGID,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.CLIENTVIEWABLE = CLIENTVIEWABLE;
           this.CREATEBY = CREATEBY;
           this.CREATEDATE = CREATEDATE;
           this.DESCRIPTION = DESCRIPTION;
           this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
           this.LOGTYPE = LOGTYPE;
           this.WORKLOGID = WORKLOGID;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the CLIENTVIEWABLE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return CLIENTVIEWABLE
     */
    public com.ibm.www.maximo.MXBooleanType getCLIENTVIEWABLE() {
        return CLIENTVIEWABLE;
    }


    /**
     * Sets the CLIENTVIEWABLE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param CLIENTVIEWABLE
     */
    public void setCLIENTVIEWABLE(com.ibm.www.maximo.MXBooleanType CLIENTVIEWABLE) {
        this.CLIENTVIEWABLE = CLIENTVIEWABLE;
    }


    /**
     * Gets the CREATEBY value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return CREATEBY
     */
    public com.ibm.www.maximo.MXStringType getCREATEBY() {
        return CREATEBY;
    }


    /**
     * Sets the CREATEBY value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param CREATEBY
     */
    public void setCREATEBY(com.ibm.www.maximo.MXStringType CREATEBY) {
        this.CREATEBY = CREATEBY;
    }


    /**
     * Gets the CREATEDATE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return CREATEDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getCREATEDATE() {
        return CREATEDATE;
    }


    /**
     * Sets the CREATEDATE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param CREATEDATE
     */
    public void setCREATEDATE(com.ibm.www.maximo.MXDateTimeType CREATEDATE) {
        this.CREATEDATE = CREATEDATE;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return DESCRIPTION_LONGDESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION_LONGDESCRIPTION() {
        return DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param DESCRIPTION_LONGDESCRIPTION
     */
    public void setDESCRIPTION_LONGDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION) {
        this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Gets the LOGTYPE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return LOGTYPE
     */
    public com.ibm.www.maximo.MXDomainType getLOGTYPE() {
        return LOGTYPE;
    }


    /**
     * Sets the LOGTYPE value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param LOGTYPE
     */
    public void setLOGTYPE(com.ibm.www.maximo.MXDomainType LOGTYPE) {
        this.LOGTYPE = LOGTYPE;
    }


    /**
     * Gets the WORKLOGID value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return WORKLOGID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getWORKLOGID() {
        return WORKLOGID;
    }


    /**
     * Sets the WORKLOGID value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param WORKLOGID   * Unique Key Component
     */
    public void setWORKLOGID(com.ibm.www.maximo.MXLongType WORKLOGID) {
        this.WORKLOGID = WORKLOGID;
    }


    /**
     * Gets the action value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSRAPROVA_WORKLOGType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRAPROVA_WORKLOGType)) return false;
        ITAUWDSRAPROVA_WORKLOGType other = (ITAUWDSRAPROVA_WORKLOGType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLIENTVIEWABLE==null && other.getCLIENTVIEWABLE()==null) || 
             (this.CLIENTVIEWABLE!=null &&
              this.CLIENTVIEWABLE.equals(other.getCLIENTVIEWABLE()))) &&
            ((this.CREATEBY==null && other.getCREATEBY()==null) || 
             (this.CREATEBY!=null &&
              this.CREATEBY.equals(other.getCREATEBY()))) &&
            ((this.CREATEDATE==null && other.getCREATEDATE()==null) || 
             (this.CREATEDATE!=null &&
              this.CREATEDATE.equals(other.getCREATEDATE()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.DESCRIPTION_LONGDESCRIPTION==null && other.getDESCRIPTION_LONGDESCRIPTION()==null) || 
             (this.DESCRIPTION_LONGDESCRIPTION!=null &&
              this.DESCRIPTION_LONGDESCRIPTION.equals(other.getDESCRIPTION_LONGDESCRIPTION()))) &&
            ((this.LOGTYPE==null && other.getLOGTYPE()==null) || 
             (this.LOGTYPE!=null &&
              this.LOGTYPE.equals(other.getLOGTYPE()))) &&
            ((this.WORKLOGID==null && other.getWORKLOGID()==null) || 
             (this.WORKLOGID!=null &&
              this.WORKLOGID.equals(other.getWORKLOGID()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLIENTVIEWABLE() != null) {
            _hashCode += getCLIENTVIEWABLE().hashCode();
        }
        if (getCREATEBY() != null) {
            _hashCode += getCREATEBY().hashCode();
        }
        if (getCREATEDATE() != null) {
            _hashCode += getCREATEDATE().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getDESCRIPTION_LONGDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION_LONGDESCRIPTION().hashCode();
        }
        if (getLOGTYPE() != null) {
            _hashCode += getLOGTYPE().hashCode();
        }
        if (getWORKLOGID() != null) {
            _hashCode += getWORKLOGID().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRAPROVA_WORKLOGType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVA_WORKLOGType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLIENTVIEWABLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLIENTVIEWABLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION_LONGDESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION_LONGDESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("LOGTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "LOGTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKLOGID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKLOGID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
