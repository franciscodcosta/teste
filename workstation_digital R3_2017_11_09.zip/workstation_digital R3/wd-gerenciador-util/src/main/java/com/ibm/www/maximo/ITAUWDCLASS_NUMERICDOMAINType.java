/**
 * ITAUWDCLASS_NUMERICDOMAINType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDCLASS_NUMERICDOMAINType  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType DOMAINID;

    private com.ibm.www.maximo.MXLongType NUMERICDOMAINID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType PLUSPCUSTOMER;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXDoubleType VALUE;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDCLASS_NUMERICDOMAINType() {
    }

    public ITAUWDCLASS_NUMERICDOMAINType(
           com.ibm.www.maximo.MXStringType DOMAINID,
           com.ibm.www.maximo.MXLongType NUMERICDOMAINID,
           com.ibm.www.maximo.MXStringType PLUSPCUSTOMER,
           com.ibm.www.maximo.MXDoubleType VALUE,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.DOMAINID = DOMAINID;
           this.NUMERICDOMAINID = NUMERICDOMAINID;
           this.PLUSPCUSTOMER = PLUSPCUSTOMER;
           this.VALUE = VALUE;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the DOMAINID value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return DOMAINID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getDOMAINID() {
        return DOMAINID;
    }


    /**
     * Sets the DOMAINID value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param DOMAINID   * Unique Key Component
     */
    public void setDOMAINID(com.ibm.www.maximo.MXStringType DOMAINID) {
        this.DOMAINID = DOMAINID;
    }


    /**
     * Gets the NUMERICDOMAINID value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return NUMERICDOMAINID
     */
    public com.ibm.www.maximo.MXLongType getNUMERICDOMAINID() {
        return NUMERICDOMAINID;
    }


    /**
     * Sets the NUMERICDOMAINID value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param NUMERICDOMAINID
     */
    public void setNUMERICDOMAINID(com.ibm.www.maximo.MXLongType NUMERICDOMAINID) {
        this.NUMERICDOMAINID = NUMERICDOMAINID;
    }


    /**
     * Gets the PLUSPCUSTOMER value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return PLUSPCUSTOMER   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getPLUSPCUSTOMER() {
        return PLUSPCUSTOMER;
    }


    /**
     * Sets the PLUSPCUSTOMER value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param PLUSPCUSTOMER   * Unique Key Component
     */
    public void setPLUSPCUSTOMER(com.ibm.www.maximo.MXStringType PLUSPCUSTOMER) {
        this.PLUSPCUSTOMER = PLUSPCUSTOMER;
    }


    /**
     * Gets the VALUE value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return VALUE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDoubleType getVALUE() {
        return VALUE;
    }


    /**
     * Sets the VALUE value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param VALUE   * Unique Key Component
     */
    public void setVALUE(com.ibm.www.maximo.MXDoubleType VALUE) {
        this.VALUE = VALUE;
    }


    /**
     * Gets the action value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDCLASS_NUMERICDOMAINType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDCLASS_NUMERICDOMAINType)) return false;
        ITAUWDCLASS_NUMERICDOMAINType other = (ITAUWDCLASS_NUMERICDOMAINType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DOMAINID==null && other.getDOMAINID()==null) || 
             (this.DOMAINID!=null &&
              this.DOMAINID.equals(other.getDOMAINID()))) &&
            ((this.NUMERICDOMAINID==null && other.getNUMERICDOMAINID()==null) || 
             (this.NUMERICDOMAINID!=null &&
              this.NUMERICDOMAINID.equals(other.getNUMERICDOMAINID()))) &&
            ((this.PLUSPCUSTOMER==null && other.getPLUSPCUSTOMER()==null) || 
             (this.PLUSPCUSTOMER!=null &&
              this.PLUSPCUSTOMER.equals(other.getPLUSPCUSTOMER()))) &&
            ((this.VALUE==null && other.getVALUE()==null) || 
             (this.VALUE!=null &&
              this.VALUE.equals(other.getVALUE()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDOMAINID() != null) {
            _hashCode += getDOMAINID().hashCode();
        }
        if (getNUMERICDOMAINID() != null) {
            _hashCode += getNUMERICDOMAINID().hashCode();
        }
        if (getPLUSPCUSTOMER() != null) {
            _hashCode += getPLUSPCUSTOMER().hashCode();
        }
        if (getVALUE() != null) {
            _hashCode += getVALUE().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDCLASS_NUMERICDOMAINType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDCLASS_NUMERICDOMAINType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOMAINID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOMAINID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NUMERICDOMAINID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NUMERICDOMAINID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PLUSPCUSTOMER");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "PLUSPCUSTOMER"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("VALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "VALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDoubleType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
