/**
 * ITAUWDLISTSWQueryType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDLISTSWQueryType  implements java.io.Serializable {
    private java.lang.String WHERE;

    private com.ibm.www.maximo.ITAUWDLISTSWQueryTypeITAU_SWSISTEMA ITAU_SWSISTEMA;

    private java.lang.String orderby;  // attribute

    private com.ibm.www.maximo.OperandModeType operandMode;  // attribute

    public ITAUWDLISTSWQueryType() {
    }

    public ITAUWDLISTSWQueryType(
           java.lang.String WHERE,
           com.ibm.www.maximo.ITAUWDLISTSWQueryTypeITAU_SWSISTEMA ITAU_SWSISTEMA,
           java.lang.String orderby,
           com.ibm.www.maximo.OperandModeType operandMode) {
           this.WHERE = WHERE;
           this.ITAU_SWSISTEMA = ITAU_SWSISTEMA;
           this.orderby = orderby;
           this.operandMode = operandMode;
    }


    /**
     * Gets the WHERE value for this ITAUWDLISTSWQueryType.
     * 
     * @return WHERE
     */
    public java.lang.String getWHERE() {
        return WHERE;
    }


    /**
     * Sets the WHERE value for this ITAUWDLISTSWQueryType.
     * 
     * @param WHERE
     */
    public void setWHERE(java.lang.String WHERE) {
        this.WHERE = WHERE;
    }


    /**
     * Gets the ITAU_SWSISTEMA value for this ITAUWDLISTSWQueryType.
     * 
     * @return ITAU_SWSISTEMA
     */
    public com.ibm.www.maximo.ITAUWDLISTSWQueryTypeITAU_SWSISTEMA getITAU_SWSISTEMA() {
        return ITAU_SWSISTEMA;
    }


    /**
     * Sets the ITAU_SWSISTEMA value for this ITAUWDLISTSWQueryType.
     * 
     * @param ITAU_SWSISTEMA
     */
    public void setITAU_SWSISTEMA(com.ibm.www.maximo.ITAUWDLISTSWQueryTypeITAU_SWSISTEMA ITAU_SWSISTEMA) {
        this.ITAU_SWSISTEMA = ITAU_SWSISTEMA;
    }


    /**
     * Gets the orderby value for this ITAUWDLISTSWQueryType.
     * 
     * @return orderby
     */
    public java.lang.String getOrderby() {
        return orderby;
    }


    /**
     * Sets the orderby value for this ITAUWDLISTSWQueryType.
     * 
     * @param orderby
     */
    public void setOrderby(java.lang.String orderby) {
        this.orderby = orderby;
    }


    /**
     * Gets the operandMode value for this ITAUWDLISTSWQueryType.
     * 
     * @return operandMode
     */
    public com.ibm.www.maximo.OperandModeType getOperandMode() {
        return operandMode;
    }


    /**
     * Sets the operandMode value for this ITAUWDLISTSWQueryType.
     * 
     * @param operandMode
     */
    public void setOperandMode(com.ibm.www.maximo.OperandModeType operandMode) {
        this.operandMode = operandMode;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDLISTSWQueryType)) return false;
        ITAUWDLISTSWQueryType other = (ITAUWDLISTSWQueryType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.WHERE==null && other.getWHERE()==null) || 
             (this.WHERE!=null &&
              this.WHERE.equals(other.getWHERE()))) &&
            ((this.ITAU_SWSISTEMA==null && other.getITAU_SWSISTEMA()==null) || 
             (this.ITAU_SWSISTEMA!=null &&
              this.ITAU_SWSISTEMA.equals(other.getITAU_SWSISTEMA()))) &&
            ((this.orderby==null && other.getOrderby()==null) || 
             (this.orderby!=null &&
              this.orderby.equals(other.getOrderby()))) &&
            ((this.operandMode==null && other.getOperandMode()==null) || 
             (this.operandMode!=null &&
              this.operandMode.equals(other.getOperandMode())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getWHERE() != null) {
            _hashCode += getWHERE().hashCode();
        }
        if (getITAU_SWSISTEMA() != null) {
            _hashCode += getITAU_SWSISTEMA().hashCode();
        }
        if (getOrderby() != null) {
            _hashCode += getOrderby().hashCode();
        }
        if (getOperandMode() != null) {
            _hashCode += getOperandMode().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDLISTSWQueryType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDLISTSWQueryType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("orderby");
        attrField.setXmlName(new javax.xml.namespace.QName("", "orderby"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("operandMode");
        attrField.setXmlName(new javax.xml.namespace.QName("", "operandMode"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OperandModeType"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WHERE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WHERE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_SWSISTEMA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_SWSISTEMA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDLISTSWQueryType>ITAU_SWSISTEMA"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
