package com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA;

public class ITAUWDWOAPROVAPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVAPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVAPortType iTAUWDWOAPROVAPortType = null;
  
  public ITAUWDWOAPROVAPortTypeProxy() {
    _initITAUWDWOAPROVAPortTypeProxy();
  }
  
  public ITAUWDWOAPROVAPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDWOAPROVAPortTypeProxy();
  }
  
  private void _initITAUWDWOAPROVAPortTypeProxy() {
    try {
      iTAUWDWOAPROVAPortType = (new com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVALocator()).getITAUWDWOAPROVASOAP11Port();
      if (iTAUWDWOAPROVAPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDWOAPROVAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDWOAPROVAPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDWOAPROVAPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDWOAPROVAPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA.ITAUWDWOAPROVAPortType getITAUWDWOAPROVAPortType() {
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDWOAPROVAResponseType queryITAUWDWOAPROVA(com.ibm.www.maximo.QueryITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType.queryITAUWDWOAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.SyncITAUWDWOAPROVAResponseType syncITAUWDWOAPROVA(com.ibm.www.maximo.SyncITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType.syncITAUWDWOAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.UpdateITAUWDWOAPROVAResponseType updateITAUWDWOAPROVA(com.ibm.www.maximo.UpdateITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType.updateITAUWDWOAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.CreateITAUWDWOAPROVAResponseType createITAUWDWOAPROVA(com.ibm.www.maximo.CreateITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType.createITAUWDWOAPROVA(parameters);
  }
  
  public com.ibm.www.maximo.DeleteITAUWDWOAPROVAResponseType deleteITAUWDWOAPROVA(com.ibm.www.maximo.DeleteITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException{
    if (iTAUWDWOAPROVAPortType == null)
      _initITAUWDWOAPROVAPortTypeProxy();
    return iTAUWDWOAPROVAPortType.deleteITAUWDWOAPROVA(parameters);
  }
  
  
}