/**
 * ITAUWDSRATUALIZAQueryTypeSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRATUALIZAQueryTypeSR  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainQueryType[] CLASS;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] TICKETID;

    private com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRWORKLOG WORKLOG;

    private com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRDOCLINKS DOCLINKS;

    public ITAUWDSRATUALIZAQueryTypeSR() {
    }

    public ITAUWDSRATUALIZAQueryTypeSR(
           com.ibm.www.maximo.MXDomainQueryType[] CLASS,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXStringQueryType[] TICKETID,
           com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRWORKLOG WORKLOG,
           com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRDOCLINKS DOCLINKS) {
           this.CLASS = CLASS;
           this.STATUS = STATUS;
           this.TICKETID = TICKETID;
           this.WORKLOG = WORKLOG;
           this.DOCLINKS = DOCLINKS;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainQueryType[] CLASS) {
        this.CLASS = CLASS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getCLASS(int i) {
        return this.CLASS[i];
    }

    public void setCLASS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.CLASS[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
        this.TICKETID = TICKETID;
    }

    public com.ibm.www.maximo.MXStringQueryType getTICKETID(int i) {
        return this.TICKETID[i];
    }

    public void setTICKETID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TICKETID[i] = _value;
    }


    /**
     * Gets the WORKLOG value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @return WORKLOG
     */
    public com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRWORKLOG getWORKLOG() {
        return WORKLOG;
    }


    /**
     * Sets the WORKLOG value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @param WORKLOG
     */
    public void setWORKLOG(com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRWORKLOG WORKLOG) {
        this.WORKLOG = WORKLOG;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRDOCLINKS getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDSRATUALIZAQueryTypeSR.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDSRATUALIZAQueryTypeSRDOCLINKS DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRATUALIZAQueryTypeSR)) return false;
        ITAUWDSRATUALIZAQueryTypeSR other = (ITAUWDSRATUALIZAQueryTypeSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              java.util.Arrays.equals(this.CLASS, other.getCLASS()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              java.util.Arrays.equals(this.TICKETID, other.getTICKETID()))) &&
            ((this.WORKLOG==null && other.getWORKLOG()==null) || 
             (this.WORKLOG!=null &&
              this.WORKLOG.equals(other.getWORKLOG()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              this.DOCLINKS.equals(other.getDOCLINKS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWORKLOG() != null) {
            _hashCode += getWORKLOG().hashCode();
        }
        if (getDOCLINKS() != null) {
            _hashCode += getDOCLINKS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRATUALIZAQueryTypeSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRATUALIZAQueryType>SR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKLOG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKLOG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRATUALIZAQueryType>SR>WORKLOG"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRATUALIZAQueryType>SR>DOCLINKS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
