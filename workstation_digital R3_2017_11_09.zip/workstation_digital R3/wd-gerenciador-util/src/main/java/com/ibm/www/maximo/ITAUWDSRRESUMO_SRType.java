/**
 * ITAUWDSRRESUMO_SRType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRRESUMO_SRType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainType CLASS;

    private com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK;

    private com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK;

    private com.ibm.www.maximo.MXBooleanType ITAU_GNSOK;

    private com.ibm.www.maximo.MXDateTimeType REPORTDATE;

    private com.ibm.www.maximo.MXStringType REPORTEDBY;

    private com.ibm.www.maximo.MXDomainType STATUS;

    private com.ibm.www.maximo.MXDateTimeType TARGETFINISH;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType TICKETID;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDSRRESUMO_SRType() {
    }

    public ITAUWDSRRESUMO_SRType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXDomainType CLASS,
           com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK,
           com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK,
           com.ibm.www.maximo.MXBooleanType ITAU_GNSOK,
           com.ibm.www.maximo.MXDateTimeType REPORTDATE,
           com.ibm.www.maximo.MXStringType REPORTEDBY,
           com.ibm.www.maximo.MXDomainType STATUS,
           com.ibm.www.maximo.MXDateTimeType TARGETFINISH,
           com.ibm.www.maximo.MXStringType TICKETID,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.CLASS = CLASS;
           this.ITAU_GDISPOK = ITAU_GDISPOK;
           this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
           this.ITAU_GNSOK = ITAU_GNSOK;
           this.REPORTDATE = REPORTDATE;
           this.REPORTEDBY = REPORTEDBY;
           this.STATUS = STATUS;
           this.TARGETFINISH = TARGETFINISH;
           this.TICKETID = TICKETID;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainType getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainType CLASS) {
        this.CLASS = CLASS;
    }


    /**
     * Gets the ITAU_GDISPOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return ITAU_GDISPOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GDISPOK() {
        return ITAU_GDISPOK;
    }


    /**
     * Sets the ITAU_GDISPOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param ITAU_GDISPOK
     */
    public void setITAU_GDISPOK(com.ibm.www.maximo.MXBooleanType ITAU_GDISPOK) {
        this.ITAU_GDISPOK = ITAU_GDISPOK;
    }


    /**
     * Gets the ITAU_GIQAGNSOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return ITAU_GIQAGNSOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GIQAGNSOK() {
        return ITAU_GIQAGNSOK;
    }


    /**
     * Sets the ITAU_GIQAGNSOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param ITAU_GIQAGNSOK
     */
    public void setITAU_GIQAGNSOK(com.ibm.www.maximo.MXBooleanType ITAU_GIQAGNSOK) {
        this.ITAU_GIQAGNSOK = ITAU_GIQAGNSOK;
    }


    /**
     * Gets the ITAU_GNSOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return ITAU_GNSOK
     */
    public com.ibm.www.maximo.MXBooleanType getITAU_GNSOK() {
        return ITAU_GNSOK;
    }


    /**
     * Sets the ITAU_GNSOK value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param ITAU_GNSOK
     */
    public void setITAU_GNSOK(com.ibm.www.maximo.MXBooleanType ITAU_GNSOK) {
        this.ITAU_GNSOK = ITAU_GNSOK;
    }


    /**
     * Gets the REPORTDATE value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return REPORTDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getREPORTDATE() {
        return REPORTDATE;
    }


    /**
     * Sets the REPORTDATE value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param REPORTDATE
     */
    public void setREPORTDATE(com.ibm.www.maximo.MXDateTimeType REPORTDATE) {
        this.REPORTDATE = REPORTDATE;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringType REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }


    /**
     * Gets the STATUS value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainType getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainType STATUS) {
        this.STATUS = STATUS;
    }


    /**
     * Gets the TARGETFINISH value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return TARGETFINISH
     */
    public com.ibm.www.maximo.MXDateTimeType getTARGETFINISH() {
        return TARGETFINISH;
    }


    /**
     * Sets the TARGETFINISH value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param TARGETFINISH
     */
    public void setTARGETFINISH(com.ibm.www.maximo.MXDateTimeType TARGETFINISH) {
        this.TARGETFINISH = TARGETFINISH;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringType TICKETID) {
        this.TICKETID = TICKETID;
    }


    /**
     * Gets the action value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDSRRESUMO_SRType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDSRRESUMO_SRType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRRESUMO_SRType)) return false;
        ITAUWDSRRESUMO_SRType other = (ITAUWDSRRESUMO_SRType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              this.CLASS.equals(other.getCLASS()))) &&
            ((this.ITAU_GDISPOK==null && other.getITAU_GDISPOK()==null) || 
             (this.ITAU_GDISPOK!=null &&
              this.ITAU_GDISPOK.equals(other.getITAU_GDISPOK()))) &&
            ((this.ITAU_GIQAGNSOK==null && other.getITAU_GIQAGNSOK()==null) || 
             (this.ITAU_GIQAGNSOK!=null &&
              this.ITAU_GIQAGNSOK.equals(other.getITAU_GIQAGNSOK()))) &&
            ((this.ITAU_GNSOK==null && other.getITAU_GNSOK()==null) || 
             (this.ITAU_GNSOK!=null &&
              this.ITAU_GNSOK.equals(other.getITAU_GNSOK()))) &&
            ((this.REPORTDATE==null && other.getREPORTDATE()==null) || 
             (this.REPORTDATE!=null &&
              this.REPORTDATE.equals(other.getREPORTDATE()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              this.REPORTEDBY.equals(other.getREPORTEDBY()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS()))) &&
            ((this.TARGETFINISH==null && other.getTARGETFINISH()==null) || 
             (this.TARGETFINISH!=null &&
              this.TARGETFINISH.equals(other.getTARGETFINISH()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              this.TICKETID.equals(other.getTICKETID()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getCLASS() != null) {
            _hashCode += getCLASS().hashCode();
        }
        if (getITAU_GDISPOK() != null) {
            _hashCode += getITAU_GDISPOK().hashCode();
        }
        if (getITAU_GIQAGNSOK() != null) {
            _hashCode += getITAU_GIQAGNSOK().hashCode();
        }
        if (getITAU_GNSOK() != null) {
            _hashCode += getITAU_GNSOK().hashCode();
        }
        if (getREPORTDATE() != null) {
            _hashCode += getREPORTDATE().hashCode();
        }
        if (getREPORTEDBY() != null) {
            _hashCode += getREPORTEDBY().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        if (getTARGETFINISH() != null) {
            _hashCode += getTARGETFINISH().hashCode();
        }
        if (getTICKETID() != null) {
            _hashCode += getTICKETID().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRRESUMO_SRType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRRESUMO_SRType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GDISPOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GDISPOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GIQAGNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GIQAGNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_GNSOK");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_GNSOK"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TARGETFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TARGETFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
