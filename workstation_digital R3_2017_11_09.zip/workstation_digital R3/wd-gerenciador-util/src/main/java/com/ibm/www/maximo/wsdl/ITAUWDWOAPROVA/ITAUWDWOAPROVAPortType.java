/**
 * ITAUWDWOAPROVAPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDWOAPROVA;

public interface ITAUWDWOAPROVAPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDWOAPROVAResponseType queryITAUWDWOAPROVA(com.ibm.www.maximo.QueryITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.SyncITAUWDWOAPROVAResponseType syncITAUWDWOAPROVA(com.ibm.www.maximo.SyncITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.UpdateITAUWDWOAPROVAResponseType updateITAUWDWOAPROVA(com.ibm.www.maximo.UpdateITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.CreateITAUWDWOAPROVAResponseType createITAUWDWOAPROVA(com.ibm.www.maximo.CreateITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.DeleteITAUWDWOAPROVAResponseType deleteITAUWDWOAPROVA(com.ibm.www.maximo.DeleteITAUWDWOAPROVAType parameters) throws java.rmi.RemoteException;
}
