/**
 * DT_Aprovacao_out.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.itau.WorkstationDigital.Aprovacao_Documento;

public class DT_Aprovacao_out  implements java.io.Serializable {
    private java.lang.String chave_produto;

    private java.lang.String funcao_sistema_produto;

    private java.lang.String funcao_atividade_sistema_produto;

    private java.lang.String funcional_sistema_produto;

    private java.lang.String comentario;

    private java.lang.String token_oauth;

    public DT_Aprovacao_out() {
    }

    public DT_Aprovacao_out(
           java.lang.String chave_produto,
           java.lang.String funcao_sistema_produto,
           java.lang.String funcao_atividade_sistema_produto,
           java.lang.String funcional_sistema_produto,
           java.lang.String comentario,
           java.lang.String token_oauth) {
           this.chave_produto = chave_produto;
           this.funcao_sistema_produto = funcao_sistema_produto;
           this.funcao_atividade_sistema_produto = funcao_atividade_sistema_produto;
           this.funcional_sistema_produto = funcional_sistema_produto;
           this.comentario = comentario;
           this.token_oauth = token_oauth;
    }


    /**
     * Gets the chave_produto value for this DT_Aprovacao_out.
     * 
     * @return chave_produto
     */
    public java.lang.String getChave_produto() {
        return chave_produto;
    }


    /**
     * Sets the chave_produto value for this DT_Aprovacao_out.
     * 
     * @param chave_produto
     */
    public void setChave_produto(java.lang.String chave_produto) {
        this.chave_produto = chave_produto;
    }


    /**
     * Gets the funcao_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @return funcao_sistema_produto
     */
    public java.lang.String getFuncao_sistema_produto() {
        return funcao_sistema_produto;
    }


    /**
     * Sets the funcao_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @param funcao_sistema_produto
     */
    public void setFuncao_sistema_produto(java.lang.String funcao_sistema_produto) {
        this.funcao_sistema_produto = funcao_sistema_produto;
    }


    /**
     * Gets the funcao_atividade_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @return funcao_atividade_sistema_produto
     */
    public java.lang.String getFuncao_atividade_sistema_produto() {
        return funcao_atividade_sistema_produto;
    }


    /**
     * Sets the funcao_atividade_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @param funcao_atividade_sistema_produto
     */
    public void setFuncao_atividade_sistema_produto(java.lang.String funcao_atividade_sistema_produto) {
        this.funcao_atividade_sistema_produto = funcao_atividade_sistema_produto;
    }


    /**
     * Gets the funcional_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @return funcional_sistema_produto
     */
    public java.lang.String getFuncional_sistema_produto() {
        return funcional_sistema_produto;
    }


    /**
     * Sets the funcional_sistema_produto value for this DT_Aprovacao_out.
     * 
     * @param funcional_sistema_produto
     */
    public void setFuncional_sistema_produto(java.lang.String funcional_sistema_produto) {
        this.funcional_sistema_produto = funcional_sistema_produto;
    }


    /**
     * Gets the comentario value for this DT_Aprovacao_out.
     * 
     * @return comentario
     */
    public java.lang.String getComentario() {
        return comentario;
    }


    /**
     * Sets the comentario value for this DT_Aprovacao_out.
     * 
     * @param comentario
     */
    public void setComentario(java.lang.String comentario) {
        this.comentario = comentario;
    }


    /**
     * Gets the token_oauth value for this DT_Aprovacao_out.
     * 
     * @return token_oauth
     */
    public java.lang.String getToken_oauth() {
        return token_oauth;
    }


    /**
     * Sets the token_oauth value for this DT_Aprovacao_out.
     * 
     * @param token_oauth
     */
    public void setToken_oauth(java.lang.String token_oauth) {
        this.token_oauth = token_oauth;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DT_Aprovacao_out)) return false;
        DT_Aprovacao_out other = (DT_Aprovacao_out) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.chave_produto==null && other.getChave_produto()==null) || 
             (this.chave_produto!=null &&
              this.chave_produto.equals(other.getChave_produto()))) &&
            ((this.funcao_sistema_produto==null && other.getFuncao_sistema_produto()==null) || 
             (this.funcao_sistema_produto!=null &&
              this.funcao_sistema_produto.equals(other.getFuncao_sistema_produto()))) &&
            ((this.funcao_atividade_sistema_produto==null && other.getFuncao_atividade_sistema_produto()==null) || 
             (this.funcao_atividade_sistema_produto!=null &&
              this.funcao_atividade_sistema_produto.equals(other.getFuncao_atividade_sistema_produto()))) &&
            ((this.funcional_sistema_produto==null && other.getFuncional_sistema_produto()==null) || 
             (this.funcional_sistema_produto!=null &&
              this.funcional_sistema_produto.equals(other.getFuncional_sistema_produto()))) &&
            ((this.comentario==null && other.getComentario()==null) || 
             (this.comentario!=null &&
              this.comentario.equals(other.getComentario()))) &&
            ((this.token_oauth==null && other.getToken_oauth()==null) || 
             (this.token_oauth!=null &&
              this.token_oauth.equals(other.getToken_oauth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getChave_produto() != null) {
            _hashCode += getChave_produto().hashCode();
        }
        if (getFuncao_sistema_produto() != null) {
            _hashCode += getFuncao_sistema_produto().hashCode();
        }
        if (getFuncao_atividade_sistema_produto() != null) {
            _hashCode += getFuncao_atividade_sistema_produto().hashCode();
        }
        if (getFuncional_sistema_produto() != null) {
            _hashCode += getFuncional_sistema_produto().hashCode();
        }
        if (getComentario() != null) {
            _hashCode += getComentario().hashCode();
        }
        if (getToken_oauth() != null) {
            _hashCode += getToken_oauth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DT_Aprovacao_out.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://itau.com.br/WorkstationDigital/Aprovacao_Documento", "DT_Aprovacao_out"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chave_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "chave_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcao_sistema_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "funcao_sistema_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcao_atividade_sistema_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "funcao_atividade_sistema_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcional_sistema_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "funcional_sistema_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comentario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "comentario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("token_oauth");
        elemField.setXmlName(new javax.xml.namespace.QName("", "token_oauth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
