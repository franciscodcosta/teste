package br.com.itau.WorkstationDigital.Aprovacao_Documento;

public class SI_Aprovacao_outProxy implements br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_out {
  private String _endpoint = null;
  private br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_out sI_Aprovacao_out = null;
  
  public SI_Aprovacao_outProxy() {
    _initSI_Aprovacao_outProxy();
  }
  
  public SI_Aprovacao_outProxy(String endpoint) {
    _endpoint = endpoint;
    _initSI_Aprovacao_outProxy();
  }
  
  private void _initSI_Aprovacao_outProxy() {
    try {
      sI_Aprovacao_out = (new br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_outServiceLocator()).getHTTPS_Port();
      if (sI_Aprovacao_out != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)sI_Aprovacao_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)sI_Aprovacao_out)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (sI_Aprovacao_out != null)
      ((javax.xml.rpc.Stub)sI_Aprovacao_out)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_out getSI_Aprovacao_out() {
    if (sI_Aprovacao_out == null)
      _initSI_Aprovacao_outProxy();
    return sI_Aprovacao_out;
  }
  
  public br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_Response_out SI_Aprovacao_out(br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_out MT_Aprovacao_out) throws java.rmi.RemoteException{
    if (sI_Aprovacao_out == null)
      _initSI_Aprovacao_outProxy();
    return sI_Aprovacao_out.SI_Aprovacao_out(MT_Aprovacao_out);
  }
  
  
}