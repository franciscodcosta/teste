/**
 * DT_Consulta_Documento_Response_out.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.itau.WorkstationDigital.Consulta_Documento;

public class DT_Consulta_Documento_Response_out  implements java.io.Serializable {
    private br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_outLog_status log_status;

    private java.math.BigInteger total_paginas;

    private java.lang.String dados;

    public DT_Consulta_Documento_Response_out() {
    }

    public DT_Consulta_Documento_Response_out(
           br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_outLog_status log_status,
           java.math.BigInteger total_paginas,
           java.lang.String dados) {
           this.log_status = log_status;
           this.total_paginas = total_paginas;
           this.dados = dados;
    }


    /**
     * Gets the log_status value for this DT_Consulta_Documento_Response_out.
     * 
     * @return log_status
     */
    public br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_outLog_status getLog_status() {
        return log_status;
    }


    /**
     * Sets the log_status value for this DT_Consulta_Documento_Response_out.
     * 
     * @param log_status
     */
    public void setLog_status(br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_outLog_status log_status) {
        this.log_status = log_status;
    }


    /**
     * Gets the total_paginas value for this DT_Consulta_Documento_Response_out.
     * 
     * @return total_paginas
     */
    public java.math.BigInteger getTotal_paginas() {
        return total_paginas;
    }


    /**
     * Sets the total_paginas value for this DT_Consulta_Documento_Response_out.
     * 
     * @param total_paginas
     */
    public void setTotal_paginas(java.math.BigInteger total_paginas) {
        this.total_paginas = total_paginas;
    }


    /**
     * Gets the dados value for this DT_Consulta_Documento_Response_out.
     * 
     * @return dados
     */
    public java.lang.String getDados() {
        return dados;
    }


    /**
     * Sets the dados value for this DT_Consulta_Documento_Response_out.
     * 
     * @param dados
     */
    public void setDados(java.lang.String dados) {
        this.dados = dados;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DT_Consulta_Documento_Response_out)) return false;
        DT_Consulta_Documento_Response_out other = (DT_Consulta_Documento_Response_out) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.log_status==null && other.getLog_status()==null) || 
             (this.log_status!=null &&
              this.log_status.equals(other.getLog_status()))) &&
            ((this.total_paginas==null && other.getTotal_paginas()==null) || 
             (this.total_paginas!=null &&
              this.total_paginas.equals(other.getTotal_paginas()))) &&
            ((this.dados==null && other.getDados()==null) || 
             (this.dados!=null &&
              this.dados.equals(other.getDados())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getLog_status() != null) {
            _hashCode += getLog_status().hashCode();
        }
        if (getTotal_paginas() != null) {
            _hashCode += getTotal_paginas().hashCode();
        }
        if (getDados() != null) {
            _hashCode += getDados().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DT_Consulta_Documento_Response_out.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://itau.com.br/WorkstationDigital/Consulta_Documento", "DT_Consulta_Documento_Response_out"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("log_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "log_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://itau.com.br/WorkstationDigital/Consulta_Documento", ">DT_Consulta_Documento_Response_out>log_status"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("total_paginas");
        elemField.setXmlName(new javax.xml.namespace.QName("", "total_paginas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dados");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dados"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
