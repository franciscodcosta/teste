package br.com.itau.wd.gerenciador.sep;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import br.com.itau.wd.gerenciador.sep.controller.SEPController;
import br.com.itau.wd.gerenciador.sep.service.SEPService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SEPController.class, SEPService.class})
@AutoConfigureMockMvc
public class WdGerenciadorSEPApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SEPService service;

	@InjectMocks
    private SEPController controller;

	@Before
	public void setup() {
   
		MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).setViewResolvers(viewResolver).build();
    }

	@Test
	public void verificaJsonNotificacaoSAP() throws Exception {

		String json = "{\"uid\": \"8500076F-F71B-473C-884A-9D9B7A0AC442\", \"status\": \"S\"}";
		Mockito.when(service.executarServico(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/servico")
				.header("servico", "NOTIFICACAO")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"SAP\",\"FUNCAO_SISTEMA_PRODUTO\":\"0001\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0004\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"00733094;0003000692;99;000000211421\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().string(json));
	}

	@Test
	public void verificaJsonNotificacaoSP2() throws Exception {

		String json = "{\"uid\": \"72DC22FF-EB50-49FD-9606-BF22A2A73AA1\", \"status\": \"S\"}";
		Mockito.when(service.executarServico(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/servico")
				.header("servico", "NOTIFICACAO")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"SP2\",\"FUNCAO_SISTEMA_PRODUTO\":\"0004\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0024\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"003764305\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().string(json));
	}

	@Test
	public void verificaJsonNotificacaoBPM() throws Exception {

		String json = "{\"uid\": \"AB62C063-47F9-4A81-AEC4-6594D8BD15AD\", \"status\": \"S\"}";
		Mockito.when(service.executarServico(Mockito.any(String.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.post("/servico")
				.header("servico", "NOTIFICACAO")
				.header("token", "")
				.header("Content-Type", MediaType.TEXT_PLAIN_VALUE)
				.content("{\"DADOS_NOTIFICACAO\":{\"SIGLA_SISTEMA_PRODUTO\":\"AH7\",\"FUNCAO_SISTEMA_PRODUTO\":\"0004\",\"FUNCAO_ATI_SISTEMA_PRODUTO\":\"0003\",\"FUNCIONAL_SISTEMA_PRODUTO\":\"003764305\",\"CHAVE_PRODUTO\":\"123\"}}")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().string(json));
	}	
}
