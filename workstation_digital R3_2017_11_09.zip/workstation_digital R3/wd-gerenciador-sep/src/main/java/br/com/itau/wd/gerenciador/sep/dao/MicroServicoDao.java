package br.com.itau.wd.gerenciador.sep.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.internal.SessionImpl;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.itau.wd.gerenciador.sep.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

/**
 * Micro Serviço DAO
 * Retorna os dados do microserviço
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Repository
@Transactional
public class MicroServicoDao {
	
	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * Retorna os dados do microserviço
	 * 
	 * @param codigoMicroServico
	 * @return
	 * @throws SEPException
	 */
	public EndpointDto obterMicroServico(int codigoMicroServico) throws SEPException {
		
		EndpointDto endpoint = null;

		try {

			Connection conexao = ((SessionImpl) entityManager.getDelegate()).connection();
			endpoint = obterEndpoint(conexao, codigoMicroServico);
		} 
		catch (Exception ex) {

			throw new SEPException(ex);
		}

		return endpoint;		
	}
	
	/**
	 * Obtem o endpoint do microserviço
	 * 
	 * @param conexao
	 * @param codigoMicroServico
	 * @return
	 * @throws SEPException
	 */
	private EndpointDto obterEndpoint(Connection conexao, int codigoMicroServico) throws SEPException {
		
		EndpointDto endpoint = new EndpointDto();
		
		try (CallableStatement callableStatement = conexao.prepareCall("{call PRC_SEL_MICRO_SERVICO(?,?)}")) {

			callableStatement.setInt(1, codigoMicroServico);
			callableStatement.registerOutParameter(2, Types.VARCHAR);

			callableStatement.execute();

			String descricaoEnderecoVirtual = GerenciadorUtils.convertObjectToString(callableStatement.getString(2));			

			endpoint.setUrlServico(descricaoEnderecoVirtual);
		}
		catch (Exception ex) {
			
			throw new SEPException(ex);
		}
		
		return endpoint;
	}
}