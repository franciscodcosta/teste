package br.com.itau.wd.gerenciador.hcs.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import br.com.itau.wd.gerenciador.hcs.exception.HCSException;

/**
 * HEALTH CHECKER SERVICE (HCS) DAO
 * 
 * @author ITAÚ
 *
 */
@Repository
public class HCSDao  {

	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * Verifica a disponibilidade do serviço
	 * 
	 * @param servico
	 * @return
	 * @throws HCSException
	 */
	public boolean verificarDisponibilidade(String servico) throws HCSException {
	
		return true;
	}
}