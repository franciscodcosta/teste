package br.com.itau.wd.gerenciador.negocio.service.pagamento;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_COMENTARIO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_MENSAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;

@Service
public class PagamentoRegistraAcaoService {

	/**
	 * Retorna o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonRequisicao = new JsonObject();

			objJsonRequisicao.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, objJson.get(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_COMENTARIO, objJson.get(JSON_KEY_COMENTARIO).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_MENSAGEM, objJson.get(JSON_KEY_MENSAGEM).getAsString());
			objJsonRequisicao.addProperty(JSON_KEY_TOKEN, objJson.get(JSON_KEY_TOKEN).getAsString());

			retorno = objJsonRequisicao.toString();
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Retorna o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonResposta = new JsonObject();

			objJsonResposta.addProperty(JSON_KEY_PAGAMENTO_CHAVE_PRODUTO, STRING_EMPTY);
			objJsonResposta.add(JSON_KEY_PAGAMENTO_DADOS, objJson.get(JSON_KEY_PAGAMENTO_DADOS));

			retorno = objJsonResposta.toString();
		} 
		catch (Exception ex) {
	
			throw new NegocioException(ex);
		}
		
		return retorno;
	}	
}