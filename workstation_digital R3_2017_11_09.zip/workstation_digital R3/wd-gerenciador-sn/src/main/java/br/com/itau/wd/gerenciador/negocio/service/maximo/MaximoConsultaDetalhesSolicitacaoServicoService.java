package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_AFFECTEDPHONE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ALNVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ASSETATTRID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICATIONID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSSTRUCTUREID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCUMENT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ANEXOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ATRIBUTOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_NUMVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTDATE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBYID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDPRIORITY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TABLEVALUE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TARGETFINISH;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_WEBURL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRDETQueryType;
import com.ibm.www.maximo.ITAUWDSRDETQueryTypeSR;
import com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType;
import com.ibm.www.maximo.ITAUWDSRDET_SRType;
import com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType;
import com.ibm.www.maximo.MXDateTimeType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXDoubleType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDSRDETResponseType;
import com.ibm.www.maximo.QueryITAUWDSRDETType;
import com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Detalhes Solicitação Serviço
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaDetalhesSolicitacaoServicoService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaDetalhesSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar detalhes da solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarDetalhesSolicitacaoServico(String json, String endpoint) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA DETALHES SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDSRDETType objeto = obterObjeto(json);

			//Envia os dados
			QueryITAUWDSRDETResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA DETALHES SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDSRDETType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		
		String TICKETID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		MXStringQueryType[] QueryTypeArray = new MXStringQueryType[1];
		QueryTypeArray[0] = new MXStringQueryType();
		QueryTypeArray[0].set_value(TICKETID);

		ITAUWDSRDETQueryTypeSR QueryTypeSR = new ITAUWDSRDETQueryTypeSR();
		QueryTypeSR.setTICKETID(QueryTypeArray);

		ITAUWDSRDETQueryType QueryType = new ITAUWDSRDETQueryType();
		QueryType.setSR(QueryTypeSR);

		QueryITAUWDSRDETType objeto = new QueryITAUWDSRDETType();
		objeto.setITAUWDSRDETQuery(QueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDSRDETResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);
		
		JsonObject objJsonDados = new JsonObject();
		
		if (resposta.getITAUWDSRDETSet().length > 0) {
		
			ITAUWDSRDET_SRType[] SRType = resposta.getITAUWDSRDETSet(); 
			
			MXStringType TICKETID = SRType[0].getTICKETID();
			MXStringType CLASSSTRUCTUREID = SRType[0].getCLASSSTRUCTUREID();
			MXDateTimeType REPORTDATE = SRType[0].getREPORTDATE();
			MXDateTimeType TARGETFINISH = SRType[0].getTARGETFINISH();
			MXDomainType STATUS = SRType[0].getSTATUS();
			MXStringType REPORTEDBY = SRType[0].getREPORTEDBY();
			MXStringType REPORTEDBYID = SRType[0].getREPORTEDBYID();
			MXStringType REPORTEDPHONE = SRType[0].getREPORTEDPHONE();
			MXStringType CLASSIFICATIONID = SRType[0].getCLASSIFICATIONID();
			MXDateTimeType ITAU_DATAAGENDAMENTO = SRType[0].getITAU_DATAAGENDAMENTO();
			MXLongType REPORTEDPRIORITY = SRType[0].getREPORTEDPRIORITY();
			MXStringType FR2CODE_LONGDESCRIPTION = SRType[0].getFR2CODE_LONGDESCRIPTION();

			objJsonDados.addProperty(JSON_KEY_MAXIMO_TICKETID, NegocioUtils.converterObjetoParaString(TICKETID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_CLASSSTRUCTUREID, NegocioUtils.converterObjetoParaString(CLASSSTRUCTUREID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDBY, NegocioUtils.converterObjetoParaString(REPORTEDBY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTDATE, NegocioUtils.converterObjetoParaString(REPORTDATE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_TARGETFINISH, NegocioUtils.converterObjetoParaString(TARGETFINISH));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_STATUS, NegocioUtils.converterObjetoParaString(STATUS));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDBYID, NegocioUtils.converterObjetoParaString(REPORTEDBYID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_AFFECTEDPHONE, NegocioUtils.converterObjetoParaString(REPORTEDPHONE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_CLASSIFICATIONID, NegocioUtils.converterObjetoParaString(CLASSIFICATIONID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO, NegocioUtils.converterObjetoParaString(ITAU_DATAAGENDAMENTO));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDPRIORITY, NegocioUtils.converterObjetoParaString(REPORTEDPRIORITY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION, NegocioUtils.converterObjetoParaString(FR2CODE_LONGDESCRIPTION));

			//Atributos
			JsonArray objJsonArrayAtributos = new JsonArray();
			
			if (SRType[0].getTICKETSPEC() != null) {

				for (ITAUWDSRDET_TICKETSPECType TICKETSPECType : SRType[0].getTICKETSPEC()) {

					JsonObject objJsonAtributo = new JsonObject();

					MXStringType ASSETATTRID = TICKETSPECType.getASSETATTRID();
					MXStringType ALNVALUE = TICKETSPECType.getALNVALUE();
					MXDoubleType NUMVALUE = TICKETSPECType.getNUMVALUE();
					MXStringType TABLEVALUE = TICKETSPECType.getTABLEVALUE();
					
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_ASSETATTRID, NegocioUtils.converterObjetoParaString(ASSETATTRID));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_ALNVALUE, NegocioUtils.converterObjetoParaString(ALNVALUE));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_NUMVALUE, NegocioUtils.converterObjetoParaString(NUMVALUE));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_TABLEVALUE, NegocioUtils.converterObjetoParaString(TABLEVALUE));

					objJsonArrayAtributos.add(objJsonAtributo);
				}
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_ATRIBUTOS, objJsonArrayAtributos);
			
			//Anexos
			JsonArray objJsonArrayAnexos = new JsonArray();
			
			if (SRType[0].getDOCLINKS() != null) {

				for (ITAUWDSRDET_DOCLINKSType DOCLINKSType : SRType[0].getDOCLINKS()) {
					
					JsonObject objJsonAnexo = new JsonObject();
					
					MXStringType WEBURL = DOCLINKSType.getWEBURL();
					MXStringType DOCUMENT = DOCLINKSType.getDOCUMENT();
					MXStringType DOCTYPE = DOCLINKSType.getDOCTYPE();

					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_WEBURL, NegocioUtils.converterObjetoParaString(WEBURL));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCUMENT, NegocioUtils.converterObjetoParaString(DOCUMENT));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCTYPE, NegocioUtils.converterObjetoParaString(DOCTYPE));
					
					objJsonArrayAnexos.add(objJsonAnexo);
				}
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_ANEXOS, objJsonArrayAnexos);
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_MAXIMO_CODIGO_RETORNO, STRING_EMPTY);
			objJsonDados.addProperty(JSON_KEY_MAXIMO_DESCRICAO_RETORNO, STRING_EMPTY);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);
		
		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDSRDETResponseType enviarDados(QueryITAUWDSRDETType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDSRDETPortTypeProxy proxy = new ITAUWDSRDETPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDSRDETSOAP11BindingStub)proxy.getITAUWDSRDETPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRDETSOAP11BindingStub)proxy.getITAUWDSRDETPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDSRDET(objeto);
	}	
}