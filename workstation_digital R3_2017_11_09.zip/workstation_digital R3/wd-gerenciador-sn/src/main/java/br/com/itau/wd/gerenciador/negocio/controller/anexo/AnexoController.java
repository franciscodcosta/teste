package br.com.itau.wd.gerenciador.negocio.controller.anexo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.anexo.AnexoService;

@RestController
@RequestMapping(value="/anexo")
public class AnexoController {

	@Autowired
	AnexoService service;

	/**
	 * Retorna o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NotificacaoException
	 */
	@RequestMapping(value="/requisicao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterAnexos(@RequestBody String json) throws NegocioException {

		return service.obterJsonRequisicao(json);
	}
	
	/**
	 * Retorna o JSON da resposta 
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/resposta", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonResposta(@RequestBody String json) throws NegocioException {

		return json;
	}

	/**
	 * Faz o upload do arquivo  
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */	
	@RequestMapping(value="/upload", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String salvarArquivo(@RequestPart(value="file") MultipartFile file, @RequestPart(value="uid") String uid) throws NegocioException  {

		return service.salvarArquivo(file, uid);
	}
}