package br.com.itau.wd.gerenciador.negocio.utils;

public class Constants {

	//MAXIMO
	public static final String JSON_KEY_MAXIMO_CREATEBY = "criado_por";
	public static final String JSON_KEY_MAXIMO_REPORTEDBY = "relatado_por";
	public static final String JSON_KEY_MAXIMO_REPORTEDBYID = "id_relatado_por";
	public static final String JSON_KEY_MAXIMO_REPORTDATE = "relatado_em";
	public static final String JSON_KEY_MAXIMO_REPORTEDPRIORITY = "prioridade_relatada";
	public static final String JSON_KEY_MAXIMO_TARGETFINISH = "termino_previsto";
	public static final String JSON_KEY_MAXIMO_AFFECTEDPERSON = "em_nome_de"; 
	public static final String JSON_KEY_MAXIMO_CLASSSTRUCTUREID = "id_estrutura_classe";
	public static final String JSON_KEY_MAXIMO_CLASSIFICATIONID =  "id_classificacao";
	public static final String JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO = "data_agendamento";
	public static final String JSON_KEY_MAXIMO_DESCRIPTION = "resumo";
	public static final String JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION = "detalhes";
	public static final String JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION = "resolucao";
	public static final String JSON_KEY_MAXIMO_LOCATION = "localizacao";
	public static final String JSON_KEY_MAXIMO_AFFECTEDPHONE = "telefone";
	public static final String JSON_KEY_MAXIMO_WHERE = "where";
	public static final String JSON_KEY_MAXIMO_STATUS = "status";
	public static final String JSON_KEY_MAXIMO_LOGTYPE = "tipo_log";
	public static final String JSON_KEY_MAXIMO_CLIENTVIEWABLE = "visualizavel";
	public static final String JSON_KEY_MAXIMO_DOCTYPE = "tipo_doc";
	public static final String JSON_KEY_MAXIMO_DOCUMENT = "documento";
	public static final String JSON_KEY_MAXIMO_URLTYPE = "tipo_url";
	public static final String JSON_KEY_MAXIMO_WEBURL = "url_doc";
	public static final String JSON_KEY_MAXIMO_DOCUMENTDATA = "dados_doc";
	public static final String JSON_KEY_MAXIMO_ASSETATTRID = "id_atributo";
	public static final String JSON_KEY_MAXIMO_DOMAINID = "dominio_id";
	public static final String JSON_KEY_MAXIMO_ORGID = "org_id";
	public static final String JSON_KEY_MAXIMO_SECTION = "secao";
	public static final String JSON_KEY_MAXIMO_SITEID = "site_id";
	public static final String JSON_KEY_MAXIMO_ALNVALUE = "valor_atributo_alfanumerico";
	public static final String JSON_KEY_MAXIMO_NUMVALUE = "valor_atributo_numerico";
	public static final String JSON_KEY_MAXIMO_TABLEVALUE = "valor_atributo_tabela";
	public static final String JSON_KEY_MAXIMO_TICKETID = "ticket_id";
	public static final String JSON_KEY_MAXIMO_TICKETUID = "ticket_uid";
	public static final String JSON_KEY_MAXIMO_CODIGO_RETORNO = "codigo_retorno";
	public static final String JSON_KEY_MAXIMO_DESCRICAO_RETORNO = "descricao_retorno";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_CORPORATIVO = "corporativo";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_DESCRICAO = "description";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU = "itau";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWREDE = "itau_swrede";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWSISTEMAID = "itau_swsistemaid";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_LICENCIADO = "licenciado";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_RESTRITO = "restrito";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_TIPO = "tipo";
	
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSIFICATIONID = "classification_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSSTRUCTUREID = "class_structure_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_DESCRIPTION = "description";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_ASSETATTRID = "asset_attr_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_DOMAINID = "domain_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_ORGID = "org_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_SECTION = "section";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_SITEID = "site_id";
	
	public static final String JSON_KEY_MAXIMO_GMUD_NUMERO = "numero_solicitacao";
	public static final String JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE = "funcional_solicitante";
	public static final String JSON_KEY_MAXIMO_GMUD_LIMITE_APROVACAO = "limite_aprovacao";
	public static final String JSON_KEY_MAXIMO_GMUD_NOME_SOLICITACAO = "nome_solicitacao";
	public static final String JSON_KEY_MAXIMO_GMUD_TIPO = "tipo";
	public static final String JSON_KEY_MAXIMO_GMUD_DETALHES = "detalhes";
	public static final String JSON_KEY_MAXIMO_GMUD_MOTIVO = "motivo";
	public static final String JSON_KEY_MAXIMO_GMUD_INICIO = "inicio";
	public static final String JSON_KEY_MAXIMO_GMUD_FIM = "fim";
	public static final String JSON_KEY_MAXIMO_GMUD_RISCO = "risco";
	public static final String JSON_KEY_MAXIMO_GMUD_IMPACTO = "impacto";
	public static final String JSON_KEY_MAXIMO_GMUD_PROBABILIDADE_IMPACTO = "probabilidade_impacto";
	public static final String JSON_KEY_MAXIMO_GMUD_STATUS = "status";

	public static final String JSON_KEY_MAXIMO_LISTA_ANEXOS = "anexos";
	public static final String JSON_KEY_MAXIMO_LISTA_LOGS = "logs";
	public static final String JSON_KEY_MAXIMO_LISTA_ATRIBUTOS = "atributos";
	public static final String JSON_KEY_MAXIMO_LISTA_TICKETS = "tickets";
	public static final String JSON_KEY_MAXIMO_LISTA_SOFTWARE = "softwares";
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSIFICACOES = "class_structure";
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSSPEC = "class_spec"; 
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSFICACAO_ASSETATTRIBUTE = "asset_attribute";
	
	public static final String CONSTANTE_MAXIMO_SR = "SR";
	public static final String CONSTANTE_MAXIMO_EXTERNALSYSTEM = "WD";
	public static final String CONSTANTE_MAXIMO_SOFTWARE = "Software";
	
	public static final String PROPERTY_KEY_SECURITY_MAXIMO_USER = "security.maximo.user";
	public static final String PROPERTY_KEY_SECURITY_MAXIMO_TOKEN = "security.maximo.token";
	
	//CAMBIO
	public static final String JSON_KEY_CAMBIO_CODRET = "codret";
	public static final String JSON_KEY_CAMBIO_SQLCODE = "sqlcode";
	public static final String JSON_KEY_CAMBIO_MSGRET = "msgret";
	public static final String JSON_KEY_CAMBIO_SEGMENTO = "segmento";
	public static final String JSON_KEY_CAMBIO_RAMOATIV = "ramoativ";
	public static final String JSON_KEY_CAMBIO_COLABORADOR = "colaborador";
	public static final String JSON_KEY_CAMBIO_SPI = "spi";
	public static final String JSON_KEY_CAMBIO_FREQUENCIA = "frequencia";
	public static final String JSON_KEY_CAMBIO_AGENCIA = "agencia";
	public static final String JSON_KEY_CAMBIO_CONTA = "conta";
	public static final String JSON_KEY_CAMBIO_PANICO = "panico";
	public static final String JSON_KEY_CAMBIO_SPREADHIS = "spreadhis";
	public static final String JSON_KEY_CAMBIO_SPREADFIN = "spreadfin";
	public static final String JSON_KEY_CAMBIO_SPREADMAX = "spreadmax";
	public static final String JSON_KEY_CAMBIO_SPREADMIN = "spreadmin";
	public static final String JSON_KEY_CAMBIO_INDALTGNI = "indaltgni";
	public static final String JSON_KEY_CAMBIO_INDFUNC = "indfunc";
	public static final String JSON_KEY_CAMBIO_STATUSIS = "statusis";
	public static final String JSON_KEY_CAMBIO_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_CAMBIO_DADOS = "dados";
	public static final String JSON_KEY_CAMBIO_CHAVE = "chave";
	public static final String JSON_KEY_CAMBIO_CODIGOCANAL = "Canal.CodigoCanal";
	public static final String JSON_KEY_CAMBIO_VALOR = "valor";
	public static final String JSON_KEY_CAMBIO_HEADER = "header";
	public static final String JSON_KEY_CAMBIO_FUNCIONAL = "funcional";
	
	public static final String CONSTANTE_CAMBIO_CONTEXTOCANAL = "contextocanal";
	
	//TMS
	public static final String JSON_KEY_TMS_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_TMS_DADOS = "dados";
	
	public static final String JSON_KEY_TMS_DATA_REUNIAO = "data_reuniao";
	public static final String JSON_KEY_TMS_REUNIAO_RECORRENTE = "reuniao_recorrente";
	public static final String JSON_KEY_TMS_RECORRENCIA = "recorrencia";
	public static final String JSON_KEY_TMS_HORA_INICIO = "hora_inicio";
	public static final String JSON_KEY_TMS_QTDE_HORAS = "qtde_horas";
	public static final String JSON_KEY_TMS_QTDE_PESSOAS = "qtde_pessoas";
	public static final String JSON_KEY_TMS_HORA_FIM = "hora_fim";
	public static final String JSON_KEY_TMS_LINK = "link";
	public static final String JSON_KEY_TMS_PIN = "pin";
	public static final String JSON_KEY_TMS_SENHA = "senha";
	public static final String JSON_KEY_TMS_ACESSO_EXTERNO = "acesso_externo";
	public static final String JSON_KEY_TMS_POLO = "polo";
	public static final String JSON_KEY_TMS_TORRE = "torre";
	public static final String JSON_KEY_TMS_ANDAR = "andar";
	public static final String JSON_KEY_TMS_NUMERO = "numero";
	public static final String JSON_KEY_TMS_CAPACIDADE = "capacidade";
	public static final String JSON_KEY_TMS_LISTA_ESPERA = "lista_espera";
	public static final String JSON_KEY_TMS_LISTA_POLOS = "polos";
	public static final String JSON_KEY_TMS_STATUS = "status";
	public static final String JSON_KEY_TMS_MENSAGEM = "mensagem";
	
	public static final String PROPERTY_KEY_SECURITY_TMS_USER = "security.tms.user";
	public static final String PROPERTY_KEY_SECURITY_TMS_TOKEN = "security.tms.token";
	
	//BPM
	public static final String JSON_KEY_BPM_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_BPM_STATUS = "status";

	//Tarefódromo
	public static final String JSON_KEY_TAREFODROMO_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_TAREFODROMO_FUNCIONAL = "funcional";
	public static final String JSON_KEY_TAREFODROMO_IND_PROXIMA_PAGINA = "ind_proxima_pagina";
	public static final String JSON_KEY_TAREFODROMO_IND_PROXIMA_ANTERIOR = "ind_proxima_anterior";
	public static final String JSON_KEY_TAREFODROMO_IND_PAGINACAO = "ind_paginacao";
	public static final String JSON_KEY_TAREFODROMO_QTD_OCORRENCIAS = "qtd_ocorrencias";
	public static final String JSON_KEY_TAREFODROMO_COD_PENDENCIA = "cod_pendencia";
	public static final String JSON_KEY_TAREFODROMO_FUNCIONAL_COLABORADOR = "funcional_colaborador";
	public static final String JSON_KEY_TAREFODROMO_NOME_PENDENCIA = "nome_pendencia";
	public static final String JSON_KEY_TAREFODROMO_URL_PENDENCIA = "url_pendencia";
	public static final String JSON_KEY_TAREFODROMO_DESCRICAO_PENDENCIA = "descricao_pendencia";
	public static final String JSON_KEY_TAREFODROMO_COD_TIPO_AUTENTICACAO = "cod_tipo_autenticacao";
	public static final String JSON_KEY_TAREFODROMO_QTD_PENDENCIAS = "qtd_pendencias";
	public static final String JSON_KEY_TAREFODROMO_LISTA_PENDENCIAS = "pendencias";
	public static final String JSON_KEY_TAREFODROMO_DADOS = "dados";

	public static final String PROPERTY_KEY_TAREFODROMO_IMS_COMPUTADOR = "tarefodromo.ims.computador";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_PORTA = "tarefodromo.ims.porta";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS = "tarefodromo.ims";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_USUARIO = "tarefodromo.ims.usuario";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_TOKEN = "tarefodromo.ims.token";
	
	public static final String CONSTANTE_TAREFODROMO_TRANCODE = "CF5I016 ";
	
	//Pagamento
	public static final String JSON_KEY_PAGAMENTO_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_PAGAMENTO_DADOS = "dados";
	
	private Constants() {}
}