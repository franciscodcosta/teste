package br.com.itau.wd.gerenciador.sr.router.service;

import static br.com.itau.wd.gerenciador.sr.util.Constants.HTTP_HEADER_AUTHORIZATION;
import static br.com.itau.wd.gerenciador.sr.util.Constants.HTTP_HEADER_CONTENT_TYPE;
import static br.com.itau.wd.gerenciador.sr.util.Constants.MSG_ERRO_SALESFORCE_JSON_INVALIDO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;
import static br.com.itau.wd.gerenciador.util.Constants.TLS_V12;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.itau.wd.gerenciador.sr.config.LoginSalesforceConfig;
import br.com.itau.wd.gerenciador.sr.dto.LoginSalesforceDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.util.SRUtils;

@Service
public class RouterSalesforceService {

	@Autowired
	LoginSalesforceConfig loginSalesforce;

	/**
	 * Envia o JSON ao Salesforce
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws SRException 
	 */
	public String executarServico(String endpoint, String json) throws SRException {

		String retorno = STRING_EMPTY;

		try {

			// Retorna os dados de login do Salesforce
			LoginSalesforceDto login = loginSalesforce.obterDados();

			// Configura o TLS 1.2
			SRUtils.configurarTls(TLS_V12);

			HttpHeaders headers = new HttpHeaders();
			
			headers.add(HTTP_HEADER_AUTHORIZATION,"OAuth " + login.getAccessToken());
			headers.add(HTTP_HEADER_CONTENT_TYPE, "application/json");

			String body = String.format("{\"dados_acao\":%s}", json);

			System.out.println("JSON SF = " + body);
			
			HttpEntity<String> entity = new HttpEntity<>(body, headers);

			String url = String.format("%s%s", login.getInstanceUrl(), endpoint);

			ResponseEntity<String> response = new RestTemplate().exchange(url, HttpMethod.POST, entity, String.class);

			if (response.getStatusCode() == HttpStatus.OK) {

				retorno = formatarJson(response.getBody());

				if (STRING_EMPTY.equals(retorno)) {
					throw new SRException(MSG_ERRO_SALESFORCE_JSON_INVALIDO);
				}
			}
			else {
				
				throw new SRException(response.getBody());
			}			

			verificarErro(retorno);
		}
		catch (Exception ex) {

			throw new SRException(ex);
		}

		return retorno;
	}

	/**
	 * Verifica se existe erro
	 * 
	 * @param json
	 * @throws IOException 
	 * @throws SRException 
	 */
	private void verificarErro(String json) throws IOException, SRException {

		if (json.contains("errorCode")) {

			ObjectMapper objectMapper = new ObjectMapper();
			List<Map<String, Object>> lista = objectMapper.readValue(json, objectMapper.getTypeFactory().constructCollectionType(List.class, Map.class));

			for (Map<String, Object> objeto : lista) {
				if (objeto.containsKey("errorCode")) {
					throw new SRException(objeto.get("message").toString());
				}
			}
		}
	}
	
	/**
	 * Retorna o JSON
	 * 
	 * @param json
	 * @return
	 */
	private String formatarJson(String json) {
		
		return json.replace("\\", "").replace("\"{", "{").replace("}\"", "}");
	}
}