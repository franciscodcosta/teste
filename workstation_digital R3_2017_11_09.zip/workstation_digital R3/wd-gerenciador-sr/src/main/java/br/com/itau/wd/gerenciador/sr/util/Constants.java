package br.com.itau.wd.gerenciador.sr.util;

public class Constants {

	private Constants() {}
	
	public static final String HTTP_HEADER_AUTHORIZATION = "Authorization";
	public static final String HTTP_HEADER_CONTENT_TYPE = "Content-type";
	public static final String HTTP_HEADER_SERVICO = "servico";
	public static final String HTTP_HEADER_TOKEN = "token";
	public static final String HTTP_HEADER_ENDPOINT = "endpoint";
	
	public static final String MSG_ERRO_SALESFORCE_JSON_INVALIDO = "JSON inválido";
}