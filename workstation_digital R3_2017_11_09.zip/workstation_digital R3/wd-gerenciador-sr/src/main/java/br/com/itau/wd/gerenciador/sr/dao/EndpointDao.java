package br.com.itau.wd.gerenciador.sr.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.internal.SessionImpl;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.com.itau.wd.gerenciador.sr.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Repository
@Transactional 
public class EndpointDao {
	
	@PersistenceContext 
	private EntityManager entityManager;

	/**
	 * Retorna os dados do endpoint do serviçp
	 * 
	 * @param codigoServico
	 * @return
	 * @throws SRException
	 */
	public EndpointDto obterEndpoint(String codigoServico) throws SRException {

		EndpointDto endpoint = null;

		try {

			Connection conexao = ((SessionImpl) entityManager.getDelegate()).connection();
			endpoint = obterEndpoint(conexao, codigoServico);
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}
		
		return endpoint;		
	}

	/**
	 * Obtem os dados do endpoint do microserviço
	 * 
	 * @param numeroOrdem
	 * @return
	 * @throws SRException
	 */
	public EndpointDto obterMicroServico(int numeroOrdem) throws SRException {
		
		EndpointDto microservico = new EndpointDto();
		
		try {
			
			Connection conexao = ((SessionImpl) entityManager.getDelegate()).connection();
			microservico = obterMicroServico(conexao, numeroOrdem);
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}
		
		return microservico;		
	}
	
	/**
	 * Obtem o endpoint so serviço
	 * 
	 * @param conexao
	 * @param codigoServico
	 * @return
	 * @throws SRException
	 */
	private EndpointDto obterEndpoint(Connection conexao, String codigoServico) throws SRException {
		
		EndpointDto endpoint = new EndpointDto();
		
		try (CallableStatement callableStatement = conexao.prepareCall("{call PRC_SEL_REGISTRO_ORDEM_EXECUCAO(?,?,?,?,?,?)}")) {

			callableStatement.setString(1, codigoServico);
			callableStatement.registerOutParameter(2, Types.VARCHAR);
			callableStatement.registerOutParameter(3, Types.VARCHAR);
			callableStatement.registerOutParameter(4, Types.CHAR);
			callableStatement.registerOutParameter(5, Types.BIT);
			callableStatement.registerOutParameter(6, Types.BIT);

			callableStatement.execute();

			String urlServico = GerenciadorUtils.convertObjectToString(callableStatement.getString(2));			
			String urlServicoNegocio = GerenciadorUtils.convertObjectToString(callableStatement.getString(3));
			String siglaSistema = GerenciadorUtils.convertObjectToString(callableStatement.getString(4));
			boolean salvaKMS = callableStatement.getBoolean(5);
			boolean consultaKMS = callableStatement.getBoolean(6);
			
			if (StringUtils.isEmpty(urlServico)) {
				throw new SRException("Serviço inexistente");
			}

			endpoint.setCodigoServico(codigoServico);
			endpoint.setSiglaSistema(siglaSistema);			
			endpoint.setUrlServico(urlServico);
			endpoint.setUrlServicoNegocio(urlServicoNegocio);
			endpoint.setSalvaKms(salvaKMS);
			endpoint.setConsultaKms(consultaKMS);
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}
		
		return endpoint;
	}
	
	/**
	 * Obtem o endpoit do microserviço
	 * 
	 * @param conexao
	 * @param numeroOrdem
	 * @return
	 * @throws SRException
	 */
	private EndpointDto obterMicroServico(Connection conexao, int numeroOrdem) throws SRException {
		
		EndpointDto microservico = new EndpointDto();
		
		try (CallableStatement callableStatement = conexao.prepareCall("{call PRC_SEL_MICRO_SERVICO(?,?)}")) {

			callableStatement.setInt(1, numeroOrdem);
			callableStatement.registerOutParameter(2, Types.VARCHAR);

			callableStatement.execute();

			String descricaoEnderecoVirtual = GerenciadorUtils.convertObjectToString(callableStatement.getString(2));			
			
			if (StringUtils.isEmpty(descricaoEnderecoVirtual)) {
				throw new SRException("Serviço inexistente");
			}
	
			microservico.setUrlServico(descricaoEnderecoVirtual);
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}
		
		return microservico;
	}
}