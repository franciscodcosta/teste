package br.com.itau.wd.gerenciador.sr.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@ComponentScan({"br.com.itau.wd.gerenciador.sr.config.*", "br.com.itau.wd.gerenciador.sr.*", "br.com.itau.wd.gerenciador.sr.service.*"})
@PropertySources({
    @PropertySource(value="file:${app.properties}", ignoreResourceNotFound=false)
})
public class WDGerenciadorSRApplication {

	public static void main(String[] args) {
		SpringApplication.run(WDGerenciadorSRApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {

		RestTemplate restTemplate = builder.build(); 
		restTemplate.setRequestFactory(clientHttpRequestFactory());

		return restTemplate;
	}

	private ClientHttpRequestFactory clientHttpRequestFactory() {

		//CloseableHttpClient x = HttpClientBuilder.create().setMaxConnTotal(200).setMaxConnPerRoute(50).build();
		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();

		factory.setConnectionRequestTimeout(60*1000);
		factory.setReadTimeout(60*1000);
		factory.setConnectTimeout(60*1000);

		return factory;
	}	
}
