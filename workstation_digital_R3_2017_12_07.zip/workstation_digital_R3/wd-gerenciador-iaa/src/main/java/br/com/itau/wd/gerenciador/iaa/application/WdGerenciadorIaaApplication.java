package br.com.itau.wd.gerenciador.iaa.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WdGerenciadorIaaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WdGerenciadorIaaApplication.class, args);
	}
}
