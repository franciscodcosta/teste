package br.com.itau.wd.gerenciador.hcs;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import br.com.itau.wd.gerenciador.hcs.controller.HCSController;
import br.com.itau.wd.gerenciador.hcs.service.HCSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {HCSController.class, HCSService.class})
@AutoConfigureMockMvc
public class WdGerenciadorHCSApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private HCSService service;

	@InjectMocks
    private HCSController controller;

	@Before
	public void setup() {
   
		MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).setViewResolvers(viewResolver).build();
    }

	@Test
	public void verificaRetornoComServicoPreenchido() throws Exception {

		Mockito.when(service.verificarDisponibilidade(Mockito.any(String.class))).thenReturn(true);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/disponibilidade").param("servico", "HCS"); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(content().string("true"));
	}
	
	@Test
	public void verificaRetornoSemServicoPreenchido() throws Exception {

		Mockito.when(service.verificarDisponibilidade("")).thenReturn(true);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.get("/disponibilidade").param("servico", ""); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(content().string("true"));
	}
}