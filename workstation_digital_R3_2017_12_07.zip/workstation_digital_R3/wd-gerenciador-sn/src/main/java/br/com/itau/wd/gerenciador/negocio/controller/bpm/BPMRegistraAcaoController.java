package br.com.itau.wd.gerenciador.negocio.controller.bpm;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.bpm.BPMRegistraAcaoService;

/**
 * BPM Controller
 * 
 * Componente responsável pela comunicação com o BPM
 * 
 * @author ITAÚ
 *
 */
@RestController
@RequestMapping(value="/bpm/registrar_acao")
public class BPMRegistraAcaoController {

	@Autowired
	private BPMRegistraAcaoService service;

	/**
	 * Retorna o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	@RequestMapping(value="/requisicao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonRequisicao(@RequestBody String json) throws NegocioException {

		return service.obterJsonRequisicao(json);
	}

	/**
	 * Retorna o JSON da resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/resposta", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonResposta(@RequestBody String json) throws NegocioException {

		return service.obterJsonResposta(json);
	}

	/**
	 * Registra a ação
	 *
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/soap", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String registrarAcao(@RequestBody String json, @RequestHeader(value="endpoint") String endpoint) throws NegocioException {

		return service.registrarAcao(json, endpoint);
	}	
}
