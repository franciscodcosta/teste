package br.com.itau.wd.gerenciador.negocio.dto.tms;

public class ConferenciaEntrada {

	private int id;
	private String dataReuniao;
	private String reuniaoRecorrente;
	private String recorrencia;
	private String horaInicio;
	private String horaFim;
	private String qtdeHoras;
	private String qtdePessoas;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDataReuniao() {
		return dataReuniao;
	}
	
	public void setDataReuniao(String dataReuniao) {
		this.dataReuniao = dataReuniao;
	}
	
	public String getReuniaoRecorrente() {
		return reuniaoRecorrente;
	}
	
	public void setReuniaoRecorrente(String reuniaoRecorrente) {
		this.reuniaoRecorrente = reuniaoRecorrente;
	}
	
	public String getRecorrencia() {
		return recorrencia;
	}
	
	public void setRecorrencia(String recorrencia) {
		this.recorrencia = recorrencia;
	}
	
	public String getHoraInicio() {
		return horaInicio;
	}
	
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	
	public String getHoraFim() {
		return horaFim;
	}
	
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}

	public String getQtdeHoras() {
		return qtdeHoras;
	}

	public void setQtdeHoras(String qtdeHoras) {
		this.qtdeHoras = qtdeHoras;
	}

	public String getQtdePessoas() {
		return qtdePessoas;
	}

	public void setQtdePessoas(String qtdePessoas) {
		this.qtdePessoas = qtdePessoas;
	}
}