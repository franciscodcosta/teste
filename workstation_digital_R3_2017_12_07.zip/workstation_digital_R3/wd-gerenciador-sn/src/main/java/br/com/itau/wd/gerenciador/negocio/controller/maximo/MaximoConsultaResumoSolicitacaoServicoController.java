package br.com.itau.wd.gerenciador.negocio.controller.maximo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.service.maximo.MaximoConsultaResumoSolicitacaoServicoService;

/**
 * Máximo Controller
 * 
 * Serviço 0213 - Consultar Resumo da Solicitação de Serviço
 * 
 * @author ITAÚ
 *
 */
@RestController
@RequestMapping(value="/maximo/consulta/resumo/ss") 
public class MaximoConsultaResumoSolicitacaoServicoController {

	@Autowired
	private MaximoConsultaResumoSolicitacaoServicoService service;
	
	/**
	 * Retorna o JSON da requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	@RequestMapping(value="/requisicao", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonRequisicao(@RequestBody String json) throws NegocioException {

		return service.obterJsonRequisicao(json);
	}
	
	/**
	 * Retorna o JSON da resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/resposta", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String obterJsonResposta(@RequestBody String json) throws NegocioException {

		return service.obterJsonResposta(json);
	}
	
	/**
	 * Consultar Resumo da Solicitação
	 *
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	@RequestMapping(value="/soap", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public String consultarResumoSolicitacaoServico(@RequestBody String json, @RequestHeader(value="endpoint") String endpoint) throws NegocioException {

		return service.consultarResumoSolicitacaoServico(json, endpoint);
	}
}