package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_MAXIMO_SR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ACTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLIENTVIEWABLE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CREATEBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_LOGS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_SR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_TICKETS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REASON;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETUID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TIPO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_USERID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRAPROVACombinedKeySetTypeSR;
import com.ibm.www.maximo.ITAUWDSRAPROVA_SRType;
import com.ibm.www.maximo.ITAUWDSRAPROVA_WORKLOGType;
import com.ibm.www.maximo.MXBooleanType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType;
import com.ibm.www.maximo.SyncITAUWDSRAPROVAType;
import com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVAPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVASOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Aprovar Solicitação de Serviço 
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoAprovacaoSolicitacaoServicoService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoAprovacaoSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Aprova a solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String aprovarSolicitacaoServico(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - APROVA SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Converte o JSON para o objeto de entrada
			SyncITAUWDSRAPROVAType objeto = obterObjeto(json);
			
			//Envia os dados
			SyncITAUWDSRAPROVAResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - APROVA SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private SyncITAUWDSRAPROVAType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String vSTATUS = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_STATUS);
		
		JsonArray objJsonArraySr = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_SR);
		JsonObject objJsonSr = (JsonObject)objJsonArraySr.get(0);

		String vTICKETID = NegocioUtils.obterDadoJson(objJsonSr, JSON_KEY_CHAVE_PRODUTO);
		String vITAUSTATUSDESC = NegocioUtils.obterDadoJson(objJsonSr, JSON_KEY_MAXIMO_ACTION);
		String vREASON = NegocioUtils.obterDadoJson(objJsonSr, JSON_KEY_MAXIMO_REASON);
		String vREPORTEDBY = NegocioUtils.obterDadoJson(objJsonSr, JSON_KEY_MAXIMO_USERID);

		ITAUWDSRAPROVA_SRType vSRType = new ITAUWDSRAPROVA_SRType();

		MXDomainType vCLASS = new MXDomainType();
		vCLASS.set_value(CONSTANTE_MAXIMO_SR);
		vCLASS.setMaxvalue(CONSTANTE_MAXIMO_SR);

		vSRType.setCLASS(vCLASS);
		vSRType.setTICKETID(new MXStringType(vTICKETID));
		vSRType.setSTATUS(new MXDomainType(vSTATUS));
		vSRType.setITAU_STATUSDESC(new MXStringType(vITAUSTATUSDESC));
		vSRType.setDESCRIPTION(new MXStringType(vREASON));
		vSRType.setREPORTEDBY(new MXStringType(vREPORTEDBY));

		//Logs
		JsonArray objJsonArrayLogs = (JsonArray) objJson.get(JSON_KEY_MAXIMO_LISTA_LOGS);

		ITAUWDSRAPROVA_WORKLOGType[] vWORKLOGType = new ITAUWDSRAPROVA_WORKLOGType[objJsonArrayLogs.size()];

		for (int i = 0; i < objJsonArrayLogs.size(); i++) {

			JsonObject objJsonLog = (JsonObject)objJsonArrayLogs.get(i);

			String vDESCRIPTION = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_DESCRIPTION);
			String vDESCRIPTIONLONGDESCRIPTION = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION);
			String vLOGTYPE = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_TIPO);
			String vCLIENTVIEWABLE = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_CLIENTVIEWABLE);
			String vCREATEBY = NegocioUtils.obterDadoJson(objJsonLog, JSON_KEY_MAXIMO_CREATEBY);

			vWORKLOGType[i] = new ITAUWDSRAPROVA_WORKLOGType();

			vWORKLOGType[i].setDESCRIPTION(new MXStringType(vDESCRIPTION));
			vWORKLOGType[i].setDESCRIPTION_LONGDESCRIPTION(new MXStringType(vDESCRIPTIONLONGDESCRIPTION));
			vWORKLOGType[i].setLOGTYPE(new MXDomainType(vLOGTYPE));
			vWORKLOGType[i].setCLIENTVIEWABLE(new MXBooleanType(NegocioUtils.converterBoolean(vCLIENTVIEWABLE)));
			vWORKLOGType[i].setCREATEBY(new MXStringType(vCREATEBY));
		}

		vSRType.setWORKLOG(vWORKLOGType);
		
		SyncITAUWDSRAPROVAType objeto = new SyncITAUWDSRAPROVAType();
		objeto.setITAUWDSRAPROVASet(new ITAUWDSRAPROVA_SRType[] {vSRType});

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(SyncITAUWDSRAPROVAResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_TICKETID);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		ITAUWDSRAPROVACombinedKeySetTypeSR[] combinedKeySetTypeSr = resposta.getITAUWDSRAPROVASet();

		if (combinedKeySetTypeSr != null) {
		
			JsonArray objJsonArrayTickets = new JsonArray();
			
			for (ITAUWDSRAPROVACombinedKeySetTypeSR CombinedKeySetTypeSR : combinedKeySetTypeSr) {
	
				MXStringType vTICKETID = CombinedKeySetTypeSR.getTICKETID();
				MXLongType vTICKETUID = CombinedKeySetTypeSR.getTICKETUID();
				
				JsonObject objJsonTicket = new JsonObject();
				
				objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETID, NegocioUtils.converterObjetoParaString(vTICKETID));
				objJsonTicket.addProperty(JSON_KEY_MAXIMO_TICKETUID, NegocioUtils.converterObjetoParaString(vTICKETUID));
				
				objJsonArrayTickets.add(objJsonTicket);
			}
	
			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_TICKETS, objJsonArrayTickets);
		}
		else {

			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private SyncITAUWDSRAPROVAResponseType enviarDados(SyncITAUWDSRAPROVAType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDSRAPROVAPortTypeProxy proxy = new ITAUWDSRAPROVAPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDSRAPROVASOAP11BindingStub)proxy.getITAUWDSRAPROVAPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRAPROVASOAP11BindingStub)proxy.getITAUWDSRAPROVAPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		//Envia os dados
		return proxy.syncITAUWDSRAPROVA(objeto);
	}
}