package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_AFFECTEDPHONE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ATRIBUTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSIFICATIONID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CLASSSTRUCTUREID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CREATEBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_CREATEDATE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRICAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCINFOID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCTYPE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_DOCUMENT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_ANEXOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_LOGS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_LISTA_TICKETSPEC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_NUMERICO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_OWNERID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_OWNERTABLE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_RECORDKEY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTDATE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDBYID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDEMAIL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_REPORTEDPRIORITY;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TABELA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TARGETFINISH;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_TICKETUID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_VALOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_WEBURL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_WORKLOGID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDSRDETQueryType;
import com.ibm.www.maximo.ITAUWDSRDETQueryTypeSR;
import com.ibm.www.maximo.ITAUWDSRDET_ASSETATTRIBUTEType;
import com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType;
import com.ibm.www.maximo.ITAUWDSRDET_SRType;
import com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType;
import com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType;
import com.ibm.www.maximo.MXDateTimeType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXDoubleType;
import com.ibm.www.maximo.MXLongType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDSRDETResponseType;
import com.ibm.www.maximo.QueryITAUWDSRDETType;
import com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Detalhes Solicitação Serviço
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaDetalhesSolicitacaoServicoService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaDetalhesSolicitacaoServicoService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar detalhes da solicitação de serviço
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarDetalhesSolicitacaoServico(String json, String endpoint) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA DETALHES SS - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDSRDETType objeto = obterObjeto(json);

			//Envia os dados
			QueryITAUWDSRDETResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA DETALHES SS - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDSRDETType obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		
		String vTICKETID = NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO);

		MXStringQueryType[] vQueryTypeArray = new MXStringQueryType[1];
		vQueryTypeArray[0] = new MXStringQueryType();
		vQueryTypeArray[0].set_value(vTICKETID);

		ITAUWDSRDETQueryTypeSR vQueryTypeSR = new ITAUWDSRDETQueryTypeSR();
		vQueryTypeSR.setTICKETID(vQueryTypeArray);

		ITAUWDSRDETQueryType vQueryType = new ITAUWDSRDETQueryType();
		vQueryType.setSR(vQueryTypeSR);

		QueryITAUWDSRDETType objeto = new QueryITAUWDSRDETType();
		objeto.setITAUWDSRDETQuery(vQueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDSRDETResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);
		
		JsonObject objJsonDados = new JsonObject();
		
		if (resposta.getITAUWDSRDETSet() != null && resposta.getITAUWDSRDETSet().length > 0) {
		
			ITAUWDSRDET_SRType[] vSRType = resposta.getITAUWDSRDETSet(); 

			MXStringType vCLASSSTRUCTUREID = vSRType[0].getCLASSSTRUCTUREID();
			MXDateTimeType vREPORTDATE = vSRType[0].getREPORTDATE();
			MXDateTimeType vTARGETFINISH = vSRType[0].getTARGETFINISH();
			MXDomainType vSTATUS = vSRType[0].getSTATUS();
			MXStringType vREPORTEDBY = vSRType[0].getREPORTEDBY();
			MXStringType vREPORTEDBYID = vSRType[0].getREPORTEDBYID();
			MXStringType vREPORTEDPHONE = vSRType[0].getREPORTEDPHONE();
			MXStringType vCLASSIFICATIONID = vSRType[0].getCLASSIFICATIONID();
			MXDateTimeType vITAUDATAAGENDAMENTO = vSRType[0].getITAU_DATAAGENDAMENTO();
			MXLongType vREPORTEDPRIORITY = vSRType[0].getREPORTEDPRIORITY();
			MXStringType vFR2CODELONGDESCRIPTION = vSRType[0].getFR2CODE_LONGDESCRIPTION();
			MXStringType vREPORTEDEMAIL = vSRType[0].getREPORTEDEMAIL();
			MXStringType vDESCRIPTIONLONGDESCRIPTION = vSRType[0].getDESCRIPTION_LONGDESCRIPTION();
			MXStringType vDESCRICAO = vSRType[0].getDESCRIPTION();

			objJsonDados.addProperty(JSON_KEY_MAXIMO_CLASSSTRUCTUREID, NegocioUtils.converterObjetoParaString(vCLASSSTRUCTUREID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDBY, NegocioUtils.converterObjetoParaString(vREPORTEDBY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTDATE, NegocioUtils.converterObjetoParaString(vREPORTDATE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_TARGETFINISH, NegocioUtils.converterObjetoParaString(vTARGETFINISH));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_STATUS, NegocioUtils.converterObjetoParaString(vSTATUS));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDBYID, NegocioUtils.converterObjetoParaString(vREPORTEDBYID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_AFFECTEDPHONE, NegocioUtils.converterObjetoParaString(vREPORTEDPHONE));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_CLASSIFICATIONID, NegocioUtils.converterObjetoParaString(vCLASSIFICATIONID));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO, NegocioUtils.converterObjetoParaString(vITAUDATAAGENDAMENTO));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDPRIORITY, NegocioUtils.converterObjetoParaString(vREPORTEDPRIORITY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION, NegocioUtils.converterObjetoParaString(vFR2CODELONGDESCRIPTION));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_REPORTEDEMAIL, NegocioUtils.converterObjetoParaString(vREPORTEDEMAIL));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION, NegocioUtils.converterObjetoParaString(vDESCRIPTIONLONGDESCRIPTION));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_DESCRIPTION, NegocioUtils.converterObjetoParaString(vDESCRICAO));

			//Logs
			JsonArray objJsonArrayLogs = new JsonArray();
			
			if (vSRType[0].getWORKLOG() != null && vSRType[0].getWORKLOG().length > 0) {
			
				for (ITAUWDSRDET_WORKLOGType vWORKLOGType : vSRType[0].getWORKLOG()) {

					JsonObject objJsonLog = new JsonObject();

					MXLongType vWORKLOGID = vWORKLOGType.getWORKLOGID();
					MXStringType vRECORDKEY = vWORKLOGType.getRECORDKEY();
					MXStringType vDESCRIPTION = vWORKLOGType.getDESCRIPTION();
					MXDateTimeType vCREATEDATE = vWORKLOGType.getCREATEDATE();
					MXStringType vCREATEBY = vWORKLOGType.getCREATEBY();

					objJsonLog.addProperty(JSON_KEY_MAXIMO_TICKETUID, STRING_EMPTY);
					objJsonLog.addProperty(JSON_KEY_MAXIMO_WORKLOGID, NegocioUtils.converterObjetoParaString(vWORKLOGID));
					objJsonLog.addProperty(JSON_KEY_MAXIMO_RECORDKEY, NegocioUtils.converterObjetoParaString(vRECORDKEY));
					objJsonLog.addProperty(JSON_KEY_MAXIMO_DESCRICAO, NegocioUtils.converterObjetoParaString(vDESCRIPTION));
					objJsonLog.addProperty(JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION, NegocioUtils.converterObjetoParaString(vDESCRIPTIONLONGDESCRIPTION));
					objJsonLog.addProperty(JSON_KEY_MAXIMO_CREATEDATE, NegocioUtils.converterObjetoParaString(vCREATEDATE));
					objJsonLog.addProperty(JSON_KEY_MAXIMO_CREATEBY, NegocioUtils.converterObjetoParaString(vCREATEBY));

					objJsonArrayLogs.add(objJsonLog);
				}
			}
			
			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_LOGS, objJsonArrayLogs);
			
			//Anexos
			JsonArray objJsonArrayAnexos = new JsonArray();
			
			if (vSRType[0].getDOCLINKS() != null && vSRType[0].getDOCLINKS().length > 0) {

				for (ITAUWDSRDET_DOCLINKSType DOCLINKSType : vSRType[0].getDOCLINKS()) {
					
					JsonObject objJsonAnexo = new JsonObject();
					
					MXLongType vDOCINFOID = DOCLINKSType.getDOCINFOID();
					MXStringType vDOCTYPE = DOCLINKSType.getDOCTYPE();
					MXStringType vDOCUMENT = DOCLINKSType.getDOCUMENT();
					MXLongType vOWNERID = DOCLINKSType.getOWNERID();
					MXStringType vOWNERTABLE = DOCLINKSType.getOWNERTABLE();
					MXStringType vWEBURL = DOCLINKSType.getWEBURL();
					
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCINFOID, NegocioUtils.converterObjetoParaString(vDOCINFOID));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCTYPE, NegocioUtils.converterObjetoParaString(vDOCTYPE));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_DOCUMENT, NegocioUtils.converterObjetoParaString(vDOCUMENT));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_OWNERID, NegocioUtils.converterObjetoParaString(vOWNERID));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_OWNERTABLE, NegocioUtils.converterObjetoParaString(vOWNERTABLE));
					objJsonAnexo.addProperty(JSON_KEY_MAXIMO_WEBURL, NegocioUtils.converterObjetoParaString(vWEBURL));
					
					objJsonArrayAnexos.add(objJsonAnexo);
				}
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_ANEXOS, objJsonArrayAnexos);
			
			//Atributos
			JsonArray objJsonArrayAtributos = new JsonArray();
			
			if (vSRType[0].getTICKETSPEC() != null && vSRType[0].getTICKETSPEC().length > 0) {

				for (ITAUWDSRDET_TICKETSPECType TICKETSPECType : vSRType[0].getTICKETSPEC()) {

					JsonObject objJsonAtributo = new JsonObject();

					MXStringType vASSETATTRID = TICKETSPECType.getASSETATTRID();
					MXStringType vALNVALUE = TICKETSPECType.getALNVALUE();
					MXDoubleType vNUMVALUE = TICKETSPECType.getNUMVALUE();
					MXStringType vTABLEVALUE = TICKETSPECType.getTABLEVALUE();
					
					ITAUWDSRDET_ASSETATTRIBUTEType[] vASSETATTRIBUTEType = TICKETSPECType.getASSETATTRIBUTE();

					if (vASSETATTRIBUTEType != null && vASSETATTRIBUTEType.length > 0) {
						objJsonAtributo.addProperty(JSON_KEY_MAXIMO_DESCRICAO, NegocioUtils.converterObjetoParaString(vASSETATTRIBUTEType[0].getDESCRIPTION()));
					} else {
						objJsonAtributo.addProperty(JSON_KEY_MAXIMO_DESCRICAO, STRING_EMPTY);
					}

					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_ATRIBUTO, NegocioUtils.converterObjetoParaString(vASSETATTRID));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_VALOR, NegocioUtils.converterObjetoParaString(vALNVALUE));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_NUMERICO, NegocioUtils.converterObjetoParaString(vNUMVALUE));
					objJsonAtributo.addProperty(JSON_KEY_MAXIMO_TABELA, NegocioUtils.converterObjetoParaString(vTABLEVALUE));

					objJsonArrayAtributos.add(objJsonAtributo);
				}
			}

			objJsonDados.add(JSON_KEY_MAXIMO_LISTA_TICKETSPEC, objJsonArrayAtributos);
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);
		
		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDSRDETResponseType enviarDados(QueryITAUWDSRDETType objeto, String endpoint) throws RemoteException {
	
		//Configura o Proxy
		ITAUWDSRDETPortTypeProxy proxy = new ITAUWDSRDETPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDSRDETSOAP11BindingStub)proxy.getITAUWDSRDETPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDSRDETSOAP11BindingStub)proxy.getITAUWDSRDETPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDSRDET(objeto);
	}	
}