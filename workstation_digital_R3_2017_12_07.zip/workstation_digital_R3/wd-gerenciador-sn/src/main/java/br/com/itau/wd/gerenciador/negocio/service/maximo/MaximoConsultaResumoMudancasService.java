package br.com.itau.wd.gerenciador.negocio.service.maximo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_LIMITE_APROVACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_NUMERO_SOLICITACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_GMUD_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_MAXIMO_NUMERO_GMUD;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_MAXIMO_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ibm.www.maximo.ITAUWDWORESUMOQueryType;
import com.ibm.www.maximo.ITAUWDWORESUMOQueryTypeWOCHANGE;
import com.ibm.www.maximo.ITAUWDWORESUMO_WOCHANGEType;
import com.ibm.www.maximo.MXDomainType;
import com.ibm.www.maximo.MXStringQueryType;
import com.ibm.www.maximo.MXStringType;
import com.ibm.www.maximo.QueryITAUWDWORESUMOResponseType;
import com.ibm.www.maximo.QueryITAUWDWORESUMOType;
import com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOPortTypeProxy;
import com.ibm.www.maximo.wsdl.ITAUWDWORESUMO.ITAUWDWORESUMOSOAP11BindingStub;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

/**
 * Máximo Service - Consulta Resumo de Mudanças
 * 
 * @author ITAÚ
 *
 */
@Service
public class MaximoConsultaResumoMudancasService {

	private static final Logger logger = LoggerFactory.getLogger(MaximoConsultaResumoMudancasService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Consultar resumo de mudanças
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarResumoMudancas(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** MAXIMO - CONSULTA RESUMO GMUD - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Converte o JSON para o objeto de entrada
			QueryITAUWDWORESUMOType objeto = obterObjeto(json);
			
			//Enviar os dados
			QueryITAUWDWORESUMOResponseType resposta = enviarDados(objeto, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(resposta, json);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** MAXIMO - CONSULTA RESUMO GMUD - FINAL *****");
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Converte o JSON para o objeto
	 * 
	 * @param json
	 * @return
	 */
	private QueryITAUWDWORESUMOType obterObjeto(String json) {
		
		// Leitura do JSON
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String vWONUM = NegocioUtils.obterDadoJson(objJson, JSON_KEY_MAXIMO_NUMERO_GMUD);

		ITAUWDWORESUMOQueryTypeWOCHANGE vQueryTypeWOCHANGE = new ITAUWDWORESUMOQueryTypeWOCHANGE();
		vQueryTypeWOCHANGE.setWONUM(new MXStringQueryType[]{new MXStringQueryType(vWONUM)});

		ITAUWDWORESUMOQueryType vQueryType = new ITAUWDWORESUMOQueryType();
		vQueryType.setWOCHANGE(vQueryTypeWOCHANGE);

		QueryITAUWDWORESUMOType objeto = new QueryITAUWDWORESUMOType();
		objeto.setITAUWDWORESUMOQuery(vQueryType);

		return objeto;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(QueryITAUWDWORESUMOResponseType resposta, String json) {
		
		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
		
		JsonObject objJsonDados = new JsonObject();

		if (resposta.getITAUWDWORESUMOSet() != null && resposta.getITAUWDWORESUMOSet().length > 0) {

			ITAUWDWORESUMO_WOCHANGEType[] vWOCHANGEType = resposta.getITAUWDWORESUMOSet();

			MXStringType vWONUM = vWOCHANGEType[0].getWONUM();
			MXDomainType vSTATUS = vWOCHANGEType[0].getSTATUS();
			MXStringType vREPORTEDBY = vWOCHANGEType[0].getREPORTEDBY();

			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_NUMERO_SOLICITACAO, NegocioUtils.converterObjetoParaString(vWONUM));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE, NegocioUtils.converterObjetoParaString(vREPORTEDBY));
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_LIMITE_APROVACAO, STRING_EMPTY);
			objJsonDados.addProperty(JSON_KEY_MAXIMO_GMUD_STATUS, NegocioUtils.converterObjetoParaString(vSTATUS));
		}
		else {
			
			objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
			objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO);
		}

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Enviar os dados
	 * 
	 * @param objeto
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private QueryITAUWDWORESUMOResponseType enviarDados(QueryITAUWDWORESUMOType objeto, String endpoint) throws RemoteException { 
	
		//Configura o Proxy
		ITAUWDWORESUMOPortTypeProxy proxy = new ITAUWDWORESUMOPortTypeProxy();
	
		proxy.setEndpoint(endpoint);
		((ITAUWDWORESUMOSOAP11BindingStub)proxy.getITAUWDWORESUMOPortType()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_USER));
		((ITAUWDWORESUMOSOAP11BindingStub)proxy.getITAUWDWORESUMOPortType()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_MAXIMO_TOKEN));
	
		return proxy.queryITAUWDWORESUMO(objeto);
	}	
}