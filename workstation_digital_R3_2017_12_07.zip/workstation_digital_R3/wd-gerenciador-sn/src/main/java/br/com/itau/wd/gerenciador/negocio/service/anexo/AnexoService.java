package br.com.itau.wd.gerenciador.negocio.service.anexo;

import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_LISTA_UID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_PASTA_UPLOAD;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class AnexoService {

	@Resource
	private Environment env;

	public class Anexo {
		private String uid;
		private String nomeArquivo;
		private String descricaoArquivo;
		private String arquivoBase64;
		
		public String getUid() {
			return uid;
		}
		
		public void setUid(String uid) {
			this.uid = uid;
		}
		
		public String getNomeArquivo() {
			return nomeArquivo;
		}
		
		public void setNomeArquivo(String nomeArquivo) {
			this.nomeArquivo = nomeArquivo;
		}
		
		public String getDescricaoArquivo() {
			return descricaoArquivo;
		}
		
		public void setDescricaoArquivo(String descricaoArquivo) {
			this.descricaoArquivo = descricaoArquivo;
		}
		
		public String getArquivoBase64() {
			return arquivoBase64;
		}
		
		public void setArquivoBase64(String arquivoBase64) {
			this.arquivoBase64 = arquivoBase64;
		}
	}

	@SuppressWarnings("unchecked")
	public String obterJsonRequisicao(String json) throws NegocioException {

		String retorno = "";
		List<Anexo> arquivos = new ArrayList<>();

		try {

			String pastaUpload = env.getRequiredProperty(PROPERTY_KEY_PASTA_UPLOAD);
			Map<String, Object> mapJson = GerenciadorUtils.convertJsonToMap(json);
			Map<String, Object> mapAnexo = new HashMap<>();

			if (mapJson.containsKey(JSON_KEY_LISTA_UID)) {

				List<Object> lista = (ArrayList<Object>)mapJson.get(JSON_KEY_LISTA_UID);
	
				for (Object entry : lista) {
	
					Map<String, Object> item = (LinkedHashMap<String, Object>)entry;

					String uid = (String)item.get("uid");
					File folder = new File(pastaUpload + "\\" + uid);
					File[] listOfFiles = folder.listFiles();

					arquivos = obterArquivos(uid, listOfFiles);
				}
			}

			for (Entry<String, Object> entry : mapJson.entrySet()) {
				if (!entry.getKey().equalsIgnoreCase(JSON_KEY_LISTA_UID)) {
					mapAnexo.put(entry.getKey(), entry.getValue());
				}
			}

			mapAnexo.put("anexos", arquivos);

			retorno = new ObjectMapper().writeValueAsString(mapAnexo);
		} 
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	private List<Anexo> obterArquivos(String uid, File[] listOfFiles) throws IOException {
		
		List<Anexo> arquivos = new ArrayList<>();
		
		for (File arquivo : listOfFiles) {
			
			if (arquivo.isFile()) {

		        String nome =  arquivo.getAbsolutePath();
		        String binario = encodeFileToBase64Binary(nome);
		        
		        Anexo arq = new Anexo();

		        arq.setNomeArquivo(arquivo.getName());
		        arq.setArquivoBase64(binario);
		        arq.setUid(uid);

		        arquivos.add(arq);
		    }
		}
		
		return arquivos;
	}
	
	/**
	 * Salva o arquivo
	 * 
	 * @param file
	 * @param uid
	 * @return
	 */
	public String salvarArquivo(MultipartFile file, String uid) throws NegocioException  {

		try {

			String pastaUpload = env.getRequiredProperty(PROPERTY_KEY_PASTA_UPLOAD);
			
			//Verifica se o arquivo possui conteúdo
			if (file.isEmpty()) {
				throw new NegocioException("O arquivo esta vazio");
	        }

			//Cria a pasta
			Path pasta = Paths.get(pastaUpload + "\\" + uid);

			if (!Files.exists(pasta)) {
				Files.createDirectories(pasta);	
			}

			//Grava o arquivo
	        byte[] bytes = file.getBytes();
	        Path path = Paths.get(pastaUpload + "\\" + uid + "\\" + file.getOriginalFilename());

	        Files.write(path, bytes);
		} 
		catch (IOException ex) {
            throw new NegocioException(ex);
        }

		return "{\"status\":\"S\"}";		
	}

	/**
	 * Converte o arquivo em base 64
	 *  
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	private String encodeFileToBase64Binary(String fileName) throws IOException {

		File file = new File(fileName);
		byte[] bytes = loadFile(file);
		byte[] encoded = Base64.encodeBase64(bytes);

		return new String(encoded);
	}

	/**
	 * 
	 * @param file
	 * @return
	 * @throws IOException
	 */
	private static byte[] loadFile(File file) throws IOException {
	    
		InputStream is = new FileInputStream(file);
	    long length = file.length();
	    byte[] bytes = new byte[(int)length];
	    int offset = 0;
	    int numRead;
		
		try {
	
		    while (offset < bytes.length && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
		        offset += numRead;
		    }
	
		    if (offset < bytes.length) {
		        throw new IOException("Could not completely read file "+file.getName());
		    }
		}
		catch (Exception ex) {
			throw ex;
		}
		finally {
			is.close();			
		}
		
	    return bytes;
	}	
}