package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.dto.tms.Teleconferencia;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaEntrada;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaSaida;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapStub;

@Service
public class TMSCancelaTeleconferenciaService {

	private static final Logger logger = LoggerFactory.getLogger(TMSCancelaTeleconferenciaService.class);

	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Cancela a teleconferência
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String cancelarTeleconferencia(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - CANCELA TELECONFERENCIA *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Obtem o objeto
			TeleconferenciaEntrada conferenciaEntrada = obterObjeto(json);

			//Envia os dados
			TeleconferenciaSaida teleconferenciaSaida = enviarDados(conferenciaEntrada, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(teleconferenciaSaida, json);
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}

	/**
	 * Obter o objeto
	 * 
	 * @param json
	 */
	private TeleconferenciaEntrada obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String id = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_ID);

		TeleconferenciaEntrada teleconferenciaEntrada = new TeleconferenciaEntrada();

		teleconferenciaEntrada.getPolos().add(new Teleconferencia(Integer.parseInt(id)));

		return teleconferenciaEntrada;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param teleconferenciaSaida
	 * @param json
	 * @return
	 */
	private String obterJson(TeleconferenciaSaida teleconferenciaSaida,String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, STRING_EMPTY);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, teleconferenciaSaida.getCodigoRetorno());
		objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, teleconferenciaSaida.getDescricaoRetorno());

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param teleconferencia
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private TeleconferenciaSaida enviarDados(TeleconferenciaEntrada teleconferencia, String endpoint) throws RemoteException {

		TeleconferenciaSaida teleconferenciaSaida = new TeleconferenciaSaida(); 
		
		try {
			//Configura o Proxy
			BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();
	
			proxy.setEndpoint(endpoint);
			((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
			((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));
	
			//Envia os dados
			proxy.deleteConferenceById(teleconferencia.getPolos().get(0).getId());

			teleconferenciaSaida.setCodigoRetorno("0");
			teleconferenciaSaida.setDescricaoRetorno("");
		}
		catch (Exception ex) {

			logger.info(ex.getMessage(), ex);
			teleconferenciaSaida.setCodigoRetorno("99");
			teleconferenciaSaida.setDescricaoRetorno(ex.getMessage());
		}
		
		return teleconferenciaSaida;
	}	
}