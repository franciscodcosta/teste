package br.com.itau.wd.gerenciador.negocio.dto.tms;

import java.util.ArrayList;
import java.util.List;

public class TeleconferenciaSaida {

	private String link;
	private String pin;
	private String status;
	private String mensagem;
	private String codigoRetorno;
	private String descricaoRetorno;
	private List<Teleconferencia> lista;
	
	public TeleconferenciaSaida() {
		lista = new ArrayList<>();
	}
	
	public String getLink() {
		return link;
	}
	
	public void setLink(String link) {
		this.link = link;
	}
	
	public String getPin() {
		return pin;
	}
	
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public String getCodigoRetorno() {
		return codigoRetorno;
	}

	public void setCodigoRetorno(String codigoRetorno) {
		this.codigoRetorno = codigoRetorno;
	}

	public String getDescricaoRetorno() {
		return descricaoRetorno;
	}

	public void setDescricaoRetorno(String descricaoRetorno) {
		this.descricaoRetorno = descricaoRetorno;
	}

	public String getMensagem() {
		return mensagem;
	}
	
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	public List<Teleconferencia> getLista() {
		return lista;
	}

	public void setLista(List<Teleconferencia> lista) {
		this.lista = lista;
	}
}