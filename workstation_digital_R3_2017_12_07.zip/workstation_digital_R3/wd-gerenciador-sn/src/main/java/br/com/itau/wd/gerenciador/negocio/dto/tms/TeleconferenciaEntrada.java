package br.com.itau.wd.gerenciador.negocio.dto.tms;

import java.util.ArrayList;
import java.util.List;

public class TeleconferenciaEntrada {

	private String dataReuniao;
	private String reuniaoRecorrente;
	private String recorrencia;
	private String horaInicio;
	private String horaFim;
	private String acessoExterno;
	private List<Teleconferencia> polos;
	
	public TeleconferenciaEntrada() {
		polos = new ArrayList<>();
	}

	public String getDataReuniao() {
		return dataReuniao;
	}
	
	public void setDataReuniao(String dataReuniao) {
		this.dataReuniao = dataReuniao;
	}
	
	public String getReuniaoRecorrente() {
		return reuniaoRecorrente;
	}
	
	public void setReuniaoRecorrente(String reuniaoRecorrente) {
		this.reuniaoRecorrente = reuniaoRecorrente;
	}
	
	public String getRecorrencia() {
		return recorrencia;
	}
	
	public void setRecorrencia(String recorrencia) {
		this.recorrencia = recorrencia;
	}
	
	public String getHoraInicio() {
		return horaInicio;
	}
	
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	
	public String getHoraFim() {
		return horaFim;
	}
	
	public void setHoraFim(String horaFim) {
		this.horaFim = horaFim;
	}
	
	public String getAcessoExterno() {
		return acessoExterno;
	}
	
	public void setAcessoExterno(String acessoExterno) {
		this.acessoExterno = acessoExterno;
	}

	public List<Teleconferencia> getPolos() {
		return polos;
	}

	public void setPolos(List<Teleconferencia> polos) {
		this.polos = polos;
	}
}