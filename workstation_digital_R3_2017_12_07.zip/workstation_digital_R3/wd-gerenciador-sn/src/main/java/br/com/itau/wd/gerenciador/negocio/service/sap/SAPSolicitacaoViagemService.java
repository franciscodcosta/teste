package br.com.itau.wd.gerenciador.negocio.service.sap;

import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD;
import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_USERNAME;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CAMBIO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_MENSAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_NUMERO_SOLICITANTE;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_NUMERO_VIAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_SENHA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_USUARIO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;
import static br.com.itau.wd.gerenciador.util.Constants.TLS_V1;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.itau.WorkstationDigital.SolicitacaoViagens.DT_SolicitacaoViagens;
import br.com.itau.WorkstationDigital.SolicitacaoViagens.DT_SolicitacaoViagens_response;
import br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_out;
import br.com.itau.WorkstationDigital.SolicitacaoViagens.SI_SolicitacaoViagens_sync_outProxy;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class SAPSolicitacaoViagemService {

	private static final Logger logger = LoggerFactory.getLogger(SAPSolicitacaoViagemService.class);	
	
	@Resource
	private Environment env;

	/**
	 * Monta o JSON de envio
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, String> mapDePara = new HashMap<>();
			
			mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
			mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
			mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
			mapDePara.put(JSON_KEY_DADOS, JSON_KEY_DADOS);
			mapDePara.put(JSON_KEY_TOKEN, JSON_KEY_TOKEN);
			
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 

		} catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, String> mapDePara = new HashMap<>();
			
			String status = GerenciadorUtils.obterDadoJson(json, JSON_KEY_STATUS);
			
			if ("00".equalsIgnoreCase(status)) {
			
				mapDePara.put(JSON_KEY_NUMERO_SOLICITANTE, JSON_KEY_NUMERO_SOLICITANTE);
				mapDePara.put(JSON_KEY_NUMERO_VIAGEM, JSON_KEY_NUMERO_VIAGEM);
				mapDePara.put(JSON_KEY_CAMBIO, JSON_KEY_CAMBIO);
				mapDePara.put(JSON_KEY_UID, JSON_KEY_UID);
			} 
			else {
				
				mapDePara.put(JSON_KEY_STATUS, JSON_KEY_STATUS);
				mapDePara.put(JSON_KEY_MENSAGEM, JSON_KEY_MENSAGEM);
				mapDePara.put(JSON_KEY_UID, JSON_KEY_UID);
			}

			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 
			
		} catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Faz o processamento do SAP
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws NegocioException 
	 */
	public String obterJsonRespostaSap(String endpoint, String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** SOLICITACAO VIAGENS (SAP) *****");
			logger.info("ENDPOINT ....................... : " + endpoint);
			
			// Configurar TLS
			NegocioUtils.configurarTls(TLS_V1);

			DT_SolicitacaoViagens dtSolicitacaoViagens = convertJsonToObject(json);

			SI_SolicitacaoViagens_sync_outProxy proxy = new SI_SolicitacaoViagens_sync_outProxy(endpoint);

			SI_SolicitacaoViagens_sync_out siSolicitacaoViagensSyncOut = proxy.getSI_SolicitacaoViagens_sync_out();
		    ((javax.xml.rpc.Stub)siSolicitacaoViagensSyncOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_USERNAME, env.getRequiredProperty(PROPERTY_KEY_SAP_USUARIO));
		    ((javax.xml.rpc.Stub)siSolicitacaoViagensSyncOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD, env.getRequiredProperty(PROPERTY_KEY_SAP_SENHA));

		    DT_SolicitacaoViagens_response resposta = proxy.SI_SolicitacaoViagens_sync_out(dtSolicitacaoViagens);

			retorno = convertObjectToJson(resposta);
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Converte JSON para DT_SolicitacaoViagens
	 * 
	 * @param json
	 * @return
	 */
	private DT_SolicitacaoViagens convertJsonToObject(String json) {
		
		String chaveProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CHAVE_PRODUTO);
		String dadosRegistrarSolicitacao = GerenciadorUtils.obterDadoJson(json, JSON_KEY_DADOS);
		String funcaoAtividadeSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
		String funcaoSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
		String tokenOauth = GerenciadorUtils.obterDadoJson(json, JSON_KEY_TOKEN);

		logger.info("JSON ........................... : " + json);
		logger.info("CHAVE PRODUTO .................. : " + chaveProduto);
		logger.info("FUNCAO ATIVIDADE SISTEMA PRODUTO : " + funcaoAtividadeSistemaProduto);
		logger.info("FUNCAO SISTEMA PRODUTO ......... : " + funcaoSistemaProduto);
		logger.info("DADOS .......................... : " + dadosRegistrarSolicitacao);
		logger.info("TOKEN .......................... : " + tokenOauth);

		DT_SolicitacaoViagens dtSolicitacaoViagens = new DT_SolicitacaoViagens();

		dtSolicitacaoViagens.setChave_produto(chaveProduto);
		dtSolicitacaoViagens.setDados_registrar_solicitacao(dadosRegistrarSolicitacao);
		dtSolicitacaoViagens.setFuncao_atividade_sistema_produto(funcaoAtividadeSistemaProduto);
		dtSolicitacaoViagens.setFuncao_sistema_produto(funcaoSistemaProduto);
		dtSolicitacaoViagens.setToken_oauth(tokenOauth);
		
		return dtSolicitacaoViagens;
	}
	
	/**
	 * Converte DT_SolicitacaoViagens_response para JSON 
	 * 
	 * @param resposta
	 * @return
	 * @throws JsonProcessingException
	 */
	private String convertObjectToJson(DT_SolicitacaoViagens_response resposta) throws JsonProcessingException {
		
	    Map<String, Object> map = new HashMap<>();
	    
		map.put(JSON_KEY_NUMERO_SOLICITANTE, resposta.getNumero_Solicitante());
		map.put(JSON_KEY_NUMERO_VIAGEM, resposta.getNumero_Viagem());
		map.put(JSON_KEY_CAMBIO, resposta.getCambio());
		map.put(JSON_KEY_STATUS, resposta.getStatus());
		map.put(JSON_KEY_MENSAGEM, resposta.getMensagem());
		map.put(JSON_KEY_UID, resposta.getUID_Salerforce());
		
		return GerenciadorUtils.convertMapToJson(map);
	}
}