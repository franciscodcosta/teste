package br.com.itau.wd.gerenciador.negocio.service.tms;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ACESSO_EXTERNO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ANDAR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_DATA_REUNIAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_FIM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_HORA_INICIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_ID;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_LINK;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_LISTA_POLOS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_MENSAGEM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_NUMERO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_PIN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_POLO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_RECORRENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_REUNIAO_RECORRENTE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_STATUS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TMS_TORRE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_SECURITY_TMS_USER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.rmi.RemoteException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.negocio.dto.tms.Teleconferencia;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaEntrada;
import br.com.itau.wd.gerenciador.negocio.dto.tms.TeleconferenciaSaida;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapProxy;
import net.tandberg._2004._02.tms.external.booking.BookingServiceSoapStub;
import net.tandberg._2004._02.tms.external.booking.Conference;
import net.tandberg._2004._02.tms.external.booking.ConferenceType;
import net.tandberg._2004._02.tms.external.booking.RecurrencePattern;
import net.tandberg._2004._02.tms.external.booking.RecurringFrequency;

@Service
public class TMSReservaTeleconferenciaService {

	private static final Logger logger = LoggerFactory.getLogger(TMSReservaTeleconferenciaService.class);
	
	@Resource
	private Environment env;

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}
	
	/**
	 * Reserva conferência
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String reservarTeleconferencia(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {

			logger.info("***** TMS - RESERVA TELECONFERENCIA *****");
			logger.info("JSON REQUISIÇÃO : " + json);
			logger.info("ENDPOINT ...... : " + endpoint);

			//Obter objeto
			TeleconferenciaEntrada teleconferenciaEntrada = obterObjeto(json);
			
			//Envia os dados
			TeleconferenciaSaida teleconferenciaSaida = enviarDados(teleconferenciaEntrada, endpoint);

			//Converte o objeto para o JSON de saída
			retorno = obterJson(teleconferenciaSaida, json);

		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obter o objeto
	 * 
	 * @param json
	 * @return
	 */
	private TeleconferenciaEntrada obterObjeto(String json) {
		
		//Cria o objeto
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String dataReuniao = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_DATA_REUNIAO);
		String reuniaoRecorrente = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_REUNIAO_RECORRENTE);
		String recorrencia = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_RECORRENCIA);
		String horaInicio = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_INICIO);
		String horaFim = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_HORA_FIM);
		String acessoExterno = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TMS_ACESSO_EXTERNO);

		TeleconferenciaEntrada teleconferenciaEntrada = new TeleconferenciaEntrada();

		teleconferenciaEntrada.setDataReuniao(dataReuniao);
		teleconferenciaEntrada.setReuniaoRecorrente(reuniaoRecorrente);
		teleconferenciaEntrada.setRecorrencia(recorrencia);
		teleconferenciaEntrada.setHoraInicio(horaInicio);
		teleconferenciaEntrada.setHoraFim(horaFim);
		teleconferenciaEntrada.setAcessoExterno(acessoExterno);
		
		JsonArray objJsonArrayPolos = (JsonArray) objJson.get(JSON_KEY_TMS_LISTA_POLOS);

		for (int i = 0; i < objJsonArrayPolos.size(); i++) {

			JsonObject objJsonPolo = (JsonObject)objJsonArrayPolos.get(i);
			
			String id = objJsonPolo.get(JSON_KEY_TMS_ID).getAsString();
			String polo = objJsonPolo.get(JSON_KEY_TMS_POLO).getAsString();
			String torre = objJsonPolo.get(JSON_KEY_TMS_TORRE).getAsString();
			String andar = objJsonPolo.get(JSON_KEY_TMS_ANDAR).getAsString();
			String numero = objJsonPolo.get(JSON_KEY_TMS_NUMERO).getAsString();
			
			Teleconferencia poloDto = new Teleconferencia();
			
			poloDto.setId(Integer.parseInt(id));
			poloDto.setPolo(polo);
			poloDto.setTorre(torre);
			poloDto.setAndar(andar);
			poloDto.setNumero(numero);

			teleconferenciaEntrada.getPolos().add(poloDto);
		}
		
		return teleconferenciaEntrada;
	}
	
	/**
	 * Converte o objeto para o JSON
	 * 
	 * @param resposta
	 * @param json
	 * @return
	 */
	private String obterJson(TeleconferenciaSaida resposta, String json) {

		//Cria o JSON
		JsonObject objJsonRet = new JsonObject();

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, STRING_EMPTY);

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		objJsonDados.addProperty(JSON_KEY_TMS_LINK, resposta.getLink());
		objJsonDados.addProperty(JSON_KEY_TMS_PIN, resposta.getPin());
		objJsonDados.addProperty(JSON_KEY_TMS_STATUS, resposta.getStatus());
		objJsonDados.addProperty(JSON_KEY_TMS_MENSAGEM, resposta.getMensagem());

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param teleconferencia
	 * @param endpoint
	 * @return
	 * @throws RemoteException
	 */
	private TeleconferenciaSaida enviarDados(TeleconferenciaEntrada teleconferencia, String endpoint) throws RemoteException {

		TeleconferenciaSaida resposta = new TeleconferenciaSaida();

		//Configura o Proxy
		BookingServiceSoapProxy proxy = new BookingServiceSoapProxy();

		proxy.setEndpoint(endpoint);
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_USER));
		((BookingServiceSoapStub)proxy.getBookingServiceSoap()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_TMS_TOKEN));

		Conference[] conferenciasEntrada = obterConferencias(proxy, teleconferencia);
		
		//Envia os dados
		Conference[] conferenciasSaida = proxy.saveConferences(conferenciasEntrada, true);
		
		//String senha = conferenciasSaida[0].getPassword();
		String link = conferenciasSaida[0].getWebConferenceAttendeeUri();
		int pin = conferenciasSaida[0].getConferenceId();

		resposta.setPin(String.valueOf(pin));
		resposta.setLink(link);
		//resposta.setSenha(senha);
		
		return resposta;
	}	
	
	/**
	 * Obtem as conferencias
	 * 
	 * @param proxy
	 * @param teleconferencia
	 * @return
	 * @throws RemoteException
	 */
	private Conference[] obterConferencias(BookingServiceSoapProxy proxy,TeleconferenciaEntrada teleconferencia) throws RemoteException {

		Conference[] conferences = new Conference[teleconferencia.getPolos().size()];
		
		for (int i = 0; i < conferences.length; i++) {
			
			conferences[i] = proxy.getDefaultConference();
	
			conferences[i].setStartTimeUTC(teleconferencia.getHoraInicio());
			conferences[i].setEndTimeUTC(teleconferencia.getHoraFim());
			conferences[i].setConferenceType(ConferenceType.fromString("Reservation Only"));
			
			RecurrencePattern recurrencePattern = new RecurrencePattern();
	
			recurrencePattern.setFrequencyType(RecurringFrequency.Daily);
			recurrencePattern.setInterval(0);
	
			conferences[i].setRecurrencePattern(recurrencePattern);
		}
		
		return conferences;
	}
}