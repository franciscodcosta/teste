package br.com.itau.wd.gerenciador.negocio.service.pagamento;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_AACOMPET;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDCRED;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDEMPPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDMOTALC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CTACTBPG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DESCPGT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DESCTBPG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTEMIPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTVENCI;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_ICLIBPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDAUTPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDAUTPAG2;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDMENSAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDNAT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_MMCOMPET;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NATCNBSI;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NMCREDOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRDOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRINTCOB;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRINTDOC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PADOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PBCO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PFATVENC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PGMLOGLP;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PNRINTDOC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PNUMCOBPG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_SEDOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_TIPOPGT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_TPMODDOC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_VALBR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_VALIQ;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itau.ob6.workstation.PjExpectedException;
import com.itau.ob6.workstation.WorkstationPagamentoProxy;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

@Service
public class PagamentoConsultaPendenciaService {

	private static final Logger logger = LoggerFactory.getLogger(PagamentoConsultaPendenciaService.class);
	
	@Resource
	private Environment env;
	
	/**
	 * Retorna o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		return json;
	}

	/**
	 * Retorna o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonResposta = new JsonObject();

			objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO));
			objJsonResposta.addProperty(JSON_KEY_UID, NegocioUtils.obterDadoJson(objJson, JSON_KEY_UID));
			objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

			retorno = objJsonResposta.toString();
		} 
		catch (Exception ex) {
	
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Consulta Pendência
	 * 
	 * @param jsonRequisicao
	 * @param endpoint
	 * @return
	 * @throws NegocioException
	 */
	public String consultarPendencia(String jsonRequisicao, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {
			
			logger.info("***** OB6 - CONSULTA PENDENCIA - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + jsonRequisicao);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Obtem o JSON de entrada
			String jsonEntradaOb6 = obterJsonEntrada(jsonRequisicao);

			//Envia os dados
			String jsonSaidaOb6 = enviarDados(jsonEntradaOb6, endpoint);

			//Obtem o JSON
			retorno = obterJsonSaida(jsonSaidaOb6, jsonRequisicao);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** OB6 - CONSULTA PENDENCIA - FINAL *****");
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obtem o JSON de entrada
	 * 
	 * @param json
	 * @return
	 */
	private String obterJsonEntrada(String jsonEntrada) {

		JsonObject objJson = (JsonObject) new JsonParser().parse(jsonEntrada);

		String pnrintdoc = NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO);
		String pgmloglp = NegocioUtils.obterDadoJson(objJson, JSON_KEY_PAGAMENTO_PGMLOGLP);

		JsonObject objJsonEntrada = new JsonObject();

		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PNRINTDOC, pnrintdoc);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PGMLOGLP, pgmloglp);

		return objJsonEntrada.toString();
	}

	/**
	 * Obtem o JSON
	 * 
	 * @param jsonDados
	 * @param json
	 * @return
	 */
	private String obterJsonSaida(String jsonDados, String json) {

		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		JsonObject objJsonDadosOb6 = (JsonObject) new JsonParser().parse(jsonDados);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_CHAVE_PRODUTO);

		//Cria o JSON de retorno
		JsonObject objJsonRet = new JsonObject();

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		JsonObject objJsonDados = new JsonObject();

		String nrintdoc = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_NRINTDOC);
		String cdcred = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_CDCRED);
		String nmcredor = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_NMCREDOR);
		String tpmoddoc = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_TPMODDOC);
		String nrdocpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_NRDOCPAG);
		String valbr = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_VALBR);
		String valiq = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_VALIQ);
		String dtpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DTPAG);
		String pbco = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_PBCO);
		String pfatvenc = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_PFATVENC);
		String pnumcobpg = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_PNUMCOBPG);
		String tipopgt = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_TIPOPGT);
		String nrintcob = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_NRINTCOB);
		String idautpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_IDAUTPAG);
		String idautpag2 = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_IDAUTPAG2);
		String dtvenci = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DTVENCI);		
		String cdmotalc = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_CDMOTALC);
		String iclibpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_ICLIBPAG);
		String sedocpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_SEDOCPAG);
		String padocpag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_PADOCPAG);
		String dtemipag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DTEMIPAG);
		String cdemppag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_CDEMPPAG);
		String descpgt = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DESCPGT);
		String idmensag = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_IDMENSAG);
		String ctactbpg = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_CTACTBPG);
		String desctbpg = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DESCTBPG);
		String idnat = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_IDNAT);
		String natcnbsi = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_NATCNBSI);
		String mmcompet = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_MMCOMPET);
		String aacompet = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_AACOMPET);
		
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_NRINTDOC, nrintdoc);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_CDCRED, cdcred);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_NMCREDOR, nmcredor);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_TPMODDOC, tpmoddoc);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_NRDOCPAG, nrdocpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_VALBR, valbr);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_VALIQ, valiq);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_DTPAG, dtpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_PBCO, pbco);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_PFATVENC, pfatvenc);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_PNUMCOBPG, pnumcobpg);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_TIPOPGT, tipopgt);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_NRINTCOB, nrintcob);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_IDAUTPAG, idautpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_IDAUTPAG2, idautpag2);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_DTVENCI, dtvenci);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_CDMOTALC, cdmotalc);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_ICLIBPAG, iclibpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_SEDOCPAG, sedocpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_PADOCPAG, padocpag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_DTEMIPAG, dtemipag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_CDEMPPAG, cdemppag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_DESCPGT, descpgt);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_IDMENSAG, idmensag);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_CTACTBPG, ctactbpg);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_DESCTBPG, desctbpg);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_IDNAT, idnat);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_NATCNBSI, natcnbsi);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_MMCOMPET, mmcompet);
		objJsonDados.addProperty(JSON_KEY_PAGAMENTO_AACOMPET, aacompet);

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}

	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException 
	 */
	private String enviarDados(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {
			//Configura o Proxy
			WorkstationPagamentoProxy proxy = new WorkstationPagamentoProxy();
			
			proxy.setEndpoint(endpoint);
			//((WorkstationServicePortBindingStub)proxy.getWorkstationService()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_PAGAMENTO_USER));
			//((WorkstationServicePortBindingStub)proxy.getWorkstationService()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_PAGAMENTO_TOKEN));
			
			retorno = proxy.consultaPendencia(json);
		}
		catch (PjExpectedException ex) {
			
			throw new NegocioException(ex.getMessage());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex.getMessage());
		}

		return retorno;
	}
}