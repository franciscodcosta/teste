package br.com.itau.wd.gerenciador.negocio.utils;

public class Constants {

	//MAXIMO
	public static final String JSON_KEY_MAXIMO_CREATEBY = "criado_por";
	public static final String JSON_KEY_MAXIMO_CREATEDATE = "criado_em";
	public static final String JSON_KEY_MAXIMO_REPORTEDBY = "relatado_por";
	public static final String JSON_KEY_MAXIMO_SOLICITANTE = "solicitante";
	public static final String JSON_KEY_MAXIMO_USUARIO_AFETADO = "usuario_afetado";
	public static final String JSON_KEY_MAXIMO_REPORTEDBYID = "id_relatado_por";
	public static final String JSON_KEY_MAXIMO_REPORTDATE = "relatado_em";
	public static final String JSON_KEY_MAXIMO_DATA_ABERTURA = "data_abertura";
	public static final String JSON_KEY_MAXIMO_LIMITE_APROVACAO = "limite_aprovacao";
	public static final String JSON_KEY_MAXIMO_REPORTEDPRIORITY = "prioridade";
	public static final String JSON_KEY_MAXIMO_TARGETFINISH = "termino_previsto";
	public static final String JSON_KEY_MAXIMO_AFFECTEDPERSON = "em_nome_de"; 
	public static final String JSON_KEY_MAXIMO_CLASSSTRUCTUREID = "id_estrutura_classe";
	public static final String JSON_KEY_MAXIMO_CLASSIFICATIONID =  "id_classificacao";
	public static final String JSON_KEY_MAXIMO_ITAU_DATAAGENDAMENTO = "data_agendamento";
	public static final String JSON_KEY_MAXIMO_DESCRIPTION = "resumo";
	public static final String JSON_KEY_MAXIMO_DESCRIPTION_LONGDESCRIPTION = "detalhes";
	public static final String JSON_KEY_MAXIMO_FR2CODE_LONGDESCRIPTION = "resolucao";
	public static final String JSON_KEY_MAXIMO_REPORTEDEMAIL = "email";
	public static final String JSON_KEY_MAXIMO_LOCATION = "localizacao";
	public static final String JSON_KEY_MAXIMO_AFFECTEDPHONE = "telefone";
	public static final String JSON_KEY_MAXIMO_FILTRO = "filtro";
	public static final String JSON_KEY_MAXIMO_ACTION = "action";
	public static final String JSON_KEY_MAXIMO_REASON = "reason";
	public static final String JSON_KEY_MAXIMO_USERID = "user_id";
	public static final String JSON_KEY_MAXIMO_TIPO = "tipo";
	public static final String JSON_KEY_MAXIMO_LOGTYPE = "tipo_log";
	public static final String JSON_KEY_MAXIMO_CLIENTVIEWABLE = "visualizavel";
	public static final String JSON_KEY_MAXIMO_WORKLOGID = "work_log_id";
	public static final String JSON_KEY_MAXIMO_RECORDKEY = "record_key";
	public static final String JSON_KEY_MAXIMO_DESCRICAO = "descricao";
	public static final String JSON_KEY_MAXIMO_DOCTYPE = "doc_tipo";
	public static final String JSON_KEY_MAXIMO_DOCUMENT = "documento";
	public static final String JSON_KEY_MAXIMO_OWNERID = "owner_id";
	public static final String JSON_KEY_MAXIMO_OWNERTABLE = "owner_table";
	public static final String JSON_KEY_MAXIMO_URLTYPE = "tipo_url";
	public static final String JSON_KEY_MAXIMO_WEBURL = "doc_url";
	public static final String JSON_KEY_MAXIMO_DOCINFOID = "doc_id";
	public static final String JSON_KEY_MAXIMO_DOCUMENTDATA = "dados_doc";
	public static final String JSON_KEY_MAXIMO_ATRIBUTO = "atributo";
	public static final String JSON_KEY_MAXIMO_ASSETATTRID = "id_atributo";
	public static final String JSON_KEY_MAXIMO_DOMAINID = "dominio_id";
	public static final String JSON_KEY_MAXIMO_ORGID = "org_id";
	public static final String JSON_KEY_MAXIMO_SECTION = "secao";
	public static final String JSON_KEY_MAXIMO_SITEID = "site_id";
	public static final String JSON_KEY_MAXIMO_ALNVALUE = "valor_atributo_alfanumerico";
	public static final String JSON_KEY_MAXIMO_NUMVALUE = "valor_atributo_numerico";
	public static final String JSON_KEY_MAXIMO_TABLEVALUE = "valor_atributo_tabela";
	public static final String JSON_KEY_MAXIMO_VALOR = "valor";
	public static final String JSON_KEY_MAXIMO_NUMERICO = "numerico";
	public static final String JSON_KEY_MAXIMO_TABELA = "tabela";
	public static final String JSON_KEY_MAXIMO_ID_SOLICITACAO = "id_solicitacao";
	public static final String JSON_KEY_MAXIMO_TICKETID = "ticket_id";
	public static final String JSON_KEY_MAXIMO_TICKETUID = "ticket_uid";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_CORPORATIVO = "corporativo";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_DESCRICAO = "description";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU = "itau";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWREDE = "itau_swrede";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_ITAU_SWSISTEMAID = "itau_swsistemaid";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_LICENCIADO = "licenciado";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_RESTRITO = "restrito";
	public static final String JSON_KEY_MAXIMO_SOFTWARE_TIPO = "tipo";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSIFICATIONID = "classification_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_CLASSSTRUCTUREID = "class_structure_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_DESCRIPTION = "description";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_ASSETATTRID = "asset_attr_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_DOMAINID = "domain_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_ORGID = "org_id";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_SECTION = "section";
	public static final String JSON_KEY_MAXIMO_CLASSIFICACAO_SITEID = "site_id";
	public static final String JSON_KEY_MAXIMO_STATUS = "status";
	public static final String JSON_KEY_MAXIMO_GMUD_NOME_SOLICITANTE = "nome_solicitante";
	public static final String JSON_KEY_MAXIMO_GMUD_NUMERO_SOLICITACAO = "numero_solicitacao";
	public static final String JSON_KEY_MAXIMO_GMUD_NUMERO_MUDANCA = "numero_mudanca";
	public static final String JSON_KEY_MAXIMO_NUMERO_GMUD = "numero_gmud";
	public static final String JSON_KEY_MAXIMO_GMUD_FUNCIONAL_SOLICITANTE = "funcional_solicitante";
	public static final String JSON_KEY_MAXIMO_GMUD_LIMITE_APROVACAO = "limite_aprovacao";
	public static final String JSON_KEY_MAXIMO_GMUD_NOME_SOLICITACAO = "nome_solicitacao";
	public static final String JSON_KEY_MAXIMO_GMUD_DESCRICAO = "descricao";
	public static final String JSON_KEY_MAXIMO_GMUD_TIPO = "tipo";
	public static final String JSON_KEY_MAXIMO_GMUD_DETALHES = "detalhes";
	public static final String JSON_KEY_MAXIMO_GMUD_MOTIVO = "motivo";
	public static final String JSON_KEY_MAXIMO_GMUD_INICIO = "inicio";
	public static final String JSON_KEY_MAXIMO_GMUD_FIM = "fim";
	public static final String JSON_KEY_MAXIMO_GMUD_RISCO = "risco";
	public static final String JSON_KEY_MAXIMO_GMUD_IMPACTO = "impacto";
	public static final String JSON_KEY_MAXIMO_GMUD_PROBABILIDADE_IMPACTO = "probabilidade_impacto";
	public static final String JSON_KEY_MAXIMO_GMUD_STATUS = "status";  
	public static final String JSON_KEY_MAXIMO_LISTA_ANEXOS = "anexos";
	public static final String JSON_KEY_MAXIMO_LISTA_LOGS = "logs";
	public static final String JSON_KEY_MAXIMO_LISTA_ATRIBUTOS = "atributos";
	public static final String JSON_KEY_MAXIMO_LISTA_TICKETSPEC = "ticket_spec";
	public static final String JSON_KEY_MAXIMO_LISTA_TICKETS = "tickets";
	public static final String JSON_KEY_MAXIMO_LISTA_SOFTWARE = "softwares";
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSIFICACOES = "class_structure";
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSIFICACAO_CLASSSPEC = "class_spec"; 
	public static final String JSON_KEY_MAXIMO_LISTA_CLASSFICACAO_ASSETATTRIBUTE = "asset_attribute";
	public static final String JSON_KEY_MAXIMO_LISTA_SR = "sr";
	
	public static final String CONSTANTE_MAXIMO_SR = "SR";
	public static final String CONSTANTE_MAXIMO_EXTERNALSYSTEM = "WD";
	public static final String CONSTANTE_MAXIMO_SOFTWARE = "Software";
	public static final String CONSTANTE_MAXIMO_SITEID = "ITAU-UBB";
	
	public static final String PROPERTY_KEY_SECURITY_MAXIMO_USER = "security.maximo.user";
	public static final String PROPERTY_KEY_SECURITY_MAXIMO_TOKEN = "security.maximo.token";
	
	public static final String COD_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO = "99";
	public static final String MSG_ERRO_MAXIMO_REGISTRO_NAO_ENCONTRADO = "registro não encontrado";
	public static final String COD_SUCESSO_MAXIMO = "0";
	public static final String MSG_SUCESSO_MAXIMO = "processado com sucesso";

	//CAMBIO
	public static final String JSON_KEY_CAMBIO_CODRET = "codret";
	public static final String JSON_KEY_CAMBIO_SQLCODE = "sqlcode";
	public static final String JSON_KEY_CAMBIO_MSGRET = "msgret";
	public static final String JSON_KEY_CAMBIO_SEGMENTO = "segmento";
	public static final String JSON_KEY_CAMBIO_RAMOATIV = "ramoativ";
	public static final String JSON_KEY_CAMBIO_COLABORADOR = "colaborador";
	public static final String JSON_KEY_CAMBIO_SPI = "spi";
	public static final String JSON_KEY_CAMBIO_FREQUENCIA = "frequencia";
	public static final String JSON_KEY_CAMBIO_AGENCIA = "agencia";
	public static final String JSON_KEY_CAMBIO_CONTA = "conta";
	public static final String JSON_KEY_CAMBIO_PANICO = "panico";
	public static final String JSON_KEY_CAMBIO_SPREADHIS = "spreadhis";
	public static final String JSON_KEY_CAMBIO_SPREADFIN = "spreadfin";
	public static final String JSON_KEY_CAMBIO_SPREADMAX = "spreadmax";
	public static final String JSON_KEY_CAMBIO_SPREADMIN = "spreadmin";
	public static final String JSON_KEY_CAMBIO_INDALTGNI = "indaltgni";
	public static final String JSON_KEY_CAMBIO_INDFUNC = "indfunc";
	public static final String JSON_KEY_CAMBIO_STATUSIS = "statusis";
	public static final String JSON_KEY_CAMBIO_CHAVE = "chave";
	public static final String JSON_KEY_CAMBIO_CODIGOCANAL = "Canal.CodigoCanal";
	public static final String JSON_KEY_CAMBIO_VALOR = "valor";
	public static final String JSON_KEY_CAMBIO_HEADER = "header";
	public static final String JSON_KEY_CAMBIO_FUNCIONAL = "funcional";
	
	public static final String CONSTANTE_CAMBIO_CONTEXTOCANAL = "contextocanal";
	
	//TMS
	public static final String JSON_KEY_TMS_DATA_REUNIAO = "data_reuniao";
	public static final String JSON_KEY_TMS_REUNIAO_RECORRENTE = "reuniao_recorrente";
	public static final String JSON_KEY_TMS_RECORRENCIA = "recorrencia";
	public static final String JSON_KEY_TMS_HORA_INICIO = "hora_inicio";
	public static final String JSON_KEY_TMS_QTDE_HORAS = "qtde_horas";
	public static final String JSON_KEY_TMS_QTDE_PESSOAS = "qtde_pessoas";
	public static final String JSON_KEY_TMS_HORA_FIM = "hora_fim";
	public static final String JSON_KEY_TMS_LINK = "link";
	public static final String JSON_KEY_TMS_PIN = "pin";
	public static final String JSON_KEY_TMS_TOKEN = "token";
	public static final String JSON_KEY_TMS_ACESSO_EXTERNO = "acesso_externo";
	public static final String JSON_KEY_TMS_POLO = "polo";
	public static final String JSON_KEY_TMS_TORRE = "torre";
	public static final String JSON_KEY_TMS_ANDAR = "andar";
	public static final String JSON_KEY_TMS_NUMERO = "numero";
	public static final String JSON_KEY_TMS_CAPACIDADE = "capacidade";
	public static final String JSON_KEY_TMS_LISTA_ESPERA = "lista_espera";
	public static final String JSON_KEY_TMS_LISTA_POLOS = "polos";
	public static final String JSON_KEY_TMS_MENSAGEM = "mensagem";
	public static final String JSON_KEY_TMS_STATUS = "status";
	public static final String JSON_KEY_TMS_ID = "id";
	public static final String JSON_KEY_TMS_TOTAL_PAGINAS = "total_paginas";
	
	public static final String PROPERTY_KEY_SECURITY_TMS_USER = "security.tms.user";
	public static final String PROPERTY_KEY_SECURITY_TMS_TOKEN = "security.tms.token";
	
	//Tarefódromo
	public static final String JSON_KEY_TAREFODROMO_FUNCIONAL = "funcional";
	public static final String JSON_KEY_TAREFODROMO_IND_PROXIMA_PAGINA = "ind_proxima_pagina";
	public static final String JSON_KEY_TAREFODROMO_IND_PROXIMA_ANTERIOR = "ind_proxima_anterior";
	public static final String JSON_KEY_TAREFODROMO_IND_PAGINACAO = "ind_paginacao";
	public static final String JSON_KEY_TAREFODROMO_QTD_OCORRENCIAS = "qtd_ocorrencias";
	public static final String JSON_KEY_TAREFODROMO_COD_PENDENCIA = "cod_pendencia";
	public static final String JSON_KEY_TAREFODROMO_FUNCIONAL_COLABORADOR = "funcional_colaborador";
	public static final String JSON_KEY_TAREFODROMO_NOME_PENDENCIA = "nome_pendencia";
	public static final String JSON_KEY_TAREFODROMO_URL_PENDENCIA = "url_pendencia";
	public static final String JSON_KEY_TAREFODROMO_DESCRICAO_PENDENCIA = "descricao_pendencia";
	public static final String JSON_KEY_TAREFODROMO_COD_TIPO_AUTENTICACAO = "cod_tipo_autenticacao";
	public static final String JSON_KEY_TAREFODROMO_QTD_PENDENCIAS = "qtd_pendencias";
	public static final String JSON_KEY_TAREFODROMO_LISTA_PENDENCIAS = "pendencias";

	public static final String PROPERTY_KEY_TAREFODROMO_IMS_COMPUTADOR = "tarefodromo.ims.computador";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_PORTA = "tarefodromo.ims.porta";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS = "tarefodromo.ims";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_USUARIO = "tarefodromo.ims.usuario";
	public static final String PROPERTY_KEY_TAREFODROMO_IMS_TOKEN = "tarefodromo.ims.token";

	public static final String CONSTANTE_TAREFODROMO_TRANCODE = "CF5I016 ";

	//Pagamentos
	public static final String COD_ERRO_PAGAMENTO = "99";
	public static final String COD_SUCESSO_PAGAMENTO = "0";
	public static final String MSG_SUCESSO_PAGAMENTO = "Processamento efetuado com sucesso";

	public static final String PROPERTY_KEY_SECURITY_PAGAMENTO_USER = "";
	public static final String PROPERTY_KEY_SECURITY_PAGAMENTO_TOKEN = "";
	
	public static final String JSON_KEY_PAGAMENTO_PNRINTDOC = "pnrintdoc";
	public static final String JSON_KEY_PAGAMENTO_PGMLOGLP = "pgmloglp";
	public static final String JSON_KEY_PAGAMENTO_CONTADOR_PAGINAS = "contador_paginas";
	public static final String JSON_KEY_PAGAMENTO_QTD_POR_PAGINA = "qtd_por_pagina";
	public static final String JSON_KEY_PAGAMENTO_NRINTDOC = "nrintdoc";
	public static final String JSON_KEY_PAGAMENTO_CDCRED = "cdcred";
	public static final String JSON_KEY_PAGAMENTO_NMCREDOR = "nmcredor";
	public static final String JSON_KEY_PAGAMENTO_TPMODDOC = "tpmoddoc";
	public static final String JSON_KEY_PAGAMENTO_NRDOCPAG = "nrdocpag";
	public static final String JSON_KEY_PAGAMENTO_VALBR = "valbr";
	public static final String JSON_KEY_PAGAMENTO_VALIQ = "valiq";
	public static final String JSON_KEY_PAGAMENTO_DTPAG = "dtpag";
	public static final String JSON_KEY_PAGAMENTO_PBCO = "pbco";
	public static final String JSON_KEY_PAGAMENTO_PFATVENC = "pfatvenc";
	public static final String JSON_KEY_PAGAMENTO_PNUMCOBPG = "pnumcobpg";
	public static final String JSON_KEY_PAGAMENTO_TIPOPGT = "tipopgt";
	public static final String JSON_KEY_PAGAMENTO_NRINTCOB = "nrintcob";
	public static final String JSON_KEY_PAGAMENTO_IDAUTPAG = "idautpag";
	public static final String JSON_KEY_PAGAMENTO_IDAUTPAG2 = "idautpag2";
	public static final String JSON_KEY_PAGAMENTO_DTVENCI = "dtvenci";
	public static final String JSON_KEY_PAGAMENTO_CDMOTALC = "cdmotalc";
	public static final String JSON_KEY_PAGAMENTO_ICLIBPAG = "iclibpag";
	public static final String JSON_KEY_PAGAMENTO_SEDOCPAG = "sedocpag";
	public static final String JSON_KEY_PAGAMENTO_PADOCPAG = "padocpag";
	public static final String JSON_KEY_PAGAMENTO_DTEMIPAG = "dtemipag";
	public static final String JSON_KEY_PAGAMENTO_CDEMPPAG = "cdemppag";
	public static final String JSON_KEY_PAGAMENTO_DESCPGT = "descpgt";
	public static final String JSON_KEY_PAGAMENTO_IDMENSAG = "idmensag";
	public static final String JSON_KEY_PAGAMENTO_CTACTBPG = "ctactbpg";
	public static final String JSON_KEY_PAGAMENTO_DESCTBPG = "desctbpg";
	public static final String JSON_KEY_PAGAMENTO_IDNAT = "idnat";
	public static final String JSON_KEY_PAGAMENTO_NATCNBSI = "natcnbsi";
	public static final String JSON_KEY_PAGAMENTO_MMCOMPET = "mmcompet";
	public static final String JSON_KEY_PAGAMENTO_AACOMPET = "aacompet";
	public static final String JSON_KEY_PAGAMENTO_OPERADOR = "operador";
	public static final String JSON_KEY_PAGAMENTO_OPERACAO = "operacao";
	public static final String JSON_KEY_PAGAMENTO_MENSAGEM = "mensagem";
	public static final String JSON_KEY_PAGAMENTO_CONFIRM = "confirm";
	public static final String JSON_KEY_PAGAMENTO_COMENTARIO = "comentario";
	public static final String JSON_KEY_PAGAMENTO_CDEMPAUT = "cdempaut";
	public static final String JSON_KEY_PAGAMENTO_JUSTIFICATIVA = "justificativa";
	public static final String JSON_KEY_PAGAMENTO_DESCRICAO_ERRO = "descricao_erro";
	
	private Constants() {}
}