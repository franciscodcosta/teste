package br.com.itau.wd.gerenciador.negocio.service.tarefodromo;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.CONSTANTE_TAREFODROMO_TRANCODE;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_COD_PENDENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_COD_TIPO_AUTENTICACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_DESCRICAO_PENDENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_FUNCIONAL;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_FUNCIONAL_COLABORADOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_IND_PAGINACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_IND_PROXIMA_ANTERIOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_IND_PROXIMA_PAGINA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_LISTA_PENDENCIAS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_NOME_PENDENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_QTD_OCORRENCIAS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_QTD_PENDENCIAS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_TAREFODROMO_URL_PENDENCIA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_TAREFODROMO_IMS;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_TAREFODROMO_IMS_COMPUTADOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_TAREFODROMO_IMS_PORTA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_TAREFODROMO_IMS_TOKEN;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.PROPERTY_KEY_TAREFODROMO_IMS_USUARIO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itau.pj.ims.PjTcpIms;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

@Service
public class TarefodromoService {

	private static final Logger logger = LoggerFactory.getLogger(TarefodromoService.class);
	
	@Resource
	private Environment env;

	private class Pendencia {
		
		private String codigoPendencia;
		private String funcionalColaborador;
		private String nomePendencia;
		private String urlPendencia;
		private String descricaoPendencia;
		private String codigoTipoAutenticacao;
		private String qtdePendencia;
	}

	/**
	 * Obtem o JSON de requisicao
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		return json;
	}

	/**
	 * Obtem o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		JsonObject objJsonResposta = new JsonObject();

		objJsonResposta.addProperty(JSON_KEY_CHAVE_PRODUTO, objJson.get(JSON_KEY_CHAVE_PRODUTO).getAsString());
		objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

		return objJsonResposta.toString();
	}

	/**
	 * Consulta Pendência
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String consultaPendencia(String json) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {
			
			//Obtem o trancode
			String trancode = obterTrancode(json);

			//Envia os dados
			String saida = enviarDados(trancode);

			//Obtem o JSON
			retorno = obterJson(saida, json);
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obtem o Trancode
	 * 
	 * @param json
	 * @return
	 */
	private String obterTrancode(String json) {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String funcional = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TAREFODROMO_FUNCIONAL);
		String indProximaPagina = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TAREFODROMO_IND_PROXIMA_PAGINA);
		String qtdOcorrencias = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TAREFODROMO_QTD_OCORRENCIAS);

		StringBuilder trancode = new StringBuilder();

		trancode.append(CONSTANTE_TAREFODROMO_TRANCODE);
		trancode.append(NegocioUtils.preencherZerosEsquerda(funcional, 9));
		trancode.append(NegocioUtils.preencherZerosEsquerda(indProximaPagina, 5));
		trancode.append(NegocioUtils.preencherZerosEsquerda(qtdOcorrencias, 9));

		return trancode.toString();
	}
	
	/**
	 * Obtem o JSON
	 * 
	 * @param dados
	 * @param json
	 * @return
	 */
	private String obterJson(String dados, String json) {
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);

		String chaveProduto = NegocioUtils.obterDadoJson(objJson, JSON_KEY_TAREFODROMO_FUNCIONAL);

		//Cria o JSON de retorno
		JsonObject objJsonRet = new JsonObject();

		objJsonRet.addProperty(JSON_KEY_CHAVE_PRODUTO, chaveProduto);

		String indProximaPagina = dados.substring(106, 115);
		String indProximaAnterior = dados.substring(115, 124);
		String indPaginacao = dados.substring(124, 125);
		int qtdOcorrencias = Integer.parseInt(dados.substring(125, 130));

		JsonObject objJsonDados = new JsonObject();

		objJsonDados.addProperty(JSON_KEY_TAREFODROMO_IND_PROXIMA_PAGINA, indProximaPagina);
		objJsonDados.addProperty(JSON_KEY_TAREFODROMO_IND_PROXIMA_ANTERIOR, indProximaAnterior);
		objJsonDados.addProperty(JSON_KEY_TAREFODROMO_IND_PAGINACAO, indPaginacao);
		objJsonDados.addProperty(JSON_KEY_TAREFODROMO_QTD_OCORRENCIAS, qtdOcorrencias);

		List<Pendencia> lista = obterLista(dados, qtdOcorrencias);

		JsonArray objJsonArrayPendencias = new JsonArray();

		for (Pendencia pendencia : lista) {

			JsonObject objJsonPendencia = new JsonObject();
			
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_COD_PENDENCIA, pendencia.codigoPendencia);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_FUNCIONAL_COLABORADOR, pendencia.funcionalColaborador);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_NOME_PENDENCIA, pendencia.nomePendencia);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_URL_PENDENCIA, pendencia.urlPendencia);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_DESCRICAO_PENDENCIA, pendencia.descricaoPendencia);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_COD_TIPO_AUTENTICACAO, pendencia.codigoTipoAutenticacao);
			objJsonPendencia.addProperty(JSON_KEY_TAREFODROMO_QTD_PENDENCIAS, pendencia.qtdePendencia);
			
			objJsonArrayPendencias.add(objJsonPendencia);
		}

		objJsonDados.add(JSON_KEY_TAREFODROMO_LISTA_PENDENCIAS, objJsonArrayPendencias);

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}

	/**
	 * Envia os dados
	 * 
	 * @param trancode
	 * @return
	 * @throws NegocioException
	 */
	private String enviarDados(String trancode) throws NegocioException {

		String computador = env.getRequiredProperty(PROPERTY_KEY_TAREFODROMO_IMS_COMPUTADOR);
		int porta = Integer.parseInt(env.getRequiredProperty(PROPERTY_KEY_TAREFODROMO_IMS_PORTA));
		String ims = env.getRequiredProperty(PROPERTY_KEY_TAREFODROMO_IMS);
		String transacao = trancode.substring(0, 5);
		String usuario = env.getRequiredProperty(PROPERTY_KEY_TAREFODROMO_IMS_USUARIO);
		String token = env.getRequiredProperty(PROPERTY_KEY_TAREFODROMO_IMS_TOKEN);
		String envio = trancode.substring(5);

		logger.info("COMPUTADOR ... : " + computador);
		logger.info("PORTA ........ : " + porta);
		logger.info("IMS .......... : " + ims);
		logger.info("TRANSACAO .... : " + transacao);
		logger.info("USUARIO ...... : " + usuario);
		logger.info("TOKEN ........ : " + token);
		logger.info("ENVIO ........ : " + envio);
		
		PjTcpIms pjTcpIms = new PjTcpIms();

		int ret = pjTcpIms.ComunicaIMS(computador, porta, ims, transacao, usuario, token, envio);

		logger.info("RET .......... :" + ret);
		logger.info("INDICE SEMENTE :" + pjTcpIms.getIndiceSemente());
		logger.info("MSGERRO ...... :" + pjTcpIms.getMensErro());
		logger.info("NUM RECEBES .. :" + pjTcpIms.getNumRecebes());
		logger.info("REASON CODE .. :" + pjTcpIms.getReasonCode());
		logger.info("RECEBE ....... :" + pjTcpIms.getRecebe());
		logger.info("TOTAL RECEBIDO :" + pjTcpIms.getTotalRecebido());
		logger.info("VERSAO ....... :" + pjTcpIms.getVersao());

		if (ret != 0) {

			throw new NegocioException(pjTcpIms.getMensErro());
		} 
		else {

			if (!"0".equals(pjTcpIms.getRecebe().substring(5, 6))) {

				String msgErro = pjTcpIms.getRecebe().substring(6).trim(); 
				throw new NegocioException(msgErro);
			}
		}

		return pjTcpIms.getRecebe();
	}

	/**
	 * Obtem a lista de pendências
	 * 
	 * @param dados
	 * @param qtdOcorrencias
	 * @return
	 */
	private List<Pendencia> obterLista(String dados, int qtdOcorrencias) {

		List<Pendencia> lista = new ArrayList<>();
		int posicao = 130;
		String registro;

		for (int i = 0; i < qtdOcorrencias; i++) {

			registro = dados.substring(posicao, posicao + 2277);
			
			String codigoPendencia = registro.substring(0, 9);
			String funcionalColaborador = registro.substring(9, 18);
			String nomePendencia = registro.substring(18, 118);
			String urlPendencia = registro.substring(118, 2166);
			String descricaoPendencia = registro.substring(2166, 2266);
			String codigoTipoAutenticacao = registro.substring(2266, 2272);
			String qtdePendencia = registro.substring(2272, 2277);

			Pendencia pendencia = new Pendencia();

			pendencia.codigoPendencia = codigoPendencia.trim();
			pendencia.funcionalColaborador = funcionalColaborador.trim();
			pendencia.nomePendencia = nomePendencia.trim();
			pendencia.urlPendencia = urlPendencia.trim();
			pendencia.descricaoPendencia = descricaoPendencia.trim();
			pendencia.codigoTipoAutenticacao = codigoTipoAutenticacao.trim();
			pendencia.qtdePendencia = qtdePendencia.trim();

			lista.add(pendencia);

			posicao += 2277;
		}

		return lista;
	}
}