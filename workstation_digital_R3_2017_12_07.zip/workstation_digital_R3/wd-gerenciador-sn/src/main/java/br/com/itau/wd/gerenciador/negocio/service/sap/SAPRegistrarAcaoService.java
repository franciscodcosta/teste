package br.com.itau.wd.gerenciador.negocio.service.sap;

import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD;
import static br.com.itau.wd.gerenciador.util.Constants.JAVAX_XML_RPC_SECURITY_AUTH_USERNAME;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_COMENTARIO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_MENSAGEM;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_STATUS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_SENHA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SAP_USUARIO;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;
import static br.com.itau.wd.gerenciador.util.Constants.TLS_V1;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_Response_out;
import br.com.itau.WorkstationDigital.Aprovacao_Documento.DT_Aprovacao_out;
import br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_out;
import br.com.itau.WorkstationDigital.Aprovacao_Documento.SI_Aprovacao_outProxy;
import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class SAPRegistrarAcaoService {

	private static final Logger logger = LoggerFactory.getLogger(SAPRegistrarAcaoService.class);	
	
	@Resource
	private Environment env;
	
	/**
	 * Monta o JSON de envio
	 * 
	 * @param json
	 * @return
	 * @throws RegistrarAcaoException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, String> mapDePara = new HashMap<>();
			
			mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
			mapDePara.put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
			mapDePara.put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
			mapDePara.put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
			mapDePara.put(JSON_KEY_COMENTARIO, JSON_KEY_COMENTARIO);
			mapDePara.put(JSON_KEY_MENSAGEM, JSON_KEY_MENSAGEM);
			mapDePara.put(JSON_KEY_TOKEN, JSON_KEY_TOKEN);
			
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 

		} catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Monta o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws RegistrarAcaoException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			Map<String, String> mapDePara = new HashMap<>();
			
			mapDePara.put(JSON_KEY_CHAVE_PRODUTO, JSON_KEY_CHAVE_PRODUTO);
			mapDePara.put(JSON_KEY_STATUS, JSON_KEY_STATUS);
			
			retorno = NegocioUtils.obterJsonDePara(json, mapDePara); 
			
		} catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}

	/**
	 * Retorna JSON do SAP
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws RegistrarAcaoException 
	 */
	public String obterJsonRespostaSap(String endpoint, String json) throws NegocioException {

		String retorno = STRING_EMPTY;
		
		try {

			// Configurar TLS
			NegocioUtils.configurarTls(TLS_V1);
			
			String chaveProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_CHAVE_PRODUTO);
			String comentario = GerenciadorUtils.obterDadoJson(json, JSON_KEY_COMENTARIO);
			String funcaoAtividadeSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO);
			String funcaoSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCAO_SISTEMA_PRODUTO);
			String funcionalSistemaProduto = GerenciadorUtils.obterDadoJson(json, JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO);
			String mensagem = GerenciadorUtils.obterDadoJson(json, JSON_KEY_MENSAGEM);
			String token = GerenciadorUtils.obterDadoJson(json, JSON_KEY_TOKEN);

			logger.info("***** REGISTRAR ACAO (SAP) *****");
			logger.info("ENDPOINT ....................... : " + endpoint);
			logger.info("JSON ........................... : " + json);
			logger.info("CHAVE PRODUTO .................. : " + chaveProduto);
			logger.info("COMENTARIO ..................... : " + comentario);
			logger.info("FUNCAO ATIVIDADE SISTEMA PRODUTO : " + funcaoAtividadeSistemaProduto);
			logger.info("FUNCAO SISTEMA PRODUTO ......... : " + funcaoSistemaProduto);
			logger.info("FUNCIONAL SISTEMA PRODUTO ...... : " + funcionalSistemaProduto);
			logger.info("MENSAGEM ....................... : " + mensagem);
			logger.info("TOKEN .......................... : " + token);

			DT_Aprovacao_out dtAprovacaoOut = new DT_Aprovacao_out();

			dtAprovacaoOut.setChave_produto(chaveProduto);
			dtAprovacaoOut.setComentario(comentario);
			dtAprovacaoOut.setFuncao_atividade_sistema_produto(funcaoAtividadeSistemaProduto);
			dtAprovacaoOut.setFuncao_sistema_produto(funcaoSistemaProduto);
			dtAprovacaoOut.setFuncional_sistema_produto(mensagem);
			dtAprovacaoOut.setToken_oauth(token);

			SI_Aprovacao_outProxy proxy = new SI_Aprovacao_outProxy(endpoint);
			
			SI_Aprovacao_out siAprovacaoOut = proxy.getSI_Aprovacao_out();
		    ((javax.xml.rpc.Stub)siAprovacaoOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_USERNAME, env.getRequiredProperty(PROPERTY_KEY_SAP_USUARIO));
		    ((javax.xml.rpc.Stub)siAprovacaoOut)._setProperty(JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD, env.getRequiredProperty(PROPERTY_KEY_SAP_SENHA));

			DT_Aprovacao_Response_out resposta = proxy.SI_Aprovacao_out(dtAprovacaoOut);

			retorno = String.format("{\"status\":\"%s\"}", resposta.getStatus());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
}