package br.com.itau.wd.gerenciador.negocio.service.pagamento;

import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_ERRO_PAGAMENTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.COD_SUCESSO_PAGAMENTO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDCRED;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDEMPAUT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDEMPPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CDMOTALC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_COMENTARIO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_CONFIRM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DESCPGT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DESCRICAO_ERRO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTEMIPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_DTVENCI;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_ICLIBPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDAUTPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDAUTPAG2;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_IDMENSAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_JUSTIFICATIVA;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_MENSAGEM;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NMCREDOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRDOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRINTCOB;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_NRINTDOC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_OPERACAO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_OPERADOR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PADOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PBCO;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PFATVENC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_PNUMCOBPG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_SEDOCPAG;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_TIPOPGT;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_TPMODDOC;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_VALBR;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.JSON_KEY_PAGAMENTO_VALIQ;
import static br.com.itau.wd.gerenciador.negocio.utils.Constants.MSG_SUCESSO_PAGAMENTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CODIGO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DADOS;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_DESCRICAO_RETORNO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.text.ParseException;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.itau.ob6.workstation.PjExpectedException;
import com.itau.ob6.workstation.WorkstationPagamentoProxy;

import br.com.itau.wd.gerenciador.negocio.exception.NegocioException;
import br.com.itau.wd.gerenciador.negocio.utils.NegocioUtils;

@Service
public class PagamentoRegistraAcaoService {

	private static final Logger logger = LoggerFactory.getLogger(PagamentoRegistraAcaoService.class);

	@Resource
	private Environment env;

	/**
	 * Retorna o JSON de requisição
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonRequisicao(String json) throws NegocioException {

		return json;
	}

	/**
	 * Retorna o JSON de resposta
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String obterJsonResposta(String json) throws NegocioException {
		
		String retorno = STRING_EMPTY;

		try {

			JsonObject objJson = (JsonObject) new JsonParser().parse(json);

			JsonObject objJsonResposta = new JsonObject();

			objJsonResposta.addProperty(JSON_KEY_UID, NegocioUtils.obterDadoJson(objJson, JSON_KEY_UID));
			objJsonResposta.add(JSON_KEY_DADOS, objJson.get(JSON_KEY_DADOS));

			retorno = objJsonResposta.toString();
		} 
		catch (Exception ex) {
	
			throw new NegocioException(ex);
		}
		
		return retorno;
	}
	
	/**
	 * Registrar Ação
	 * 
	 * @param json
	 * @return
	 * @throws NegocioException
	 */
	public String registrarAcao(String jsonRequisicao, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;

		try {
			
			logger.info("***** OB6 - REGISTRAR ACAO - INICIO *****");
			logger.info("JSON REQUISIÇÃO : " + jsonRequisicao);
			logger.info("ENDPOINT ...... : " + endpoint);
			
			//Obtem o JSON de entrada
			String jsonEntradaOb6 = obterJsonEntrada(jsonRequisicao);

			//Envia os dados
			String jsonSaidaOb6 = enviarDados(jsonEntradaOb6, endpoint);

			//Obtem o JSON
			retorno = obterJsonSaida(jsonSaidaOb6, jsonRequisicao);
			
			logger.info("JSON RESPOSTA . : " + retorno);			
			logger.info("***** OB6 - REGISTRAR ACAO - FINAL *****");
		}
		catch (Exception ex) {

			throw new NegocioException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obtem o JSON de entrada
	 * 
	 * @param json
	 * @return
	 * @throws ParseException 
	 */
	private String obterJsonEntrada(String json) throws ParseException {

		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		
		String comentario = NegocioUtils.obterDadoJson(objJson, JSON_KEY_PAGAMENTO_COMENTARIO);
		
		JsonObject objJsonMensagem = (JsonObject) objJson.get(JSON_KEY_PAGAMENTO_MENSAGEM);

		String operador = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_OPERADOR);
		String operacao = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_OPERACAO);
		String nrintdoc = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_NRINTDOC);
		String cdcred = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_CDCRED);
		String nmcredor = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_NMCREDOR);
		String tpmoddoc = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_TPMODDOC);
		String nrdocpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_NRDOCPAG);
		String valbr = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_VALBR);
		String valiq = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_VALIQ);
		String dtpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_DTPAG);
		String pbco = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_PBCO);
		String pfatvenc = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_PFATVENC);
		String pnumcobpg = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_PNUMCOBPG);
		String tipopgt = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_TIPOPGT);
		String nrintcob = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_NRINTCOB);
		String idautpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_IDAUTPAG);
		String idautpag2 = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_IDAUTPAG2);
		String dtvenci = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_DTVENCI);
		String cdmotalc = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_CDMOTALC);
		String iclibpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_ICLIBPAG);
		String sedocpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_SEDOCPAG);
		String padocpag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_PADOCPAG);
		String dtemipag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_DTEMIPAG);
		String cdemppag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_CDEMPPAG);
		String descpgt = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_DESCPGT);
		String confirm = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_CONFIRM);
		String idmensag = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_IDMENSAG);
		String cdempaut = NegocioUtils.obterDadoJson(objJsonMensagem, JSON_KEY_PAGAMENTO_CDEMPAUT);

		JsonObject objJsonEntrada = new JsonObject();

		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_OPERADOR, operador);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_OPERACAO, operacao);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_NRINTDOC, nrintdoc);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_CDCRED, cdcred);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_NMCREDOR, nmcredor);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_TPMODDOC, tpmoddoc);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_NRDOCPAG, nrdocpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_VALBR, valbr);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_VALIQ, valiq);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_DTPAG, dtpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PBCO, pbco);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PFATVENC, pfatvenc);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PNUMCOBPG, pnumcobpg);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_TIPOPGT, tipopgt);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_NRINTCOB, nrintcob);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_IDAUTPAG, idautpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_IDAUTPAG2, idautpag2);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_DTVENCI, dtvenci);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_CDMOTALC, cdmotalc);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_ICLIBPAG, iclibpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_SEDOCPAG, sedocpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_PADOCPAG, padocpag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_DTEMIPAG, dtemipag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_CDEMPPAG, cdemppag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_DESCPGT, descpgt);		
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_CONFIRM, confirm);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_IDMENSAG, idmensag);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_CDEMPAUT, cdempaut);
		objJsonEntrada.addProperty(JSON_KEY_PAGAMENTO_JUSTIFICATIVA, comentario);
	
		return objJsonEntrada.toString();
	}

	/**
	 * Obtem o JSON
	 * 
	 * @param dados
	 * @param json
	 * @return
	 */
	private String obterJsonSaida(String jsonDados, String json) {
		
		//Obtem os dados do JSON de entrada
		JsonObject objJson = (JsonObject) new JsonParser().parse(json);
		JsonObject objJsonDadosOb6 = (JsonObject) new JsonParser().parse(jsonDados);

		String uid = NegocioUtils.obterDadoJson(objJson, JSON_KEY_UID);
		String descricaoErro = NegocioUtils.obterDadoJson(objJsonDadosOb6, JSON_KEY_PAGAMENTO_DESCRICAO_ERRO);
		
		//Cria o JSON de retorno
		JsonObject objJsonRet = new JsonObject();

		objJsonRet.addProperty(JSON_KEY_UID, uid);

		String codigoRetorno;
		String descricaoRetorno;

		if (!STRING_EMPTY.equals(descricaoErro.trim())) {
			codigoRetorno = COD_ERRO_PAGAMENTO;
			descricaoRetorno = descricaoErro;
		} else {
			codigoRetorno = COD_SUCESSO_PAGAMENTO;
			descricaoRetorno = MSG_SUCESSO_PAGAMENTO;
		}

		JsonObject objJsonDados = new JsonObject();

		objJsonDados.addProperty(JSON_KEY_CODIGO_RETORNO, codigoRetorno);
		objJsonDados.addProperty(JSON_KEY_DESCRICAO_RETORNO, descricaoRetorno);

		objJsonRet.add(JSON_KEY_DADOS, objJsonDados);

		return objJsonRet.toString();
	}
	
	/**
	 * Envia os dados
	 * 
	 * @param json
	 * @param endpoint
	 * @return
	 * @throws NegocioException 
	 */
	private String enviarDados(String json, String endpoint) throws NegocioException {

		String retorno = STRING_EMPTY;
		
		try {
			//Configura o Proxy
			WorkstationPagamentoProxy proxy = new WorkstationPagamentoProxy();
	
			proxy.setEndpoint(endpoint);
			//((WorkstationServicePortBindingStub)proxy.getWorkstationService()).setUsername(env.getRequiredProperty(PROPERTY_KEY_SECURITY_PAGAMENTO_USER));
			//((WorkstationServicePortBindingStub)proxy.getWorkstationService()).setPassword(env.getRequiredProperty(PROPERTY_KEY_SECURITY_PAGAMENTO_TOKEN));
	
			retorno = proxy.registraAcao(json);
		}
		catch (PjExpectedException ex) {
			
			throw new NegocioException(ex.getMessage());
		}
		catch (Exception ex) {
			
			throw new NegocioException(ex.getMessage());
		}
		
		return retorno;
	}	
}