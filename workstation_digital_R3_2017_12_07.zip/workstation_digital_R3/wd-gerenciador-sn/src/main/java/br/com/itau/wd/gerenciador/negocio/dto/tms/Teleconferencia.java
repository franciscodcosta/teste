package br.com.itau.wd.gerenciador.negocio.dto.tms;

public class Teleconferencia {

	private int id;
	private String polo;
	private String torre;
	private String andar;
	private String numero;
	private String capacidade;
	private String listaEspera;
	
	public Teleconferencia() {
		//Construtor default		
	}
	
	public Teleconferencia(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPolo() {
		return polo;
	}
	
	public void setPolo(String polo) {
		this.polo = polo;
	}
	
	public String getTorre() {
		return torre;
	}
	
	public void setTorre(String torre) {
		this.torre = torre;
	}
	
	public String getAndar() {
		return andar;
	}
	
	public void setAndar(String andar) {
		this.andar = andar;
	}
	
	public String getNumero() {
		return numero;
	}
	
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public String getCapacidade() {
		return capacidade;
	}
	
	public void setCapacidade(String capacidade) {
		this.capacidade = capacidade;
	}
	
	public String getListaEspera() {
		return listaEspera;
	}
	
	public void setListaEspera(String listaEspera) {
		this.listaEspera = listaEspera;
	}
}