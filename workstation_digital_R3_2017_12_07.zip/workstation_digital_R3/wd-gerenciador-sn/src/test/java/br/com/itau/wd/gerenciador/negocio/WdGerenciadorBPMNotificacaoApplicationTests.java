package br.com.itau.wd.gerenciador.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.bpm.BPMNotificacaoController;
import br.com.itau.wd.gerenciador.negocio.service.bpm.BPMNotificacaoService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {BPMNotificacaoController.class, BPMNotificacaoService.class})
@AutoConfigureMockMvc
public class WdGerenciadorBPMNotificacaoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BPMNotificacaoService service;

	@Test
	public void verificaJsonRequisicaoNotificacao() throws Exception {

		String json = "{\"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"funcional_sistema_produto\": \"003764305\",  \"chave_produto\": \"123\", \"contador_paginas\": \"1\", \"qtd_por_pagina\": \"1\", \"token\": \"adf0948d26d85130395f731867cc3263\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/bpm/notificacao/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaNotificacao() throws Exception {

		String json = "{\"uid\":\"F058E523-3E96-491F-A295-7D9701442E22\", \"total_paginas\":\"1\", \"dados\": {\"descricao\":\"teste\"}}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/bpm/notificacao/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
}