package br.com.itau.wd.gerenciador.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.maximo.MaximoConsultaListaClassificacoesAtributosController;
import br.com.itau.wd.gerenciador.negocio.service.maximo.MaximoConsultaListaClassificacoesAtributosService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {MaximoConsultaListaClassificacoesAtributosController.class, MaximoConsultaListaClassificacoesAtributosService.class})
@AutoConfigureMockMvc
public class WdGerenciadorMaximoConsultaListaClassificacoesAtributosApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private MaximoConsultaListaClassificacoesAtributosService service;

	@Test
	public void verificaJsonRequisicaoConsultaDetalhesSolicitacaoServico() throws Exception {

		String json = "{\"numero_mudanca\":\"S123456\", \"status\":\"true\", \"funcional_solicitante\": \"999999999\", \"resumo\": \"teste\", \"tipo\": \"LOG\", \"detalhes\": \"teste\", \"visualizavel\": \"1\", \"criado_por\": \"999999999\", \"resumo\": \"teste\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/maximo/consulta/classificacao_e_atributo/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
	@Test
	public void verificaJsonRespostaConsultaDetalhesSolicitacaoServico() throws Exception {

		String json = "{\"uid\":\"F058E523-3E96-491F-A295-7D9701442E22\", \"total_paginas\":\"1\", \"dados\": {\"descricao\":\"teste\"}}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/maximo/consulta/classificacao_e_atributo/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}

	@Test
	public void verificaJsonConsultaDetalhesSolicitacaoServico() throws Exception {
		
		String json = "{\"funcao_sistema_produto\":\"0004\", \"funcao_atividade_sistema_produto\":\"0005\", \"chave_produto\": \"123\", \"total_paginas\": \"1\", \"dados\": {\"descricao\":\"teste\"}}";
		String endpoint = "http://gstiace.itau/meaweb/services/ITAUWDANEXO";
		Mockito.when(service.consultarListaClassificacoesAtributos(Mockito.any(String.class), Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/maximo/consulta/classificacao_e_atributo/soap").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).header("endpoint", endpoint).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
}