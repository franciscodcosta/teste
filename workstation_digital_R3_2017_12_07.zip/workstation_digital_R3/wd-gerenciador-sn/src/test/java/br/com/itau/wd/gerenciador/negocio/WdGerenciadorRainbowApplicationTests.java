package br.com.itau.wd.gerenciador.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.rainbow.RainbowController;
import br.com.itau.wd.gerenciador.negocio.service.rainbow.RainbowService;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {RainbowController.class, RainbowService.class})
@AutoConfigureMockMvc
public class WdGerenciadorRainbowApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private RainbowService service;

	@Test
	public void verificaJsonRequisicaoRainbow() throws Exception {

		String json = "{\"uid\": \"\", \"funcao_sistema_produto\":\"0003\", \"funcao_atividade_sistema_produto\":\"0051\", \"dados\": {}}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/rainbow/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
		
	@Test
	public void verificaJsonRespostaRainbow() throws Exception {

		String json = "{\"status\": \"\", \"mensagem\": \"\", \"chave_produto\": \"\", \"dados\": {}}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/rainbow/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
}