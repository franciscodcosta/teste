package br.com.itau.wd.gerenciador.negocio;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import br.com.itau.wd.gerenciador.negocio.controller.tarefodromo.TarefodromoController;
import br.com.itau.wd.gerenciador.negocio.service.tarefodromo.TarefodromoService;


@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TarefodromoController.class, TarefodromoService.class})
@AutoConfigureMockMvc
public class WdGerenciadorTarefodromoApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private TarefodromoService service;

	@Test
	public void verificaJsonRequisicaoTarefodromo() throws Exception {

		String json = "{\"uid\": \"\", \"sigla_sistema_produto\": \"CF5\", \"funcao_sistema_produto\":\"0003\", \"funcao_atividade_sistema_produto\":\"0320\", \"funcional\": \"111111111\", \"ind_proxima_pagina\": \"1\", \"qtd_ocorrencias\": \"10\"}";
		Mockito.when(service.obterJsonRequisicao(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/tarefodromo/requisicao").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
		
	@Test
	public void verificaJsonRespostaTarefodromo() throws Exception {

		String json = "{\"chave_produto\": \"\", \"dados\": { \"ind_proxima_pagina\": \"1\", \"ind_proxima_anterior\": \"0\", \"ind_paginacao\": \"0\", \"qtd_ocorrencias\": \"10\", \"pendencias\": [{ \"cod_pendencia\": \"\", \"funcional_colaborador\": \"\", \"nome_pendencia\": \"\", \"url_pendencia\": \"\", \"descricao_pendencia\": \"\", \"cod_tipo_autenticacao\": \"\", \"qtd_pendencias\": \"\" }] }}";
		Mockito.when(service.obterJsonResposta(Mockito.any(String.class))).thenReturn(json);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/tarefodromo/resposta").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}

	@Test
	public void verificaConsultaPendencia() throws Exception {
		
		String json = "{\"chave_produto\": \"\", \"dados\": { \"ind_proxima_pagina\": \"1\", \"ind_proxima_anterior\": \"0\", \"ind_paginacao\": \"0\", \"qtd_ocorrencias\": \"10\", \"pendencias\": [{ \"cod_pendencia\": \"\", \"funcional_colaborador\": \"\", \"nome_pendencia\": \"\", \"url_pendencia\": \"\", \"descricao_pendencia\": \"\", \"cod_tipo_autenticacao\": \"\", \"qtd_pendencias\": \"\" }] }}";
		Mockito.when(service.consultaPendencia(Mockito.any(String.class))).thenReturn(json);
		
		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders.post("/tarefodromo/mainframe").header("Content-Type", MediaType.TEXT_PLAIN_VALUE).content(json).accept(MediaType.APPLICATION_JSON); 
		mockMvc.perform(requestBuilder).andExpect(status().isOk()).andExpect(view().name(json));
	}
	
}