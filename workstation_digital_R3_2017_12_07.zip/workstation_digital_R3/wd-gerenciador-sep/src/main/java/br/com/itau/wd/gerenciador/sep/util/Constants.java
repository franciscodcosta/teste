package br.com.itau.wd.gerenciador.sep.util;

public class Constants {

	public static final String HTTP_HEADER_ENDPOINT = "endpoint";
	public static final String HTTP_HEADER_ENDPOINT_NEGOCIO = "endpointnegocio";
	public static final String HTTP_HEADER_CODIGO_SERVICO = "codigo_servico";
	public static final String HTTP_HEADER_CHAVE_PRODUTO = "chave_produto";
	public static final String HTTP_HEADER_FUNCAO_SISTEMA_PRODUTO = "funcao_sistema_produto";
	public static final String HTTP_HEADER_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO = "funcao_atividade_sistema_produto";
	public static final String HTTP_HEADER_FUNCIONAL_SISTEMA_PRODUTO = "funcional_sistema_produto";
	
	public static final String MSG_ERRO_KMS_CHAVE_INEXISTENTE = "Chave inexistente";
	public static final String MSG_ERRO_KMS_CHAVE_NAO_ENCONTRADA = "Chave não encontrada";
	public static final String MSG_ERRO_SR_ENDPOINT_INVALIDO = "Endpoint inválido";
	public static final String MSG_ERRO_SEP_SERVICO_INEXISTENTE = "Serviço não existente";
	
	private Constants() {}
}