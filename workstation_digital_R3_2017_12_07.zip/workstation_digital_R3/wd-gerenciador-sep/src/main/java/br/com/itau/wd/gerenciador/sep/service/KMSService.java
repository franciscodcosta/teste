package br.com.itau.wd.gerenciador.sep.service;

import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_CODIGO_SERVICO;
import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.sep.util.Constants.HTTP_HEADER_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.sep.util.Constants.MSG_ERRO_KMS_CHAVE_INEXISTENTE;
import static br.com.itau.wd.gerenciador.sep.util.Constants.MSG_ERRO_KMS_CHAVE_NAO_ENCONTRADA;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_CHAVE_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCAO_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_UID;
import static br.com.itau.wd.gerenciador.util.Constants.MICRO_SERVICO_KMS;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.sep.dao.MicroServicoDao;
import br.com.itau.wd.gerenciador.sep.dto.ChaveDto;
import br.com.itau.wd.gerenciador.sep.dto.DadosDto;
import br.com.itau.wd.gerenciador.sep.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sep.exception.SEPException;

/**
 * <b>Serviço KMS</b>
 * Realiza a criação da chave externa ou consulta ao KMS
 * 
 * @author ITAÚ
 * @version 1.0
 * @since 2017-04-01
 */
@Service
public class KMSService {

	@Autowired
	MicroServicoDao dao;

	@Autowired
	ClientRestService clientRest;
	
	/**
	 * Verifica se a chave externa deverá ser criada, consultada ou nenhuma das duas.
	 *  
	 * @param dados
	 * @return
	 * @throws Exception
	 */
	public void verificarChave(DadosDto dados) throws SEPException {

		if (dados.getEndpoint().isConsultaKms()) {

			consultarChave(dados);
		}
		else if (dados.getEndpoint().isSalvaKms()) {

			salvarChave(dados);
		}
	}

	/**
	 * Consulta a chave
	 * 
	 * @param dados
	 * @throws SEPException
	 */
	private void consultarChave(DadosDto dados) throws SEPException {

		// Verifica se a chave externa foi enviada no JSON
		if (dados.isExisteTag(JSON_KEY_UID)) {

			// Consulta a chave externa na base de dados
			List<ChaveDto> chaves = consultarDadosChave(dados);

			// Verifica se retornou os dados
			if (chaves != null && !chaves.isEmpty()) {

				obterDadosChave(dados, chaves);
			}
			else {
				// A chave externa não existe na base de dados
				throw new SEPException(MSG_ERRO_KMS_CHAVE_NAO_ENCONTRADA);
			}
		}
		else {
			// A chave externa não existe no JSON
			throw new SEPException(MSG_ERRO_KMS_CHAVE_INEXISTENTE);
		}
	}
	
	/**
	 * Obtem os dados da chave externa
	 * 
	 * @param dados
	 * @param chaves
	 */
	private void obterDadosChave(DadosDto dados, List<ChaveDto> chaves) {
		
		// Se a chave existir no JSON o valor não deverá ser alterado
		// Chave Produto
		if (!dados.isExisteTag(JSON_KEY_CHAVE_PRODUTO)) {
			dados.getDados().put(JSON_KEY_CHAVE_PRODUTO, chaves.get(0).getChaveProduto());
		}
		// Função Sistema Produto
		if (!dados.isExisteTag(JSON_KEY_FUNCAO_SISTEMA_PRODUTO)) {
			dados.getDados().put(JSON_KEY_FUNCAO_SISTEMA_PRODUTO, chaves.get(0).getFuncaoSistemaProduto());
		}
		// Função Atividade Sistema Produto
		if (!dados.isExisteTag(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO)) {
			dados.getDados().put(JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, chaves.get(0).getFuncaoAtividadeSistemaProduto());
		}
		// Funcional Sistema Produto
		if (!dados.isExisteTag(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO)) {
			dados.getDados().put(JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO, chaves.get(0).getFuncionalSistemaProduto());
		}

		// Adiciona os dados a chave externa
		dados.getChave().setChaveProduto(chaves.get(0).getChaveProduto());
		dados.getChave().setFuncaoSistemaProduto(chaves.get(0).getFuncaoSistemaProduto());
		dados.getChave().setFuncaoAtividadeSistemaProduto(chaves.get(0).getFuncaoAtividadeSistemaProduto());
		dados.getChave().setSiglaSistemaProduto(chaves.get(0).getSiglaSistemaProduto());
		dados.getChave().setFuncionalSistemaProduto(chaves.get(0).getFuncionalSistemaProduto());
	}

	/**
	 * Cria a chave
	 * 
	 * @param dados
	 * @throws SEPException
	 */
	private void salvarChave(DadosDto dados) throws SEPException {
		
		// Cria a chave
		String chaveExterna = salvarDadosChave(dados);

		// Adiciona a chave
		dados.getDados().put(JSON_KEY_UID, chaveExterna);
		dados.getChave().setChaveExterna(chaveExterna);
	}

	/**
	 * Insere os dados e cria a chave externa
	 * 
	 * @param dados
	 * @return
	 * @throws SEPException
	 */
	private String salvarDadosChave(DadosDto dados) throws SEPException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();

			headers.add(HTTP_HEADER_CODIGO_SERVICO, dados.getChave().getCodigoServico());
			headers.add(HTTP_HEADER_CHAVE_PRODUTO, dados.getChave().getChaveProduto());
			headers.add(HTTP_HEADER_FUNCAO_SISTEMA_PRODUTO, dados.getChave().getFuncaoSistemaProduto());
			headers.add(HTTP_HEADER_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO, dados.getChave().getFuncaoAtividadeSistemaProduto());
			headers.add(HTTP_HEADER_FUNCIONAL_SISTEMA_PRODUTO, dados.getChave().getFuncionalSistemaProduto());

			HttpEntity<String> entity = new HttpEntity<>(headers);

		    String url = String.format("%s/chave", obterEndpointKms());

		    retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}
		
        return retorno;
	}

	/**
	 * Consulta os dados da chave externa
	 * 
	 * @param chave
	 * @return
	 * @throws SEPException 
	 */
	private List<ChaveDto> consultarDadosChave(DadosDto dadosWD) throws SEPException {

		List<ChaveDto> lista = new ArrayList<>();

		try {

			String url = String.format("%s/chave?chave_externa={chave}", obterEndpointKms());

			String retorno = clientRest.enviarJson(url, dadosWD.getChave().getChaveExterna());

			lista = obterListaChaves(retorno);
		}
		catch (Exception ex) {

			throw new SEPException(ex);
		}

	    return lista;
	}

	/**
	 * Retorna a lista de chaves
	 * 
	 * @param json
	 * @return
	 */
	private List<ChaveDto> obterListaChaves(String json) {
		
		List<ChaveDto> lista = new ArrayList<>();

		JsonArray jsonChaves = new JsonParser().parse(json).getAsJsonArray();

		for (JsonElement jsonElement : jsonChaves) {

		    JsonObject jsonChave = jsonElement.getAsJsonObject();

			String chaveExterna = jsonChave.get("chaveExterna").getAsString();
			String chaveProduto = jsonChave.get("chaveProduto").getAsString();
			String codigoServico = jsonChave.get("codigoServico").getAsString();
			String funcaoAtividadeSistemaProduto = jsonChave.get("funcaoAtividadeSistemaProduto").getAsString();
			String funcaoSistemaProduto = jsonChave.get("funcaoSistemaProduto").getAsString();
			String funcionalSistemaProduto = jsonChave.get("funcionalSistemaProduto").getAsString();
			String siglaSistemaProduto = jsonChave.get("siglaSistemaProduto").getAsString();

			ChaveDto chave = new ChaveDto();

			chave.setChaveExterna(chaveExterna);
			chave.setChaveProduto(chaveProduto);
			chave.setCodigoServico(codigoServico);
			chave.setFuncaoAtividadeSistemaProduto(funcaoAtividadeSistemaProduto);
			chave.setFuncaoSistemaProduto(funcaoSistemaProduto);
			chave.setFuncionalSistemaProduto(funcionalSistemaProduto);
			chave.setSiglaSistemaProduto(siglaSistemaProduto);
			
			lista.add(chave);
		}
		
		return lista;
	}

	/**
	 * Retorna o endpoint do microserviço KMS
	 * 
	 * @return
	 * @throws SEPException
	 */
	private String obterEndpointKms() throws SEPException {
		
		EndpointDto microServico = dao.obterMicroServico(MICRO_SERVICO_KMS);

		return microServico.getUrlServico();
	}
}