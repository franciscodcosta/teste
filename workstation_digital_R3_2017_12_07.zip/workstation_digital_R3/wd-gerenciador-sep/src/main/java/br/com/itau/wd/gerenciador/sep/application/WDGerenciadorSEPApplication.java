package br.com.itau.wd.gerenciador.sep.application;

import javax.annotation.Resource;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@ComponentScan(basePackages = {"br.com.itau.wd.gerenciador.sep.*"})
@PropertySources({
    @PropertySource(value="file:${app.properties}", ignoreResourceNotFound=false)
})
public class WDGerenciadorSEPApplication {

	@Resource
	private Environment env;
	
	public static void main(String[] args) {
		SpringApplication.run(WDGerenciadorSEPApplication.class, args);
	}

	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {

		RestTemplate restTemplate = builder.build(); 
		restTemplate.setRequestFactory(clientHttpRequestFactory());

		return restTemplate;
	}
	
	private ClientHttpRequestFactory clientHttpRequestFactory() {

		HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();

		factory.setConnectionRequestTimeout(60*1000);
		factory.setReadTimeout(60*1000);
		factory.setConnectTimeout(60*1000);

		return factory;
	}
}