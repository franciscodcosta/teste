package br.com.itau.wd.gerenciador.sep.exception;

import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import br.com.itau.wd.gerenciador.exception.GerenciadorErrorInfo;

@ControllerAdvice
public class SEPErrorController {

	private static final Logger logger = LoggerFactory.getLogger(SEPErrorController.class);	

	private String errorMessage = STRING_EMPTY;
	private String errorURL = STRING_EMPTY;

    @ExceptionHandler(SEPException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleSEPException(HttpServletRequest req, SEPException ex) {

    	errorMessage = ex.getMensagem();
        errorURL = STRING_EMPTY.equals(ex.getUrl()) ? req.getRequestURL().toString() : ex.getUrl();
        logger.info(ex.getMensagem());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }
    
    @ExceptionHandler(JsonParseException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleJsonParseException(HttpServletRequest req, JsonParseException ex) {

        errorMessage = ex.getMessage();
        errorURL = req.getRequestURL().toString();
        logger.info(ex.getMessage());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }
    
    @ExceptionHandler(JsonMappingException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleJsonMappingException(HttpServletRequest req, JsonMappingException ex) {

        errorMessage = ex.getMessage();
        errorURL = req.getRequestURL().toString();
        logger.info(ex.getMessage());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }

    @ExceptionHandler(JsonProcessingException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleJsonProcessingException(HttpServletRequest req, JsonProcessingException ex) {

        errorMessage = ex.getMessage();
        errorURL = req.getRequestURL().toString();
        logger.info(ex.getMessage());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }
    
    @ExceptionHandler(IOException.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleIOException(HttpServletRequest req, IOException ex) {

        errorMessage = ex.getMessage();
        errorURL = req.getRequestURL().toString();
        logger.info(ex.getMessage());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }
    
    @ExceptionHandler(Exception.class)
    @ResponseStatus(value=HttpStatus.BAD_REQUEST)
    @ResponseBody
    public GerenciadorErrorInfo handleException(HttpServletRequest req, Exception ex) {

        errorMessage = ex.getMessage();
        errorURL = req.getRequestURL().toString();
        logger.info(ex.getMessage());

        return new GerenciadorErrorInfo(errorURL, errorMessage);
    }    
}