package br.com.itau.wd.gerenciador.sep.dto;

import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_MAINFRAME;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_REST;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_SALESFORCE;
import static br.com.itau.wd.gerenciador.util.Constants.ROUTER_ENDPOINT_SOAP;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_BPM;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_CAMBIO;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_MAXIMO;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_PAGAMENTO;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_RAINBOW;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SALESFORCE;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SAP;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_SP2;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_TAREFODROMO;
import static br.com.itau.wd.gerenciador.util.Constants.SIGLA_SISTEMA_TMS;

import java.util.HashMap;
import java.util.Map;

public class EndpointDto {

	private String codigoServico;
	private String urlServico;
	private String urlServicoNegocio;
	private String siglaSistema;
	private boolean isSalvaKms;
	private boolean isConsultaKms;
	private Map<String, String> tipoEndpoint;

	public EndpointDto() {
		
		tipoEndpoint = new HashMap<>(); 
		
		tipoEndpoint.put(SIGLA_SISTEMA_SALESFORCE, ROUTER_ENDPOINT_SALESFORCE);
		tipoEndpoint.put(SIGLA_SISTEMA_MAXIMO, ROUTER_ENDPOINT_SOAP);
		tipoEndpoint.put(SIGLA_SISTEMA_SAP, ROUTER_ENDPOINT_SOAP);
		tipoEndpoint.put(SIGLA_SISTEMA_TMS, ROUTER_ENDPOINT_SOAP);
		tipoEndpoint.put(SIGLA_SISTEMA_PAGAMENTO, ROUTER_ENDPOINT_SOAP);
		tipoEndpoint.put(SIGLA_SISTEMA_BPM, ROUTER_ENDPOINT_REST);
		tipoEndpoint.put(SIGLA_SISTEMA_CAMBIO, ROUTER_ENDPOINT_REST);
		tipoEndpoint.put(SIGLA_SISTEMA_RAINBOW, ROUTER_ENDPOINT_REST);
		tipoEndpoint.put(SIGLA_SISTEMA_SP2, ROUTER_ENDPOINT_REST);
		tipoEndpoint.put(SIGLA_SISTEMA_TAREFODROMO, ROUTER_ENDPOINT_MAINFRAME);
	}
	
	public String getCodigoServico() {
		return codigoServico;
	}
	
	public void setCodigoServico(String codigoServico) {
		this.codigoServico = codigoServico;
	}
	
	public String getUrlServico() {
		return urlServico;
	}
	
	public void setUrlServico(String urlServico) {
		this.urlServico = urlServico;
	}
	
	public String getUrlServicoNegocio() {
		return urlServicoNegocio;
	}

	public void setUrlServicoNegocio(String urlServicoNegocio) {
		this.urlServicoNegocio = urlServicoNegocio;
	}

	public String getSiglaSistema() {
		return siglaSistema;
	}

	public void setSiglaSistema(String siglaSistema) {
		this.siglaSistema = siglaSistema;
	}

	public boolean isSalvaKms() {
		return isSalvaKms;
	}

	public void setSalvaKms(boolean isSalvaKms) {
		this.isSalvaKms = isSalvaKms;
	}

	public boolean isConsultaKms() {
		return isConsultaKms;
	}

	public void setConsultaKms(boolean isConsultaKms) {
		this.isConsultaKms = isConsultaKms;
	}
	
	public String getTipoEndpoint() {
		return tipoEndpoint.get(siglaSistema.toUpperCase());
	}	
}