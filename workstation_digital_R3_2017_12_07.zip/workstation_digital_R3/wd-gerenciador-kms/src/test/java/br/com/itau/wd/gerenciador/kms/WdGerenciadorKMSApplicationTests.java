package br.com.itau.wd.gerenciador.kms;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import br.com.itau.wd.gerenciador.kms.controller.KMSController;
import br.com.itau.wd.gerenciador.kms.dto.ChaveDto;
import br.com.itau.wd.gerenciador.kms.exception.KMSErrorController;
import br.com.itau.wd.gerenciador.kms.exception.KMSException;
import br.com.itau.wd.gerenciador.kms.service.KMSService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {KMSController.class, KMSService.class})
@AutoConfigureMockMvc
public class WdGerenciadorKMSApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private KMSService service;

	@InjectMocks
    private KMSController controller;

	@Before
	public void setup() {
   
		MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).setControllerAdvice(new KMSErrorController()).setViewResolvers(viewResolver).build();
    }

	@Test
	public void deveRetornarJSONComListaDeChaves() throws Exception {

		Mockito.when(service.consultarChave(Mockito.any(String.class))).thenReturn(obterChavesMock());

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/chave")
			.param("chave_externa", "9105FC2E-1296-4883-B97B-502672DC1640");

		mockMvc.perform(requestBuilder)
    		.andExpect(status().isOk())		
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        	.andExpect(MockMvcResultMatchers.jsonPath("$.[0].codigoServico").value("0001"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].chaveProduto").value("123"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].codigoServico").value("0001"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].funcaoAtividadeSistemaProduto").value("0004"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].funcaoSistemaProduto").value("0005"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].funcionalSistemaProduto").value("9999999"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.[0].siglaSistemaProduto").value("SAP"));
	}

	@Test
	public void deveRetornarJSONSemListaDeChaves() throws Exception {

		Mockito.when(service.consultarChave(Mockito.any(String.class))).thenReturn(new ArrayList<ChaveDto>());

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/chave")
			.param("chave_externa", "B5C00A9F-0A41-4D69-93D9-57399E286963"); 

		mockMvc.perform(requestBuilder)
			.andExpect(status().isOk())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
        	.andExpect(content().string("[]"));
	}

	@Test
	public void deveRetornarMetodoNaoEncontradoDoConsultaChave() throws Exception {

		Mockito.when(service.consultarChave(Mockito.any(String.class))).thenReturn(new ArrayList<ChaveDto>());

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/chaves")
			.param("chave_externa", "C2D7BDC0-1646-4630-AC67-3E648A39E0CC"); 

		mockMvc.perform(requestBuilder)
			.andExpect(status().isNotFound());
	}

	@Test
	public void deveRetornarJSONExcecaoConsultaChave() throws Exception {

		Mockito.doThrow(new KMSException("ERRO")).when(service).consultarChave("C2D7BDC0-1646-4630-AC67-3E648A39E0CC");

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.get("/chave")
			.param("chave_externa", "C2D7BDC0-1646-4630-AC67-3E648A39E0CC"); 

		mockMvc.perform(requestBuilder)
			.andExpect(status().isNotFound())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
			.andExpect(MockMvcResultMatchers.jsonPath("$.erro.servico").value("http://localhost/chave"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.erro.mensagem").value("ERRO"));
	}	

	@Test
	public void deveRetornarChaveExterna() throws Exception {

		String codigoServico = "0001";
		String chaveProduto = "4500013014;000004875877";
		String funcaoSistemaProduto = "0003";
		String funcaoAtividadeSistemaProduto = "0005";
		String funcionalSistemaProduto = "003809803";
		String chave = "9105FC2E-1296-4883-B97B-502672DC1640";

		Mockito.when(service.salvarChave(Mockito.any(ChaveDto.class))).thenReturn(chave);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.post("/chave")
			.header("codigo_servico", codigoServico)
			.header("chave_produto", chaveProduto)
			.header("funcao_sistema_produto", funcaoSistemaProduto)
			.header("funcao_atividade_sistema_produto", funcaoAtividadeSistemaProduto)
			.header("funcional_sistema_produto", funcionalSistemaProduto);

		mockMvc.perform(requestBuilder)
			.andExpect(status().isOk())
			.andExpect(content().string(chave));
	}

	@Test
	public void deveRetornarJSONExcecaoSalvaChave() throws Exception {

		String codigoServico = "0001";
		String chaveProduto = "4500013014;000004875877";
		String funcaoSistemaProduto = "0003";
		String funcaoAtividadeSistemaProduto = "0005";
		String funcionalSistemaProduto = "003809803";

		Mockito.doThrow(new KMSException("ERRO")).when(service).salvarChave((Mockito.any(ChaveDto.class)));

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
			.post("/chave")
			.header("codigo_servico", codigoServico)
			.header("chave_produto", chaveProduto)
			.header("funcao_sistema_produto", funcaoSistemaProduto)
			.header("funcao_atividade_sistema_produto", funcaoAtividadeSistemaProduto)
			.header("funcional_sistema_produto", funcionalSistemaProduto);

		mockMvc.perform(requestBuilder)
			.andExpect(status().isNotFound())
			.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
			.andExpect(MockMvcResultMatchers.jsonPath("$.erro.servico").value("http://localhost/chave"))
			.andExpect(MockMvcResultMatchers.jsonPath("$.erro.mensagem").value("ERRO"));
	}	
	
	private List<ChaveDto> obterChavesMock() {
		
		List<ChaveDto> chaves = new ArrayList<ChaveDto>();
		
		ChaveDto chave = new ChaveDto();
		
		chave.setChaveExterna("9105FC2E-1296-4883-B97B-502672DC1640");
		chave.setChaveProduto("123");
		chave.setCodigoServico("0001");
		chave.setFuncaoAtividadeSistemaProduto("0004");
		chave.setFuncaoSistemaProduto("0005");
		chave.setFuncionalSistemaProduto("9999999");
		chave.setSiglaSistemaProduto("SAP");

		chaves.add(chave);
		
		return chaves;
	}
}
