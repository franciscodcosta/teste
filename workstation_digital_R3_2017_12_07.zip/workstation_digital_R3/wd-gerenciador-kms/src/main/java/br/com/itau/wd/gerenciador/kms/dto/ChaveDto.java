package br.com.itau.wd.gerenciador.kms.dto;

import org.springframework.util.StringUtils;

public class ChaveDto {

	private String chaveExterna;
	private String chaveProduto;
	private String codigoServico;
	private String siglaSistemaProduto;
	private String funcaoSistemaProduto;
	private String funcaoAtividadeSistemaProduto;
	private String funcionalSistemaProduto;
	
	public String getChaveExterna() {
		return chaveExterna;
	}

	public void setChaveExterna(String chaveExterna) {
		this.chaveExterna = chaveExterna;
	}

	public String getChaveProduto() {
		return StringUtils.trimWhitespace(chaveProduto);
	}
	
	public void setChaveProduto(String chaveProduto) {
		this.chaveProduto = chaveProduto;
	}
	
	public String getCodigoServico() {
		return StringUtils.trimWhitespace(codigoServico);
	}
	
	public void setCodigoServico(String codigoServico) {
		this.codigoServico = codigoServico;
	}
	
	public String getSiglaSistemaProduto() {
		return siglaSistemaProduto;
	}

	public void setSiglaSistemaProduto(String siglaSistemaProduto) {
		this.siglaSistemaProduto = siglaSistemaProduto;
	}
	
	public String getFuncaoSistemaProduto() {
		return funcaoSistemaProduto;
	}

	public void setFuncaoSistemaProduto(String funcaoSistemaProduto) {
		this.funcaoSistemaProduto = funcaoSistemaProduto;
	}

	public String getFuncaoAtividadeSistemaProduto() {
		return funcaoAtividadeSistemaProduto;
	}

	public void setFuncaoAtividadeSistemaProduto(String funcaoAtividadeSistemaProduto) {
		this.funcaoAtividadeSistemaProduto = funcaoAtividadeSistemaProduto;
	}

	public String getFuncionalSistemaProduto() {
		return StringUtils.trimWhitespace(funcionalSistemaProduto);
	}
	
	public void setFuncionalSistemaProduto(String funcionalSistemaProduto) {
		this.funcionalSistemaProduto = funcionalSistemaProduto;
	}
}