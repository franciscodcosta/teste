package br.com.itau.wd.gerenciador.sr;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.hamcrest.core.StringContains;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import br.com.itau.wd.gerenciador.sr.controller.SRController;
import br.com.itau.wd.gerenciador.sr.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sr.service.SRService;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {SRController.class, SRService.class})
@AutoConfigureMockMvc
public class WdGerenciadorRouterApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SRService srService;
	
	@InjectMocks
    private SRController controller;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        this.mockMvc = MockMvcBuilders.standaloneSetup(controller).setViewResolvers(viewResolver).build();
    }
	
	@Test
	public void verificaJsonEndpointSR() throws Exception {
		
		EndpointDto endpoint = new EndpointDto();
		
		endpoint.setCodigoServico("0001");
		endpoint.setSiglaSistema("SF");
		endpoint.setUrlServicoNegocio("http://colaboradoresd.rdhi.com.br/wd-gerenciador-sep-notificacao");
		endpoint.setConsultaKms(false);
		endpoint.setUrlServico("services/apexrest/notification");
		endpoint.setSalvaKms(true);

		Mockito.when(srService.obterEndpoint(Mockito.any(String.class))).thenReturn(endpoint);

		MockHttpServletRequestBuilder requestBuilder = MockMvcRequestBuilders
				.get("/endpoint")
				.param("codigo_servico", "0001")
				.accept(MediaType.APPLICATION_JSON); 

		mockMvc.perform(requestBuilder)
				.andExpect(status().isOk())
				.andExpect(content().string(new StringContains("\"codigoServico\":\"0001\"")))
				.andExpect(content().string(new StringContains("\"siglaSistema\":\"SF\"")))
				//.andExpect(content().string(new StringContains("\"urlservico\":\"/services/apexrest/notification\"")))
				.andExpect(content().string(new StringContains("\"urlservicoNegocio\":\"http://colaboradoresd.rdhi.com.br/wd-gerenciador-sep-notificacao\"")))
				.andExpect(content().string(new StringContains("\"salvaKMS\":true")))
				.andExpect(content().string(new StringContains("\"consultaKMS\":false")));
	}	
}
