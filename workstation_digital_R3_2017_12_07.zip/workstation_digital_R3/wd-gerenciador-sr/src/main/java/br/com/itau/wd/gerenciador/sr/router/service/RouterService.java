package br.com.itau.wd.gerenciador.sr.router.service;

import static br.com.itau.wd.gerenciador.sr.util.Constants.HTTP_HEADER_SERVICO;
import static br.com.itau.wd.gerenciador.sr.util.Constants.HTTP_HEADER_TOKEN;
import static br.com.itau.wd.gerenciador.util.Constants.COD_ENDPOINT_SEP;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import br.com.itau.wd.gerenciador.sr.dto.EndpointDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.service.SRService;

@Service
public class RouterService {

	@Autowired
	SRService service;

	@Autowired
	ClientRestService clientRest;
	
	/**
	 * Faz a chamada ao SEP
	 * 
	 * @param servico
	 * @param json
	 * @param token
	 * @return
	 * @throws SRException
	 */
	public String executarSEP(String servico, String json, String token) throws SRException {

		String retorno = STRING_EMPTY;

		try {

			HttpHeaders headers = new HttpHeaders();
			headers.add(HTTP_HEADER_SERVICO, servico);

			if (token != null && !STRING_EMPTY.equals(StringUtils.trimWhitespace(token))) {
				headers.add(HTTP_HEADER_TOKEN, token);
			}

			HttpEntity<String> entity = new HttpEntity<>(json, headers);

		    String url = String.format("%s/servico", obterEndpointSEP());

		    retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}

	    return retorno;		
	}

	/**
	 * Retorna o endpoint
	 * 
	 * @return
	 * @throws SRException
	 */
	private String obterEndpointSEP() throws SRException {
		
		EndpointDto microServico = service.obterMicroServico(COD_ENDPOINT_SEP);

		return microServico.getUrlServico();
	}
}