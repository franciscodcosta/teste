package br.com.itau.wd.gerenciador.sr.config;

import static br.com.itau.wd.gerenciador.sr.util.Constants.JSON_KEY_SALESFORCE_ACCESS_TOKEN;
import static br.com.itau.wd.gerenciador.sr.util.Constants.JSON_KEY_SALESFORCE_INSTANCE_URL;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SALESFORCE_CLIENTID;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SALESFORCE_CLIENTSECRET;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SALESFORCE_LOGINURL;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SALESFORCE_SENHA;
import static br.com.itau.wd.gerenciador.util.Constants.PROPERTY_KEY_SALESFORCE_USERNAME;
import static br.com.itau.wd.gerenciador.util.Constants.TLS_V12;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import br.com.itau.wd.gerenciador.sr.dto.LoginSalesforceDto;
import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.sr.util.SRUtils;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Configuration
public class LoginSalesforceConfig {

	private static final Logger logger = LoggerFactory.getLogger(LoginSalesforceConfig.class);
	
	@Resource
	private Environment env;

	/**
	 * Faz o login no Salesforce
	 * 
	 * @return
	 * @throws SRException
	 */
    public LoginSalesforceDto obterDados() throws SRException {

    	LoginSalesforceDto login = new LoginSalesforceDto();

    	try {

    		// Configura o TLS 1.2
    		SRUtils.configurarTls(TLS_V12);
    		
    		MultiValueMap<String, String> variables = new LinkedMultiValueMap<>();
    		
    		variables.add("grant_type", "password");
    		variables.add("client_id", env.getRequiredProperty(PROPERTY_KEY_SALESFORCE_CLIENTID));
    		variables.add("client_secret", env.getRequiredProperty(PROPERTY_KEY_SALESFORCE_CLIENTSECRET));
    		variables.add("username", env.getRequiredProperty(PROPERTY_KEY_SALESFORCE_USERNAME));
    		variables.add("password", env.getRequiredProperty(PROPERTY_KEY_SALESFORCE_SENHA));

    		String url = env.getRequiredProperty(PROPERTY_KEY_SALESFORCE_LOGINURL) + "/services/oauth2/token";
            
            String result = new RestTemplate().postForObject(url, variables, String.class);

            login = obterDadosLogin(result);
    	}
    	catch (Exception ex) {

    		throw new SRException(ex);
    	}

    	return login;
    }
    
    /**
     * Retorna os dados de login
     * 
     * @param json
     * @return
     */
    private LoginSalesforceDto obterDadosLogin(String json) {
    	
    	LoginSalesforceDto login = new LoginSalesforceDto();
    	
    	String accessToken = GerenciadorUtils.obterDadoJson(json, JSON_KEY_SALESFORCE_ACCESS_TOKEN);
    	String instanceUrl = GerenciadorUtils.obterDadoJson(json, JSON_KEY_SALESFORCE_INSTANCE_URL);
    	
    	logger.info("ACCESS TOKEN = " + accessToken);
    	logger.info("INSTANCE URL = " + instanceUrl);

		login.setAccessToken(accessToken);
		login.setInstanceUrl(instanceUrl);
		
    	return login;
    }
}