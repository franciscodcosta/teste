package br.com.itau.wd.gerenciador.sr.router.service;

import static br.com.itau.wd.gerenciador.sr.util.Constants.HTTP_HEADER_CONTENT_TYPE;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_HEADER;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_HEADER_CHAVE;
import static br.com.itau.wd.gerenciador.util.Constants.JSON_KEY_HEADER_VALOR;
import static br.com.itau.wd.gerenciador.util.Constants.STRING_EMPTY;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import br.com.itau.wd.gerenciador.sr.exception.SRException;
import br.com.itau.wd.gerenciador.util.GerenciadorUtils;

@Service
public class RouterRestService {

	@Autowired
	ClientRestService clientRest;

	/**
	 * Executa o serviço REST
	 * 
	 * @param endpoint
	 * @param json
	 * @return
	 * @throws SRException 
	 */
	public String executarServico(String url, String json) throws SRException {

		String retorno = STRING_EMPTY;

		try {

			String jsonBody;
			HttpHeaders headers = new HttpHeaders();

			// Obtem os headers do JSON - 09/10/2017
			if (GerenciadorUtils.existeTagJson(json, JSON_KEY_HEADER)) {

				obterHeadersJson(json, headers);
				jsonBody = obterJsonServico(json);
			}
			else {

				jsonBody = json;
			}

			headers.add(HTTP_HEADER_CONTENT_TYPE, "application/json");

			HttpEntity<String> entity = new HttpEntity<>(jsonBody, headers);

			retorno = clientRest.enviarJson(url, HttpMethod.POST, entity);  
		}
		catch (Exception ex) {
			
			throw new SRException(ex);
		}

		return retorno;
	}
	
	/**
	 * Obtem o JSON do serviço
	 * 
	 * @param json
	 * @return
	 */
	private String obterJsonServico(String json) {
		
		JsonElement objJsonElement = new JsonParser().parse(json);
		
		JsonObject objJson = objJsonElement.getAsJsonObject();
		
		objJson.getAsJsonObject().remove(JSON_KEY_HEADER);

		return objJson.toString();
	}
	
	/**
	 * Obtem os headers do JSON
	 * 
	 * @param headers
	 */
	private void obterHeadersJson(String json, HttpHeaders headers) {
		
		JsonElement objJsonElement = new JsonParser().parse(json);

		if (objJsonElement.isJsonObject()) {

			JsonElement objJsonHeaders = objJsonElement.getAsJsonObject().get(JSON_KEY_HEADER);

			if (objJsonHeaders != null && objJsonHeaders.isJsonArray()) {

				for (JsonElement objJsonHeaderElement : objJsonHeaders.getAsJsonArray()) {
	
				    JsonObject objJsonHeader = objJsonHeaderElement.getAsJsonObject();
	
					String chave = objJsonHeader.get(JSON_KEY_HEADER_CHAVE).getAsString();
					String valor = obterValor(objJsonHeader);
					
					headers.add(chave, valor);
				}
			}
		}
	}
	
	/**
	 * Obtem o valor do Header
	 * 
	 * @param objJsonHeader
	 * @return
	 */
	private String obterValor(JsonObject objJsonHeader) {
		
		if (objJsonHeader.get(JSON_KEY_HEADER_VALOR).isJsonObject()) {
			return objJsonHeader.get(JSON_KEY_HEADER_VALOR).toString();
		} else {
			return objJsonHeader.get(JSON_KEY_HEADER_VALOR).getAsString();
		}
	}
}