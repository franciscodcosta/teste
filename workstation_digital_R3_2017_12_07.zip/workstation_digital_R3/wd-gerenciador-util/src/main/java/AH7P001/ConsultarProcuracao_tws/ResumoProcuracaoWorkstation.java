/**
 * ResumoProcuracaoWorkstation.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package AH7P001.ConsultarProcuracao_tws;

public class ResumoProcuracaoWorkstation  implements java.io.Serializable {
    private java.lang.String solicitanteNome;

    private java.lang.String areaSolicitacaoProcuracao;

    private java.lang.String tipoInstrumento;

    private java.lang.String nomePoder;

    private java.lang.String textoDescricaoPoder;

    private java.lang.String idTarefa;

    private java.lang.Integer idProcuracao;

    private java.util.Calendar dataSolicitacaoAprovacao;

    public ResumoProcuracaoWorkstation() {
    }

    public ResumoProcuracaoWorkstation(
           java.lang.String solicitanteNome,
           java.lang.String areaSolicitacaoProcuracao,
           java.lang.String tipoInstrumento,
           java.lang.String nomePoder,
           java.lang.String textoDescricaoPoder,
           java.lang.String idTarefa,
           java.lang.Integer idProcuracao,
           java.util.Calendar dataSolicitacaoAprovacao) {
           this.solicitanteNome = solicitanteNome;
           this.areaSolicitacaoProcuracao = areaSolicitacaoProcuracao;
           this.tipoInstrumento = tipoInstrumento;
           this.nomePoder = nomePoder;
           this.textoDescricaoPoder = textoDescricaoPoder;
           this.idTarefa = idTarefa;
           this.idProcuracao = idProcuracao;
           this.dataSolicitacaoAprovacao = dataSolicitacaoAprovacao;
    }


    /**
     * Gets the solicitanteNome value for this ResumoProcuracaoWorkstation.
     * 
     * @return solicitanteNome
     */
    public java.lang.String getSolicitanteNome() {
        return solicitanteNome;
    }


    /**
     * Sets the solicitanteNome value for this ResumoProcuracaoWorkstation.
     * 
     * @param solicitanteNome
     */
    public void setSolicitanteNome(java.lang.String solicitanteNome) {
        this.solicitanteNome = solicitanteNome;
    }


    /**
     * Gets the areaSolicitacaoProcuracao value for this ResumoProcuracaoWorkstation.
     * 
     * @return areaSolicitacaoProcuracao
     */
    public java.lang.String getAreaSolicitacaoProcuracao() {
        return areaSolicitacaoProcuracao;
    }


    /**
     * Sets the areaSolicitacaoProcuracao value for this ResumoProcuracaoWorkstation.
     * 
     * @param areaSolicitacaoProcuracao
     */
    public void setAreaSolicitacaoProcuracao(java.lang.String areaSolicitacaoProcuracao) {
        this.areaSolicitacaoProcuracao = areaSolicitacaoProcuracao;
    }


    /**
     * Gets the tipoInstrumento value for this ResumoProcuracaoWorkstation.
     * 
     * @return tipoInstrumento
     */
    public java.lang.String getTipoInstrumento() {
        return tipoInstrumento;
    }


    /**
     * Sets the tipoInstrumento value for this ResumoProcuracaoWorkstation.
     * 
     * @param tipoInstrumento
     */
    public void setTipoInstrumento(java.lang.String tipoInstrumento) {
        this.tipoInstrumento = tipoInstrumento;
    }


    /**
     * Gets the nomePoder value for this ResumoProcuracaoWorkstation.
     * 
     * @return nomePoder
     */
    public java.lang.String getNomePoder() {
        return nomePoder;
    }


    /**
     * Sets the nomePoder value for this ResumoProcuracaoWorkstation.
     * 
     * @param nomePoder
     */
    public void setNomePoder(java.lang.String nomePoder) {
        this.nomePoder = nomePoder;
    }


    /**
     * Gets the textoDescricaoPoder value for this ResumoProcuracaoWorkstation.
     * 
     * @return textoDescricaoPoder
     */
    public java.lang.String getTextoDescricaoPoder() {
        return textoDescricaoPoder;
    }


    /**
     * Sets the textoDescricaoPoder value for this ResumoProcuracaoWorkstation.
     * 
     * @param textoDescricaoPoder
     */
    public void setTextoDescricaoPoder(java.lang.String textoDescricaoPoder) {
        this.textoDescricaoPoder = textoDescricaoPoder;
    }


    /**
     * Gets the idTarefa value for this ResumoProcuracaoWorkstation.
     * 
     * @return idTarefa
     */
    public java.lang.String getIdTarefa() {
        return idTarefa;
    }


    /**
     * Sets the idTarefa value for this ResumoProcuracaoWorkstation.
     * 
     * @param idTarefa
     */
    public void setIdTarefa(java.lang.String idTarefa) {
        this.idTarefa = idTarefa;
    }


    /**
     * Gets the idProcuracao value for this ResumoProcuracaoWorkstation.
     * 
     * @return idProcuracao
     */
    public java.lang.Integer getIdProcuracao() {
        return idProcuracao;
    }


    /**
     * Sets the idProcuracao value for this ResumoProcuracaoWorkstation.
     * 
     * @param idProcuracao
     */
    public void setIdProcuracao(java.lang.Integer idProcuracao) {
        this.idProcuracao = idProcuracao;
    }


    /**
     * Gets the dataSolicitacaoAprovacao value for this ResumoProcuracaoWorkstation.
     * 
     * @return dataSolicitacaoAprovacao
     */
    public java.util.Calendar getDataSolicitacaoAprovacao() {
        return dataSolicitacaoAprovacao;
    }


    /**
     * Sets the dataSolicitacaoAprovacao value for this ResumoProcuracaoWorkstation.
     * 
     * @param dataSolicitacaoAprovacao
     */
    public void setDataSolicitacaoAprovacao(java.util.Calendar dataSolicitacaoAprovacao) {
        this.dataSolicitacaoAprovacao = dataSolicitacaoAprovacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ResumoProcuracaoWorkstation)) return false;
        ResumoProcuracaoWorkstation other = (ResumoProcuracaoWorkstation) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.solicitanteNome==null && other.getSolicitanteNome()==null) || 
             (this.solicitanteNome!=null &&
              this.solicitanteNome.equals(other.getSolicitanteNome()))) &&
            ((this.areaSolicitacaoProcuracao==null && other.getAreaSolicitacaoProcuracao()==null) || 
             (this.areaSolicitacaoProcuracao!=null &&
              this.areaSolicitacaoProcuracao.equals(other.getAreaSolicitacaoProcuracao()))) &&
            ((this.tipoInstrumento==null && other.getTipoInstrumento()==null) || 
             (this.tipoInstrumento!=null &&
              this.tipoInstrumento.equals(other.getTipoInstrumento()))) &&
            ((this.nomePoder==null && other.getNomePoder()==null) || 
             (this.nomePoder!=null &&
              this.nomePoder.equals(other.getNomePoder()))) &&
            ((this.textoDescricaoPoder==null && other.getTextoDescricaoPoder()==null) || 
             (this.textoDescricaoPoder!=null &&
              this.textoDescricaoPoder.equals(other.getTextoDescricaoPoder()))) &&
            ((this.idTarefa==null && other.getIdTarefa()==null) || 
             (this.idTarefa!=null &&
              this.idTarefa.equals(other.getIdTarefa()))) &&
            ((this.idProcuracao==null && other.getIdProcuracao()==null) || 
             (this.idProcuracao!=null &&
              this.idProcuracao.equals(other.getIdProcuracao()))) &&
            ((this.dataSolicitacaoAprovacao==null && other.getDataSolicitacaoAprovacao()==null) || 
             (this.dataSolicitacaoAprovacao!=null &&
              this.dataSolicitacaoAprovacao.equals(other.getDataSolicitacaoAprovacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSolicitanteNome() != null) {
            _hashCode += getSolicitanteNome().hashCode();
        }
        if (getAreaSolicitacaoProcuracao() != null) {
            _hashCode += getAreaSolicitacaoProcuracao().hashCode();
        }
        if (getTipoInstrumento() != null) {
            _hashCode += getTipoInstrumento().hashCode();
        }
        if (getNomePoder() != null) {
            _hashCode += getNomePoder().hashCode();
        }
        if (getTextoDescricaoPoder() != null) {
            _hashCode += getTextoDescricaoPoder().hashCode();
        }
        if (getIdTarefa() != null) {
            _hashCode += getIdTarefa().hashCode();
        }
        if (getIdProcuracao() != null) {
            _hashCode += getIdProcuracao().hashCode();
        }
        if (getDataSolicitacaoAprovacao() != null) {
            _hashCode += getDataSolicitacaoAprovacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ResumoProcuracaoWorkstation.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "ResumoProcuracaoWorkstation"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solicitanteNome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "solicitanteNome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("areaSolicitacaoProcuracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "areaSolicitacaoProcuracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoInstrumento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "tipoInstrumento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePoder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "nomePoder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("textoDescricaoPoder");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "textoDescricaoPoder"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idTarefa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "idTarefa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idProcuracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "idProcuracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataSolicitacaoAprovacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://AH7P001/ConsultarProcuracao.tws", "dataSolicitacaoAprovacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
