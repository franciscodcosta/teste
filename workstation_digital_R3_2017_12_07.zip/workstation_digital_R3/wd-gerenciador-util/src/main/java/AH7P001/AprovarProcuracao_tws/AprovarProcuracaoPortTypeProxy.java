package AH7P001.AprovarProcuracao_tws;

public class AprovarProcuracaoPortTypeProxy implements AH7P001.AprovarProcuracao_tws.AprovarProcuracaoPortType {
  private String _endpoint = null;
  private AH7P001.AprovarProcuracao_tws.AprovarProcuracaoPortType aprovarProcuracaoPortType = null;
  
  public AprovarProcuracaoPortTypeProxy() {
    _initAprovarProcuracaoPortTypeProxy();
  }
  
  public AprovarProcuracaoPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initAprovarProcuracaoPortTypeProxy();
  }
  
  private void _initAprovarProcuracaoPortTypeProxy() {
    try {
      aprovarProcuracaoPortType = (new AH7P001.AprovarProcuracao_tws.AprovarProcuracao_ServiceLocator()).getAprovarProcuracaoSoap();
      if (aprovarProcuracaoPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)aprovarProcuracaoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)aprovarProcuracaoPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (aprovarProcuracaoPortType != null)
      ((javax.xml.rpc.Stub)aprovarProcuracaoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public AH7P001.AprovarProcuracao_tws.AprovarProcuracaoPortType getAprovarProcuracaoPortType() {
    if (aprovarProcuracaoPortType == null)
      _initAprovarProcuracaoPortTypeProxy();
    return aprovarProcuracaoPortType;
  }
  
  public void aprovarProcuracao(int identificadorProcuracao, java.lang.String procuracaoValidada, java.lang.String textoJustificativaWorkstation, java.lang.String funcionalDiretor, int idTarefa, java.lang.String usuarioAcesso, java.lang.String tokenAcesso, javax.xml.rpc.holders.IntHolder codigoRetorno, javax.xml.rpc.holders.StringHolder mensagemRetorno) throws java.rmi.RemoteException{
    if (aprovarProcuracaoPortType == null)
      _initAprovarProcuracaoPortTypeProxy();
    aprovarProcuracaoPortType.aprovarProcuracao(identificadorProcuracao, procuracaoValidada, textoJustificativaWorkstation, funcionalDiretor, idTarefa, usuarioAcesso, tokenAcesso, codigoRetorno, mensagemRetorno);
  }
  
  
}