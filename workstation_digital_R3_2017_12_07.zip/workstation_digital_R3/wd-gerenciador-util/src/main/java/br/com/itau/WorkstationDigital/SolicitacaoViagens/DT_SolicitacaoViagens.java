/**
 * DT_SolicitacaoViagens.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.itau.WorkstationDigital.SolicitacaoViagens;

public class DT_SolicitacaoViagens  implements java.io.Serializable {
    private java.lang.String funcao_sistema_produto;

    private java.lang.String funcao_atividade_sistema_produto;

    private java.lang.String dados_registrar_solicitacao;

    private java.lang.String chave_produto;

    private java.lang.String token_oauth;

    public DT_SolicitacaoViagens() {
    }

    public DT_SolicitacaoViagens(
           java.lang.String funcao_sistema_produto,
           java.lang.String funcao_atividade_sistema_produto,
           java.lang.String dados_registrar_solicitacao,
           java.lang.String chave_produto,
           java.lang.String token_oauth) {
           this.funcao_sistema_produto = funcao_sistema_produto;
           this.funcao_atividade_sistema_produto = funcao_atividade_sistema_produto;
           this.dados_registrar_solicitacao = dados_registrar_solicitacao;
           this.chave_produto = chave_produto;
           this.token_oauth = token_oauth;
    }


    /**
     * Gets the funcao_sistema_produto value for this DT_SolicitacaoViagens.
     * 
     * @return funcao_sistema_produto
     */
    public java.lang.String getFuncao_sistema_produto() {
        return funcao_sistema_produto;
    }


    /**
     * Sets the funcao_sistema_produto value for this DT_SolicitacaoViagens.
     * 
     * @param funcao_sistema_produto
     */
    public void setFuncao_sistema_produto(java.lang.String funcao_sistema_produto) {
        this.funcao_sistema_produto = funcao_sistema_produto;
    }


    /**
     * Gets the funcao_atividade_sistema_produto value for this DT_SolicitacaoViagens.
     * 
     * @return funcao_atividade_sistema_produto
     */
    public java.lang.String getFuncao_atividade_sistema_produto() {
        return funcao_atividade_sistema_produto;
    }


    /**
     * Sets the funcao_atividade_sistema_produto value for this DT_SolicitacaoViagens.
     * 
     * @param funcao_atividade_sistema_produto
     */
    public void setFuncao_atividade_sistema_produto(java.lang.String funcao_atividade_sistema_produto) {
        this.funcao_atividade_sistema_produto = funcao_atividade_sistema_produto;
    }


    /**
     * Gets the dados_registrar_solicitacao value for this DT_SolicitacaoViagens.
     * 
     * @return dados_registrar_solicitacao
     */
    public java.lang.String getDados_registrar_solicitacao() {
        return dados_registrar_solicitacao;
    }


    /**
     * Sets the dados_registrar_solicitacao value for this DT_SolicitacaoViagens.
     * 
     * @param dados_registrar_solicitacao
     */
    public void setDados_registrar_solicitacao(java.lang.String dados_registrar_solicitacao) {
        this.dados_registrar_solicitacao = dados_registrar_solicitacao;
    }


    /**
     * Gets the chave_produto value for this DT_SolicitacaoViagens.
     * 
     * @return chave_produto
     */
    public java.lang.String getChave_produto() {
        return chave_produto;
    }


    /**
     * Sets the chave_produto value for this DT_SolicitacaoViagens.
     * 
     * @param chave_produto
     */
    public void setChave_produto(java.lang.String chave_produto) {
        this.chave_produto = chave_produto;
    }


    /**
     * Gets the token_oauth value for this DT_SolicitacaoViagens.
     * 
     * @return token_oauth
     */
    public java.lang.String getToken_oauth() {
        return token_oauth;
    }


    /**
     * Sets the token_oauth value for this DT_SolicitacaoViagens.
     * 
     * @param token_oauth
     */
    public void setToken_oauth(java.lang.String token_oauth) {
        this.token_oauth = token_oauth;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DT_SolicitacaoViagens)) return false;
        DT_SolicitacaoViagens other = (DT_SolicitacaoViagens) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.funcao_sistema_produto==null && other.getFuncao_sistema_produto()==null) || 
             (this.funcao_sistema_produto!=null &&
              this.funcao_sistema_produto.equals(other.getFuncao_sistema_produto()))) &&
            ((this.funcao_atividade_sistema_produto==null && other.getFuncao_atividade_sistema_produto()==null) || 
             (this.funcao_atividade_sistema_produto!=null &&
              this.funcao_atividade_sistema_produto.equals(other.getFuncao_atividade_sistema_produto()))) &&
            ((this.dados_registrar_solicitacao==null && other.getDados_registrar_solicitacao()==null) || 
             (this.dados_registrar_solicitacao!=null &&
              this.dados_registrar_solicitacao.equals(other.getDados_registrar_solicitacao()))) &&
            ((this.chave_produto==null && other.getChave_produto()==null) || 
             (this.chave_produto!=null &&
              this.chave_produto.equals(other.getChave_produto()))) &&
            ((this.token_oauth==null && other.getToken_oauth()==null) || 
             (this.token_oauth!=null &&
              this.token_oauth.equals(other.getToken_oauth())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFuncao_sistema_produto() != null) {
            _hashCode += getFuncao_sistema_produto().hashCode();
        }
        if (getFuncao_atividade_sistema_produto() != null) {
            _hashCode += getFuncao_atividade_sistema_produto().hashCode();
        }
        if (getDados_registrar_solicitacao() != null) {
            _hashCode += getDados_registrar_solicitacao().hashCode();
        }
        if (getChave_produto() != null) {
            _hashCode += getChave_produto().hashCode();
        }
        if (getToken_oauth() != null) {
            _hashCode += getToken_oauth().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DT_SolicitacaoViagens.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://itau.com.br/WorkstationDigital/SolicitacaoViagens", "DT_SolicitacaoViagens"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcao_sistema_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "funcao_sistema_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("funcao_atividade_sistema_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "funcao_atividade_sistema_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dados_registrar_solicitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dados_registrar_solicitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("chave_produto");
        elemField.setXmlName(new javax.xml.namespace.QName("", "chave_produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("token_oauth");
        elemField.setXmlName(new javax.xml.namespace.QName("", "token_oauth"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
