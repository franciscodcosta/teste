/**
 * SI_Consulta_Documento_out.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.itau.WorkstationDigital.Consulta_Documento;

public interface SI_Consulta_Documento_out extends java.rmi.Remote {
    public br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_Response_out SI_Consulta_Documento_out(br.com.itau.WorkstationDigital.Consulta_Documento.DT_Consulta_Documento_out MT_Consulta_Documento_out) throws java.rmi.RemoteException;
}
