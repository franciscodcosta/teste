package br.com.itau.wd.gerenciador.util;

public class Constants {

	//Pool
	public static final String PROPERTY_KEY_POOL_MAX_TOTAL = "pool.maxtotal";
	public static final String PROPERTY_KEY_POOL_MAX_PER_ROUTE = "pool.maxperroute";
	
	//TimeOut
	public static final String PROPERTY_KEY_CONNECTION_REQUEST_TIMEOUT = "connection.request.timeout";
	public static final String PROPERTY_KEY_CONNECT_TIMEOUT = "connect.timeout";
	public static final String PROPERTY_KEY_SOCKET_TIMEOUT = "socket.timeout";

	// Hibernate
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_PROVIDER_CLASS = "hibernate.connection.provider_class";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_CLIENT_ID = "hibernate.connection.client_id";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_TOKEN = "hibernate.connection.token";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_DATASOURCE = "hibernate.connection.datasource";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_USERNAME = "hibernate.connection.username";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_SENHA = "hibernate.connection.password";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_DRIVER_CLASS = "hibernate.connection.driver_class";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_URL = "hibernate.connection.url";
	public static final String PROPERTY_KEY_HIBERNATE_CONNECTION_DIALECT = "hibernate.dialect";

	public static final String PROPERTY_KEY_SAP_USUARIO = "sap.username";
	public static final String PROPERTY_KEY_SAP_SENHA = "sap.password";
	
	public static final String PROPERTY_KEY_SALESFORCE_LOGINURL = "salesforce.loginurl";
	public static final String PROPERTY_KEY_SALESFORCE_GRANTSERVICE = "salesforce.grantservice";
	public static final String PROPERTY_KEY_SALESFORCE_CLIENTID = "salesforce.clientid";
	public static final String PROPERTY_KEY_SALESFORCE_CLIENTSECRET = "salesforce.clientsecret";
	public static final String PROPERTY_KEY_SALESFORCE_USERNAME = "salesforce.username";
	public static final String PROPERTY_KEY_SALESFORCE_SENHA = "salesforce.password";
	
	public static final String PROPERTY_KEY_PASTA_UPLOAD = "pasta.upload";
	
	//BPM
	public static final String PROPERTY_KEY_SECURITY_FUNCIONAL_ITAU = "security.funcional_itau";
	public static final String PROPERTY_KEY_SECURITY_ITAU_CREDENTIALS = "security.itau_credentials";
	public static final String PROPERTY_KEY_SECURITY_AUTHORIZATION = "security.authorization";
	public static final String PROPERTY_KEY_URL_CONSULTA_PENDENCIA = "url.consulta_pendencia";
	public static final String PROPERTY_KEY_URL_REGISTRAR_ACAO = "url.registrar_acao";
	
	// Procedure
	public static final String PRC_NAME_INS_CHAVE = "PRC_INS_CHAVE";
	public static final String PRC_NAME_SEL_CHAVE = "PRC_SEL_CHAVE";
	public static final String PRC_PARAM_NAME_CODIGO_CHAVE_SISTEMA_INTERNO = "COD_CHAV_SIST_INRN";
	public static final String PRC_PARAM_NAME_CODIGO_ATIVIDADE_SISTEMA_INTERNO = "COD_ATII_SIST_INRN";
	public static final String PRC_PARAM_NAME_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO = "COD_FUNO_ATII_SIST_PROD";
	public static final String PRC_PARAM_NAME_NUMERO_FUNCIONAL_COLABORADOR_CONGLOMERADO = "NUM_FUNL_COLA_COGL";
	public static final String PRC_PARAM_NAME_CODIGO_CHAVE_EXTERNA = "COD_CHAV_EXTO";
	
	public static final Integer COLUMN_INDEX_CODIGO_CHAVE_SISTEMA_INTERNO = 0;
	public static final Integer COLUMN_INDEX_CODIGO_ATIVIDADE_SISTEMA_INTERNO = 1;
	public static final Integer COLUMN_INDEX_NUMERO_FUNCIONAL_COLABORADOR_CONGLOMERADO = 2;
	public static final Integer COLUMN_INDEX_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO = 3;
	public static final Integer COLUMN_INDEX_FUNCAO_SISTEMA_PRODUTO = 4;
	public static final Integer COLUMN_INDEX_SIGLA_SISTEMA = 5;

	public static final String PRC_SEL_MICRO_SERVICO = "PRC_SEL_MICRO_SERVICO";
	public static final String PRC_PARAM_NAME_DESCRICAO_ENDERECO_VIRTUAL = "DES_ENDE_VIRT";
	public static final String PRC_PARAM_NAME_NUMERO_ORDENACAO = "NUM_ORDN";

	public static final String PRC_SEL_REGISTRO_ORDEM_EXECUCAO = "PRC_SEL_REGISTRO_ORDEM_EXECUCAO";
	public static final String PRC_PARAM_NAME_DESCRICAO_ENDERECO_VIRTUAL_NEGOCIO = "DES_ENDE_VIRT_SERV_NEGO";
	public static final String PRC_PARAM_NAME_NUM_ORDN = "NUM_ORDN";

	public static final String PRC_SEL_ATIVIDADE_SISTEMA_INTERNO = "PRC_SEL_ATIVIDADE_SISTEMA_INTERNO";
	public static final String PRC_PARAM_NAME_DESCRICAO_ATIVIDADE = "DES_ATII";
	public static final String PRC_PARAM_NAME_SIGLA_SISTEMA = "SIG3STM";
	
	// **********************
	// ****   SERVI�OS   ****
	// **********************

	// NOTIFICA��O
	public static final String SERVICO_NOTIFICACAO = "notificacao";

	// SAP
	public static final String SERVICO_REGISTRAR_ACAO = "registrar_acao";
	public static final String SERVICO_CONSULTA_PENDENCIA = "consulta_pendencia";

	// SP2 - PONTO
	public static final String SERVICO_APROVACAO_ACERTO_PONTO = "aprovacao_acerto_ponto";
	public static final String SERVICO_ASSINATURA_ESPELHO_PONTO = "assinatura_espelho_ponto";
	public static final String SERVICO_CONSULTA_DADOS_BASICOS = "consulta_dados_basicos";
	public static final String SERVICO_CONSULTA_DADOS_GESTOR = "consulta_dados_gestor";
	public static final String SERVICO_CONSULTA_DELEGACAO_EQUIPE = "consulta_delegacao_equipe";
	public static final String SERVICO_CONSULTA_ESPELHO_PONTO = "consulta_espelho_ponto";
	public static final String SERVICO_CONSULTA_ESPELHO_PONTO_EQUIPE = "consulta_espelho_ponto_equipe";
	public static final String SERVICO_CONSULTA_MARCACAO_PENDENTE = "consulta_marcacao_pendente";
	public static final String SERVICO_CONSULTA_MARCACAO_PONTO = "consulta_marcacao_ponto";
	public static final String SERVICO_CONSULTA_MARCACAO_PONTO_EQUIPE = "consulta_marcacao_ponto_equipe";
	public static final String SERVICO_CONSULTA_MOTIVOS_ACERTOS = "consulta_motivos_acertos";
	public static final String SERVICO_CONSULTA_PENDENCIA_APROVACAO = "consulta_pendencia_aprovacao";
	public static final String SERVICO_SALDO_HORAS = "consulta_saldo_horas";
	public static final String SERVICO_INCLUSAO_ABONO = "inclusao_abono";
	public static final String SERVICO_INCLUSAO_ABONOS_COLABORADOR = "inclusao_abonos_colaborador";
	public static final String SERVICO_INCLUSAO_ACERTO_PONTO = "inclusao_acerto_ponto";

	// SP2 - F�RIAS
	public static final String SERVICO_CONSULTA_FERIAS = "consulta_ferias";
	public static final String SERVICO_INCLUSAO_REQUISICAO_FERIAS = "inclusao_requisicao_ferias";
	public static final String SERVICO_INCLUSAO_REQUISICAO_REPROGRAMACAO = "inclusao_requisicao_reprogramacao";
	public static final String SERVICO_INCLUSAO_ASSINATURA_AVISO = "inclusao_assinatura_aviso";
	public static final String SERVICO_INCLUSAO_APROVACAO_AGENDAMENTO= "inclusao_aprovacao_agendamento";

	public static final String ROUTER_ENDPOINT_SALESFORCE = "SF";
	public static final String ROUTER_ENDPOINT_REST = "REST";
	public static final String ROUTER_ENDPOINT_SOAP = "SOAP";
	public static final String ROUTER_ENDPOINT_MAINFRAME = "MAINFRAME";
	public static final String ROUTER_ENDPOINT_INDEFINIDO = "INDEFINIDO";

	public static final String SIGLA_SISTEMA_SAP = "SAP";
	public static final String SIGLA_SISTEMA_SP2 = "SP2";
	public static final String SIGLA_SISTEMA_BPM = "AH7";
	public static final String SIGLA_SISTEMA_RAINBOW = "CR";
	public static final String SIGLA_SISTEMA_CAMBIO = "DI2";
	public static final String SIGLA_SISTEMA_MAXIMO = "V4";
	public static final String SIGLA_SISTEMA_TMS = "TMS";
	public static final String SIGLA_SISTEMA_TAREFODROMO = "CF5";
	public static final String SIGLA_SISTEMA_PAGAMENTO = "OB6";
	public static final String SIGLA_SISTEMA_SALESFORCE = "SF";

	public static final int MICRO_SERVICO_SEP = 4;
	public static final int MICRO_SERVICO_SR = 5;
	public static final int MICRO_SERVICO_KMS = 6;
	public static final int MICRO_SERVICO_HCS = 7;
	
	public static final int COD_ENDPOINT_SEP = 4;
	public static final int COD_ENDPOINT_SR = 5;
	public static final int COD_ENDPOINT_KMS = 6;
	public static final int COD_ENDPOINT_HCS = 7;
	
	//C�digos de Status
	public static final String STATUS_ZEROS_OK = "00";
	
	// JSON
	public static final String JSON_KEY_UID = "uid";
	public static final String JSON_KEY_TOKEN = "token";
	public static final String JSON_KEY_SIGLA_SISTEMA_PRODUTO = "sigla_sistema_produto";
	public static final String JSON_KEY_CHAVE_PRODUTO = "chave_produto";
	public static final String JSON_KEY_FUNCAO_SISTEMA_PRODUTO = "funcao_sistema_produto";
	public static final String JSON_KEY_FUNCAO_ATIVIDADE_SISTEMA_PRODUTO = "funcao_atividade_sistema_produto";
	public static final String JSON_KEY_FUNCAO_ATI_SISTEMA_PRODUTO = "funcao_ati_sistema_produto";
	public static final String JSON_KEY_FUNCIONAL_SISTEMA_PRODUTO = "funcional_sistema_produto";
	public static final String JSON_KEY_CONTADOR_PAGINAS = "contador_paginas";
	public static final String JSON_KEY_QTD_POR_PAGINA = "qtd_por_pagina";
	public static final String JSON_KEY_TOTAL_PAGINAS = "total_paginas";
	public static final String JSON_KEY_ID_SOLICITACAO = "id_solicitacao";
	public static final String JSON_KEY_DADOS = "dados";
	public static final String JSON_KEY_STATUS = "status";
	public static final String JSON_KEY_MENSAGEM = "mensagem";
	public static final String JSON_KEY_COMENTARIO = "comentario";
	public static final String JSON_KEY_NUMERO_SOLICITANTE = "numero_solicitante";
	public static final String JSON_KEY_NUMERO_VIAGEM = "numero_viagem";
	public static final String JSON_KEY_CAMBIO = "cambio";
	public static final String JSON_KEY_HEADER = "header";
	public static final String JSON_KEY_HEADER_CHAVE = "chave";
	public static final String JSON_KEY_HEADER_VALOR = "valor";
	public static final String JSON_KEY_FUNCIONAL = "funcional";
	public static final String JSON_KEY_CODIGO_CANAL = "codigo_canal";
	public static final String JSON_KEY_CODIGO_RETORNO = "codigo_retorno";
	public static final String JSON_KEY_DESCRICAO_RETORNO = "descricao_retorno";
	public static final String JSON_KEY_LISTA_UID = "LISTA_UID";

	public static final String JAVAX_XML_RPC_SECURITY_AUTH_USERNAME = "javax.xml.rpc.security.auth.username";
	public static final String JAVAX_XML_RPC_SECURITY_AUTH_PASSWORD = "javax.xml.rpc.security.auth.password";
	
	public static final String TLS_V1 = "TLSv1";
	public static final String TLS_V12 = "TLSv1.2";
	
	public static final String STRING_EMPTY = "";
	
	private Constants() {}
}