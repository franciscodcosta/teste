/**
 * ITAUWDCLASSPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDCLASS;

public interface ITAUWDCLASSPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDCLASSResponseType queryITAUWDCLASS(com.ibm.www.maximo.QueryITAUWDCLASSType parameters) throws java.rmi.RemoteException;
}
