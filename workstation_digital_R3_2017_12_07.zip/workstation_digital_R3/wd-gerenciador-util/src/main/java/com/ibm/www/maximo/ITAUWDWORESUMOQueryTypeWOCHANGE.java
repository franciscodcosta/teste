/**
 * ITAUWDWORESUMOQueryTypeWOCHANGE.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDWORESUMOQueryTypeWOCHANGE  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXStringQueryType[] ITAU_CALENDSIG_STATUS;

    private com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATA_QUALID;

    private com.ibm.www.maximo.MXStringQueryType[] ITAU_PARECER_QUALID;

    private com.ibm.www.maximo.MXStringQueryType[] ITAU_RESP_QUALID;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] SITEID;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] WONUM;

    public ITAUWDWORESUMOQueryTypeWOCHANGE() {
    }

    public ITAUWDWORESUMOQueryTypeWOCHANGE(
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXStringQueryType[] ITAU_CALENDSIG_STATUS,
           com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATA_QUALID,
           com.ibm.www.maximo.MXStringQueryType[] ITAU_PARECER_QUALID,
           com.ibm.www.maximo.MXStringQueryType[] ITAU_RESP_QUALID,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY,
           com.ibm.www.maximo.MXStringQueryType[] SITEID,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXStringQueryType[] WONUM) {
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU_CALENDSIG_STATUS = ITAU_CALENDSIG_STATUS;
           this.ITAU_DATA_QUALID = ITAU_DATA_QUALID;
           this.ITAU_PARECER_QUALID = ITAU_PARECER_QUALID;
           this.ITAU_RESP_QUALID = ITAU_RESP_QUALID;
           this.REPORTEDBY = REPORTEDBY;
           this.SITEID = SITEID;
           this.STATUS = STATUS;
           this.WONUM = WONUM;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the ITAU_CALENDSIG_STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return ITAU_CALENDSIG_STATUS
     */
    public com.ibm.www.maximo.MXStringQueryType[] getITAU_CALENDSIG_STATUS() {
        return ITAU_CALENDSIG_STATUS;
    }


    /**
     * Sets the ITAU_CALENDSIG_STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param ITAU_CALENDSIG_STATUS
     */
    public void setITAU_CALENDSIG_STATUS(com.ibm.www.maximo.MXStringQueryType[] ITAU_CALENDSIG_STATUS) {
        this.ITAU_CALENDSIG_STATUS = ITAU_CALENDSIG_STATUS;
    }

    public com.ibm.www.maximo.MXStringQueryType getITAU_CALENDSIG_STATUS(int i) {
        return this.ITAU_CALENDSIG_STATUS[i];
    }

    public void setITAU_CALENDSIG_STATUS(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ITAU_CALENDSIG_STATUS[i] = _value;
    }


    /**
     * Gets the ITAU_DATA_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return ITAU_DATA_QUALID
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getITAU_DATA_QUALID() {
        return ITAU_DATA_QUALID;
    }


    /**
     * Sets the ITAU_DATA_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param ITAU_DATA_QUALID
     */
    public void setITAU_DATA_QUALID(com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATA_QUALID) {
        this.ITAU_DATA_QUALID = ITAU_DATA_QUALID;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getITAU_DATA_QUALID(int i) {
        return this.ITAU_DATA_QUALID[i];
    }

    public void setITAU_DATA_QUALID(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.ITAU_DATA_QUALID[i] = _value;
    }


    /**
     * Gets the ITAU_PARECER_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return ITAU_PARECER_QUALID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getITAU_PARECER_QUALID() {
        return ITAU_PARECER_QUALID;
    }


    /**
     * Sets the ITAU_PARECER_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param ITAU_PARECER_QUALID
     */
    public void setITAU_PARECER_QUALID(com.ibm.www.maximo.MXStringQueryType[] ITAU_PARECER_QUALID) {
        this.ITAU_PARECER_QUALID = ITAU_PARECER_QUALID;
    }

    public com.ibm.www.maximo.MXStringQueryType getITAU_PARECER_QUALID(int i) {
        return this.ITAU_PARECER_QUALID[i];
    }

    public void setITAU_PARECER_QUALID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ITAU_PARECER_QUALID[i] = _value;
    }


    /**
     * Gets the ITAU_RESP_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return ITAU_RESP_QUALID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getITAU_RESP_QUALID() {
        return ITAU_RESP_QUALID;
    }


    /**
     * Sets the ITAU_RESP_QUALID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param ITAU_RESP_QUALID
     */
    public void setITAU_RESP_QUALID(com.ibm.www.maximo.MXStringQueryType[] ITAU_RESP_QUALID) {
        this.ITAU_RESP_QUALID = ITAU_RESP_QUALID;
    }

    public com.ibm.www.maximo.MXStringQueryType getITAU_RESP_QUALID(int i) {
        return this.ITAU_RESP_QUALID[i];
    }

    public void setITAU_RESP_QUALID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ITAU_RESP_QUALID[i] = _value;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDBY(int i) {
        return this.REPORTEDBY[i];
    }

    public void setREPORTEDBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDBY[i] = _value;
    }


    /**
     * Gets the SITEID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringQueryType[] SITEID) {
        this.SITEID = SITEID;
    }

    public com.ibm.www.maximo.MXStringQueryType getSITEID(int i) {
        return this.SITEID[i];
    }

    public void setSITEID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SITEID[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the WONUM value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @return WONUM   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getWONUM() {
        return WONUM;
    }


    /**
     * Sets the WONUM value for this ITAUWDWORESUMOQueryTypeWOCHANGE.
     * 
     * @param WONUM   * Unique Key Component
     */
    public void setWONUM(com.ibm.www.maximo.MXStringQueryType[] WONUM) {
        this.WONUM = WONUM;
    }

    public com.ibm.www.maximo.MXStringQueryType getWONUM(int i) {
        return this.WONUM[i];
    }

    public void setWONUM(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.WONUM[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDWORESUMOQueryTypeWOCHANGE)) return false;
        ITAUWDWORESUMOQueryTypeWOCHANGE other = (ITAUWDWORESUMOQueryTypeWOCHANGE) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.ITAU_CALENDSIG_STATUS==null && other.getITAU_CALENDSIG_STATUS()==null) || 
             (this.ITAU_CALENDSIG_STATUS!=null &&
              java.util.Arrays.equals(this.ITAU_CALENDSIG_STATUS, other.getITAU_CALENDSIG_STATUS()))) &&
            ((this.ITAU_DATA_QUALID==null && other.getITAU_DATA_QUALID()==null) || 
             (this.ITAU_DATA_QUALID!=null &&
              java.util.Arrays.equals(this.ITAU_DATA_QUALID, other.getITAU_DATA_QUALID()))) &&
            ((this.ITAU_PARECER_QUALID==null && other.getITAU_PARECER_QUALID()==null) || 
             (this.ITAU_PARECER_QUALID!=null &&
              java.util.Arrays.equals(this.ITAU_PARECER_QUALID, other.getITAU_PARECER_QUALID()))) &&
            ((this.ITAU_RESP_QUALID==null && other.getITAU_RESP_QUALID()==null) || 
             (this.ITAU_RESP_QUALID!=null &&
              java.util.Arrays.equals(this.ITAU_RESP_QUALID, other.getITAU_RESP_QUALID()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              java.util.Arrays.equals(this.REPORTEDBY, other.getREPORTEDBY()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              java.util.Arrays.equals(this.SITEID, other.getSITEID()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.WONUM==null && other.getWONUM()==null) || 
             (this.WONUM!=null &&
              java.util.Arrays.equals(this.WONUM, other.getWONUM())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_CALENDSIG_STATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_CALENDSIG_STATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_CALENDSIG_STATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_DATA_QUALID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_DATA_QUALID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_DATA_QUALID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_PARECER_QUALID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_PARECER_QUALID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_PARECER_QUALID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_RESP_QUALID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_RESP_QUALID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_RESP_QUALID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSITEID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSITEID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSITEID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWONUM() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWONUM());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWONUM(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDWORESUMOQueryTypeWOCHANGE.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDWORESUMOQueryType>WOCHANGE"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_CALENDSIG_STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_CALENDSIG_STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_DATA_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_DATA_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_PARECER_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_PARECER_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_RESP_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_RESP_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
