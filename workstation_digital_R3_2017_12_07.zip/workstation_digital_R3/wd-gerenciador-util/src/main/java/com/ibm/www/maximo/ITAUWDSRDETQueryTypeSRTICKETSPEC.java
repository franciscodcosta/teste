/**
 * ITAUWDSRDETQueryTypeSRTICKETSPEC.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRDETQueryTypeSRTICKETSPEC  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] ALNVALUE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID;

    private com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] SECTION;

    private com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE;

    private java.lang.Boolean filter;  // attribute

    public ITAUWDSRDETQueryTypeSRTICKETSPEC() {
    }

    public ITAUWDSRDETQueryTypeSRTICKETSPEC(
           com.ibm.www.maximo.MXStringQueryType[] ALNVALUE,
           com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID,
           com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE,
           com.ibm.www.maximo.MXStringQueryType[] SECTION,
           com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE,
           java.lang.Boolean filter) {
           this.ALNVALUE = ALNVALUE;
           this.ASSETATTRID = ASSETATTRID;
           this.NUMVALUE = NUMVALUE;
           this.SECTION = SECTION;
           this.TABLEVALUE = TABLEVALUE;
           this.filter = filter;
    }


    /**
     * Gets the ALNVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return ALNVALUE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getALNVALUE() {
        return ALNVALUE;
    }


    /**
     * Sets the ALNVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param ALNVALUE
     */
    public void setALNVALUE(com.ibm.www.maximo.MXStringQueryType[] ALNVALUE) {
        this.ALNVALUE = ALNVALUE;
    }

    public com.ibm.www.maximo.MXStringQueryType getALNVALUE(int i) {
        return this.ALNVALUE[i];
    }

    public void setALNVALUE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ALNVALUE[i] = _value;
    }


    /**
     * Gets the ASSETATTRID value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return ASSETATTRID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getASSETATTRID() {
        return ASSETATTRID;
    }


    /**
     * Sets the ASSETATTRID value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param ASSETATTRID   * Unique Key Component
     */
    public void setASSETATTRID(com.ibm.www.maximo.MXStringQueryType[] ASSETATTRID) {
        this.ASSETATTRID = ASSETATTRID;
    }

    public com.ibm.www.maximo.MXStringQueryType getASSETATTRID(int i) {
        return this.ASSETATTRID[i];
    }

    public void setASSETATTRID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.ASSETATTRID[i] = _value;
    }


    /**
     * Gets the NUMVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return NUMVALUE
     */
    public com.ibm.www.maximo.MXDoubleQueryType[] getNUMVALUE() {
        return NUMVALUE;
    }


    /**
     * Sets the NUMVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param NUMVALUE
     */
    public void setNUMVALUE(com.ibm.www.maximo.MXDoubleQueryType[] NUMVALUE) {
        this.NUMVALUE = NUMVALUE;
    }

    public com.ibm.www.maximo.MXDoubleQueryType getNUMVALUE(int i) {
        return this.NUMVALUE[i];
    }

    public void setNUMVALUE(int i, com.ibm.www.maximo.MXDoubleQueryType _value) {
        this.NUMVALUE[i] = _value;
    }


    /**
     * Gets the SECTION value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return SECTION   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getSECTION() {
        return SECTION;
    }


    /**
     * Sets the SECTION value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param SECTION   * Unique Key Component
     */
    public void setSECTION(com.ibm.www.maximo.MXStringQueryType[] SECTION) {
        this.SECTION = SECTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getSECTION(int i) {
        return this.SECTION[i];
    }

    public void setSECTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.SECTION[i] = _value;
    }


    /**
     * Gets the TABLEVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return TABLEVALUE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTABLEVALUE() {
        return TABLEVALUE;
    }


    /**
     * Sets the TABLEVALUE value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param TABLEVALUE
     */
    public void setTABLEVALUE(com.ibm.www.maximo.MXStringQueryType[] TABLEVALUE) {
        this.TABLEVALUE = TABLEVALUE;
    }

    public com.ibm.www.maximo.MXStringQueryType getTABLEVALUE(int i) {
        return this.TABLEVALUE[i];
    }

    public void setTABLEVALUE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TABLEVALUE[i] = _value;
    }


    /**
     * Gets the filter value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @return filter
     */
    public java.lang.Boolean getFilter() {
        return filter;
    }


    /**
     * Sets the filter value for this ITAUWDSRDETQueryTypeSRTICKETSPEC.
     * 
     * @param filter
     */
    public void setFilter(java.lang.Boolean filter) {
        this.filter = filter;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRDETQueryTypeSRTICKETSPEC)) return false;
        ITAUWDSRDETQueryTypeSRTICKETSPEC other = (ITAUWDSRDETQueryTypeSRTICKETSPEC) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ALNVALUE==null && other.getALNVALUE()==null) || 
             (this.ALNVALUE!=null &&
              java.util.Arrays.equals(this.ALNVALUE, other.getALNVALUE()))) &&
            ((this.ASSETATTRID==null && other.getASSETATTRID()==null) || 
             (this.ASSETATTRID!=null &&
              java.util.Arrays.equals(this.ASSETATTRID, other.getASSETATTRID()))) &&
            ((this.NUMVALUE==null && other.getNUMVALUE()==null) || 
             (this.NUMVALUE!=null &&
              java.util.Arrays.equals(this.NUMVALUE, other.getNUMVALUE()))) &&
            ((this.SECTION==null && other.getSECTION()==null) || 
             (this.SECTION!=null &&
              java.util.Arrays.equals(this.SECTION, other.getSECTION()))) &&
            ((this.TABLEVALUE==null && other.getTABLEVALUE()==null) || 
             (this.TABLEVALUE!=null &&
              java.util.Arrays.equals(this.TABLEVALUE, other.getTABLEVALUE()))) &&
            ((this.filter==null && other.getFilter()==null) || 
             (this.filter!=null &&
              this.filter.equals(other.getFilter())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getALNVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getALNVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getALNVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getASSETATTRID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getASSETATTRID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getASSETATTRID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNUMVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNUMVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNUMVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSECTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSECTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSECTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTABLEVALUE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTABLEVALUE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTABLEVALUE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFilter() != null) {
            _hashCode += getFilter().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRDETQueryTypeSRTICKETSPEC.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRDETQueryType>SR>TICKETSPEC"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("filter");
        attrField.setXmlName(new javax.xml.namespace.QName("", "filter"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ALNVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ALNVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ASSETATTRID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ASSETATTRID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NUMVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NUMVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDoubleQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TABLEVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TABLEVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
