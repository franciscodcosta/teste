/**
 * ITAUWDSRRESUMOLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO;

public class ITAUWDSRRESUMOLocator extends org.apache.axis.client.Service implements com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMO {

    public ITAUWDSRRESUMOLocator() {
    }


    public ITAUWDSRRESUMOLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ITAUWDSRRESUMOLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ITAUWDSRRESUMOSOAP11Port
    private java.lang.String ITAUWDSRRESUMOSOAP11Port_address = "http://gstides.itau/meaweb/services/ITAUWDSRRESUMO";

    public java.lang.String getITAUWDSRRESUMOSOAP11PortAddress() {
        return ITAUWDSRRESUMOSOAP11Port_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ITAUWDSRRESUMOSOAP11PortWSDDServiceName = "ITAUWDSRRESUMOSOAP11Port";

    public java.lang.String getITAUWDSRRESUMOSOAP11PortWSDDServiceName() {
        return ITAUWDSRRESUMOSOAP11PortWSDDServiceName;
    }

    public void setITAUWDSRRESUMOSOAP11PortWSDDServiceName(java.lang.String name) {
        ITAUWDSRRESUMOSOAP11PortWSDDServiceName = name;
    }

    public com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType getITAUWDSRRESUMOSOAP11Port() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ITAUWDSRRESUMOSOAP11Port_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getITAUWDSRRESUMOSOAP11Port(endpoint);
    }

    public com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType getITAUWDSRRESUMOSOAP11Port(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOSOAP11BindingStub _stub = new com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOSOAP11BindingStub(portAddress, this);
            _stub.setPortName(getITAUWDSRRESUMOSOAP11PortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setITAUWDSRRESUMOSOAP11PortEndpointAddress(java.lang.String address) {
        ITAUWDSRRESUMOSOAP11Port_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOPortType.class.isAssignableFrom(serviceEndpointInterface)) {
                com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOSOAP11BindingStub _stub = new com.ibm.www.maximo.wsdl.ITAUWDSRRESUMO.ITAUWDSRRESUMOSOAP11BindingStub(new java.net.URL(ITAUWDSRRESUMOSOAP11Port_address), this);
                _stub.setPortName(getITAUWDSRRESUMOSOAP11PortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ITAUWDSRRESUMOSOAP11Port".equals(inputPortName)) {
            return getITAUWDSRRESUMOSOAP11Port();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://www.ibm.com/maximo/wsdl/ITAUWDSRRESUMO", "ITAUWDSRRESUMO");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://www.ibm.com/maximo/wsdl/ITAUWDSRRESUMO", "ITAUWDSRRESUMOSOAP11Port"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ITAUWDSRRESUMOSOAP11Port".equals(portName)) {
            setITAUWDSRRESUMOSOAP11PortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
