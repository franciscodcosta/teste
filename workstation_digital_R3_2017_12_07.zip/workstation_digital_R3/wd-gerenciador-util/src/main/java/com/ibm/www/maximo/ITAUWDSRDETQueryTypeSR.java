/**
 * ITAUWDSRDETQueryTypeSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRDETQueryTypeSR  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainQueryType[] CLASS;

    private com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID;

    private com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATAAGENDAMENTO;

    private com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDEMAIL;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDPHONE;

    private com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY;

    private com.ibm.www.maximo.MXDomainQueryType[] STATUS;

    private com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] TICKETID;

    private com.ibm.www.maximo.MXLongQueryType[] TICKETUID;

    private com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRWORKLOG WORKLOG;

    private com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRDOCLINKS DOCLINKS;

    private com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRTICKETSPEC TICKETSPEC;

    private com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTURE;

    public ITAUWDSRDETQueryTypeSR() {
    }

    public ITAUWDSRDETQueryTypeSR(
           com.ibm.www.maximo.MXDomainQueryType[] CLASS,
           com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID,
           com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATAAGENDAMENTO,
           com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDEMAIL,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDPHONE,
           com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY,
           com.ibm.www.maximo.MXDomainQueryType[] STATUS,
           com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH,
           com.ibm.www.maximo.MXStringQueryType[] TICKETID,
           com.ibm.www.maximo.MXLongQueryType[] TICKETUID,
           com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRWORKLOG WORKLOG,
           com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRDOCLINKS DOCLINKS,
           com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRTICKETSPEC TICKETSPEC,
           com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTURE) {
           this.CLASS = CLASS;
           this.CLASSIFICATIONID = CLASSIFICATIONID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU_DATAAGENDAMENTO = ITAU_DATAAGENDAMENTO;
           this.REPORTDATE = REPORTDATE;
           this.REPORTEDBY = REPORTEDBY;
           this.REPORTEDEMAIL = REPORTEDEMAIL;
           this.REPORTEDPHONE = REPORTEDPHONE;
           this.REPORTEDPRIORITY = REPORTEDPRIORITY;
           this.STATUS = STATUS;
           this.TARGETFINISH = TARGETFINISH;
           this.TICKETID = TICKETID;
           this.TICKETUID = TICKETUID;
           this.WORKLOG = WORKLOG;
           this.DOCLINKS = DOCLINKS;
           this.TICKETSPEC = TICKETSPEC;
           this.CLASSSTRUCTURE = CLASSSTRUCTURE;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainQueryType[] CLASS) {
        this.CLASS = CLASS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getCLASS(int i) {
        return this.CLASS[i];
    }

    public void setCLASS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.CLASS[i] = _value;
    }


    /**
     * Gets the CLASSIFICATIONID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return CLASSIFICATIONID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSIFICATIONID() {
        return CLASSIFICATIONID;
    }


    /**
     * Sets the CLASSIFICATIONID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param CLASSIFICATIONID
     */
    public void setCLASSIFICATIONID(com.ibm.www.maximo.MXStringQueryType[] CLASSIFICATIONID) {
        this.CLASSIFICATIONID = CLASSIFICATIONID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSIFICATIONID(int i) {
        return this.CLASSIFICATIONID[i];
    }

    public void setCLASSIFICATIONID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSIFICATIONID[i] = _value;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return CLASSSTRUCTUREID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param CLASSSTRUCTUREID
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSSTRUCTUREID(int i) {
        return this.CLASSSTRUCTUREID[i];
    }

    public void setCLASSSTRUCTUREID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSSTRUCTUREID[i] = _value;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the ITAU_DATAAGENDAMENTO value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return ITAU_DATAAGENDAMENTO
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getITAU_DATAAGENDAMENTO() {
        return ITAU_DATAAGENDAMENTO;
    }


    /**
     * Sets the ITAU_DATAAGENDAMENTO value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param ITAU_DATAAGENDAMENTO
     */
    public void setITAU_DATAAGENDAMENTO(com.ibm.www.maximo.MXDateTimeQueryType[] ITAU_DATAAGENDAMENTO) {
        this.ITAU_DATAAGENDAMENTO = ITAU_DATAAGENDAMENTO;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getITAU_DATAAGENDAMENTO(int i) {
        return this.ITAU_DATAAGENDAMENTO[i];
    }

    public void setITAU_DATAAGENDAMENTO(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.ITAU_DATAAGENDAMENTO[i] = _value;
    }


    /**
     * Gets the REPORTDATE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return REPORTDATE
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getREPORTDATE() {
        return REPORTDATE;
    }


    /**
     * Sets the REPORTDATE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param REPORTDATE
     */
    public void setREPORTDATE(com.ibm.www.maximo.MXDateTimeQueryType[] REPORTDATE) {
        this.REPORTDATE = REPORTDATE;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getREPORTDATE(int i) {
        return this.REPORTDATE[i];
    }

    public void setREPORTDATE(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.REPORTDATE[i] = _value;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDBY(int i) {
        return this.REPORTEDBY[i];
    }

    public void setREPORTEDBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDBY[i] = _value;
    }


    /**
     * Gets the REPORTEDEMAIL value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return REPORTEDEMAIL
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDEMAIL() {
        return REPORTEDEMAIL;
    }


    /**
     * Sets the REPORTEDEMAIL value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param REPORTEDEMAIL
     */
    public void setREPORTEDEMAIL(com.ibm.www.maximo.MXStringQueryType[] REPORTEDEMAIL) {
        this.REPORTEDEMAIL = REPORTEDEMAIL;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDEMAIL(int i) {
        return this.REPORTEDEMAIL[i];
    }

    public void setREPORTEDEMAIL(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDEMAIL[i] = _value;
    }


    /**
     * Gets the REPORTEDPHONE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return REPORTEDPHONE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDPHONE() {
        return REPORTEDPHONE;
    }


    /**
     * Sets the REPORTEDPHONE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param REPORTEDPHONE
     */
    public void setREPORTEDPHONE(com.ibm.www.maximo.MXStringQueryType[] REPORTEDPHONE) {
        this.REPORTEDPHONE = REPORTEDPHONE;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDPHONE(int i) {
        return this.REPORTEDPHONE[i];
    }

    public void setREPORTEDPHONE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDPHONE[i] = _value;
    }


    /**
     * Gets the REPORTEDPRIORITY value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return REPORTEDPRIORITY
     */
    public com.ibm.www.maximo.MXLongQueryType[] getREPORTEDPRIORITY() {
        return REPORTEDPRIORITY;
    }


    /**
     * Sets the REPORTEDPRIORITY value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param REPORTEDPRIORITY
     */
    public void setREPORTEDPRIORITY(com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY) {
        this.REPORTEDPRIORITY = REPORTEDPRIORITY;
    }

    public com.ibm.www.maximo.MXLongQueryType getREPORTEDPRIORITY(int i) {
        return this.REPORTEDPRIORITY[i];
    }

    public void setREPORTEDPRIORITY(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.REPORTEDPRIORITY[i] = _value;
    }


    /**
     * Gets the STATUS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainQueryType[] STATUS) {
        this.STATUS = STATUS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getSTATUS(int i) {
        return this.STATUS[i];
    }

    public void setSTATUS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.STATUS[i] = _value;
    }


    /**
     * Gets the TARGETFINISH value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return TARGETFINISH
     */
    public com.ibm.www.maximo.MXDateTimeQueryType[] getTARGETFINISH() {
        return TARGETFINISH;
    }


    /**
     * Sets the TARGETFINISH value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param TARGETFINISH
     */
    public void setTARGETFINISH(com.ibm.www.maximo.MXDateTimeQueryType[] TARGETFINISH) {
        this.TARGETFINISH = TARGETFINISH;
    }

    public com.ibm.www.maximo.MXDateTimeQueryType getTARGETFINISH(int i) {
        return this.TARGETFINISH[i];
    }

    public void setTARGETFINISH(int i, com.ibm.www.maximo.MXDateTimeQueryType _value) {
        this.TARGETFINISH[i] = _value;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
        this.TICKETID = TICKETID;
    }

    public com.ibm.www.maximo.MXStringQueryType getTICKETID(int i) {
        return this.TICKETID[i];
    }

    public void setTICKETID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TICKETID[i] = _value;
    }


    /**
     * Gets the TICKETUID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return TICKETUID
     */
    public com.ibm.www.maximo.MXLongQueryType[] getTICKETUID() {
        return TICKETUID;
    }


    /**
     * Sets the TICKETUID value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param TICKETUID
     */
    public void setTICKETUID(com.ibm.www.maximo.MXLongQueryType[] TICKETUID) {
        this.TICKETUID = TICKETUID;
    }

    public com.ibm.www.maximo.MXLongQueryType getTICKETUID(int i) {
        return this.TICKETUID[i];
    }

    public void setTICKETUID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.TICKETUID[i] = _value;
    }


    /**
     * Gets the WORKLOG value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return WORKLOG
     */
    public com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRWORKLOG getWORKLOG() {
        return WORKLOG;
    }


    /**
     * Sets the WORKLOG value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param WORKLOG
     */
    public void setWORKLOG(com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRWORKLOG WORKLOG) {
        this.WORKLOG = WORKLOG;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRDOCLINKS getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRDOCLINKS DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }


    /**
     * Gets the TICKETSPEC value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return TICKETSPEC
     */
    public com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRTICKETSPEC getTICKETSPEC() {
        return TICKETSPEC;
    }


    /**
     * Sets the TICKETSPEC value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param TICKETSPEC
     */
    public void setTICKETSPEC(com.ibm.www.maximo.ITAUWDSRDETQueryTypeSRTICKETSPEC TICKETSPEC) {
        this.TICKETSPEC = TICKETSPEC;
    }


    /**
     * Gets the CLASSSTRUCTURE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @return CLASSSTRUCTURE
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSSTRUCTURE() {
        return CLASSSTRUCTURE;
    }


    /**
     * Sets the CLASSSTRUCTURE value for this ITAUWDSRDETQueryTypeSR.
     * 
     * @param CLASSSTRUCTURE
     */
    public void setCLASSSTRUCTURE(com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTURE) {
        this.CLASSSTRUCTURE = CLASSSTRUCTURE;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRDETQueryTypeSR)) return false;
        ITAUWDSRDETQueryTypeSR other = (ITAUWDSRDETQueryTypeSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              java.util.Arrays.equals(this.CLASS, other.getCLASS()))) &&
            ((this.CLASSIFICATIONID==null && other.getCLASSIFICATIONID()==null) || 
             (this.CLASSIFICATIONID!=null &&
              java.util.Arrays.equals(this.CLASSIFICATIONID, other.getCLASSIFICATIONID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTUREID, other.getCLASSSTRUCTUREID()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.ITAU_DATAAGENDAMENTO==null && other.getITAU_DATAAGENDAMENTO()==null) || 
             (this.ITAU_DATAAGENDAMENTO!=null &&
              java.util.Arrays.equals(this.ITAU_DATAAGENDAMENTO, other.getITAU_DATAAGENDAMENTO()))) &&
            ((this.REPORTDATE==null && other.getREPORTDATE()==null) || 
             (this.REPORTDATE!=null &&
              java.util.Arrays.equals(this.REPORTDATE, other.getREPORTDATE()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              java.util.Arrays.equals(this.REPORTEDBY, other.getREPORTEDBY()))) &&
            ((this.REPORTEDEMAIL==null && other.getREPORTEDEMAIL()==null) || 
             (this.REPORTEDEMAIL!=null &&
              java.util.Arrays.equals(this.REPORTEDEMAIL, other.getREPORTEDEMAIL()))) &&
            ((this.REPORTEDPHONE==null && other.getREPORTEDPHONE()==null) || 
             (this.REPORTEDPHONE!=null &&
              java.util.Arrays.equals(this.REPORTEDPHONE, other.getREPORTEDPHONE()))) &&
            ((this.REPORTEDPRIORITY==null && other.getREPORTEDPRIORITY()==null) || 
             (this.REPORTEDPRIORITY!=null &&
              java.util.Arrays.equals(this.REPORTEDPRIORITY, other.getREPORTEDPRIORITY()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              java.util.Arrays.equals(this.STATUS, other.getSTATUS()))) &&
            ((this.TARGETFINISH==null && other.getTARGETFINISH()==null) || 
             (this.TARGETFINISH!=null &&
              java.util.Arrays.equals(this.TARGETFINISH, other.getTARGETFINISH()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              java.util.Arrays.equals(this.TICKETID, other.getTICKETID()))) &&
            ((this.TICKETUID==null && other.getTICKETUID()==null) || 
             (this.TICKETUID!=null &&
              java.util.Arrays.equals(this.TICKETUID, other.getTICKETUID()))) &&
            ((this.WORKLOG==null && other.getWORKLOG()==null) || 
             (this.WORKLOG!=null &&
              this.WORKLOG.equals(other.getWORKLOG()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              this.DOCLINKS.equals(other.getDOCLINKS()))) &&
            ((this.TICKETSPEC==null && other.getTICKETSPEC()==null) || 
             (this.TICKETSPEC!=null &&
              this.TICKETSPEC.equals(other.getTICKETSPEC()))) &&
            ((this.CLASSSTRUCTURE==null && other.getCLASSSTRUCTURE()==null) || 
             (this.CLASSSTRUCTURE!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTURE, other.getCLASSSTRUCTURE())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCLASS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSIFICATIONID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSIFICATIONID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSIFICATIONID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSTRUCTUREID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTUREID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTUREID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getITAU_DATAAGENDAMENTO() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getITAU_DATAAGENDAMENTO());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getITAU_DATAAGENDAMENTO(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTDATE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTDATE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTDATE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDEMAIL() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDEMAIL());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDEMAIL(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDPHONE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDPHONE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDPHONE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDPRIORITY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDPRIORITY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDPRIORITY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSTATUS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSTATUS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSTATUS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTARGETFINISH() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTARGETFINISH());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTARGETFINISH(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETUID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETUID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETUID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getWORKLOG() != null) {
            _hashCode += getWORKLOG().hashCode();
        }
        if (getDOCLINKS() != null) {
            _hashCode += getDOCLINKS().hashCode();
        }
        if (getTICKETSPEC() != null) {
            _hashCode += getTICKETSPEC().hashCode();
        }
        if (getCLASSSTRUCTURE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTURE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTURE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRDETQueryTypeSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRDETQueryType>SR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSIFICATIONID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSIFICATIONID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_DATAAGENDAMENTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_DATAAGENDAMENTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDEMAIL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDEMAIL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDPHONE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDPHONE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDPRIORITY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDPRIORITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TARGETFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TARGETFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKLOG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKLOG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRDETQueryType>SR>WORKLOG"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRDETQueryType>SR>DOCLINKS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRDETQueryType>SR>TICKETSPEC"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTURE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTURE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
