/**
 * ITAUWDSR_DOCLINKSType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSR_DOCLINKSType  implements java.io.Serializable {
    private com.ibm.www.maximo.MXBooleanType ADDINFO;

    private com.ibm.www.maximo.MXStringType APP;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType DMSNAME;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType DOCINFOID;

    private com.ibm.www.maximo.MXLongType DOCLINKSID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType DOCTYPE;

    private com.ibm.www.maximo.MXBinaryType DOCUMENTDATA;

    private com.ibm.www.maximo.MXStringType KEYCOLUMN;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType OWNERID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType OWNERTABLE;

    private com.ibm.www.maximo.MXBooleanType SHOW;

    private com.ibm.www.maximo.MXBooleanType UPLOAD;

    private com.ibm.www.maximo.MXStringType URLNAME;

    private com.ibm.www.maximo.MXStringType URLTYPE;

    private com.ibm.www.maximo.MXStringType WEBURL;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDSR_DOCLINKSType() {
    }

    public ITAUWDSR_DOCLINKSType(
           com.ibm.www.maximo.MXBooleanType ADDINFO,
           com.ibm.www.maximo.MXStringType APP,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType DMSNAME,
           com.ibm.www.maximo.MXLongType DOCINFOID,
           com.ibm.www.maximo.MXLongType DOCLINKSID,
           com.ibm.www.maximo.MXStringType DOCTYPE,
           com.ibm.www.maximo.MXBinaryType DOCUMENTDATA,
           com.ibm.www.maximo.MXStringType KEYCOLUMN,
           com.ibm.www.maximo.MXLongType OWNERID,
           com.ibm.www.maximo.MXStringType OWNERTABLE,
           com.ibm.www.maximo.MXBooleanType SHOW,
           com.ibm.www.maximo.MXBooleanType UPLOAD,
           com.ibm.www.maximo.MXStringType URLNAME,
           com.ibm.www.maximo.MXStringType URLTYPE,
           com.ibm.www.maximo.MXStringType WEBURL,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.ADDINFO = ADDINFO;
           this.APP = APP;
           this.DESCRIPTION = DESCRIPTION;
           this.DMSNAME = DMSNAME;
           this.DOCINFOID = DOCINFOID;
           this.DOCLINKSID = DOCLINKSID;
           this.DOCTYPE = DOCTYPE;
           this.DOCUMENTDATA = DOCUMENTDATA;
           this.KEYCOLUMN = KEYCOLUMN;
           this.OWNERID = OWNERID;
           this.OWNERTABLE = OWNERTABLE;
           this.SHOW = SHOW;
           this.UPLOAD = UPLOAD;
           this.URLNAME = URLNAME;
           this.URLTYPE = URLTYPE;
           this.WEBURL = WEBURL;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the ADDINFO value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return ADDINFO
     */
    public com.ibm.www.maximo.MXBooleanType getADDINFO() {
        return ADDINFO;
    }


    /**
     * Sets the ADDINFO value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param ADDINFO
     */
    public void setADDINFO(com.ibm.www.maximo.MXBooleanType ADDINFO) {
        this.ADDINFO = ADDINFO;
    }


    /**
     * Gets the APP value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return APP
     */
    public com.ibm.www.maximo.MXStringType getAPP() {
        return APP;
    }


    /**
     * Sets the APP value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param APP
     */
    public void setAPP(com.ibm.www.maximo.MXStringType APP) {
        this.APP = APP;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the DMSNAME value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DMSNAME
     */
    public com.ibm.www.maximo.MXStringType getDMSNAME() {
        return DMSNAME;
    }


    /**
     * Sets the DMSNAME value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DMSNAME
     */
    public void setDMSNAME(com.ibm.www.maximo.MXStringType DMSNAME) {
        this.DMSNAME = DMSNAME;
    }


    /**
     * Gets the DOCINFOID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DOCINFOID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getDOCINFOID() {
        return DOCINFOID;
    }


    /**
     * Sets the DOCINFOID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DOCINFOID   * Unique Key Component
     */
    public void setDOCINFOID(com.ibm.www.maximo.MXLongType DOCINFOID) {
        this.DOCINFOID = DOCINFOID;
    }


    /**
     * Gets the DOCLINKSID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DOCLINKSID
     */
    public com.ibm.www.maximo.MXLongType getDOCLINKSID() {
        return DOCLINKSID;
    }


    /**
     * Sets the DOCLINKSID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DOCLINKSID
     */
    public void setDOCLINKSID(com.ibm.www.maximo.MXLongType DOCLINKSID) {
        this.DOCLINKSID = DOCLINKSID;
    }


    /**
     * Gets the DOCTYPE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DOCTYPE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getDOCTYPE() {
        return DOCTYPE;
    }


    /**
     * Sets the DOCTYPE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DOCTYPE   * Unique Key Component
     */
    public void setDOCTYPE(com.ibm.www.maximo.MXStringType DOCTYPE) {
        this.DOCTYPE = DOCTYPE;
    }


    /**
     * Gets the DOCUMENTDATA value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DOCUMENTDATA
     */
    public com.ibm.www.maximo.MXBinaryType getDOCUMENTDATA() {
        return DOCUMENTDATA;
    }


    /**
     * Sets the DOCUMENTDATA value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DOCUMENTDATA
     */
    public void setDOCUMENTDATA(com.ibm.www.maximo.MXBinaryType DOCUMENTDATA) {
        this.DOCUMENTDATA = DOCUMENTDATA;
    }


    /**
     * Gets the KEYCOLUMN value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return KEYCOLUMN
     */
    public com.ibm.www.maximo.MXStringType getKEYCOLUMN() {
        return KEYCOLUMN;
    }


    /**
     * Sets the KEYCOLUMN value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param KEYCOLUMN
     */
    public void setKEYCOLUMN(com.ibm.www.maximo.MXStringType KEYCOLUMN) {
        this.KEYCOLUMN = KEYCOLUMN;
    }


    /**
     * Gets the OWNERID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return OWNERID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getOWNERID() {
        return OWNERID;
    }


    /**
     * Sets the OWNERID value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param OWNERID   * Unique Key Component
     */
    public void setOWNERID(com.ibm.www.maximo.MXLongType OWNERID) {
        this.OWNERID = OWNERID;
    }


    /**
     * Gets the OWNERTABLE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return OWNERTABLE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getOWNERTABLE() {
        return OWNERTABLE;
    }


    /**
     * Sets the OWNERTABLE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param OWNERTABLE   * Unique Key Component
     */
    public void setOWNERTABLE(com.ibm.www.maximo.MXStringType OWNERTABLE) {
        this.OWNERTABLE = OWNERTABLE;
    }


    /**
     * Gets the SHOW value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return SHOW
     */
    public com.ibm.www.maximo.MXBooleanType getSHOW() {
        return SHOW;
    }


    /**
     * Sets the SHOW value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param SHOW
     */
    public void setSHOW(com.ibm.www.maximo.MXBooleanType SHOW) {
        this.SHOW = SHOW;
    }


    /**
     * Gets the UPLOAD value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return UPLOAD
     */
    public com.ibm.www.maximo.MXBooleanType getUPLOAD() {
        return UPLOAD;
    }


    /**
     * Sets the UPLOAD value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param UPLOAD
     */
    public void setUPLOAD(com.ibm.www.maximo.MXBooleanType UPLOAD) {
        this.UPLOAD = UPLOAD;
    }


    /**
     * Gets the URLNAME value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return URLNAME
     */
    public com.ibm.www.maximo.MXStringType getURLNAME() {
        return URLNAME;
    }


    /**
     * Sets the URLNAME value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param URLNAME
     */
    public void setURLNAME(com.ibm.www.maximo.MXStringType URLNAME) {
        this.URLNAME = URLNAME;
    }


    /**
     * Gets the URLTYPE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return URLTYPE
     */
    public com.ibm.www.maximo.MXStringType getURLTYPE() {
        return URLTYPE;
    }


    /**
     * Sets the URLTYPE value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param URLTYPE
     */
    public void setURLTYPE(com.ibm.www.maximo.MXStringType URLTYPE) {
        this.URLTYPE = URLTYPE;
    }


    /**
     * Gets the WEBURL value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return WEBURL
     */
    public com.ibm.www.maximo.MXStringType getWEBURL() {
        return WEBURL;
    }


    /**
     * Sets the WEBURL value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param WEBURL
     */
    public void setWEBURL(com.ibm.www.maximo.MXStringType WEBURL) {
        this.WEBURL = WEBURL;
    }


    /**
     * Gets the action value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSR_DOCLINKSType)) return false;
        ITAUWDSR_DOCLINKSType other = (ITAUWDSR_DOCLINKSType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ADDINFO==null && other.getADDINFO()==null) || 
             (this.ADDINFO!=null &&
              this.ADDINFO.equals(other.getADDINFO()))) &&
            ((this.APP==null && other.getAPP()==null) || 
             (this.APP!=null &&
              this.APP.equals(other.getAPP()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.DMSNAME==null && other.getDMSNAME()==null) || 
             (this.DMSNAME!=null &&
              this.DMSNAME.equals(other.getDMSNAME()))) &&
            ((this.DOCINFOID==null && other.getDOCINFOID()==null) || 
             (this.DOCINFOID!=null &&
              this.DOCINFOID.equals(other.getDOCINFOID()))) &&
            ((this.DOCLINKSID==null && other.getDOCLINKSID()==null) || 
             (this.DOCLINKSID!=null &&
              this.DOCLINKSID.equals(other.getDOCLINKSID()))) &&
            ((this.DOCTYPE==null && other.getDOCTYPE()==null) || 
             (this.DOCTYPE!=null &&
              this.DOCTYPE.equals(other.getDOCTYPE()))) &&
            ((this.DOCUMENTDATA==null && other.getDOCUMENTDATA()==null) || 
             (this.DOCUMENTDATA!=null &&
              this.DOCUMENTDATA.equals(other.getDOCUMENTDATA()))) &&
            ((this.KEYCOLUMN==null && other.getKEYCOLUMN()==null) || 
             (this.KEYCOLUMN!=null &&
              this.KEYCOLUMN.equals(other.getKEYCOLUMN()))) &&
            ((this.OWNERID==null && other.getOWNERID()==null) || 
             (this.OWNERID!=null &&
              this.OWNERID.equals(other.getOWNERID()))) &&
            ((this.OWNERTABLE==null && other.getOWNERTABLE()==null) || 
             (this.OWNERTABLE!=null &&
              this.OWNERTABLE.equals(other.getOWNERTABLE()))) &&
            ((this.SHOW==null && other.getSHOW()==null) || 
             (this.SHOW!=null &&
              this.SHOW.equals(other.getSHOW()))) &&
            ((this.UPLOAD==null && other.getUPLOAD()==null) || 
             (this.UPLOAD!=null &&
              this.UPLOAD.equals(other.getUPLOAD()))) &&
            ((this.URLNAME==null && other.getURLNAME()==null) || 
             (this.URLNAME!=null &&
              this.URLNAME.equals(other.getURLNAME()))) &&
            ((this.URLTYPE==null && other.getURLTYPE()==null) || 
             (this.URLTYPE!=null &&
              this.URLTYPE.equals(other.getURLTYPE()))) &&
            ((this.WEBURL==null && other.getWEBURL()==null) || 
             (this.WEBURL!=null &&
              this.WEBURL.equals(other.getWEBURL()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getADDINFO() != null) {
            _hashCode += getADDINFO().hashCode();
        }
        if (getAPP() != null) {
            _hashCode += getAPP().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getDMSNAME() != null) {
            _hashCode += getDMSNAME().hashCode();
        }
        if (getDOCINFOID() != null) {
            _hashCode += getDOCINFOID().hashCode();
        }
        if (getDOCLINKSID() != null) {
            _hashCode += getDOCLINKSID().hashCode();
        }
        if (getDOCTYPE() != null) {
            _hashCode += getDOCTYPE().hashCode();
        }
        if (getDOCUMENTDATA() != null) {
            _hashCode += getDOCUMENTDATA().hashCode();
        }
        if (getKEYCOLUMN() != null) {
            _hashCode += getKEYCOLUMN().hashCode();
        }
        if (getOWNERID() != null) {
            _hashCode += getOWNERID().hashCode();
        }
        if (getOWNERTABLE() != null) {
            _hashCode += getOWNERTABLE().hashCode();
        }
        if (getSHOW() != null) {
            _hashCode += getSHOW().hashCode();
        }
        if (getUPLOAD() != null) {
            _hashCode += getUPLOAD().hashCode();
        }
        if (getURLNAME() != null) {
            _hashCode += getURLNAME().hashCode();
        }
        if (getURLTYPE() != null) {
            _hashCode += getURLTYPE().hashCode();
        }
        if (getWEBURL() != null) {
            _hashCode += getWEBURL().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSR_DOCLINKSType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSR_DOCLINKSType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDINFO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ADDINFO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "APP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DMSNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DMSNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCINFOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCINFOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKSID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKSID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCUMENTDATA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCUMENTDATA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBinaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KEYCOLUMN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "KEYCOLUMN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERTABLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERTABLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOW");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SHOW"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UPLOAD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UPLOAD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WEBURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WEBURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
