/**
 * ITAUWDSR_TICKETSPECType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSR_TICKETSPECType  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringType ALNVALUE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType ASSETATTRID;

    private com.ibm.www.maximo.MXLongType CLASSSPECID;

    private com.ibm.www.maximo.MXDoubleType NUMVALUE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType SECTION;

    private com.ibm.www.maximo.MXStringType TABLEVALUE;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDSR_TICKETSPECType() {
    }

    public ITAUWDSR_TICKETSPECType(
           com.ibm.www.maximo.MXStringType ALNVALUE,
           com.ibm.www.maximo.MXStringType ASSETATTRID,
           com.ibm.www.maximo.MXLongType CLASSSPECID,
           com.ibm.www.maximo.MXDoubleType NUMVALUE,
           com.ibm.www.maximo.MXStringType SECTION,
           com.ibm.www.maximo.MXStringType TABLEVALUE,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.ALNVALUE = ALNVALUE;
           this.ASSETATTRID = ASSETATTRID;
           this.CLASSSPECID = CLASSSPECID;
           this.NUMVALUE = NUMVALUE;
           this.SECTION = SECTION;
           this.TABLEVALUE = TABLEVALUE;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the ALNVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return ALNVALUE
     */
    public com.ibm.www.maximo.MXStringType getALNVALUE() {
        return ALNVALUE;
    }


    /**
     * Sets the ALNVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param ALNVALUE
     */
    public void setALNVALUE(com.ibm.www.maximo.MXStringType ALNVALUE) {
        this.ALNVALUE = ALNVALUE;
    }


    /**
     * Gets the ASSETATTRID value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return ASSETATTRID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getASSETATTRID() {
        return ASSETATTRID;
    }


    /**
     * Sets the ASSETATTRID value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param ASSETATTRID   * Unique Key Component
     */
    public void setASSETATTRID(com.ibm.www.maximo.MXStringType ASSETATTRID) {
        this.ASSETATTRID = ASSETATTRID;
    }


    /**
     * Gets the CLASSSPECID value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return CLASSSPECID
     */
    public com.ibm.www.maximo.MXLongType getCLASSSPECID() {
        return CLASSSPECID;
    }


    /**
     * Sets the CLASSSPECID value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param CLASSSPECID
     */
    public void setCLASSSPECID(com.ibm.www.maximo.MXLongType CLASSSPECID) {
        this.CLASSSPECID = CLASSSPECID;
    }


    /**
     * Gets the NUMVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return NUMVALUE
     */
    public com.ibm.www.maximo.MXDoubleType getNUMVALUE() {
        return NUMVALUE;
    }


    /**
     * Sets the NUMVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param NUMVALUE
     */
    public void setNUMVALUE(com.ibm.www.maximo.MXDoubleType NUMVALUE) {
        this.NUMVALUE = NUMVALUE;
    }


    /**
     * Gets the SECTION value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return SECTION   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getSECTION() {
        return SECTION;
    }


    /**
     * Sets the SECTION value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param SECTION   * Unique Key Component
     */
    public void setSECTION(com.ibm.www.maximo.MXStringType SECTION) {
        this.SECTION = SECTION;
    }


    /**
     * Gets the TABLEVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return TABLEVALUE
     */
    public com.ibm.www.maximo.MXStringType getTABLEVALUE() {
        return TABLEVALUE;
    }


    /**
     * Sets the TABLEVALUE value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param TABLEVALUE
     */
    public void setTABLEVALUE(com.ibm.www.maximo.MXStringType TABLEVALUE) {
        this.TABLEVALUE = TABLEVALUE;
    }


    /**
     * Gets the action value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSR_TICKETSPECType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSR_TICKETSPECType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSR_TICKETSPECType)) return false;
        ITAUWDSR_TICKETSPECType other = (ITAUWDSR_TICKETSPECType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ALNVALUE==null && other.getALNVALUE()==null) || 
             (this.ALNVALUE!=null &&
              this.ALNVALUE.equals(other.getALNVALUE()))) &&
            ((this.ASSETATTRID==null && other.getASSETATTRID()==null) || 
             (this.ASSETATTRID!=null &&
              this.ASSETATTRID.equals(other.getASSETATTRID()))) &&
            ((this.CLASSSPECID==null && other.getCLASSSPECID()==null) || 
             (this.CLASSSPECID!=null &&
              this.CLASSSPECID.equals(other.getCLASSSPECID()))) &&
            ((this.NUMVALUE==null && other.getNUMVALUE()==null) || 
             (this.NUMVALUE!=null &&
              this.NUMVALUE.equals(other.getNUMVALUE()))) &&
            ((this.SECTION==null && other.getSECTION()==null) || 
             (this.SECTION!=null &&
              this.SECTION.equals(other.getSECTION()))) &&
            ((this.TABLEVALUE==null && other.getTABLEVALUE()==null) || 
             (this.TABLEVALUE!=null &&
              this.TABLEVALUE.equals(other.getTABLEVALUE()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getALNVALUE() != null) {
            _hashCode += getALNVALUE().hashCode();
        }
        if (getASSETATTRID() != null) {
            _hashCode += getASSETATTRID().hashCode();
        }
        if (getCLASSSPECID() != null) {
            _hashCode += getCLASSSPECID().hashCode();
        }
        if (getNUMVALUE() != null) {
            _hashCode += getNUMVALUE().hashCode();
        }
        if (getSECTION() != null) {
            _hashCode += getSECTION().hashCode();
        }
        if (getTABLEVALUE() != null) {
            _hashCode += getTABLEVALUE().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSR_TICKETSPECType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSR_TICKETSPECType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ALNVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ALNVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ASSETATTRID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ASSETATTRID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSPECID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSPECID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NUMVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NUMVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDoubleType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SECTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SECTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TABLEVALUE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TABLEVALUE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
