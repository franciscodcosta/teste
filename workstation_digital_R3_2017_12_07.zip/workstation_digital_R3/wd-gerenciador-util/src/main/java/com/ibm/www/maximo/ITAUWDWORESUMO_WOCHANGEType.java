/**
 * ITAUWDWORESUMO_WOCHANGEType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDWORESUMO_WOCHANGEType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType ITAU_CALENDSIG_STATUS;

    private com.ibm.www.maximo.MXDateTimeType ITAU_DATA_QUALID;

    private com.ibm.www.maximo.MXStringType ITAU_PARECER_QUALID;

    private com.ibm.www.maximo.MXStringType ITAU_RESP_QUALID;

    private com.ibm.www.maximo.MXStringType REPORTEDBY;

    private com.ibm.www.maximo.MXStringType REPORTEDBYNAME;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType SITEID;

    private com.ibm.www.maximo.MXDomainType STATUS;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType WONUM;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDWORESUMO_WOCHANGEType() {
    }

    public ITAUWDWORESUMO_WOCHANGEType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType ITAU_CALENDSIG_STATUS,
           com.ibm.www.maximo.MXDateTimeType ITAU_DATA_QUALID,
           com.ibm.www.maximo.MXStringType ITAU_PARECER_QUALID,
           com.ibm.www.maximo.MXStringType ITAU_RESP_QUALID,
           com.ibm.www.maximo.MXStringType REPORTEDBY,
           com.ibm.www.maximo.MXStringType REPORTEDBYNAME,
           com.ibm.www.maximo.MXStringType SITEID,
           com.ibm.www.maximo.MXDomainType STATUS,
           com.ibm.www.maximo.MXStringType WONUM,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.DESCRIPTION = DESCRIPTION;
           this.ITAU_CALENDSIG_STATUS = ITAU_CALENDSIG_STATUS;
           this.ITAU_DATA_QUALID = ITAU_DATA_QUALID;
           this.ITAU_PARECER_QUALID = ITAU_PARECER_QUALID;
           this.ITAU_RESP_QUALID = ITAU_RESP_QUALID;
           this.REPORTEDBY = REPORTEDBY;
           this.REPORTEDBYNAME = REPORTEDBYNAME;
           this.SITEID = SITEID;
           this.STATUS = STATUS;
           this.WONUM = WONUM;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return DESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param DESCRIPTION
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the ITAU_CALENDSIG_STATUS value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return ITAU_CALENDSIG_STATUS
     */
    public com.ibm.www.maximo.MXStringType getITAU_CALENDSIG_STATUS() {
        return ITAU_CALENDSIG_STATUS;
    }


    /**
     * Sets the ITAU_CALENDSIG_STATUS value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param ITAU_CALENDSIG_STATUS
     */
    public void setITAU_CALENDSIG_STATUS(com.ibm.www.maximo.MXStringType ITAU_CALENDSIG_STATUS) {
        this.ITAU_CALENDSIG_STATUS = ITAU_CALENDSIG_STATUS;
    }


    /**
     * Gets the ITAU_DATA_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return ITAU_DATA_QUALID
     */
    public com.ibm.www.maximo.MXDateTimeType getITAU_DATA_QUALID() {
        return ITAU_DATA_QUALID;
    }


    /**
     * Sets the ITAU_DATA_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param ITAU_DATA_QUALID
     */
    public void setITAU_DATA_QUALID(com.ibm.www.maximo.MXDateTimeType ITAU_DATA_QUALID) {
        this.ITAU_DATA_QUALID = ITAU_DATA_QUALID;
    }


    /**
     * Gets the ITAU_PARECER_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return ITAU_PARECER_QUALID
     */
    public com.ibm.www.maximo.MXStringType getITAU_PARECER_QUALID() {
        return ITAU_PARECER_QUALID;
    }


    /**
     * Sets the ITAU_PARECER_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param ITAU_PARECER_QUALID
     */
    public void setITAU_PARECER_QUALID(com.ibm.www.maximo.MXStringType ITAU_PARECER_QUALID) {
        this.ITAU_PARECER_QUALID = ITAU_PARECER_QUALID;
    }


    /**
     * Gets the ITAU_RESP_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return ITAU_RESP_QUALID
     */
    public com.ibm.www.maximo.MXStringType getITAU_RESP_QUALID() {
        return ITAU_RESP_QUALID;
    }


    /**
     * Sets the ITAU_RESP_QUALID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param ITAU_RESP_QUALID
     */
    public void setITAU_RESP_QUALID(com.ibm.www.maximo.MXStringType ITAU_RESP_QUALID) {
        this.ITAU_RESP_QUALID = ITAU_RESP_QUALID;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringType REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }


    /**
     * Gets the REPORTEDBYNAME value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return REPORTEDBYNAME
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBYNAME() {
        return REPORTEDBYNAME;
    }


    /**
     * Sets the REPORTEDBYNAME value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param REPORTEDBYNAME
     */
    public void setREPORTEDBYNAME(com.ibm.www.maximo.MXStringType REPORTEDBYNAME) {
        this.REPORTEDBYNAME = REPORTEDBYNAME;
    }


    /**
     * Gets the SITEID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return SITEID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getSITEID() {
        return SITEID;
    }


    /**
     * Sets the SITEID value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param SITEID   * Unique Key Component
     */
    public void setSITEID(com.ibm.www.maximo.MXStringType SITEID) {
        this.SITEID = SITEID;
    }


    /**
     * Gets the STATUS value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainType getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainType STATUS) {
        this.STATUS = STATUS;
    }


    /**
     * Gets the WONUM value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return WONUM   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getWONUM() {
        return WONUM;
    }


    /**
     * Sets the WONUM value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param WONUM   * Unique Key Component
     */
    public void setWONUM(com.ibm.www.maximo.MXStringType WONUM) {
        this.WONUM = WONUM;
    }


    /**
     * Gets the action value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDWORESUMO_WOCHANGEType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDWORESUMO_WOCHANGEType)) return false;
        ITAUWDWORESUMO_WOCHANGEType other = (ITAUWDWORESUMO_WOCHANGEType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.ITAU_CALENDSIG_STATUS==null && other.getITAU_CALENDSIG_STATUS()==null) || 
             (this.ITAU_CALENDSIG_STATUS!=null &&
              this.ITAU_CALENDSIG_STATUS.equals(other.getITAU_CALENDSIG_STATUS()))) &&
            ((this.ITAU_DATA_QUALID==null && other.getITAU_DATA_QUALID()==null) || 
             (this.ITAU_DATA_QUALID!=null &&
              this.ITAU_DATA_QUALID.equals(other.getITAU_DATA_QUALID()))) &&
            ((this.ITAU_PARECER_QUALID==null && other.getITAU_PARECER_QUALID()==null) || 
             (this.ITAU_PARECER_QUALID!=null &&
              this.ITAU_PARECER_QUALID.equals(other.getITAU_PARECER_QUALID()))) &&
            ((this.ITAU_RESP_QUALID==null && other.getITAU_RESP_QUALID()==null) || 
             (this.ITAU_RESP_QUALID!=null &&
              this.ITAU_RESP_QUALID.equals(other.getITAU_RESP_QUALID()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              this.REPORTEDBY.equals(other.getREPORTEDBY()))) &&
            ((this.REPORTEDBYNAME==null && other.getREPORTEDBYNAME()==null) || 
             (this.REPORTEDBYNAME!=null &&
              this.REPORTEDBYNAME.equals(other.getREPORTEDBYNAME()))) &&
            ((this.SITEID==null && other.getSITEID()==null) || 
             (this.SITEID!=null &&
              this.SITEID.equals(other.getSITEID()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS()))) &&
            ((this.WONUM==null && other.getWONUM()==null) || 
             (this.WONUM!=null &&
              this.WONUM.equals(other.getWONUM()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getITAU_CALENDSIG_STATUS() != null) {
            _hashCode += getITAU_CALENDSIG_STATUS().hashCode();
        }
        if (getITAU_DATA_QUALID() != null) {
            _hashCode += getITAU_DATA_QUALID().hashCode();
        }
        if (getITAU_PARECER_QUALID() != null) {
            _hashCode += getITAU_PARECER_QUALID().hashCode();
        }
        if (getITAU_RESP_QUALID() != null) {
            _hashCode += getITAU_RESP_QUALID().hashCode();
        }
        if (getREPORTEDBY() != null) {
            _hashCode += getREPORTEDBY().hashCode();
        }
        if (getREPORTEDBYNAME() != null) {
            _hashCode += getREPORTEDBYNAME().hashCode();
        }
        if (getSITEID() != null) {
            _hashCode += getSITEID().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        if (getWONUM() != null) {
            _hashCode += getWONUM().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDWORESUMO_WOCHANGEType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDWORESUMO_WOCHANGEType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_CALENDSIG_STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_CALENDSIG_STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_DATA_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_DATA_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_PARECER_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_PARECER_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_RESP_QUALID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_RESP_QUALID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBYNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBYNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SITEID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SITEID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WONUM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WONUM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
