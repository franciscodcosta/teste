package com.ibm.www.maximo.wsdl.ITAUWDCLASS;

public class ITAUWDCLASSPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSPortType iTAUWDCLASSPortType = null;
  
  public ITAUWDCLASSPortTypeProxy() {
    _initITAUWDCLASSPortTypeProxy();
  }
  
  public ITAUWDCLASSPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDCLASSPortTypeProxy();
  }
  
  private void _initITAUWDCLASSPortTypeProxy() {
    try {
      iTAUWDCLASSPortType = (new com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSLocator()).getITAUWDCLASSSOAP11Port();
      if (iTAUWDCLASSPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDCLASSPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDCLASSPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDCLASSPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDCLASSPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDCLASS.ITAUWDCLASSPortType getITAUWDCLASSPortType() {
    if (iTAUWDCLASSPortType == null)
      _initITAUWDCLASSPortTypeProxy();
    return iTAUWDCLASSPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDCLASSResponseType queryITAUWDCLASS(com.ibm.www.maximo.QueryITAUWDCLASSType parameters) throws java.rmi.RemoteException{
    if (iTAUWDCLASSPortType == null)
      _initITAUWDCLASSPortTypeProxy();
    return iTAUWDCLASSPortType.queryITAUWDCLASS(parameters);
  }
  
  
}