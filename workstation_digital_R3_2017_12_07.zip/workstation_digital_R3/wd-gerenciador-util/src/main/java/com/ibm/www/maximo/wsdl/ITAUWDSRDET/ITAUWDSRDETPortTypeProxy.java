package com.ibm.www.maximo.wsdl.ITAUWDSRDET;

public class ITAUWDSRDETPortTypeProxy implements com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETPortType {
  private String _endpoint = null;
  private com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETPortType iTAUWDSRDETPortType = null;
  
  public ITAUWDSRDETPortTypeProxy() {
    _initITAUWDSRDETPortTypeProxy();
  }
  
  public ITAUWDSRDETPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initITAUWDSRDETPortTypeProxy();
  }
  
  private void _initITAUWDSRDETPortTypeProxy() {
    try {
      iTAUWDSRDETPortType = (new com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETLocator()).getITAUWDSRDETSOAP11Port();
      if (iTAUWDSRDETPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)iTAUWDSRDETPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)iTAUWDSRDETPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (iTAUWDSRDETPortType != null)
      ((javax.xml.rpc.Stub)iTAUWDSRDETPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.ibm.www.maximo.wsdl.ITAUWDSRDET.ITAUWDSRDETPortType getITAUWDSRDETPortType() {
    if (iTAUWDSRDETPortType == null)
      _initITAUWDSRDETPortTypeProxy();
    return iTAUWDSRDETPortType;
  }
  
  public com.ibm.www.maximo.QueryITAUWDSRDETResponseType queryITAUWDSRDET(com.ibm.www.maximo.QueryITAUWDSRDETType parameters) throws java.rmi.RemoteException{
    if (iTAUWDSRDETPortType == null)
      _initITAUWDSRDETPortTypeProxy();
    return iTAUWDSRDETPortType.queryITAUWDSRDET(parameters);
  }
  
  
}