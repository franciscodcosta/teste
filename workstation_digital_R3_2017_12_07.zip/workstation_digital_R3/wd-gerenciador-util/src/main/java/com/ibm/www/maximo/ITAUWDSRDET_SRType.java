/**
 * ITAUWDSRDET_SRType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRDET_SRType  implements java.io.Serializable {
    private java.lang.String MAXINTERRORMSG;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainType CLASS;

    private com.ibm.www.maximo.MXStringType CLASSIFICATIONID;

    private com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringType DESCRIPTION;

    private com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION;

    private com.ibm.www.maximo.MXStringType FR2CODE_LONGDESCRIPTION;

    private com.ibm.www.maximo.MXDateTimeType ITAU_DATAAGENDAMENTO;

    private com.ibm.www.maximo.MXDateTimeType REPORTDATE;

    private com.ibm.www.maximo.MXStringType REPORTEDBY;

    private com.ibm.www.maximo.MXStringType REPORTEDBYID;

    private com.ibm.www.maximo.MXStringType REPORTEDBYNAME;

    private com.ibm.www.maximo.MXStringType REPORTEDEMAIL;

    private com.ibm.www.maximo.MXStringType REPORTEDPHONE;

    private com.ibm.www.maximo.MXLongType REPORTEDPRIORITY;

    private com.ibm.www.maximo.MXDomainType STATUS;

    private com.ibm.www.maximo.MXDateTimeType TARGETFINISH;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType TICKETID;

    private com.ibm.www.maximo.MXLongType TICKETUID;

    private com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType[] WORKLOG;

    private com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType[] DOCLINKS;

    private com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType[] TICKETSPEC;

    private com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType[] CLASSSTRUCTURE;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    private java.lang.String transLanguage;  // attribute

    public ITAUWDSRDET_SRType() {
    }

    public ITAUWDSRDET_SRType(
           java.lang.String MAXINTERRORMSG,
           com.ibm.www.maximo.MXDomainType CLASS,
           com.ibm.www.maximo.MXStringType CLASSIFICATIONID,
           com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringType DESCRIPTION,
           com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION,
           com.ibm.www.maximo.MXStringType FR2CODE_LONGDESCRIPTION,
           com.ibm.www.maximo.MXDateTimeType ITAU_DATAAGENDAMENTO,
           com.ibm.www.maximo.MXDateTimeType REPORTDATE,
           com.ibm.www.maximo.MXStringType REPORTEDBY,
           com.ibm.www.maximo.MXStringType REPORTEDBYID,
           com.ibm.www.maximo.MXStringType REPORTEDBYNAME,
           com.ibm.www.maximo.MXStringType REPORTEDEMAIL,
           com.ibm.www.maximo.MXStringType REPORTEDPHONE,
           com.ibm.www.maximo.MXLongType REPORTEDPRIORITY,
           com.ibm.www.maximo.MXDomainType STATUS,
           com.ibm.www.maximo.MXDateTimeType TARGETFINISH,
           com.ibm.www.maximo.MXStringType TICKETID,
           com.ibm.www.maximo.MXLongType TICKETUID,
           com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType[] WORKLOG,
           com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType[] DOCLINKS,
           com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType[] TICKETSPEC,
           com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType[] CLASSSTRUCTURE,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert,
           java.lang.String transLanguage) {
           this.MAXINTERRORMSG = MAXINTERRORMSG;
           this.CLASS = CLASS;
           this.CLASSIFICATIONID = CLASSIFICATIONID;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DESCRIPTION = DESCRIPTION;
           this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
           this.FR2CODE_LONGDESCRIPTION = FR2CODE_LONGDESCRIPTION;
           this.ITAU_DATAAGENDAMENTO = ITAU_DATAAGENDAMENTO;
           this.REPORTDATE = REPORTDATE;
           this.REPORTEDBY = REPORTEDBY;
           this.REPORTEDBYID = REPORTEDBYID;
           this.REPORTEDBYNAME = REPORTEDBYNAME;
           this.REPORTEDEMAIL = REPORTEDEMAIL;
           this.REPORTEDPHONE = REPORTEDPHONE;
           this.REPORTEDPRIORITY = REPORTEDPRIORITY;
           this.STATUS = STATUS;
           this.TARGETFINISH = TARGETFINISH;
           this.TICKETID = TICKETID;
           this.TICKETUID = TICKETUID;
           this.WORKLOG = WORKLOG;
           this.DOCLINKS = DOCLINKS;
           this.TICKETSPEC = TICKETSPEC;
           this.CLASSSTRUCTURE = CLASSSTRUCTURE;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
           this.transLanguage = transLanguage;
    }


    /**
     * Gets the MAXINTERRORMSG value for this ITAUWDSRDET_SRType.
     * 
     * @return MAXINTERRORMSG
     */
    public java.lang.String getMAXINTERRORMSG() {
        return MAXINTERRORMSG;
    }


    /**
     * Sets the MAXINTERRORMSG value for this ITAUWDSRDET_SRType.
     * 
     * @param MAXINTERRORMSG
     */
    public void setMAXINTERRORMSG(java.lang.String MAXINTERRORMSG) {
        this.MAXINTERRORMSG = MAXINTERRORMSG;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRDET_SRType.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainType getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRDET_SRType.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainType CLASS) {
        this.CLASS = CLASS;
    }


    /**
     * Gets the CLASSIFICATIONID value for this ITAUWDSRDET_SRType.
     * 
     * @return CLASSIFICATIONID
     */
    public com.ibm.www.maximo.MXStringType getCLASSIFICATIONID() {
        return CLASSIFICATIONID;
    }


    /**
     * Sets the CLASSIFICATIONID value for this ITAUWDSRDET_SRType.
     * 
     * @param CLASSIFICATIONID
     */
    public void setCLASSIFICATIONID(com.ibm.www.maximo.MXStringType CLASSIFICATIONID) {
        this.CLASSIFICATIONID = CLASSIFICATIONID;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDSRDET_SRType.
     * 
     * @return CLASSSTRUCTUREID
     */
    public com.ibm.www.maximo.MXStringType getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDSRDET_SRType.
     * 
     * @param CLASSSTRUCTUREID
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringType CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }


    /**
     * Gets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @return DESCRIPTION_LONGDESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getDESCRIPTION_LONGDESCRIPTION() {
        return DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION_LONGDESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @param DESCRIPTION_LONGDESCRIPTION
     */
    public void setDESCRIPTION_LONGDESCRIPTION(com.ibm.www.maximo.MXStringType DESCRIPTION_LONGDESCRIPTION) {
        this.DESCRIPTION_LONGDESCRIPTION = DESCRIPTION_LONGDESCRIPTION;
    }


    /**
     * Gets the FR2CODE_LONGDESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @return FR2CODE_LONGDESCRIPTION
     */
    public com.ibm.www.maximo.MXStringType getFR2CODE_LONGDESCRIPTION() {
        return FR2CODE_LONGDESCRIPTION;
    }


    /**
     * Sets the FR2CODE_LONGDESCRIPTION value for this ITAUWDSRDET_SRType.
     * 
     * @param FR2CODE_LONGDESCRIPTION
     */
    public void setFR2CODE_LONGDESCRIPTION(com.ibm.www.maximo.MXStringType FR2CODE_LONGDESCRIPTION) {
        this.FR2CODE_LONGDESCRIPTION = FR2CODE_LONGDESCRIPTION;
    }


    /**
     * Gets the ITAU_DATAAGENDAMENTO value for this ITAUWDSRDET_SRType.
     * 
     * @return ITAU_DATAAGENDAMENTO
     */
    public com.ibm.www.maximo.MXDateTimeType getITAU_DATAAGENDAMENTO() {
        return ITAU_DATAAGENDAMENTO;
    }


    /**
     * Sets the ITAU_DATAAGENDAMENTO value for this ITAUWDSRDET_SRType.
     * 
     * @param ITAU_DATAAGENDAMENTO
     */
    public void setITAU_DATAAGENDAMENTO(com.ibm.www.maximo.MXDateTimeType ITAU_DATAAGENDAMENTO) {
        this.ITAU_DATAAGENDAMENTO = ITAU_DATAAGENDAMENTO;
    }


    /**
     * Gets the REPORTDATE value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getREPORTDATE() {
        return REPORTDATE;
    }


    /**
     * Sets the REPORTDATE value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTDATE
     */
    public void setREPORTDATE(com.ibm.www.maximo.MXDateTimeType REPORTDATE) {
        this.REPORTDATE = REPORTDATE;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringType REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }


    /**
     * Gets the REPORTEDBYID value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDBYID
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBYID() {
        return REPORTEDBYID;
    }


    /**
     * Sets the REPORTEDBYID value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDBYID
     */
    public void setREPORTEDBYID(com.ibm.www.maximo.MXStringType REPORTEDBYID) {
        this.REPORTEDBYID = REPORTEDBYID;
    }


    /**
     * Gets the REPORTEDBYNAME value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDBYNAME
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDBYNAME() {
        return REPORTEDBYNAME;
    }


    /**
     * Sets the REPORTEDBYNAME value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDBYNAME
     */
    public void setREPORTEDBYNAME(com.ibm.www.maximo.MXStringType REPORTEDBYNAME) {
        this.REPORTEDBYNAME = REPORTEDBYNAME;
    }


    /**
     * Gets the REPORTEDEMAIL value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDEMAIL
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDEMAIL() {
        return REPORTEDEMAIL;
    }


    /**
     * Sets the REPORTEDEMAIL value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDEMAIL
     */
    public void setREPORTEDEMAIL(com.ibm.www.maximo.MXStringType REPORTEDEMAIL) {
        this.REPORTEDEMAIL = REPORTEDEMAIL;
    }


    /**
     * Gets the REPORTEDPHONE value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDPHONE
     */
    public com.ibm.www.maximo.MXStringType getREPORTEDPHONE() {
        return REPORTEDPHONE;
    }


    /**
     * Sets the REPORTEDPHONE value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDPHONE
     */
    public void setREPORTEDPHONE(com.ibm.www.maximo.MXStringType REPORTEDPHONE) {
        this.REPORTEDPHONE = REPORTEDPHONE;
    }


    /**
     * Gets the REPORTEDPRIORITY value for this ITAUWDSRDET_SRType.
     * 
     * @return REPORTEDPRIORITY
     */
    public com.ibm.www.maximo.MXLongType getREPORTEDPRIORITY() {
        return REPORTEDPRIORITY;
    }


    /**
     * Sets the REPORTEDPRIORITY value for this ITAUWDSRDET_SRType.
     * 
     * @param REPORTEDPRIORITY
     */
    public void setREPORTEDPRIORITY(com.ibm.www.maximo.MXLongType REPORTEDPRIORITY) {
        this.REPORTEDPRIORITY = REPORTEDPRIORITY;
    }


    /**
     * Gets the STATUS value for this ITAUWDSRDET_SRType.
     * 
     * @return STATUS
     */
    public com.ibm.www.maximo.MXDomainType getSTATUS() {
        return STATUS;
    }


    /**
     * Sets the STATUS value for this ITAUWDSRDET_SRType.
     * 
     * @param STATUS
     */
    public void setSTATUS(com.ibm.www.maximo.MXDomainType STATUS) {
        this.STATUS = STATUS;
    }


    /**
     * Gets the TARGETFINISH value for this ITAUWDSRDET_SRType.
     * 
     * @return TARGETFINISH
     */
    public com.ibm.www.maximo.MXDateTimeType getTARGETFINISH() {
        return TARGETFINISH;
    }


    /**
     * Sets the TARGETFINISH value for this ITAUWDSRDET_SRType.
     * 
     * @param TARGETFINISH
     */
    public void setTARGETFINISH(com.ibm.www.maximo.MXDateTimeType TARGETFINISH) {
        this.TARGETFINISH = TARGETFINISH;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRDET_SRType.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRDET_SRType.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringType TICKETID) {
        this.TICKETID = TICKETID;
    }


    /**
     * Gets the TICKETUID value for this ITAUWDSRDET_SRType.
     * 
     * @return TICKETUID
     */
    public com.ibm.www.maximo.MXLongType getTICKETUID() {
        return TICKETUID;
    }


    /**
     * Sets the TICKETUID value for this ITAUWDSRDET_SRType.
     * 
     * @param TICKETUID
     */
    public void setTICKETUID(com.ibm.www.maximo.MXLongType TICKETUID) {
        this.TICKETUID = TICKETUID;
    }


    /**
     * Gets the WORKLOG value for this ITAUWDSRDET_SRType.
     * 
     * @return WORKLOG
     */
    public com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType[] getWORKLOG() {
        return WORKLOG;
    }


    /**
     * Sets the WORKLOG value for this ITAUWDSRDET_SRType.
     * 
     * @param WORKLOG
     */
    public void setWORKLOG(com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType[] WORKLOG) {
        this.WORKLOG = WORKLOG;
    }

    public com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType getWORKLOG(int i) {
        return this.WORKLOG[i];
    }

    public void setWORKLOG(int i, com.ibm.www.maximo.ITAUWDSRDET_WORKLOGType _value) {
        this.WORKLOG[i] = _value;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDSRDET_SRType.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType[] getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDSRDET_SRType.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType[] DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }

    public com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType getDOCLINKS(int i) {
        return this.DOCLINKS[i];
    }

    public void setDOCLINKS(int i, com.ibm.www.maximo.ITAUWDSRDET_DOCLINKSType _value) {
        this.DOCLINKS[i] = _value;
    }


    /**
     * Gets the TICKETSPEC value for this ITAUWDSRDET_SRType.
     * 
     * @return TICKETSPEC
     */
    public com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType[] getTICKETSPEC() {
        return TICKETSPEC;
    }


    /**
     * Sets the TICKETSPEC value for this ITAUWDSRDET_SRType.
     * 
     * @param TICKETSPEC
     */
    public void setTICKETSPEC(com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType[] TICKETSPEC) {
        this.TICKETSPEC = TICKETSPEC;
    }

    public com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType getTICKETSPEC(int i) {
        return this.TICKETSPEC[i];
    }

    public void setTICKETSPEC(int i, com.ibm.www.maximo.ITAUWDSRDET_TICKETSPECType _value) {
        this.TICKETSPEC[i] = _value;
    }


    /**
     * Gets the CLASSSTRUCTURE value for this ITAUWDSRDET_SRType.
     * 
     * @return CLASSSTRUCTURE
     */
    public com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType[] getCLASSSTRUCTURE() {
        return CLASSSTRUCTURE;
    }


    /**
     * Sets the CLASSSTRUCTURE value for this ITAUWDSRDET_SRType.
     * 
     * @param CLASSSTRUCTURE
     */
    public void setCLASSSTRUCTURE(com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType[] CLASSSTRUCTURE) {
        this.CLASSSTRUCTURE = CLASSSTRUCTURE;
    }

    public com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType getCLASSSTRUCTURE(int i) {
        return this.CLASSSTRUCTURE[i];
    }

    public void setCLASSSTRUCTURE(int i, com.ibm.www.maximo.ITAUWDSRDET_CLASSSTRUCTUREType _value) {
        this.CLASSSTRUCTURE[i] = _value;
    }


    /**
     * Gets the action value for this ITAUWDSRDET_SRType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSRDET_SRType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSRDET_SRType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSRDET_SRType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSRDET_SRType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSRDET_SRType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the transLanguage value for this ITAUWDSRDET_SRType.
     * 
     * @return transLanguage
     */
    public java.lang.String getTransLanguage() {
        return transLanguage;
    }


    /**
     * Sets the transLanguage value for this ITAUWDSRDET_SRType.
     * 
     * @param transLanguage
     */
    public void setTransLanguage(java.lang.String transLanguage) {
        this.transLanguage = transLanguage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRDET_SRType)) return false;
        ITAUWDSRDET_SRType other = (ITAUWDSRDET_SRType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.MAXINTERRORMSG==null && other.getMAXINTERRORMSG()==null) || 
             (this.MAXINTERRORMSG!=null &&
              this.MAXINTERRORMSG.equals(other.getMAXINTERRORMSG()))) &&
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              this.CLASS.equals(other.getCLASS()))) &&
            ((this.CLASSIFICATIONID==null && other.getCLASSIFICATIONID()==null) || 
             (this.CLASSIFICATIONID!=null &&
              this.CLASSIFICATIONID.equals(other.getCLASSIFICATIONID()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              this.CLASSSTRUCTUREID.equals(other.getCLASSSTRUCTUREID()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              this.DESCRIPTION.equals(other.getDESCRIPTION()))) &&
            ((this.DESCRIPTION_LONGDESCRIPTION==null && other.getDESCRIPTION_LONGDESCRIPTION()==null) || 
             (this.DESCRIPTION_LONGDESCRIPTION!=null &&
              this.DESCRIPTION_LONGDESCRIPTION.equals(other.getDESCRIPTION_LONGDESCRIPTION()))) &&
            ((this.FR2CODE_LONGDESCRIPTION==null && other.getFR2CODE_LONGDESCRIPTION()==null) || 
             (this.FR2CODE_LONGDESCRIPTION!=null &&
              this.FR2CODE_LONGDESCRIPTION.equals(other.getFR2CODE_LONGDESCRIPTION()))) &&
            ((this.ITAU_DATAAGENDAMENTO==null && other.getITAU_DATAAGENDAMENTO()==null) || 
             (this.ITAU_DATAAGENDAMENTO!=null &&
              this.ITAU_DATAAGENDAMENTO.equals(other.getITAU_DATAAGENDAMENTO()))) &&
            ((this.REPORTDATE==null && other.getREPORTDATE()==null) || 
             (this.REPORTDATE!=null &&
              this.REPORTDATE.equals(other.getREPORTDATE()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              this.REPORTEDBY.equals(other.getREPORTEDBY()))) &&
            ((this.REPORTEDBYID==null && other.getREPORTEDBYID()==null) || 
             (this.REPORTEDBYID!=null &&
              this.REPORTEDBYID.equals(other.getREPORTEDBYID()))) &&
            ((this.REPORTEDBYNAME==null && other.getREPORTEDBYNAME()==null) || 
             (this.REPORTEDBYNAME!=null &&
              this.REPORTEDBYNAME.equals(other.getREPORTEDBYNAME()))) &&
            ((this.REPORTEDEMAIL==null && other.getREPORTEDEMAIL()==null) || 
             (this.REPORTEDEMAIL!=null &&
              this.REPORTEDEMAIL.equals(other.getREPORTEDEMAIL()))) &&
            ((this.REPORTEDPHONE==null && other.getREPORTEDPHONE()==null) || 
             (this.REPORTEDPHONE!=null &&
              this.REPORTEDPHONE.equals(other.getREPORTEDPHONE()))) &&
            ((this.REPORTEDPRIORITY==null && other.getREPORTEDPRIORITY()==null) || 
             (this.REPORTEDPRIORITY!=null &&
              this.REPORTEDPRIORITY.equals(other.getREPORTEDPRIORITY()))) &&
            ((this.STATUS==null && other.getSTATUS()==null) || 
             (this.STATUS!=null &&
              this.STATUS.equals(other.getSTATUS()))) &&
            ((this.TARGETFINISH==null && other.getTARGETFINISH()==null) || 
             (this.TARGETFINISH!=null &&
              this.TARGETFINISH.equals(other.getTARGETFINISH()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              this.TICKETID.equals(other.getTICKETID()))) &&
            ((this.TICKETUID==null && other.getTICKETUID()==null) || 
             (this.TICKETUID!=null &&
              this.TICKETUID.equals(other.getTICKETUID()))) &&
            ((this.WORKLOG==null && other.getWORKLOG()==null) || 
             (this.WORKLOG!=null &&
              java.util.Arrays.equals(this.WORKLOG, other.getWORKLOG()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              java.util.Arrays.equals(this.DOCLINKS, other.getDOCLINKS()))) &&
            ((this.TICKETSPEC==null && other.getTICKETSPEC()==null) || 
             (this.TICKETSPEC!=null &&
              java.util.Arrays.equals(this.TICKETSPEC, other.getTICKETSPEC()))) &&
            ((this.CLASSSTRUCTURE==null && other.getCLASSSTRUCTURE()==null) || 
             (this.CLASSSTRUCTURE!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTURE, other.getCLASSSTRUCTURE()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert()))) &&
            ((this.transLanguage==null && other.getTransLanguage()==null) || 
             (this.transLanguage!=null &&
              this.transLanguage.equals(other.getTransLanguage())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMAXINTERRORMSG() != null) {
            _hashCode += getMAXINTERRORMSG().hashCode();
        }
        if (getCLASS() != null) {
            _hashCode += getCLASS().hashCode();
        }
        if (getCLASSIFICATIONID() != null) {
            _hashCode += getCLASSIFICATIONID().hashCode();
        }
        if (getCLASSSTRUCTUREID() != null) {
            _hashCode += getCLASSSTRUCTUREID().hashCode();
        }
        if (getDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION().hashCode();
        }
        if (getDESCRIPTION_LONGDESCRIPTION() != null) {
            _hashCode += getDESCRIPTION_LONGDESCRIPTION().hashCode();
        }
        if (getFR2CODE_LONGDESCRIPTION() != null) {
            _hashCode += getFR2CODE_LONGDESCRIPTION().hashCode();
        }
        if (getITAU_DATAAGENDAMENTO() != null) {
            _hashCode += getITAU_DATAAGENDAMENTO().hashCode();
        }
        if (getREPORTDATE() != null) {
            _hashCode += getREPORTDATE().hashCode();
        }
        if (getREPORTEDBY() != null) {
            _hashCode += getREPORTEDBY().hashCode();
        }
        if (getREPORTEDBYID() != null) {
            _hashCode += getREPORTEDBYID().hashCode();
        }
        if (getREPORTEDBYNAME() != null) {
            _hashCode += getREPORTEDBYNAME().hashCode();
        }
        if (getREPORTEDEMAIL() != null) {
            _hashCode += getREPORTEDEMAIL().hashCode();
        }
        if (getREPORTEDPHONE() != null) {
            _hashCode += getREPORTEDPHONE().hashCode();
        }
        if (getREPORTEDPRIORITY() != null) {
            _hashCode += getREPORTEDPRIORITY().hashCode();
        }
        if (getSTATUS() != null) {
            _hashCode += getSTATUS().hashCode();
        }
        if (getTARGETFINISH() != null) {
            _hashCode += getTARGETFINISH().hashCode();
        }
        if (getTICKETID() != null) {
            _hashCode += getTICKETID().hashCode();
        }
        if (getTICKETUID() != null) {
            _hashCode += getTICKETUID().hashCode();
        }
        if (getWORKLOG() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getWORKLOG());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getWORKLOG(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOCLINKS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDOCLINKS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDOCLINKS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETSPEC() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETSPEC());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETSPEC(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSTRUCTURE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTURE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTURE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        if (getTransLanguage() != null) {
            _hashCode += getTransLanguage().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRDET_SRType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRDET_SRType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("transLanguage");
        attrField.setXmlName(new javax.xml.namespace.QName("", "transLanguage"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("MAXINTERRORMSG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MAXINTERRORMSG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSIFICATIONID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSIFICATIONID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION_LONGDESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION_LONGDESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("FR2CODE_LONGDESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "FR2CODE_LONGDESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ITAU_DATAAGENDAMENTO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAU_DATAAGENDAMENTO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBYID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBYID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBYNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBYNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDEMAIL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDEMAIL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDPHONE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDPHONE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDPRIORITY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDPRIORITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("STATUS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "STATUS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TARGETFINISH");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TARGETFINISH"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETUID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WORKLOG");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WORKLOG"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRDET_WORKLOGType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRDET_DOCLINKSType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRDET_TICKETSPECType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTURE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTURE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRDET_CLASSSTRUCTUREType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
