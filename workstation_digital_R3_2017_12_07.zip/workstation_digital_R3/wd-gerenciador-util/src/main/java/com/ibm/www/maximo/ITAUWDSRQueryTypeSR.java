/**
 * ITAUWDSRQueryTypeSR.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRQueryTypeSR  implements java.io.Serializable {
    private com.ibm.www.maximo.MXStringQueryType[] AFFECTEDPERSON;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXDomainQueryType[] CLASS;

    private com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID;

    /* Multiple languages supported */
    private com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION;

    private com.ibm.www.maximo.MXDomainQueryType[] EXTERNALSYSTEM;

    private com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY;

    private com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] TICKETID;

    private com.ibm.www.maximo.ITAUWDSRQueryTypeSRTICKETSPEC TICKETSPEC;

    private com.ibm.www.maximo.ITAUWDSRQueryTypeSRDOCLINKS DOCLINKS;

    public ITAUWDSRQueryTypeSR() {
    }

    public ITAUWDSRQueryTypeSR(
           com.ibm.www.maximo.MXStringQueryType[] AFFECTEDPERSON,
           com.ibm.www.maximo.MXDomainQueryType[] CLASS,
           com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID,
           com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION,
           com.ibm.www.maximo.MXDomainQueryType[] EXTERNALSYSTEM,
           com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY,
           com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY,
           com.ibm.www.maximo.MXStringQueryType[] TICKETID,
           com.ibm.www.maximo.ITAUWDSRQueryTypeSRTICKETSPEC TICKETSPEC,
           com.ibm.www.maximo.ITAUWDSRQueryTypeSRDOCLINKS DOCLINKS) {
           this.AFFECTEDPERSON = AFFECTEDPERSON;
           this.CLASS = CLASS;
           this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
           this.DESCRIPTION = DESCRIPTION;
           this.EXTERNALSYSTEM = EXTERNALSYSTEM;
           this.REPORTEDBY = REPORTEDBY;
           this.REPORTEDPRIORITY = REPORTEDPRIORITY;
           this.TICKETID = TICKETID;
           this.TICKETSPEC = TICKETSPEC;
           this.DOCLINKS = DOCLINKS;
    }


    /**
     * Gets the AFFECTEDPERSON value for this ITAUWDSRQueryTypeSR.
     * 
     * @return AFFECTEDPERSON
     */
    public com.ibm.www.maximo.MXStringQueryType[] getAFFECTEDPERSON() {
        return AFFECTEDPERSON;
    }


    /**
     * Sets the AFFECTEDPERSON value for this ITAUWDSRQueryTypeSR.
     * 
     * @param AFFECTEDPERSON
     */
    public void setAFFECTEDPERSON(com.ibm.www.maximo.MXStringQueryType[] AFFECTEDPERSON) {
        this.AFFECTEDPERSON = AFFECTEDPERSON;
    }

    public com.ibm.www.maximo.MXStringQueryType getAFFECTEDPERSON(int i) {
        return this.AFFECTEDPERSON[i];
    }

    public void setAFFECTEDPERSON(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.AFFECTEDPERSON[i] = _value;
    }


    /**
     * Gets the CLASS value for this ITAUWDSRQueryTypeSR.
     * 
     * @return CLASS   * Unique Key Component
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getCLASS() {
        return CLASS;
    }


    /**
     * Sets the CLASS value for this ITAUWDSRQueryTypeSR.
     * 
     * @param CLASS   * Unique Key Component
     */
    public void setCLASS(com.ibm.www.maximo.MXDomainQueryType[] CLASS) {
        this.CLASS = CLASS;
    }

    public com.ibm.www.maximo.MXDomainQueryType getCLASS(int i) {
        return this.CLASS[i];
    }

    public void setCLASS(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.CLASS[i] = _value;
    }


    /**
     * Gets the CLASSSTRUCTUREID value for this ITAUWDSRQueryTypeSR.
     * 
     * @return CLASSSTRUCTUREID
     */
    public com.ibm.www.maximo.MXStringQueryType[] getCLASSSTRUCTUREID() {
        return CLASSSTRUCTUREID;
    }


    /**
     * Sets the CLASSSTRUCTUREID value for this ITAUWDSRQueryTypeSR.
     * 
     * @param CLASSSTRUCTUREID
     */
    public void setCLASSSTRUCTUREID(com.ibm.www.maximo.MXStringQueryType[] CLASSSTRUCTUREID) {
        this.CLASSSTRUCTUREID = CLASSSTRUCTUREID;
    }

    public com.ibm.www.maximo.MXStringQueryType getCLASSSTRUCTUREID(int i) {
        return this.CLASSSTRUCTUREID[i];
    }

    public void setCLASSSTRUCTUREID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.CLASSSTRUCTUREID[i] = _value;
    }


    /**
     * Gets the DESCRIPTION value for this ITAUWDSRQueryTypeSR.
     * 
     * @return DESCRIPTION   * Multiple languages supported
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDESCRIPTION() {
        return DESCRIPTION;
    }


    /**
     * Sets the DESCRIPTION value for this ITAUWDSRQueryTypeSR.
     * 
     * @param DESCRIPTION   * Multiple languages supported
     */
    public void setDESCRIPTION(com.ibm.www.maximo.MXStringQueryType[] DESCRIPTION) {
        this.DESCRIPTION = DESCRIPTION;
    }

    public com.ibm.www.maximo.MXStringQueryType getDESCRIPTION(int i) {
        return this.DESCRIPTION[i];
    }

    public void setDESCRIPTION(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DESCRIPTION[i] = _value;
    }


    /**
     * Gets the EXTERNALSYSTEM value for this ITAUWDSRQueryTypeSR.
     * 
     * @return EXTERNALSYSTEM
     */
    public com.ibm.www.maximo.MXDomainQueryType[] getEXTERNALSYSTEM() {
        return EXTERNALSYSTEM;
    }


    /**
     * Sets the EXTERNALSYSTEM value for this ITAUWDSRQueryTypeSR.
     * 
     * @param EXTERNALSYSTEM
     */
    public void setEXTERNALSYSTEM(com.ibm.www.maximo.MXDomainQueryType[] EXTERNALSYSTEM) {
        this.EXTERNALSYSTEM = EXTERNALSYSTEM;
    }

    public com.ibm.www.maximo.MXDomainQueryType getEXTERNALSYSTEM(int i) {
        return this.EXTERNALSYSTEM[i];
    }

    public void setEXTERNALSYSTEM(int i, com.ibm.www.maximo.MXDomainQueryType _value) {
        this.EXTERNALSYSTEM[i] = _value;
    }


    /**
     * Gets the REPORTEDBY value for this ITAUWDSRQueryTypeSR.
     * 
     * @return REPORTEDBY
     */
    public com.ibm.www.maximo.MXStringQueryType[] getREPORTEDBY() {
        return REPORTEDBY;
    }


    /**
     * Sets the REPORTEDBY value for this ITAUWDSRQueryTypeSR.
     * 
     * @param REPORTEDBY
     */
    public void setREPORTEDBY(com.ibm.www.maximo.MXStringQueryType[] REPORTEDBY) {
        this.REPORTEDBY = REPORTEDBY;
    }

    public com.ibm.www.maximo.MXStringQueryType getREPORTEDBY(int i) {
        return this.REPORTEDBY[i];
    }

    public void setREPORTEDBY(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.REPORTEDBY[i] = _value;
    }


    /**
     * Gets the REPORTEDPRIORITY value for this ITAUWDSRQueryTypeSR.
     * 
     * @return REPORTEDPRIORITY
     */
    public com.ibm.www.maximo.MXLongQueryType[] getREPORTEDPRIORITY() {
        return REPORTEDPRIORITY;
    }


    /**
     * Sets the REPORTEDPRIORITY value for this ITAUWDSRQueryTypeSR.
     * 
     * @param REPORTEDPRIORITY
     */
    public void setREPORTEDPRIORITY(com.ibm.www.maximo.MXLongQueryType[] REPORTEDPRIORITY) {
        this.REPORTEDPRIORITY = REPORTEDPRIORITY;
    }

    public com.ibm.www.maximo.MXLongQueryType getREPORTEDPRIORITY(int i) {
        return this.REPORTEDPRIORITY[i];
    }

    public void setREPORTEDPRIORITY(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.REPORTEDPRIORITY[i] = _value;
    }


    /**
     * Gets the TICKETID value for this ITAUWDSRQueryTypeSR.
     * 
     * @return TICKETID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getTICKETID() {
        return TICKETID;
    }


    /**
     * Sets the TICKETID value for this ITAUWDSRQueryTypeSR.
     * 
     * @param TICKETID   * Unique Key Component
     */
    public void setTICKETID(com.ibm.www.maximo.MXStringQueryType[] TICKETID) {
        this.TICKETID = TICKETID;
    }

    public com.ibm.www.maximo.MXStringQueryType getTICKETID(int i) {
        return this.TICKETID[i];
    }

    public void setTICKETID(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.TICKETID[i] = _value;
    }


    /**
     * Gets the TICKETSPEC value for this ITAUWDSRQueryTypeSR.
     * 
     * @return TICKETSPEC
     */
    public com.ibm.www.maximo.ITAUWDSRQueryTypeSRTICKETSPEC getTICKETSPEC() {
        return TICKETSPEC;
    }


    /**
     * Sets the TICKETSPEC value for this ITAUWDSRQueryTypeSR.
     * 
     * @param TICKETSPEC
     */
    public void setTICKETSPEC(com.ibm.www.maximo.ITAUWDSRQueryTypeSRTICKETSPEC TICKETSPEC) {
        this.TICKETSPEC = TICKETSPEC;
    }


    /**
     * Gets the DOCLINKS value for this ITAUWDSRQueryTypeSR.
     * 
     * @return DOCLINKS
     */
    public com.ibm.www.maximo.ITAUWDSRQueryTypeSRDOCLINKS getDOCLINKS() {
        return DOCLINKS;
    }


    /**
     * Sets the DOCLINKS value for this ITAUWDSRQueryTypeSR.
     * 
     * @param DOCLINKS
     */
    public void setDOCLINKS(com.ibm.www.maximo.ITAUWDSRQueryTypeSRDOCLINKS DOCLINKS) {
        this.DOCLINKS = DOCLINKS;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRQueryTypeSR)) return false;
        ITAUWDSRQueryTypeSR other = (ITAUWDSRQueryTypeSR) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.AFFECTEDPERSON==null && other.getAFFECTEDPERSON()==null) || 
             (this.AFFECTEDPERSON!=null &&
              java.util.Arrays.equals(this.AFFECTEDPERSON, other.getAFFECTEDPERSON()))) &&
            ((this.CLASS==null && other.getCLASS()==null) || 
             (this.CLASS!=null &&
              java.util.Arrays.equals(this.CLASS, other.getCLASS()))) &&
            ((this.CLASSSTRUCTUREID==null && other.getCLASSSTRUCTUREID()==null) || 
             (this.CLASSSTRUCTUREID!=null &&
              java.util.Arrays.equals(this.CLASSSTRUCTUREID, other.getCLASSSTRUCTUREID()))) &&
            ((this.DESCRIPTION==null && other.getDESCRIPTION()==null) || 
             (this.DESCRIPTION!=null &&
              java.util.Arrays.equals(this.DESCRIPTION, other.getDESCRIPTION()))) &&
            ((this.EXTERNALSYSTEM==null && other.getEXTERNALSYSTEM()==null) || 
             (this.EXTERNALSYSTEM!=null &&
              java.util.Arrays.equals(this.EXTERNALSYSTEM, other.getEXTERNALSYSTEM()))) &&
            ((this.REPORTEDBY==null && other.getREPORTEDBY()==null) || 
             (this.REPORTEDBY!=null &&
              java.util.Arrays.equals(this.REPORTEDBY, other.getREPORTEDBY()))) &&
            ((this.REPORTEDPRIORITY==null && other.getREPORTEDPRIORITY()==null) || 
             (this.REPORTEDPRIORITY!=null &&
              java.util.Arrays.equals(this.REPORTEDPRIORITY, other.getREPORTEDPRIORITY()))) &&
            ((this.TICKETID==null && other.getTICKETID()==null) || 
             (this.TICKETID!=null &&
              java.util.Arrays.equals(this.TICKETID, other.getTICKETID()))) &&
            ((this.TICKETSPEC==null && other.getTICKETSPEC()==null) || 
             (this.TICKETSPEC!=null &&
              this.TICKETSPEC.equals(other.getTICKETSPEC()))) &&
            ((this.DOCLINKS==null && other.getDOCLINKS()==null) || 
             (this.DOCLINKS!=null &&
              this.DOCLINKS.equals(other.getDOCLINKS())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAFFECTEDPERSON() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getAFFECTEDPERSON());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getAFFECTEDPERSON(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASS() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASS());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASS(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCLASSSTRUCTUREID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCLASSSTRUCTUREID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCLASSSTRUCTUREID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDESCRIPTION() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDESCRIPTION());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDESCRIPTION(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEXTERNALSYSTEM() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEXTERNALSYSTEM());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEXTERNALSYSTEM(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDBY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDBY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDBY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getREPORTEDPRIORITY() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getREPORTEDPRIORITY());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getREPORTEDPRIORITY(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTICKETID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTICKETID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTICKETSPEC() != null) {
            _hashCode += getTICKETSPEC().hashCode();
        }
        if (getDOCLINKS() != null) {
            _hashCode += getDOCLINKS().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRQueryTypeSR.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRQueryType>SR"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("AFFECTEDPERSON");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "AFFECTEDPERSON"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CLASSSTRUCTUREID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CLASSSTRUCTUREID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DESCRIPTION");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DESCRIPTION"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("EXTERNALSYSTEM");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "EXTERNALSYSTEM"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("REPORTEDPRIORITY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "REPORTEDPRIORITY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("TICKETSPEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "TICKETSPEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRQueryType>SR>TICKETSPEC"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRQueryType>SR>DOCLINKS"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
