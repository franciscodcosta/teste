/**
 * ITAUWDSRQueryTypeSRDOCLINKS.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRQueryTypeSRDOCLINKS  implements java.io.Serializable {
    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongQueryType[] DOCINFOID;

    private com.ibm.www.maximo.MXLongQueryType[] DOCLINKSID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] DOCTYPE;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongQueryType[] OWNERID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringQueryType[] OWNERTABLE;

    private java.lang.Boolean filter;  // attribute

    public ITAUWDSRQueryTypeSRDOCLINKS() {
    }

    public ITAUWDSRQueryTypeSRDOCLINKS(
           com.ibm.www.maximo.MXLongQueryType[] DOCINFOID,
           com.ibm.www.maximo.MXLongQueryType[] DOCLINKSID,
           com.ibm.www.maximo.MXStringQueryType[] DOCTYPE,
           com.ibm.www.maximo.MXLongQueryType[] OWNERID,
           com.ibm.www.maximo.MXStringQueryType[] OWNERTABLE,
           java.lang.Boolean filter) {
           this.DOCINFOID = DOCINFOID;
           this.DOCLINKSID = DOCLINKSID;
           this.DOCTYPE = DOCTYPE;
           this.OWNERID = OWNERID;
           this.OWNERTABLE = OWNERTABLE;
           this.filter = filter;
    }


    /**
     * Gets the DOCINFOID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return DOCINFOID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongQueryType[] getDOCINFOID() {
        return DOCINFOID;
    }


    /**
     * Sets the DOCINFOID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param DOCINFOID   * Unique Key Component
     */
    public void setDOCINFOID(com.ibm.www.maximo.MXLongQueryType[] DOCINFOID) {
        this.DOCINFOID = DOCINFOID;
    }

    public com.ibm.www.maximo.MXLongQueryType getDOCINFOID(int i) {
        return this.DOCINFOID[i];
    }

    public void setDOCINFOID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.DOCINFOID[i] = _value;
    }


    /**
     * Gets the DOCLINKSID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return DOCLINKSID
     */
    public com.ibm.www.maximo.MXLongQueryType[] getDOCLINKSID() {
        return DOCLINKSID;
    }


    /**
     * Sets the DOCLINKSID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param DOCLINKSID
     */
    public void setDOCLINKSID(com.ibm.www.maximo.MXLongQueryType[] DOCLINKSID) {
        this.DOCLINKSID = DOCLINKSID;
    }

    public com.ibm.www.maximo.MXLongQueryType getDOCLINKSID(int i) {
        return this.DOCLINKSID[i];
    }

    public void setDOCLINKSID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.DOCLINKSID[i] = _value;
    }


    /**
     * Gets the DOCTYPE value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return DOCTYPE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getDOCTYPE() {
        return DOCTYPE;
    }


    /**
     * Sets the DOCTYPE value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param DOCTYPE   * Unique Key Component
     */
    public void setDOCTYPE(com.ibm.www.maximo.MXStringQueryType[] DOCTYPE) {
        this.DOCTYPE = DOCTYPE;
    }

    public com.ibm.www.maximo.MXStringQueryType getDOCTYPE(int i) {
        return this.DOCTYPE[i];
    }

    public void setDOCTYPE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.DOCTYPE[i] = _value;
    }


    /**
     * Gets the OWNERID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return OWNERID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongQueryType[] getOWNERID() {
        return OWNERID;
    }


    /**
     * Sets the OWNERID value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param OWNERID   * Unique Key Component
     */
    public void setOWNERID(com.ibm.www.maximo.MXLongQueryType[] OWNERID) {
        this.OWNERID = OWNERID;
    }

    public com.ibm.www.maximo.MXLongQueryType getOWNERID(int i) {
        return this.OWNERID[i];
    }

    public void setOWNERID(int i, com.ibm.www.maximo.MXLongQueryType _value) {
        this.OWNERID[i] = _value;
    }


    /**
     * Gets the OWNERTABLE value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return OWNERTABLE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringQueryType[] getOWNERTABLE() {
        return OWNERTABLE;
    }


    /**
     * Sets the OWNERTABLE value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param OWNERTABLE   * Unique Key Component
     */
    public void setOWNERTABLE(com.ibm.www.maximo.MXStringQueryType[] OWNERTABLE) {
        this.OWNERTABLE = OWNERTABLE;
    }

    public com.ibm.www.maximo.MXStringQueryType getOWNERTABLE(int i) {
        return this.OWNERTABLE[i];
    }

    public void setOWNERTABLE(int i, com.ibm.www.maximo.MXStringQueryType _value) {
        this.OWNERTABLE[i] = _value;
    }


    /**
     * Gets the filter value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @return filter
     */
    public java.lang.Boolean getFilter() {
        return filter;
    }


    /**
     * Sets the filter value for this ITAUWDSRQueryTypeSRDOCLINKS.
     * 
     * @param filter
     */
    public void setFilter(java.lang.Boolean filter) {
        this.filter = filter;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRQueryTypeSRDOCLINKS)) return false;
        ITAUWDSRQueryTypeSRDOCLINKS other = (ITAUWDSRQueryTypeSRDOCLINKS) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.DOCINFOID==null && other.getDOCINFOID()==null) || 
             (this.DOCINFOID!=null &&
              java.util.Arrays.equals(this.DOCINFOID, other.getDOCINFOID()))) &&
            ((this.DOCLINKSID==null && other.getDOCLINKSID()==null) || 
             (this.DOCLINKSID!=null &&
              java.util.Arrays.equals(this.DOCLINKSID, other.getDOCLINKSID()))) &&
            ((this.DOCTYPE==null && other.getDOCTYPE()==null) || 
             (this.DOCTYPE!=null &&
              java.util.Arrays.equals(this.DOCTYPE, other.getDOCTYPE()))) &&
            ((this.OWNERID==null && other.getOWNERID()==null) || 
             (this.OWNERID!=null &&
              java.util.Arrays.equals(this.OWNERID, other.getOWNERID()))) &&
            ((this.OWNERTABLE==null && other.getOWNERTABLE()==null) || 
             (this.OWNERTABLE!=null &&
              java.util.Arrays.equals(this.OWNERTABLE, other.getOWNERTABLE()))) &&
            ((this.filter==null && other.getFilter()==null) || 
             (this.filter!=null &&
              this.filter.equals(other.getFilter())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDOCINFOID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDOCINFOID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDOCINFOID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOCLINKSID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDOCLINKSID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDOCLINKSID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDOCTYPE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDOCTYPE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDOCTYPE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOWNERID() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOWNERID());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOWNERID(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getOWNERTABLE() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOWNERTABLE());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOWNERTABLE(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFilter() != null) {
            _hashCode += getFilter().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRQueryTypeSRDOCLINKS.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRQueryType>SR>DOCLINKS"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("filter");
        attrField.setXmlName(new javax.xml.namespace.QName("", "filter"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCINFOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCINFOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCLINKSID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCLINKSID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERTABLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERTABLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
