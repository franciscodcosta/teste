/**
 * ITAUWDSRATUALIZA_DOCLINKSType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo;

public class ITAUWDSRATUALIZA_DOCLINKSType  implements java.io.Serializable {
    private com.ibm.www.maximo.MXBooleanType ADDINFO;

    private com.ibm.www.maximo.MXStringType APP;

    private com.ibm.www.maximo.MXStringType CREATEBY;

    private com.ibm.www.maximo.MXDateTimeType CREATEDATE;

    private com.ibm.www.maximo.MXStringType DMSNAME;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType DOCINFOID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType DOCTYPE;

    private com.ibm.www.maximo.MXStringType DOCUMENT;

    private com.ibm.www.maximo.MXStringType KEYCOLUMN;

    private com.ibm.www.maximo.MXStringType NEWURLNAME;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXLongType OWNERID;

    /* Unique Key Component */
    private com.ibm.www.maximo.MXStringType OWNERTABLE;

    private com.ibm.www.maximo.MXStringType PMSCOFFERING;

    private com.ibm.www.maximo.MXBooleanType SHOW;

    private com.ibm.www.maximo.MXBooleanType UPLOAD;

    private com.ibm.www.maximo.MXStringType URLNAME;

    private com.ibm.www.maximo.MXStringType URLPARAM1;

    private com.ibm.www.maximo.MXStringType URLPARAM2;

    private com.ibm.www.maximo.MXStringType URLPARAM3;

    private com.ibm.www.maximo.MXStringType URLPARAM4;

    private com.ibm.www.maximo.MXStringType URLPARAM5;

    private com.ibm.www.maximo.MXStringType URLTYPE;

    private com.ibm.www.maximo.MXStringType WEBURL;
    
    private com.ibm.www.maximo.MXBinaryType DOCUMENTDATA;

    private com.ibm.www.maximo.ProcessingActionType action;  // attribute

    private java.lang.String relationship;  // attribute

    private java.lang.String deleteForInsert;  // attribute

    public ITAUWDSRATUALIZA_DOCLINKSType() {
    }

    public ITAUWDSRATUALIZA_DOCLINKSType(
           com.ibm.www.maximo.MXBooleanType ADDINFO,
           com.ibm.www.maximo.MXStringType APP,
           com.ibm.www.maximo.MXStringType CREATEBY,
           com.ibm.www.maximo.MXDateTimeType CREATEDATE,
           com.ibm.www.maximo.MXStringType DMSNAME,
           com.ibm.www.maximo.MXLongType DOCINFOID,
           com.ibm.www.maximo.MXStringType DOCTYPE,
           com.ibm.www.maximo.MXStringType DOCUMENT,
           com.ibm.www.maximo.MXStringType KEYCOLUMN,
           com.ibm.www.maximo.MXStringType NEWURLNAME,
           com.ibm.www.maximo.MXLongType OWNERID,
           com.ibm.www.maximo.MXStringType OWNERTABLE,
           com.ibm.www.maximo.MXStringType PMSCOFFERING,
           com.ibm.www.maximo.MXBooleanType SHOW,
           com.ibm.www.maximo.MXBooleanType UPLOAD,
           com.ibm.www.maximo.MXStringType URLNAME,
           com.ibm.www.maximo.MXStringType URLPARAM1,
           com.ibm.www.maximo.MXStringType URLPARAM2,
           com.ibm.www.maximo.MXStringType URLPARAM3,
           com.ibm.www.maximo.MXStringType URLPARAM4,
           com.ibm.www.maximo.MXStringType URLPARAM5,
           com.ibm.www.maximo.MXStringType URLTYPE,
           com.ibm.www.maximo.MXStringType WEBURL,
           com.ibm.www.maximo.MXBinaryType DOCUMENTDATA,
           com.ibm.www.maximo.ProcessingActionType action,
           java.lang.String relationship,
           java.lang.String deleteForInsert) {
           this.ADDINFO = ADDINFO;
           this.APP = APP;
           this.CREATEBY = CREATEBY;
           this.CREATEDATE = CREATEDATE;
           this.DMSNAME = DMSNAME;
           this.DOCINFOID = DOCINFOID;
           this.DOCTYPE = DOCTYPE;
           this.DOCUMENT = DOCUMENT;
           this.KEYCOLUMN = KEYCOLUMN;
           this.NEWURLNAME = NEWURLNAME;
           this.OWNERID = OWNERID;
           this.OWNERTABLE = OWNERTABLE;
           this.PMSCOFFERING = PMSCOFFERING;
           this.SHOW = SHOW;
           this.UPLOAD = UPLOAD;
           this.URLNAME = URLNAME;
           this.URLPARAM1 = URLPARAM1;
           this.URLPARAM2 = URLPARAM2;
           this.URLPARAM3 = URLPARAM3;
           this.URLPARAM4 = URLPARAM4;
           this.URLPARAM5 = URLPARAM5;
           this.URLTYPE = URLTYPE;
           this.WEBURL = WEBURL;
           this.DOCUMENTDATA = DOCUMENTDATA;
           this.action = action;
           this.relationship = relationship;
           this.deleteForInsert = deleteForInsert;
    }


    /**
     * Gets the ADDINFO value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return ADDINFO
     */
    public com.ibm.www.maximo.MXBooleanType getADDINFO() {
        return ADDINFO;
    }


    /**
     * Sets the ADDINFO value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param ADDINFO
     */
    public void setADDINFO(com.ibm.www.maximo.MXBooleanType ADDINFO) {
        this.ADDINFO = ADDINFO;
    }


    /**
     * Gets the APP value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return APP
     */
    public com.ibm.www.maximo.MXStringType getAPP() {
        return APP;
    }


    /**
     * Sets the APP value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param APP
     */
    public void setAPP(com.ibm.www.maximo.MXStringType APP) {
        this.APP = APP;
    }


    /**
     * Gets the CREATEBY value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return CREATEBY
     */
    public com.ibm.www.maximo.MXStringType getCREATEBY() {
        return CREATEBY;
    }


    /**
     * Sets the CREATEBY value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param CREATEBY
     */
    public void setCREATEBY(com.ibm.www.maximo.MXStringType CREATEBY) {
        this.CREATEBY = CREATEBY;
    }


    /**
     * Gets the CREATEDATE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return CREATEDATE
     */
    public com.ibm.www.maximo.MXDateTimeType getCREATEDATE() {
        return CREATEDATE;
    }


    /**
     * Sets the CREATEDATE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param CREATEDATE
     */
    public void setCREATEDATE(com.ibm.www.maximo.MXDateTimeType CREATEDATE) {
        this.CREATEDATE = CREATEDATE;
    }


    /**
     * Gets the DMSNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return DMSNAME
     */
    public com.ibm.www.maximo.MXStringType getDMSNAME() {
        return DMSNAME;
    }


    /**
     * Sets the DMSNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param DMSNAME
     */
    public void setDMSNAME(com.ibm.www.maximo.MXStringType DMSNAME) {
        this.DMSNAME = DMSNAME;
    }


    /**
     * Gets the DOCINFOID value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return DOCINFOID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getDOCINFOID() {
        return DOCINFOID;
    }


    /**
     * Sets the DOCINFOID value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param DOCINFOID   * Unique Key Component
     */
    public void setDOCINFOID(com.ibm.www.maximo.MXLongType DOCINFOID) {
        this.DOCINFOID = DOCINFOID;
    }


    /**
     * Gets the DOCTYPE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return DOCTYPE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getDOCTYPE() {
        return DOCTYPE;
    }


    /**
     * Sets the DOCTYPE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param DOCTYPE   * Unique Key Component
     */
    public void setDOCTYPE(com.ibm.www.maximo.MXStringType DOCTYPE) {
        this.DOCTYPE = DOCTYPE;
    }


    /**
     * Gets the DOCUMENT value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return DOCUMENT
     */
    public com.ibm.www.maximo.MXStringType getDOCUMENT() {
        return DOCUMENT;
    }


    /**
     * Sets the DOCUMENT value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param DOCUMENT
     */
    public void setDOCUMENT(com.ibm.www.maximo.MXStringType DOCUMENT) {
        this.DOCUMENT = DOCUMENT;
    }


    /**
     * Gets the KEYCOLUMN value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return KEYCOLUMN
     */
    public com.ibm.www.maximo.MXStringType getKEYCOLUMN() {
        return KEYCOLUMN;
    }


    /**
     * Sets the KEYCOLUMN value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param KEYCOLUMN
     */
    public void setKEYCOLUMN(com.ibm.www.maximo.MXStringType KEYCOLUMN) {
        this.KEYCOLUMN = KEYCOLUMN;
    }


    /**
     * Gets the NEWURLNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return NEWURLNAME
     */
    public com.ibm.www.maximo.MXStringType getNEWURLNAME() {
        return NEWURLNAME;
    }


    /**
     * Sets the NEWURLNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param NEWURLNAME
     */
    public void setNEWURLNAME(com.ibm.www.maximo.MXStringType NEWURLNAME) {
        this.NEWURLNAME = NEWURLNAME;
    }


    /**
     * Gets the OWNERID value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return OWNERID   * Unique Key Component
     */
    public com.ibm.www.maximo.MXLongType getOWNERID() {
        return OWNERID;
    }


    /**
     * Sets the OWNERID value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param OWNERID   * Unique Key Component
     */
    public void setOWNERID(com.ibm.www.maximo.MXLongType OWNERID) {
        this.OWNERID = OWNERID;
    }


    /**
     * Gets the OWNERTABLE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return OWNERTABLE   * Unique Key Component
     */
    public com.ibm.www.maximo.MXStringType getOWNERTABLE() {
        return OWNERTABLE;
    }


    /**
     * Sets the OWNERTABLE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param OWNERTABLE   * Unique Key Component
     */
    public void setOWNERTABLE(com.ibm.www.maximo.MXStringType OWNERTABLE) {
        this.OWNERTABLE = OWNERTABLE;
    }


    /**
     * Gets the PMSCOFFERING value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return PMSCOFFERING
     */
    public com.ibm.www.maximo.MXStringType getPMSCOFFERING() {
        return PMSCOFFERING;
    }


    /**
     * Sets the PMSCOFFERING value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param PMSCOFFERING
     */
    public void setPMSCOFFERING(com.ibm.www.maximo.MXStringType PMSCOFFERING) {
        this.PMSCOFFERING = PMSCOFFERING;
    }


    /**
     * Gets the SHOW value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return SHOW
     */
    public com.ibm.www.maximo.MXBooleanType getSHOW() {
        return SHOW;
    }


    /**
     * Sets the SHOW value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param SHOW
     */
    public void setSHOW(com.ibm.www.maximo.MXBooleanType SHOW) {
        this.SHOW = SHOW;
    }


    /**
     * Gets the UPLOAD value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return UPLOAD
     */
    public com.ibm.www.maximo.MXBooleanType getUPLOAD() {
        return UPLOAD;
    }


    /**
     * Sets the UPLOAD value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param UPLOAD
     */
    public void setUPLOAD(com.ibm.www.maximo.MXBooleanType UPLOAD) {
        this.UPLOAD = UPLOAD;
    }


    /**
     * Gets the URLNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLNAME
     */
    public com.ibm.www.maximo.MXStringType getURLNAME() {
        return URLNAME;
    }


    /**
     * Sets the URLNAME value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLNAME
     */
    public void setURLNAME(com.ibm.www.maximo.MXStringType URLNAME) {
        this.URLNAME = URLNAME;
    }


    /**
     * Gets the URLPARAM1 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLPARAM1
     */
    public com.ibm.www.maximo.MXStringType getURLPARAM1() {
        return URLPARAM1;
    }


    /**
     * Sets the URLPARAM1 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLPARAM1
     */
    public void setURLPARAM1(com.ibm.www.maximo.MXStringType URLPARAM1) {
        this.URLPARAM1 = URLPARAM1;
    }


    /**
     * Gets the URLPARAM2 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLPARAM2
     */
    public com.ibm.www.maximo.MXStringType getURLPARAM2() {
        return URLPARAM2;
    }


    /**
     * Sets the URLPARAM2 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLPARAM2
     */
    public void setURLPARAM2(com.ibm.www.maximo.MXStringType URLPARAM2) {
        this.URLPARAM2 = URLPARAM2;
    }


    /**
     * Gets the URLPARAM3 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLPARAM3
     */
    public com.ibm.www.maximo.MXStringType getURLPARAM3() {
        return URLPARAM3;
    }


    /**
     * Sets the URLPARAM3 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLPARAM3
     */
    public void setURLPARAM3(com.ibm.www.maximo.MXStringType URLPARAM3) {
        this.URLPARAM3 = URLPARAM3;
    }


    /**
     * Gets the URLPARAM4 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLPARAM4
     */
    public com.ibm.www.maximo.MXStringType getURLPARAM4() {
        return URLPARAM4;
    }


    /**
     * Sets the URLPARAM4 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLPARAM4
     */
    public void setURLPARAM4(com.ibm.www.maximo.MXStringType URLPARAM4) {
        this.URLPARAM4 = URLPARAM4;
    }


    /**
     * Gets the URLPARAM5 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLPARAM5
     */
    public com.ibm.www.maximo.MXStringType getURLPARAM5() {
        return URLPARAM5;
    }


    /**
     * Sets the URLPARAM5 value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLPARAM5
     */
    public void setURLPARAM5(com.ibm.www.maximo.MXStringType URLPARAM5) {
        this.URLPARAM5 = URLPARAM5;
    }


    /**
     * Gets the URLTYPE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return URLTYPE
     */
    public com.ibm.www.maximo.MXStringType getURLTYPE() {
        return URLTYPE;
    }


    /**
     * Sets the URLTYPE value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param URLTYPE
     */
    public void setURLTYPE(com.ibm.www.maximo.MXStringType URLTYPE) {
        this.URLTYPE = URLTYPE;
    }


    /**
     * Gets the WEBURL value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return WEBURL
     */
    public com.ibm.www.maximo.MXStringType getWEBURL() {
        return WEBURL;
    }


    /**
     * Sets the WEBURL value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param WEBURL
     */
    public void setWEBURL(com.ibm.www.maximo.MXStringType WEBURL) {
        this.WEBURL = WEBURL;
    }

    /**
     * Gets the DOCUMENTDATA value for this ITAUWDSR_DOCLINKSType.
     * 
     * @return DOCUMENTDATA
     */
    public com.ibm.www.maximo.MXBinaryType getDOCUMENTDATA() {
        return DOCUMENTDATA;
    }


    /**
     * Sets the DOCUMENTDATA value for this ITAUWDSR_DOCLINKSType.
     * 
     * @param DOCUMENTDATA
     */
    public void setDOCUMENTDATA(com.ibm.www.maximo.MXBinaryType DOCUMENTDATA) {
        this.DOCUMENTDATA = DOCUMENTDATA;
    }

    /**
     * Gets the action value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return action
     */
    public com.ibm.www.maximo.ProcessingActionType getAction() {
        return action;
    }


    /**
     * Sets the action value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param action
     */
    public void setAction(com.ibm.www.maximo.ProcessingActionType action) {
        this.action = action;
    }


    /**
     * Gets the relationship value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return relationship
     */
    public java.lang.String getRelationship() {
        return relationship;
    }


    /**
     * Sets the relationship value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param relationship
     */
    public void setRelationship(java.lang.String relationship) {
        this.relationship = relationship;
    }


    /**
     * Gets the deleteForInsert value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @return deleteForInsert
     */
    public java.lang.String getDeleteForInsert() {
        return deleteForInsert;
    }


    /**
     * Sets the deleteForInsert value for this ITAUWDSRATUALIZA_DOCLINKSType.
     * 
     * @param deleteForInsert
     */
    public void setDeleteForInsert(java.lang.String deleteForInsert) {
        this.deleteForInsert = deleteForInsert;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ITAUWDSRATUALIZA_DOCLINKSType)) return false;
        ITAUWDSRATUALIZA_DOCLINKSType other = (ITAUWDSRATUALIZA_DOCLINKSType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ADDINFO==null && other.getADDINFO()==null) || 
             (this.ADDINFO!=null &&
              this.ADDINFO.equals(other.getADDINFO()))) &&
            ((this.APP==null && other.getAPP()==null) || 
             (this.APP!=null &&
              this.APP.equals(other.getAPP()))) &&
            ((this.CREATEBY==null && other.getCREATEBY()==null) || 
             (this.CREATEBY!=null &&
              this.CREATEBY.equals(other.getCREATEBY()))) &&
            ((this.CREATEDATE==null && other.getCREATEDATE()==null) || 
             (this.CREATEDATE!=null &&
              this.CREATEDATE.equals(other.getCREATEDATE()))) &&
            ((this.DMSNAME==null && other.getDMSNAME()==null) || 
             (this.DMSNAME!=null &&
              this.DMSNAME.equals(other.getDMSNAME()))) &&
            ((this.DOCINFOID==null && other.getDOCINFOID()==null) || 
             (this.DOCINFOID!=null &&
              this.DOCINFOID.equals(other.getDOCINFOID()))) &&
            ((this.DOCTYPE==null && other.getDOCTYPE()==null) || 
             (this.DOCTYPE!=null &&
              this.DOCTYPE.equals(other.getDOCTYPE()))) &&
            ((this.DOCUMENT==null && other.getDOCUMENT()==null) || 
             (this.DOCUMENT!=null &&
              this.DOCUMENT.equals(other.getDOCUMENT()))) &&
            ((this.KEYCOLUMN==null && other.getKEYCOLUMN()==null) || 
             (this.KEYCOLUMN!=null &&
              this.KEYCOLUMN.equals(other.getKEYCOLUMN()))) &&
            ((this.NEWURLNAME==null && other.getNEWURLNAME()==null) || 
             (this.NEWURLNAME!=null &&
              this.NEWURLNAME.equals(other.getNEWURLNAME()))) &&
            ((this.OWNERID==null && other.getOWNERID()==null) || 
             (this.OWNERID!=null &&
              this.OWNERID.equals(other.getOWNERID()))) &&
            ((this.OWNERTABLE==null && other.getOWNERTABLE()==null) || 
             (this.OWNERTABLE!=null &&
              this.OWNERTABLE.equals(other.getOWNERTABLE()))) &&
            ((this.PMSCOFFERING==null && other.getPMSCOFFERING()==null) || 
             (this.PMSCOFFERING!=null &&
              this.PMSCOFFERING.equals(other.getPMSCOFFERING()))) &&
            ((this.SHOW==null && other.getSHOW()==null) || 
             (this.SHOW!=null &&
              this.SHOW.equals(other.getSHOW()))) &&
            ((this.UPLOAD==null && other.getUPLOAD()==null) || 
             (this.UPLOAD!=null &&
              this.UPLOAD.equals(other.getUPLOAD()))) &&
            ((this.URLNAME==null && other.getURLNAME()==null) || 
             (this.URLNAME!=null &&
              this.URLNAME.equals(other.getURLNAME()))) &&
            ((this.URLPARAM1==null && other.getURLPARAM1()==null) || 
             (this.URLPARAM1!=null &&
              this.URLPARAM1.equals(other.getURLPARAM1()))) &&
            ((this.URLPARAM2==null && other.getURLPARAM2()==null) || 
             (this.URLPARAM2!=null &&
              this.URLPARAM2.equals(other.getURLPARAM2()))) &&
            ((this.URLPARAM3==null && other.getURLPARAM3()==null) || 
             (this.URLPARAM3!=null &&
              this.URLPARAM3.equals(other.getURLPARAM3()))) &&
            ((this.URLPARAM4==null && other.getURLPARAM4()==null) || 
             (this.URLPARAM4!=null &&
              this.URLPARAM4.equals(other.getURLPARAM4()))) &&
            ((this.URLPARAM5==null && other.getURLPARAM5()==null) || 
             (this.URLPARAM5!=null &&
              this.URLPARAM5.equals(other.getURLPARAM5()))) &&
            ((this.URLTYPE==null && other.getURLTYPE()==null) || 
             (this.URLTYPE!=null &&
              this.URLTYPE.equals(other.getURLTYPE()))) &&
            ((this.WEBURL==null && other.getWEBURL()==null) || 
             (this.WEBURL!=null &&
              this.WEBURL.equals(other.getWEBURL()))) &&
            ((this.DOCUMENTDATA==null && other.getDOCUMENTDATA()==null) || 
                    (this.DOCUMENTDATA!=null &&
                     this.DOCUMENTDATA.equals(other.getDOCUMENTDATA()))) &&
            ((this.action==null && other.getAction()==null) || 
             (this.action!=null &&
              this.action.equals(other.getAction()))) &&
            ((this.relationship==null && other.getRelationship()==null) || 
             (this.relationship!=null &&
              this.relationship.equals(other.getRelationship()))) &&
            ((this.deleteForInsert==null && other.getDeleteForInsert()==null) || 
             (this.deleteForInsert!=null &&
              this.deleteForInsert.equals(other.getDeleteForInsert())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getADDINFO() != null) {
            _hashCode += getADDINFO().hashCode();
        }
        if (getAPP() != null) {
            _hashCode += getAPP().hashCode();
        }
        if (getCREATEBY() != null) {
            _hashCode += getCREATEBY().hashCode();
        }
        if (getCREATEDATE() != null) {
            _hashCode += getCREATEDATE().hashCode();
        }
        if (getDMSNAME() != null) {
            _hashCode += getDMSNAME().hashCode();
        }
        if (getDOCINFOID() != null) {
            _hashCode += getDOCINFOID().hashCode();
        }
        if (getDOCTYPE() != null) {
            _hashCode += getDOCTYPE().hashCode();
        }
        if (getDOCUMENT() != null) {
            _hashCode += getDOCUMENT().hashCode();
        }
        if (getKEYCOLUMN() != null) {
            _hashCode += getKEYCOLUMN().hashCode();
        }
        if (getNEWURLNAME() != null) {
            _hashCode += getNEWURLNAME().hashCode();
        }
        if (getOWNERID() != null) {
            _hashCode += getOWNERID().hashCode();
        }
        if (getOWNERTABLE() != null) {
            _hashCode += getOWNERTABLE().hashCode();
        }
        if (getPMSCOFFERING() != null) {
            _hashCode += getPMSCOFFERING().hashCode();
        }
        if (getSHOW() != null) {
            _hashCode += getSHOW().hashCode();
        }
        if (getUPLOAD() != null) {
            _hashCode += getUPLOAD().hashCode();
        }
        if (getURLNAME() != null) {
            _hashCode += getURLNAME().hashCode();
        }
        if (getURLPARAM1() != null) {
            _hashCode += getURLPARAM1().hashCode();
        }
        if (getURLPARAM2() != null) {
            _hashCode += getURLPARAM2().hashCode();
        }
        if (getURLPARAM3() != null) {
            _hashCode += getURLPARAM3().hashCode();
        }
        if (getURLPARAM4() != null) {
            _hashCode += getURLPARAM4().hashCode();
        }
        if (getURLPARAM5() != null) {
            _hashCode += getURLPARAM5().hashCode();
        }
        if (getURLTYPE() != null) {
            _hashCode += getURLTYPE().hashCode();
        }
        if (getWEBURL() != null) {
            _hashCode += getWEBURL().hashCode();
        }
        if (getDOCUMENTDATA() != null) {
            _hashCode += getDOCUMENTDATA().hashCode();
        }
        if (getAction() != null) {
            _hashCode += getAction().hashCode();
        }
        if (getRelationship() != null) {
            _hashCode += getRelationship().hashCode();
        }
        if (getDeleteForInsert() != null) {
            _hashCode += getDeleteForInsert().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ITAUWDSRATUALIZA_DOCLINKSType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRATUALIZA_DOCLINKSType"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("action");
        attrField.setXmlName(new javax.xml.namespace.QName("", "action"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("relationship");
        attrField.setXmlName(new javax.xml.namespace.QName("", "relationship"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("deleteForInsert");
        attrField.setXmlName(new javax.xml.namespace.QName("", "deleteForInsert"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ADDINFO");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ADDINFO"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("APP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "APP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEBY");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEBY"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("CREATEDATE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CREATEDATE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DMSNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DMSNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCINFOID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCINFOID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCUMENT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCUMENT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("KEYCOLUMN");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "KEYCOLUMN"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("NEWURLNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "NEWURLNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("OWNERTABLE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OWNERTABLE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("PMSCOFFERING");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "PMSCOFFERING"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("SHOW");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SHOW"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("UPLOAD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UPLOAD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLNAME");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLNAME"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLPARAM1");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLPARAM1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLPARAM2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLPARAM2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLPARAM3");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLPARAM3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLPARAM4");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLPARAM4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLPARAM5");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLPARAM5"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("URLTYPE");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "URLTYPE"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("WEBURL");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "WEBURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("DOCUMENTDATA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DOCUMENTDATA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBinaryType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
