/**
 * ITAUWDSRATUALIZAPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDSRATUALIZA;

public interface ITAUWDSRATUALIZAPortType extends java.rmi.Remote {
    public com.ibm.www.maximo.QueryITAUWDSRATUALIZAResponseType queryITAUWDSRATUALIZA(com.ibm.www.maximo.QueryITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.SyncITAUWDSRATUALIZAResponseType syncITAUWDSRATUALIZA(com.ibm.www.maximo.SyncITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.UpdateITAUWDSRATUALIZAResponseType updateITAUWDSRATUALIZA(com.ibm.www.maximo.UpdateITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.CreateITAUWDSRATUALIZAResponseType createITAUWDSRATUALIZA(com.ibm.www.maximo.CreateITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException;
    public com.ibm.www.maximo.DeleteITAUWDSRATUALIZAResponseType deleteITAUWDSRATUALIZA(com.ibm.www.maximo.DeleteITAUWDSRATUALIZAType parameters) throws java.rmi.RemoteException;
}
