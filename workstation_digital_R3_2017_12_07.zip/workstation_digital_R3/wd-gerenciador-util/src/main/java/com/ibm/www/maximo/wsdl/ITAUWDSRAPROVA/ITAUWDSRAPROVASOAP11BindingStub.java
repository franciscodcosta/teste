/**
 * ITAUWDSRAPROVASOAP11BindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA;

public class ITAUWDSRAPROVASOAP11BindingStub extends org.apache.axis.client.Stub implements com.ibm.www.maximo.wsdl.ITAUWDSRAPROVA.ITAUWDSRAPROVAPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[5];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("QueryITAUWDSRAPROVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVAType"), com.ibm.www.maximo.QueryITAUWDSRAPROVAType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVAResponseType"));
        oper.setReturnClass(com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVAResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("SyncITAUWDSRAPROVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVAType"), com.ibm.www.maximo.SyncITAUWDSRAPROVAType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVAResponseType"));
        oper.setReturnClass(com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVAResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateITAUWDSRAPROVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVAType"), com.ibm.www.maximo.UpdateITAUWDSRAPROVAType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVAResponseType"));
        oper.setReturnClass(com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVAResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateITAUWDSRAPROVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVAType"), com.ibm.www.maximo.CreateITAUWDSRAPROVAType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVAResponseType"));
        oper.setReturnClass(com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVAResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteITAUWDSRAPROVA");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVA"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVAType"), com.ibm.www.maximo.DeleteITAUWDSRAPROVAType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVAResponseType"));
        oper.setReturnClass(com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVAResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[4] = oper;

    }

    public ITAUWDSRAPROVASOAP11BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public ITAUWDSRAPROVASOAP11BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public ITAUWDSRAPROVASOAP11BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">>ITAUWDSRAPROVAQueryType>SR>WORKLOG");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVAQueryTypeSRWORKLOG.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRAPROVACombinedKeySetType>SR");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVACombinedKeySetTypeSR.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRAPROVAQueryType>SR");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVAQueryTypeSR.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "BooleanType");
            cachedSerQNames.add(qName);
            cls = boolean.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ChangeIndicatorType");
            cachedSerQNames.add(qName);
            cls = boolean.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVAResponseType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "CreateITAUWDSRAPROVAType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.CreateITAUWDSRAPROVAType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVAResponseType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "DeleteITAUWDSRAPROVAType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.DeleteITAUWDSRAPROVAType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVA_SRType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVA_SRType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVA_WORKLOGType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVA_WORKLOGType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVACombinedKeySetType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVACombinedKeySetTypeSR[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", ">ITAUWDSRAPROVACombinedKeySetType>SR");
            qName2 = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SR");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVAQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVAQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVASetType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ITAUWDSRAPROVA_SRType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ITAUWDSRAPROVA_SRType");
            qName2 = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SR");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MaximoVersionType");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXBooleanQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXBooleanType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXBooleanType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXDateTimeQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDateTimeType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXDateTimeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXDomainQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXDomainType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXDomainType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXLongQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXLongType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXLongType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringQueryType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXStringQueryType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "MXStringType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.MXStringType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "OperandModeType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.OperandModeType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "ProcessingActionType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.ProcessingActionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVAResponseType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryITAUWDSRAPROVAType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.QueryITAUWDSRAPROVAType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "QueryOperatorType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.QueryOperatorType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVAResponseType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "SyncITAUWDSRAPROVAType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.SyncITAUWDSRAPROVAType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVAResponseType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://www.ibm.com/maximo", "UpdateITAUWDSRAPROVAType");
            cachedSerQNames.add(qName);
            cls = com.ibm.www.maximo.UpdateITAUWDSRAPROVAType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType queryITAUWDSRAPROVA(com.ibm.www.maximo.QueryITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processDocument");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "QueryITAUWDSRAPROVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.ibm.www.maximo.QueryITAUWDSRAPROVAResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType syncITAUWDSRAPROVA(com.ibm.www.maximo.SyncITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processDocument");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "SyncITAUWDSRAPROVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.ibm.www.maximo.SyncITAUWDSRAPROVAResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType updateITAUWDSRAPROVA(com.ibm.www.maximo.UpdateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processDocument");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "UpdateITAUWDSRAPROVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.ibm.www.maximo.UpdateITAUWDSRAPROVAResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType createITAUWDSRAPROVA(com.ibm.www.maximo.CreateITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processDocument");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "CreateITAUWDSRAPROVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.ibm.www.maximo.CreateITAUWDSRAPROVAResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType deleteITAUWDSRAPROVA(com.ibm.www.maximo.DeleteITAUWDSRAPROVAType parameters) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("urn:processDocument");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "DeleteITAUWDSRAPROVA"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, com.ibm.www.maximo.DeleteITAUWDSRAPROVAResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
