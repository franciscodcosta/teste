package com.itau.ob6.workstation;

public class WorkstationPagamentoProxy implements com.itau.ob6.workstation.WorkstationPagamento {
  private String _endpoint = null;
  private com.itau.ob6.workstation.WorkstationPagamento workstationPagamento = null;
  
  public WorkstationPagamentoProxy() {
    _initWorkstationPagamentoProxy();
  }
  
  public WorkstationPagamentoProxy(String endpoint) {
    _endpoint = endpoint;
    _initWorkstationPagamentoProxy();
  }
  
  private void _initWorkstationPagamentoProxy() {
    try {
      workstationPagamento = (new com.itau.ob6.workstation.WorkstationPagamentoServiceLocator()).getWorkstationPagamentoPort();
      if (workstationPagamento != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)workstationPagamento)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)workstationPagamento)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (workstationPagamento != null)
      ((javax.xml.rpc.Stub)workstationPagamento)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.itau.ob6.workstation.WorkstationPagamento getWorkstationPagamento() {
    if (workstationPagamento == null)
      _initWorkstationPagamentoProxy();
    return workstationPagamento;
  }
  
  public java.lang.String registraAcao(java.lang.String json) throws java.rmi.RemoteException, com.itau.ob6.workstation.PjExpectedException, com.itau.ob6.workstation.PjUnexpectedException{
    if (workstationPagamento == null)
      _initWorkstationPagamentoProxy();
    return workstationPagamento.registraAcao(json);
  }
  
  public java.lang.String consultaPendencia(java.lang.String json) throws java.rmi.RemoteException, com.itau.ob6.workstation.PjExpectedException, com.itau.ob6.workstation.PjUnexpectedException{
    if (workstationPagamento == null)
      _initWorkstationPagamentoProxy();
    return workstationPagamento.consultaPendencia(json);
  }
  
  
}