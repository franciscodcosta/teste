/**
 * PjUnexpectedException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.itau.ob6.workstation;

public class PjUnexpectedException  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private java.lang.String className;

    private boolean criticalError;

    private java.lang.String message1;

    private java.lang.String methodName;

    private com.itau.ob6.workstation.StackTraceElement[] previousException;

    private com.itau.ob6.workstation.Timestamp timestamp;

    public PjUnexpectedException() {
    }

    public PjUnexpectedException(
           java.lang.String className,
           boolean criticalError,
           java.lang.String message1,
           java.lang.String methodName,
           com.itau.ob6.workstation.StackTraceElement[] previousException,
           com.itau.ob6.workstation.Timestamp timestamp) {
        this.className = className;
        this.criticalError = criticalError;
        this.message1 = message1;
        this.methodName = methodName;
        this.previousException = previousException;
        this.timestamp = timestamp;
    }


    /**
     * Gets the className value for this PjUnexpectedException.
     * 
     * @return className
     */
    public java.lang.String getClassName() {
        return className;
    }


    /**
     * Sets the className value for this PjUnexpectedException.
     * 
     * @param className
     */
    public void setClassName(java.lang.String className) {
        this.className = className;
    }


    /**
     * Gets the criticalError value for this PjUnexpectedException.
     * 
     * @return criticalError
     */
    public boolean isCriticalError() {
        return criticalError;
    }


    /**
     * Sets the criticalError value for this PjUnexpectedException.
     * 
     * @param criticalError
     */
    public void setCriticalError(boolean criticalError) {
        this.criticalError = criticalError;
    }


    /**
     * Gets the message1 value for this PjUnexpectedException.
     * 
     * @return message1
     */
    public java.lang.String getMessage1() {
        return message1;
    }


    /**
     * Sets the message1 value for this PjUnexpectedException.
     * 
     * @param message1
     */
    public void setMessage1(java.lang.String message1) {
        this.message1 = message1;
    }


    /**
     * Gets the methodName value for this PjUnexpectedException.
     * 
     * @return methodName
     */
    public java.lang.String getMethodName() {
        return methodName;
    }


    /**
     * Sets the methodName value for this PjUnexpectedException.
     * 
     * @param methodName
     */
    public void setMethodName(java.lang.String methodName) {
        this.methodName = methodName;
    }


    /**
     * Gets the previousException value for this PjUnexpectedException.
     * 
     * @return previousException
     */
    public com.itau.ob6.workstation.StackTraceElement[] getPreviousException() {
        return previousException;
    }


    /**
     * Sets the previousException value for this PjUnexpectedException.
     * 
     * @param previousException
     */
    public void setPreviousException(com.itau.ob6.workstation.StackTraceElement[] previousException) {
        this.previousException = previousException;
    }


    /**
     * Gets the timestamp value for this PjUnexpectedException.
     * 
     * @return timestamp
     */
    public com.itau.ob6.workstation.Timestamp getTimestamp() {
        return timestamp;
    }


    /**
     * Sets the timestamp value for this PjUnexpectedException.
     * 
     * @param timestamp
     */
    public void setTimestamp(com.itau.ob6.workstation.Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PjUnexpectedException)) return false;
        PjUnexpectedException other = (PjUnexpectedException) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.className==null && other.getClassName()==null) || 
             (this.className!=null &&
              this.className.equals(other.getClassName()))) &&
            this.criticalError == other.isCriticalError() &&
            ((this.message1==null && other.getMessage1()==null) || 
             (this.message1!=null &&
              this.message1.equals(other.getMessage1()))) &&
            ((this.methodName==null && other.getMethodName()==null) || 
             (this.methodName!=null &&
              this.methodName.equals(other.getMethodName()))) &&
            ((this.previousException==null && other.getPreviousException()==null) || 
             (this.previousException!=null &&
              java.util.Arrays.equals(this.previousException, other.getPreviousException()))) &&
            ((this.timestamp==null && other.getTimestamp()==null) || 
             (this.timestamp!=null &&
              this.timestamp.equals(other.getTimestamp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getClassName() != null) {
            _hashCode += getClassName().hashCode();
        }
        _hashCode += (isCriticalError() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMessage1() != null) {
            _hashCode += getMessage1().hashCode();
        }
        if (getMethodName() != null) {
            _hashCode += getMethodName().hashCode();
        }
        if (getPreviousException() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPreviousException());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPreviousException(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTimestamp() != null) {
            _hashCode += getTimestamp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PjUnexpectedException.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://workstation.ob6.itau.com/", "PjUnexpectedException"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("className");
        elemField.setXmlName(new javax.xml.namespace.QName("", "className"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("criticalError");
        elemField.setXmlName(new javax.xml.namespace.QName("", "criticalError"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("message1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "message"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("methodName");
        elemField.setXmlName(new javax.xml.namespace.QName("", "methodName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("previousException");
        elemField.setXmlName(new javax.xml.namespace.QName("", "previousException"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://workstation.ob6.itau.com/", "stackTraceElement"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "stackTrace"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timestamp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "timestamp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://workstation.ob6.itau.com/", "timestamp"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
