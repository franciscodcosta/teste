/**
 * WorkstationPagamento.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.itau.ob6.workstation;

public interface WorkstationPagamento extends java.rmi.Remote {
    public java.lang.String registraAcao(java.lang.String json) throws java.rmi.RemoteException, com.itau.ob6.workstation.PjExpectedException, com.itau.ob6.workstation.PjUnexpectedException;
    public java.lang.String consultaPendencia(java.lang.String json) throws java.rmi.RemoteException, com.itau.ob6.workstation.PjExpectedException, com.itau.ob6.workstation.PjUnexpectedException;
}
