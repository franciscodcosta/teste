/**
 * WorkstationPagamentoService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.itau.ob6.workstation;

public interface WorkstationPagamentoService extends javax.xml.rpc.Service {
    public java.lang.String getWorkstationPagamentoPortAddress();

    public com.itau.ob6.workstation.WorkstationPagamento getWorkstationPagamentoPort() throws javax.xml.rpc.ServiceException;

    public com.itau.ob6.workstation.WorkstationPagamento getWorkstationPagamentoPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
