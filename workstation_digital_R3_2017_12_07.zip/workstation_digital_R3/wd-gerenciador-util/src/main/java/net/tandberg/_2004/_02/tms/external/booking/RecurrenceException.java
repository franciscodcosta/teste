/**
 * RecurrenceException.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class RecurrenceException  implements java.io.Serializable {
    private net.tandberg._2004._02.tms.external.booking.ExceptionType exceptionType;

    private java.lang.String recurrenceIdUTC;

    private net.tandberg._2004._02.tms.external.booking.ExceptionIdRange recurrenceIdRange;

    private int modifiedMask;

    private net.tandberg._2004._02.tms.external.booking.Conference modifiedData;

    public RecurrenceException() {
    }

    public RecurrenceException(
           net.tandberg._2004._02.tms.external.booking.ExceptionType exceptionType,
           java.lang.String recurrenceIdUTC,
           net.tandberg._2004._02.tms.external.booking.ExceptionIdRange recurrenceIdRange,
           int modifiedMask,
           net.tandberg._2004._02.tms.external.booking.Conference modifiedData) {
           this.exceptionType = exceptionType;
           this.recurrenceIdUTC = recurrenceIdUTC;
           this.recurrenceIdRange = recurrenceIdRange;
           this.modifiedMask = modifiedMask;
           this.modifiedData = modifiedData;
    }


    /**
     * Gets the exceptionType value for this RecurrenceException.
     * 
     * @return exceptionType
     */
    public net.tandberg._2004._02.tms.external.booking.ExceptionType getExceptionType() {
        return exceptionType;
    }


    /**
     * Sets the exceptionType value for this RecurrenceException.
     * 
     * @param exceptionType
     */
    public void setExceptionType(net.tandberg._2004._02.tms.external.booking.ExceptionType exceptionType) {
        this.exceptionType = exceptionType;
    }


    /**
     * Gets the recurrenceIdUTC value for this RecurrenceException.
     * 
     * @return recurrenceIdUTC
     */
    public java.lang.String getRecurrenceIdUTC() {
        return recurrenceIdUTC;
    }


    /**
     * Sets the recurrenceIdUTC value for this RecurrenceException.
     * 
     * @param recurrenceIdUTC
     */
    public void setRecurrenceIdUTC(java.lang.String recurrenceIdUTC) {
        this.recurrenceIdUTC = recurrenceIdUTC;
    }


    /**
     * Gets the recurrenceIdRange value for this RecurrenceException.
     * 
     * @return recurrenceIdRange
     */
    public net.tandberg._2004._02.tms.external.booking.ExceptionIdRange getRecurrenceIdRange() {
        return recurrenceIdRange;
    }


    /**
     * Sets the recurrenceIdRange value for this RecurrenceException.
     * 
     * @param recurrenceIdRange
     */
    public void setRecurrenceIdRange(net.tandberg._2004._02.tms.external.booking.ExceptionIdRange recurrenceIdRange) {
        this.recurrenceIdRange = recurrenceIdRange;
    }


    /**
     * Gets the modifiedMask value for this RecurrenceException.
     * 
     * @return modifiedMask
     */
    public int getModifiedMask() {
        return modifiedMask;
    }


    /**
     * Sets the modifiedMask value for this RecurrenceException.
     * 
     * @param modifiedMask
     */
    public void setModifiedMask(int modifiedMask) {
        this.modifiedMask = modifiedMask;
    }


    /**
     * Gets the modifiedData value for this RecurrenceException.
     * 
     * @return modifiedData
     */
    public net.tandberg._2004._02.tms.external.booking.Conference getModifiedData() {
        return modifiedData;
    }


    /**
     * Sets the modifiedData value for this RecurrenceException.
     * 
     * @param modifiedData
     */
    public void setModifiedData(net.tandberg._2004._02.tms.external.booking.Conference modifiedData) {
        this.modifiedData = modifiedData;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RecurrenceException)) return false;
        RecurrenceException other = (RecurrenceException) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.exceptionType==null && other.getExceptionType()==null) || 
             (this.exceptionType!=null &&
              this.exceptionType.equals(other.getExceptionType()))) &&
            ((this.recurrenceIdUTC==null && other.getRecurrenceIdUTC()==null) || 
             (this.recurrenceIdUTC!=null &&
              this.recurrenceIdUTC.equals(other.getRecurrenceIdUTC()))) &&
            ((this.recurrenceIdRange==null && other.getRecurrenceIdRange()==null) || 
             (this.recurrenceIdRange!=null &&
              this.recurrenceIdRange.equals(other.getRecurrenceIdRange()))) &&
            this.modifiedMask == other.getModifiedMask() &&
            ((this.modifiedData==null && other.getModifiedData()==null) || 
             (this.modifiedData!=null &&
              this.modifiedData.equals(other.getModifiedData())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getExceptionType() != null) {
            _hashCode += getExceptionType().hashCode();
        }
        if (getRecurrenceIdUTC() != null) {
            _hashCode += getRecurrenceIdUTC().hashCode();
        }
        if (getRecurrenceIdRange() != null) {
            _hashCode += getRecurrenceIdRange().hashCode();
        }
        _hashCode += getModifiedMask();
        if (getModifiedData() != null) {
            _hashCode += getModifiedData().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RecurrenceException.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceException"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exceptionType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExceptionType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExceptionType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrenceIdUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrenceIdRange");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceIdRange"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExceptionIdRange"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedMask");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ModifiedMask"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedData");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ModifiedData"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Conference"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
