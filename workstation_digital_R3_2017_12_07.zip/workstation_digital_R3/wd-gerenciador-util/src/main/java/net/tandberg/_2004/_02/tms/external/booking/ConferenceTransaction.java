/**
 * ConferenceTransaction.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class ConferenceTransaction  implements java.io.Serializable {
    private long transactionId;

    private java.lang.String externalSourceId;

    private java.lang.String externalPrimaryKey;

    private java.lang.String recurrenceInstanceIdUTC;

    private net.tandberg._2004._02.tms.external.booking.TransactionType transType;

    private int performedByUserId;

    private java.lang.String participantIds;

    public ConferenceTransaction() {
    }

    public ConferenceTransaction(
           long transactionId,
           java.lang.String externalSourceId,
           java.lang.String externalPrimaryKey,
           java.lang.String recurrenceInstanceIdUTC,
           net.tandberg._2004._02.tms.external.booking.TransactionType transType,
           int performedByUserId,
           java.lang.String participantIds) {
           this.transactionId = transactionId;
           this.externalSourceId = externalSourceId;
           this.externalPrimaryKey = externalPrimaryKey;
           this.recurrenceInstanceIdUTC = recurrenceInstanceIdUTC;
           this.transType = transType;
           this.performedByUserId = performedByUserId;
           this.participantIds = participantIds;
    }


    /**
     * Gets the transactionId value for this ConferenceTransaction.
     * 
     * @return transactionId
     */
    public long getTransactionId() {
        return transactionId;
    }


    /**
     * Sets the transactionId value for this ConferenceTransaction.
     * 
     * @param transactionId
     */
    public void setTransactionId(long transactionId) {
        this.transactionId = transactionId;
    }


    /**
     * Gets the externalSourceId value for this ConferenceTransaction.
     * 
     * @return externalSourceId
     */
    public java.lang.String getExternalSourceId() {
        return externalSourceId;
    }


    /**
     * Sets the externalSourceId value for this ConferenceTransaction.
     * 
     * @param externalSourceId
     */
    public void setExternalSourceId(java.lang.String externalSourceId) {
        this.externalSourceId = externalSourceId;
    }


    /**
     * Gets the externalPrimaryKey value for this ConferenceTransaction.
     * 
     * @return externalPrimaryKey
     */
    public java.lang.String getExternalPrimaryKey() {
        return externalPrimaryKey;
    }


    /**
     * Sets the externalPrimaryKey value for this ConferenceTransaction.
     * 
     * @param externalPrimaryKey
     */
    public void setExternalPrimaryKey(java.lang.String externalPrimaryKey) {
        this.externalPrimaryKey = externalPrimaryKey;
    }


    /**
     * Gets the recurrenceInstanceIdUTC value for this ConferenceTransaction.
     * 
     * @return recurrenceInstanceIdUTC
     */
    public java.lang.String getRecurrenceInstanceIdUTC() {
        return recurrenceInstanceIdUTC;
    }


    /**
     * Sets the recurrenceInstanceIdUTC value for this ConferenceTransaction.
     * 
     * @param recurrenceInstanceIdUTC
     */
    public void setRecurrenceInstanceIdUTC(java.lang.String recurrenceInstanceIdUTC) {
        this.recurrenceInstanceIdUTC = recurrenceInstanceIdUTC;
    }


    /**
     * Gets the transType value for this ConferenceTransaction.
     * 
     * @return transType
     */
    public net.tandberg._2004._02.tms.external.booking.TransactionType getTransType() {
        return transType;
    }


    /**
     * Sets the transType value for this ConferenceTransaction.
     * 
     * @param transType
     */
    public void setTransType(net.tandberg._2004._02.tms.external.booking.TransactionType transType) {
        this.transType = transType;
    }


    /**
     * Gets the performedByUserId value for this ConferenceTransaction.
     * 
     * @return performedByUserId
     */
    public int getPerformedByUserId() {
        return performedByUserId;
    }


    /**
     * Sets the performedByUserId value for this ConferenceTransaction.
     * 
     * @param performedByUserId
     */
    public void setPerformedByUserId(int performedByUserId) {
        this.performedByUserId = performedByUserId;
    }


    /**
     * Gets the participantIds value for this ConferenceTransaction.
     * 
     * @return participantIds
     */
    public java.lang.String getParticipantIds() {
        return participantIds;
    }


    /**
     * Sets the participantIds value for this ConferenceTransaction.
     * 
     * @param participantIds
     */
    public void setParticipantIds(java.lang.String participantIds) {
        this.participantIds = participantIds;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConferenceTransaction)) return false;
        ConferenceTransaction other = (ConferenceTransaction) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.transactionId == other.getTransactionId() &&
            ((this.externalSourceId==null && other.getExternalSourceId()==null) || 
             (this.externalSourceId!=null &&
              this.externalSourceId.equals(other.getExternalSourceId()))) &&
            ((this.externalPrimaryKey==null && other.getExternalPrimaryKey()==null) || 
             (this.externalPrimaryKey!=null &&
              this.externalPrimaryKey.equals(other.getExternalPrimaryKey()))) &&
            ((this.recurrenceInstanceIdUTC==null && other.getRecurrenceInstanceIdUTC()==null) || 
             (this.recurrenceInstanceIdUTC!=null &&
              this.recurrenceInstanceIdUTC.equals(other.getRecurrenceInstanceIdUTC()))) &&
            ((this.transType==null && other.getTransType()==null) || 
             (this.transType!=null &&
              this.transType.equals(other.getTransType()))) &&
            this.performedByUserId == other.getPerformedByUserId() &&
            ((this.participantIds==null && other.getParticipantIds()==null) || 
             (this.participantIds!=null &&
              this.participantIds.equals(other.getParticipantIds())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getTransactionId()).hashCode();
        if (getExternalSourceId() != null) {
            _hashCode += getExternalSourceId().hashCode();
        }
        if (getExternalPrimaryKey() != null) {
            _hashCode += getExternalPrimaryKey().hashCode();
        }
        if (getRecurrenceInstanceIdUTC() != null) {
            _hashCode += getRecurrenceInstanceIdUTC().hashCode();
        }
        if (getTransType() != null) {
            _hashCode += getTransType().hashCode();
        }
        _hashCode += getPerformedByUserId();
        if (getParticipantIds() != null) {
            _hashCode += getParticipantIds().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConferenceTransaction.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ConferenceTransaction"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transactionId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransactionId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalSourceId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalSourceId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("externalPrimaryKey");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ExternalPrimaryKey"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurrenceInstanceIdUTC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "RecurrenceInstanceIdUTC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "TransactionType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("performedByUserId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "PerformedByUserId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participantIds");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantIds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
