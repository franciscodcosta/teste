/**
 * RemoteSetupService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking.remotesetup;

public interface RemoteSetupService extends javax.xml.rpc.Service {

/**
 * Refer to the Cisco TelePresence Management Suite Extension Booking
 * API Programming Reference Guide for more information.
 */
    public java.lang.String getRemoteSetupServiceSoapAddress();

    public net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoap getRemoteSetupServiceSoap() throws javax.xml.rpc.ServiceException;

    public net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoap getRemoteSetupServiceSoap(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
