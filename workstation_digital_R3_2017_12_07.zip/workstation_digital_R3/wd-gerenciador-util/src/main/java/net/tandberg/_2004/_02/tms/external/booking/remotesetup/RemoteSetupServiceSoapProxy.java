package net.tandberg._2004._02.tms.external.booking.remotesetup;

public class RemoteSetupServiceSoapProxy implements net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoap {
  private String _endpoint = null;
  private net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoap remoteSetupServiceSoap = null;
  
  public RemoteSetupServiceSoapProxy() {
    _initRemoteSetupServiceSoapProxy();
  }
  
  public RemoteSetupServiceSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initRemoteSetupServiceSoapProxy();
  }
  
  private void _initRemoteSetupServiceSoapProxy() {
    try {
      remoteSetupServiceSoap = (new net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceLocator()).getRemoteSetupServiceSoap();
      if (remoteSetupServiceSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)remoteSetupServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)remoteSetupServiceSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (remoteSetupServiceSoap != null)
      ((javax.xml.rpc.Stub)remoteSetupServiceSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.RemoteSetupServiceSoap getRemoteSetupServiceSoap() {
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap;
  }
  
  public boolean setPrimarySystem(java.lang.String primSys) throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.setPrimarySystem(primSys);
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.User[] getUsers() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.getUsers();
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem[] getSystemsForUser() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.getSystemsForUser();
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem[] getSystems() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.getSystems();
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.TMSSystem getSystemById(long TMSSystemId) throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.getSystemById(TMSSystemId);
  }
  
  public java.lang.String generateConferenceAPIUser(java.lang.String userNameBase, java.lang.String encPassword, java.lang.String emailAddress, boolean sendNotifications) throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.generateConferenceAPIUser(userNameBase, encPassword, emailAddress, sendNotifications);
  }
  
  public void disableConferenceAPIUser(java.lang.String userName) throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    remoteSetupServiceSoap.disableConferenceAPIUser(userName);
  }
  
  public boolean isAlive() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isAlive();
  }
  
  public boolean isTMSSiteAdmin() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isTMSSiteAdmin();
  }
  
  public boolean isTMSServiceUser() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isTMSServiceUser();
  }
  
  public boolean isTMSBookOnBehalfUser() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isTMSBookOnBehalfUser();
  }
  
  public boolean isBookOnBehalfOfUser(net.tandberg._2004._02.tms.external.booking.remotesetup.User user) throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isBookOnBehalfOfUser(user);
  }
  
  public boolean isLocalAdmin() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.isLocalAdmin();
  }
  
  public net.tandberg._2004._02.tms.external.booking.remotesetup.Language[] getConferenceLanguages() throws java.rmi.RemoteException{
    if (remoteSetupServiceSoap == null)
      _initRemoteSetupServiceSoapProxy();
    return remoteSetupServiceSoap.getConferenceLanguages();
  }
  
  
}