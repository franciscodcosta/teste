/**
 * Participant.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package net.tandberg._2004._02.tms.external.booking;

public class Participant  implements java.io.Serializable {
    private int participantId;

    private java.lang.String nameOrNumber;

    private java.lang.String emailAddress;

    private net.tandberg._2004._02.tms.external.booking.ParticipantType participantCallType;

    public Participant() {
    }

    public Participant(
           int participantId,
           java.lang.String nameOrNumber,
           java.lang.String emailAddress,
           net.tandberg._2004._02.tms.external.booking.ParticipantType participantCallType) {
           this.participantId = participantId;
           this.nameOrNumber = nameOrNumber;
           this.emailAddress = emailAddress;
           this.participantCallType = participantCallType;
    }


    /**
     * Gets the participantId value for this Participant.
     * 
     * @return participantId
     */
    public int getParticipantId() {
        return participantId;
    }


    /**
     * Sets the participantId value for this Participant.
     * 
     * @param participantId
     */
    public void setParticipantId(int participantId) {
        this.participantId = participantId;
    }


    /**
     * Gets the nameOrNumber value for this Participant.
     * 
     * @return nameOrNumber
     */
    public java.lang.String getNameOrNumber() {
        return nameOrNumber;
    }


    /**
     * Sets the nameOrNumber value for this Participant.
     * 
     * @param nameOrNumber
     */
    public void setNameOrNumber(java.lang.String nameOrNumber) {
        this.nameOrNumber = nameOrNumber;
    }


    /**
     * Gets the emailAddress value for this Participant.
     * 
     * @return emailAddress
     */
    public java.lang.String getEmailAddress() {
        return emailAddress;
    }


    /**
     * Sets the emailAddress value for this Participant.
     * 
     * @param emailAddress
     */
    public void setEmailAddress(java.lang.String emailAddress) {
        this.emailAddress = emailAddress;
    }


    /**
     * Gets the participantCallType value for this Participant.
     * 
     * @return participantCallType
     */
    public net.tandberg._2004._02.tms.external.booking.ParticipantType getParticipantCallType() {
        return participantCallType;
    }


    /**
     * Sets the participantCallType value for this Participant.
     * 
     * @param participantCallType
     */
    public void setParticipantCallType(net.tandberg._2004._02.tms.external.booking.ParticipantType participantCallType) {
        this.participantCallType = participantCallType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Participant)) return false;
        Participant other = (Participant) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.participantId == other.getParticipantId() &&
            ((this.nameOrNumber==null && other.getNameOrNumber()==null) || 
             (this.nameOrNumber!=null &&
              this.nameOrNumber.equals(other.getNameOrNumber()))) &&
            ((this.emailAddress==null && other.getEmailAddress()==null) || 
             (this.emailAddress!=null &&
              this.emailAddress.equals(other.getEmailAddress()))) &&
            ((this.participantCallType==null && other.getParticipantCallType()==null) || 
             (this.participantCallType!=null &&
              this.participantCallType.equals(other.getParticipantCallType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getParticipantId();
        if (getNameOrNumber() != null) {
            _hashCode += getNameOrNumber().hashCode();
        }
        if (getEmailAddress() != null) {
            _hashCode += getEmailAddress().hashCode();
        }
        if (getParticipantCallType() != null) {
            _hashCode += getParticipantCallType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Participant.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "Participant"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participantId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nameOrNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "NameOrNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailAddress");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "EmailAddress"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("participantCallType");
        elemField.setXmlName(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantCallType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://tandberg.net/2004/02/tms/external/booking/", "ParticipantType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
