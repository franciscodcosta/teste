package br.com.itau;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.util.logging.Logger;

import javax.sql.DataSource;

import com.itau.sc.conexao.ConexaoBD;

public class SCConexaoDSHibernateDataSource implements DataSource {

	private String dataSourceName;
	private String userName;
	private String password;
	private String token;
	private String clientId;
	private String driverClassName;
	private String url;
	private boolean usePool;
	private transient ConexaoBD conexaoBD = null;	
	
	public String getDataSourceName() {
		return dataSourceName;
	}

	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getDriverClassName() {
		return driverClassName;
	}

	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public PrintWriter getLogWriter() throws SQLException {
		return null;
	}

	public int getLoginTimeout() throws SQLException {
		return 0;
	}

	public Logger getParentLogger() throws SQLFeatureNotSupportedException {
		return null;
	}

	public void setLogWriter(PrintWriter arg0) throws SQLException {

	}

	public void setLoginTimeout(int arg0) throws SQLException {
			
	}

	public boolean isWrapperFor(Class<?> arg0) throws SQLException {
		return false;
	}

	public <T> T unwrap(Class<T> arg0) throws SQLException {
		return null;
	}

	public Connection getConnection() throws SQLException {

		try {

			if (conexaoBD == null) {
			
			    usePool = (url == null) || "".equals(url);

				conexaoBD = new ConexaoBD(dataSourceName, driverClassName, url, userName, password, token, usePool);
			    conexaoBD.setClientIdentifier(clientId);
			}
			
			return conexaoBD.getConnection();
				
		} 
		catch (SQLException e) {
			throw e;
		} 
		catch (Exception e) {
			throw new SQLException(e.getMessage());
		}	
	}

	public Connection getConnection(String arg0, String arg1) throws SQLException {
		return null;
	}
}
